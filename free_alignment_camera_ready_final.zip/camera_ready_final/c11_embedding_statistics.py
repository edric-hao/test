"""c11_embedding_statistics.py -- per-dimension feature statistics of the REAL untrained models and of the NumPy sweep networks (base setting).   (reviewer 7BsF: "validate on feature statistics")
c1 and c6 compare CKA, kNN, Procrustes and the spectrum; this adds what they do not: the raw (pre-PCA) embedding statistics, per model and per initialisation, on the sweep's complexes.
Per embedding (width 64 for both, so dimensions are comparable): per-dimension mean and SD (median, min, max, coefficient of variation across dimensions), the offset |mean|/SD,
share of near-constant dimensions, per-complex L2 norm (mean, SD, CV), mean |skewness| and excess kurtosis of the dimensions, and the correlation between dimensions (mean |r|).
Scale itself differs by construction (the NumPy networks have no biases and a scaled initialisation), so each statistic is also given scale-free (CV, offset, correlation).
Also the trained primary models (reference protocol complexes) for context.
Output: c11_embedding_statistics.tsv (mean and SD over initialisations), c11_per_embedding.tsv"""
from cr_common import *
import randnets as rn, sweeplib as sl
from scipy.stats import skew, kurtosis

plan = fc.load_plan(); core = fc.core_ids(plan); ids = sl.sweep_ids(plan, core); sw = plan["sweep"]; S = sw["n_seeds"]
tags = fc.UNTRAINED_TAGS[:S]

def stats(E):
    E = np.asarray(E, np.float64); sd = E.std(0); mu = E.mean(0); live = sd > 1e-8 * max(sd.max(), 1e-300)
    nrm = np.linalg.norm(E, axis=1)
    Z = (E[:, live] - mu[live]) / sd[live]; C = np.corrcoef(Z.T) if live.sum() > 1 else np.ones((1, 1))
    off = np.abs(mu[live]) / sd[live]
    return dict(width=E.shape[1], dim_sd_median=float(np.median(sd)), dim_sd_min=float(sd.min()), dim_sd_max=float(sd.max()), dim_sd_cv=float(sd.std() / max(sd.mean(), 1e-300)),
                dim_mean_abs_median=float(np.median(np.abs(mu))), dim_offset_median=float(np.median(off)) if live.any() else float("nan"), dim_offset_max=float(off.max()) if live.any() else float("nan"),
                share_near_constant=float(1 - live.mean()), norm_mean=float(nrm.mean()), norm_cv=float(nrm.std() / max(nrm.mean(), 1e-300)),
                abs_skew_mean=float(np.nanmean(np.abs(skew(E[:, live], axis=0)))), excess_kurtosis_mean=float(np.nanmean(kurtosis(E[:, live], axis=0))),
                mean_abs_dim_corr=float(np.abs(C[np.triu_indices_from(C, 1)]).mean()) if live.sum() > 1 else float("nan"))

rows = []
for a in rn.ARCHS:
    for i, t in enumerate(tags): rows.append(dict(source="real_untrained", arch=a, init=t, **stats(raw_test(fc.EMB, a, t, ids))))
base = dict(sw["base"]); G = {}
def numpy_emb(arch, seed):
    p = sl.emb_path(plan, base, arch, seed)
    if p.exists(): return np.load(p)
    if not G:
        from build_graphs import Graphs
        g = Graphs(); g.rows(ids); G.update(g=g, items=sl.load_items(g, ids))
    return sl.get_embedding(plan, base, arch, seed, G["items"], G["g"].n_elem)
for a in rn.ARCHS:
    for s in range(S): rows.append(dict(source="numpy_base_setting", arch=a, init=f"seed{s}", **stats(numpy_emb(a, s))))
for a in rn.ARCHS:      # trained reference models, for context (not a validation target)
    try: rows.append(dict(source="real_trained_primary", arch=a, init="primary", **stats(raw_test(fc.EMB, a, "primary", ids))))
    except Exception as e: log(f"trained {a}: skipped ({e})")
P = pd.DataFrame(rows); write_tsv(P, "c11_per_embedding.tsv")
num = [c for c in P.columns if c not in ("source", "arch", "init")]
G_ = P.groupby(["source", "arch"])[num].agg(["mean", "std"]); G_.columns = [f"{a}_{b}" for a, b in G_.columns]
write_tsv(G_.reset_index(), "c11_embedding_statistics.tsv")
keep = ["dim_sd_median", "dim_sd_cv", "dim_offset_median", "share_near_constant", "norm_cv", "abs_skew_mean", "excess_kurtosis_mean", "mean_abs_dim_corr"]
print(P.groupby(["arch", "source"])[keep].mean().round(3).to_string())
