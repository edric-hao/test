"""c5_network_count.py -- how many distinct networks does a sweep grid contain?  (answers the 260 vs 270 question; no GPU, no data needed)
EGNN ignores n_rbf, so EGNN networks of settings that differ only in n_rbf share one cached embedding. This script applies the
cache-key rule of findings/randnets.py (cfg_id with n_rbf dropped for egnn) to every settings table it is given.
Usage: python3 camera_ready/c5_network_count.py [settings.tsv ...]   (default: findings_out/res_sweep_configs.tsv and any res_r*_settings.tsv found)"""
import os, sys
from cr_common import *
import randnets as rn

def count(df, n_seeds=5):
    cfgs = [{k: r[k] for k in rn.CFG_KEYS} for _, r in df.iterrows()]
    for c in cfgs:
        for k in ("width", "depth", "n_rbf"): c[k] = int(c[k])
        for k in ("radius", "gain"): c[k] = float(c[k])
    nominal = len(cfgs) * 2 * n_seeds
    emb = {(a, rn.cfg_id(c, a), s) for c in cfgs for a in rn.ARCHS for s in range(n_seeds)}
    draws = {(a, c["width"], c["depth"], s) for c in cfgs for a in rn.ARCHS for s in range(n_seeds)}   # weights keyed by (arch, width, depth, seed)
    egnn_shared = sum(1 for c in cfgs for s in range(n_seeds)) - len({(rn.cfg_id(c, "egnn"), s) for c in cfgs for s in range(n_seeds)})
    return dict(n_settings=len(cfgs), nominal_networks=nominal, distinct_embeddings=len(emb), egnn_duplicates_from_n_rbf=egnn_shared, distinct_weight_draws=len(draws))

if __name__ == "__main__":
    paths = [Path(a) for a in sys.argv[1:]]
    if not paths:
        paths = [fc.OUT / "res_sweep_configs.tsv"] + sorted(fc.OUT / n for n in os.listdir(fc.OUT) if n.startswith("res_r") and n.endswith("_settings.tsv"))
    rows = []
    for p in paths:
        if not p.exists(): print("skip (missing):", p); continue
        d = pd.read_csv(p, sep="\t")
        if not set(rn.CFG_KEYS) <= set(d.columns): print("skip (no config columns):", p); continue
        rows.append(dict(file=str(p), **count(d)))
    R = pd.DataFrame(rows); print(R.T.to_string()); write_tsv(R, "c5_network_count.tsv")
