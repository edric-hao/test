#!/bin/bash
# run_final.sh -- the last round, with the settings of findings/plan/findings_plan.yaml (1000 cluster-bootstrap draws for the real-model analyses).
#  (1) extra training seeds for the max readout (GPU, started in the background, resumable)
#  (2) c11 per-dimension embedding statistics   (3) every interval-reporting analysis: c3 c7b c8 c9 c10 t2 t4 t5 t6   (4) t7 seed variability per readout, once the GPU job is done
# The folder camera_ready_final/ is self-contained and writes its tables to camera_ready_out_final/, so the tables of earlier runs (camera_ready_out/) stay as they are.
# It WAITS for run_all.sh and run_extras.sh to finish, so it can be started right away (from the folder that contains camera_ready_final/):
#     nohup bash camera_ready_final/run_final.sh > run_final.log 2>&1 &
# Options (environment variables before "bash"): CR_NBOOT=1000  CR_NPERM=1000  EXTRA_SEEDS=2  INCLUDE_GNINA=0 (skips the voxel model in c3, c8, c9)  RUN_TRAIN=0  RUN_WIDTHS="128" (empty = none)  PROJECT_ROOT=...
HERE="$(cd "$(dirname "$0")" && pwd)"; cd "$HERE" || exit 1
export CR_OUT="camera_ready_out_final" CR_NBOOT="${CR_NBOOT:-1000}" CR_NPERM="${CR_NPERM:-1000}"
EXTRA_SEEDS="${EXTRA_SEEDS:-2}"
EXTRA_ARMS=$(python3 -c "print(','.join('extra%d' % i for i in range(1, int('$EXTRA_SEEDS') + 1)))")
mkdir -p "$HERE/logs_tmp"
while pgrep -f "run_all.sh|run_extras.sh" > /dev/null; do sleep 60; done
echo "earlier runs have finished; starting the final round $(date +%H:%M:%S)  (CR_NBOOT=$CR_NBOOT CR_NPERM=$CR_NPERM)"
run() { name="$1"; shift; echo "=== $(date +%H:%M:%S) START $name"; "$@" > "$HERE/logs_tmp/$name.log" 2>&1; rc=$?; echo "=== $(date +%H:%M:%S) END   $name  exit=$rc"; return $rc; }
run preflight python3 preflight.py || { echo "preflight failed:"; tail -30 "$HERE/logs_tmp/preflight.log"; exit 1; }

T1PID=""
if [ "${RUN_TRAIN:-1}" = "1" ]; then
  run t1_train_max_extra_seeds python3 t1_train_maxreadout.py --readouts max --arms "$EXTRA_ARMS" &
  T1PID=$!
fi

run c11_embedding_statistics    python3 c11_embedding_statistics.py
run c3_trained_components       python3 c3_trained_components.py
run c7b_composition_real        python3 c7b_composition_real.py
run c8_alternative_nulls        python3 c8_alternative_nulls.py
run c10_pooled_feature_baseline python3 c10_pooled_feature_baseline.py
if [ "${INCLUDE_GNINA:-1}" = "1" ]; then run c9_pca_truncation python3 c9_pca_truncation.py; fi
EXTRA_DIRS=""; for H in ${RUN_WIDTHS-128}; do EXTRA_DIRS="$EXTRA_DIRS,embeddings_readout_mean_h$H"; done
EXTRA_T2_DIRS="${EXTRA_DIRS#,}" run t2_readout_alignment python3 t2_readout_alignment.py
run t4_targets_and_seeds        python3 t4_targets_and_seeds.py
run t5_null_targets_vs_init     python3 t5_null_targets_vs_init.py
run t6_no_message_passing       python3 t6_no_message_passing.py

if [ -n "$T1PID" ]; then wait "$T1PID"; echo "max-readout extra seeds finished (exit=$?)"; fi
run t7_seeds_by_readout         python3 t7_seeds_by_readout.py

python3 - <<'PY'
import os, sys, zipfile
sys.path.insert(0, ".")
from cr_common import ROOT, OUT
z = ROOT / "camera_ready_results_final.zip"
with zipfile.ZipFile(z, "w", zipfile.ZIP_DEFLATED) as f:
    for dp, _, fn in os.walk(OUT):
        for n in sorted(fn): f.write(os.path.join(dp, n), OUT.name + "/" + os.path.relpath(os.path.join(dp, n), OUT))
    for n in sorted(os.listdir("logs_tmp")): f.write(os.path.join("logs_tmp", n), "logs_tmp_final/" + n)
print("results zip:", z, round(z.stat().st_size / 1e6, 2), "MB")
PY
echo "FINAL ROUND FINISHED $(date +%H:%M:%S)"
