"""c8_alternative_nulls.py -- alternative references for a trained pair, computed from the existing embeddings.   (reviewer r29H)
(a) trained model vs its OWN initialisation (the arm 'untrained' shares the initial weights of 'primary'), and trained model vs the untrained network of the other architecture;
(b) permutation nulls for the trained pair and the untrained floor: plain row permutation, and row permutation within deciles of complex size (keeps whatever the pair shares through size);
Reference protocol (train-fit PCA-64, core test set). Env: CR_NPERM (default 1000), INCLUDE_GNINA=0 skips the voxel model.   Output: c8_alternative_nulls.tsv, c8_permutation_nulls.tsv"""
import os
from cr_common import *

plan = fc.load_plan(); core = fc.core_ids(plan); W = boot_weights(core, plan, seed_off=55)
models = [m for m in fc.MODELS if m != "gnina" or os.environ.get("INCLUDE_GNINA", "1") == "1"]
pairs = [p for p in fc.PAIRS if p[0] in models and p[1] in models]
R = {(m, t): ref_rep(fc.EMB, m, t, core, plan["pca_dim"]) for m in models for t in ["primary", "anchor", "untrained"]}
rows = []
def add(name, a, b, note=""):
    lo, hi = boot_ci([(a, b)], W); rows.append(dict(reference=name, cka=al.cka_feature(a, b), ci_lo=lo, ci_hi=hi, note=note))
for m in models:
    add(f"{m}: trained vs own initialisation", R[(m, "primary")], R[(m, "untrained")], "primary vs untrained (same seed, same initial weights)")
    add(f"{m}: anchor vs own initialisation", R[(m, "anchor")], R[(m, "untrained")], "anchor seed differs from the initialisation seed")
for a_, b_ in pairs:
    add(f"{a_} trained vs {b_} untrained", R[(a_, "primary")], R[(b_, "untrained")]); add(f"{b_} trained vs {a_} untrained", R[(b_, "primary")], R[(a_, "untrained")])
    add(f"{a_} x {b_}: trained pair", R[(a_, "primary")], R[(b_, "primary")]); add(f"{a_} x {b_}: untrained pair (init 1)", R[(a_, "untrained")], R[(b_, "untrained")])
A = pd.DataFrame(rows); write_tsv(A, "c8_alternative_nulls.tsv"); print(A.round(3).to_string())

# ---- permutation nulls
cov = pd.read_csv(ROOT / plan["covariates_file"], sep="\t", index_col=0); cov.index = cov.index.astype(str).str.lower()
size = cov.loc[core, "complex_atom_count"].values.astype(float); strata = pd.qcut(size, 10, labels=False, duplicates="drop")
n_perm = int(os.environ.get("CR_NPERM", "1000")); rng = np.random.default_rng(plan["seed"] + 5)
def perm(kind):
    if kind == "plain": return rng.permutation(len(core))
    p = np.arange(len(core))
    for s in np.unique(strata): ix = np.where(strata == s)[0]; p[ix] = rng.permutation(ix)
    return p
out = []
for a_, b_ in pairs:
    for state, (ta, tb) in (("trained", ("primary", "primary")), ("untrained_init1", ("untrained", "untrained"))):
        XA, XB = R[(a_, ta)], R[(b_, tb)]; obs = al.cka_feature(XA, XB)
        for kind in ("plain", "size_stratified"):
            null = np.array([al.cka_feature(XA, XB[perm(kind)]) for _ in range(n_perm)])
            out.append(dict(pair=f"{a_}_x_{b_}", state=state, null=kind, observed=obs, null_mean=float(null.mean()), null_p95=float(np.percentile(null, 95)), null_max=float(null.max()),
                            p_value=float((1 + (null >= obs).sum()) / (n_perm + 1)), n_perm=n_perm))
        log("permutation null", a_, b_, state)
P = pd.DataFrame(out); write_tsv(P, "c8_permutation_nulls.tsv"); print(P.round(3).to_string())
