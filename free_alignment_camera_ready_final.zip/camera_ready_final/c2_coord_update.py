"""c2_coord_update.py -- does the EGNN coordinate update matter in the NumPy random networks?  (all four reviewers)
For each test setting and seed the SAME random weights are run twice: with the coordinate update (standard) and with coordinates held at their input values.
Reports (i) how far atoms move per layer (A) and how much the squared edge distances change, (ii) CKA / kNN overlap between the two variants,
(iii) cross-architecture matched CKA against the Distance-GNN of the same seed for both variants.
Implementation note: in findings/randnets.py the edge set is fixed from the INPUT coordinates, and the update affects the node features only through the
squared-distance edge feature of LATER layers. With depth 1 the update has no effect by construction (kept as a built-in control).
A self-test first checks that the standard variant reproduces findings/randnets.forward exactly.
Output: camera_ready_out/c2_coord_update.tsv, c2_coord_displacement.tsv"""
import os
from scipy import sparse
from joblib import Parallel, delayed
from cr_common import *
import randnets as rn, sweeplib as sl
from build_graphs import Graphs

plan = fc.load_plan(); core = fc.core_ids(plan); ids = sl.sweep_ids(plan, core); sw = plan["sweep"]; S = int(os.environ.get("C2_SEEDS", sw["n_seeds"])); kp, kn = sw["pca_k"], sw["knn_k"]
g = Graphs(); g.rows(ids); items = sl.load_items(g, ids); n_elem = g.n_elem
base = dict(sw["base"])
SETTINGS = [("base", {}), ("max_readout", dict(readout="max")), ("sum_readout", dict(readout="sum")), ("gain2", dict(gain=2.0)),
            ("depth6", dict(depth=6)), ("depth1_control", dict(depth=1))]
cfgs = {name: {**base, **o} for name, o in SETTINGS}

def egnn_forward(P, cfg, B, update=True, track=None):
    dtype = np.float32; A = B.xyz.shape[0]; E = len(B.src); radius = cfg["radius"]
    h = B.feat.astype(dtype) @ P["W_in"]; x = B.xyz.copy(); x0 = B.xyz
    Sm = sparse.csr_matrix((np.ones(E, dtype), (B.dst, np.arange(E))), shape=(A, E))
    deg = np.maximum(np.asarray(Sm.sum(1)).ravel(), 1.0).astype(dtype)
    Sd = sparse.csr_matrix((np.ones(E), (B.dst, np.arange(E))), shape=(A, E))
    d2_0 = ((x0[B.dst] - x0[B.src]) ** 2).sum(1)
    for li, Lp in enumerate(P["layers"]):
        diff = x[B.dst] - x[B.src]; ef = ((diff ** 2).sum(1) / radius ** 2)[:, None].astype(dtype)
        pre = (h @ Lp["Wi"])[B.dst] + (h @ Lp["Wj"])[B.src] + ef @ Lp["We"]
        m = rn.silu(rn.silu(pre) @ Lp["W2"])
        agg = Sm @ m
        if cfg["aggr"] == "mean": agg = agg / deg[:, None]
        h = h + rn.silu(np.concatenate([h, agg], 1) @ Lp["Wh1"]) @ Lp["Wh2"]
        w = np.tanh(m @ Lp["wx"]).astype(np.float64)
        step = (Sd @ (diff * w[:, None])) / deg.astype(np.float64)[:, None]
        if update: x = x + step
        if track is not None:
            d2 = ((x[B.dst] - x[B.src]) ** 2).sum(1)
            track.append(dict(layer=li, n_atoms=A, n_edges=E, step_sum=float(np.linalg.norm(step, axis=1).sum()), cum_sum=float(np.linalg.norm(x - x0, axis=1).sum()),
                              rel_d2_sum=float((np.abs(d2 - d2_0) / np.maximum(d2_0, 1e-9)).sum())))
    off = B.off[:-1]
    if cfg["readout"] == "max": out = np.maximum.reduceat(h, off, axis=0)
    else:
        out = np.add.reduceat(h, off, axis=0)
        if cfg["readout"] == "mean": out = out / np.diff(B.off)[:, None].astype(dtype)
    return out.astype(np.float64)

def embed(cfg, seed, update, track=False):
    P = rn.make_params(cfg, "egnn", seed, n_elem + 1, plan["seed"], np.float32)
    out = np.zeros((len(items), cfg["width"])); tr = [] if track else None
    with np.errstate(over="ignore", invalid="ignore"):
        for a, b, B in rn.batches(items, cfg["radius"], n_elem):
            out[a:b] = egnn_forward(P, cfg, B, update, tr)
    return out, tr

# ---- self-test: the standard variant must equal findings/randnets.forward
cfg0 = cfgs["base"]; sub = items[:40]; P0 = rn.make_params(cfg0, "egnn", 0, n_elem + 1, plan["seed"], np.float32)
ref = rn.embed_all(sub, cfg0, "egnn", 0, n_elem, plan["seed"], np.float32)
mine = np.zeros_like(ref)
for a, b, B in rn.batches(sub, cfg0["radius"], n_elem): mine[a:b] = egnn_forward(P0, cfg0, B, True, None)
assert np.allclose(ref, mine, rtol=1e-4, atol=1e-5), f"self-test failed: max |diff| {np.abs(ref - mine).max():.3e}"
log("self-test passed: standard variant == findings/randnets.forward")

jobs = [(name, s, upd) for name in cfgs for s in range(S) for upd in (True, False)]
res = Parallel(n_jobs=sw["n_jobs"], verbose=5)(delayed(embed)(cfgs[n], s, u, track=(u and s == 0)) for n, s, u in jobs)
EMB_ = {(n, s, u): r[0] for (n, s, u), r in zip(jobs, res)}
TR = {n: r[1] for (n, s, u), r in zip(jobs, res) if r[1] is not None}

disp = []
for n, tr in TR.items():
    for li in sorted({t["layer"] for t in tr}):
        T = [t for t in tr if t["layer"] == li]; na = sum(t["n_atoms"] for t in T); ne = sum(t["n_edges"] for t in T)
        disp.append(dict(setting=n, layer=li + 1, mean_step_A=sum(t["step_sum"] for t in T) / na, mean_cum_displacement_A=sum(t["cum_sum"] for t in T) / na,
                         mean_rel_change_d2=sum(t["rel_d2_sum"] for t in T) / ne))
write_tsv(pd.DataFrame(disp), "c2_coord_displacement.tsv")

rows = []
for n in cfgs:
    cfg = cfgs[n]
    Rs = {u: [sl.Rep(EMB_[(n, s, u)], kp, kn) for s in range(S)] for u in (True, False)}
    D = [sl.Rep(sl.get_embedding(plan, cfg, "distance_gnn", s, items, n_elem), kp, kn) for s in range(S)]
    for s in range(S):
        a = sl.pair_metrics(Rs[True][s], Rs[False][s], kn)
        cu = sl.pair_metrics(Rs[True][s], D[s], kn); cf = sl.pair_metrics(Rs[False][s], D[s], kn)
        rel = float(np.linalg.norm(EMB_[(n, s, True)] - EMB_[(n, s, False)]) / max(np.linalg.norm(EMB_[(n, s, True)] - EMB_[(n, s, True)].mean(0)), 1e-12))
        rows.append(dict(setting=n, seed=s, cka_update_vs_frozen=a["cka"], knn_update_vs_frozen=a["knn"], rel_embedding_change=rel,
                         cross_cka_update=cu["cka"], cross_cka_frozen=cf["cka"], cross_knn_update=cu["knn"], cross_knn_frozen=cf["knn"]))
R = pd.DataFrame(rows); write_tsv(R, "c2_coord_update.tsv")
print(R.groupby("setting").mean(numeric_only=True).drop(columns="seed").round(4).to_string()); print(pd.DataFrame(disp).round(4).to_string())
