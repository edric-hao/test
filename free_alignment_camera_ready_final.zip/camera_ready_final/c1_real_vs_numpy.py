"""c1_real_vs_numpy.py -- do the NumPy sweep networks reproduce the REAL untrained reference models?  (reviewers eCg1, 7BsF)
Same complexes (the sweep's 1,200), same preprocessing (sweep protocol: centre, PCA-64 on the evaluation set if width > 64, centred-cosine kNN k=10).
Reports for real untrained EGNN / Distance-GNN (5 inits each) and for the NumPy base setting (5 seeds each): matched and all-pairs cross-architecture
CKA, mutual kNN, Procrustes angle, within-architecture CKA, and the embedding spectrum (participation ratio, leading-component share).
Also gives the real models under the reference protocol (train-fit PCA-64) on the full core set, which matches the paper's spectrum table.
Output: camera_ready_out/c1_real_vs_numpy.tsv"""
from cr_common import *
import randnets as rn, sweeplib as sl

plan = fc.load_plan(); core = fc.core_ids(plan); ids = sl.sweep_ids(plan, core); sw = plan["sweep"]; S = sw["n_seeds"]; kp, kn = sw["pca_k"], sw["knn_k"]
log(f"core {len(core)} | sweep ids {len(ids)}")
rows = []
add = lambda source, scope, metric, vals: add_row(rows, source, scope, metric, vals)
summarise = lambda source, R: summarise_sets(rows, source, R, S, kn)

# ---- real untrained, sweep protocol on the sweep ids
tags = fc.UNTRAINED_TAGS[:S]
real = {a: [sl.Rep(raw_test(fc.EMB, a, t, ids), kp, kn) for t in tags] for a in rn.ARCHS}
summarise("real_untrained_sweep_protocol", real)

# ---- real untrained, reference protocol (train-fit PCA-64) on the full core set and on the sweep subset
idx = [core.index(p) for p in ids]
refc = {a: [ref_rep(fc.EMB, a, t, core, plan["pca_dim"]) for t in tags] for a in rn.ARCHS}
for a in rn.ARCHS:
    sp = [spectrum(X) for X in refc[a]]
    for k in ("pr", "top1", "top3"): add("real_untrained_reference_protocol_full_core", f"spectrum_{a}", k, [s[k] for s in sp])
add("real_untrained_reference_protocol_full_core", "cross_matched", "cka", [al.cka_feature(refc["egnn"][i], refc["distance_gnn"][i]) for i in range(S)])
refs = {a: [sl.Rep(X[idx], kp, kn) for X in refc[a]] for a in rn.ARCHS}
summarise("real_untrained_reference_protocol_sweep_subset", refs)

# ---- NumPy sweep base setting
base = dict(sw["base"]); G = {}
def numpy_emb(arch, seed):
    p = sl.emb_path(plan, base, arch, seed)
    if p.exists(): return np.load(p)
    if not G:
        from build_graphs import Graphs
        g = Graphs(); g.rows(ids); G.update(g=g, items=sl.load_items(g, ids))
    return sl.get_embedding(plan, base, arch, seed, G["items"], G["g"].n_elem)
npy = {a: [sl.Rep(numpy_emb(a, s), kp, kn) for s in range(S)] for a in rn.ARCHS}
summarise("numpy_base_setting", npy)

R = pd.DataFrame(rows); write_tsv(R, "c1_real_vs_numpy.tsv")
P = R.pivot_table(index=["scope", "metric"], columns="source", values="mean")
print(P.round(3).to_string())
