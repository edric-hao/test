"""c7a_composition_sweep.py -- does the untrained floor of the NumPy sweep survive residualising on the full composition of the complex?   (reviewer r29H)
Covariates (cr_features): size2 = (atom count, ligand atom count) as in the paper; comp = size2 + element counts of pocket and ligand; full = comp + degree histogram + edge-distance histogram (5 A).
All settings in findings_out/res_r1_settings.tsv (else res_sweep_configs.tsv): untrained cross-architecture matched CKA / kNN for raw embeddings and after OLS residualisation within the 1,200 sweep complexes,
and the share of embedding variance the covariates absorb. Needs no bootstrap. Missing sweep embeddings are computed in parallel and cached in findings_out/sweep_cache.
Env: C7_MAX_SETTINGS=N limits the run to the first N settings.   Output: c7_composition_sweep.tsv"""
import os
from cr_common import *
import randnets as rn, sweeplib as sl
from build_graphs import Graphs
from cr_features import features, design, VARIANTS
from joblib import Parallel, delayed

plan = fc.load_plan(); core = fc.core_ids(plan); sw = plan["sweep"]; S = sw["n_seeds"]; kp, kn = sw["pca_k"], sw["knn_k"]
ids = sl.sweep_ids(plan, core); g = Graphs(); g.rows(ids); items = sl.load_items(g, ids)
FA = [features(el, lig.astype(int), xyz, g.n_elem + 1) for xyz, el, lig in items]
ZA = {v: design(FA, n) for v, n in VARIANTS.items()}
cf = next((p_ for p_ in (fc.OUT / "res_r1_settings.tsv", fc.OUT / "res_sweep_configs.tsv") if p_.exists()), None)
log("settings table:", cf)
cfgs = [dict(r) for _, r in pd.read_csv(cf, sep="\t").iterrows()] if cf else [dict(plan["sweep"]["base"])]
cfgs = [{k: (int(r[k]) if k in ("width", "depth", "n_rbf") else float(r[k]) if k in ("radius", "gain") else r[k]) for k in rn.CFG_KEYS} for r in cfgs]
cfgs = cfgs[:int(os.environ.get("C7_MAX_SETTINGS", len(cfgs)))]
todo = {}      # only the sweep embeddings that are not cached yet
for cfg in cfgs:
    for a_ in rn.ARCHS:
        for s_ in range(S):
            p_ = sl.emb_path(plan, cfg, a_, s_)
            if not p_.exists(): todo[p_] = (cfg, a_, s_)
log(f"{len(todo)} sweep embeddings missing from the cache" + (" -> computing" if todo else ""))
Parallel(n_jobs=sw["n_jobs"], verbose=5)(delayed(sl.get_embedding)(plan, c_, a_, s_, items, g.n_elem) for c_, a_, s_ in todo.values())
rows = []
for cfg in cfgs:
    Es = {a: [sl.get_embedding(plan, cfg, a, s, items, g.n_elem) for s in range(S)] for a in rn.ARCHS}
    row = dict(cfg_id=rn.cfg_id(cfg, "distance_gnn"), **{k: cfg[k] for k in rn.CFG_KEYS})
    for v in ["raw"] + list(VARIANTS):
        Ev = Es if v == "raw" else {a: [al.ols_resid(E, ZA[v]) for E in Es[a]] for a in rn.ARCHS}
        reps = {a: [sl.Rep(E, kp, kn) for E in Ev[a]] for a in rn.ARCHS}
        pm = [sl.pair_metrics(reps["egnn"][i], reps["distance_gnn"][i], kn) for i in range(S)]
        row[f"cka_{v}"] = float(np.mean([p["cka"] for p in pm])); row[f"knn_{v}"] = float(np.mean([p["knn"] for p in pm]))
        if v != "raw": row[f"var_explained_{v}"] = float(np.mean([1 - (Ev[a][i] ** 2).sum() / ((Es[a][i] - Es[a][i].mean(0)) ** 2).sum() for a in rn.ARCHS for i in range(S)]))
    rows.append(row); log(f"{row['cfg_id']}: raw {row['cka_raw']:.3f} size2 {row['cka_size2']:.3f} comp {row['cka_comp']:.3f} full {row['cka_full']:.3f}")
A = pd.DataFrame(rows); write_tsv(A, "c7_composition_sweep.tsv")
print(A[["cfg_id", "cka_raw", "cka_size2", "cka_comp", "cka_full", "var_explained_full"]].round(3).to_string())
print("mean change in floor, full vs raw:", round((A.cka_full - A.cka_raw).mean(), 4), "| min full:", round(A.cka_full.min(), 3))
