"""t4_targets_and_seeds.py -- trained pairs under null training targets.   (reviewers r29H, WKPN)
EGNN x Distance-GNN trained on (i) the real affinity, (ii) affinity shuffled within each split, (iii) the OLS size-only prediction. CKA of the pair, same-architecture ceilings
        (primary x anchor), the cross-target CKA with the real-affinity models, test r against the real affinity and on the trained target, all against the untrained floor of the reference models (mean readout).
        Needs t1 runs with --target shuffled / sizeonly (folders data/embeddings_readout_mean_shuffled, _sizeonly).
Seed variability over extra training seeds is in t7_seeds_by_readout.py.   Output: t4_targets.tsv"""
import json
from cr_common import *

plan = fc.load_plan(); core = fc.core_ids(plan); W = boot_weights(core, plan, seed_off=66); A, B = "egnn", "distance_gnn"
floor_pairs = [(ref_rep(fc.EMB, A, t, core, plan["pca_dim"]), ref_rep(fc.EMB, B, t, core, plan["pca_dim"])) for t in fc.UNTRAINED_TAGS]
floor = mean_cka(floor_pairs); dfloor = np.array([mean_cka(floor_pairs, w) for w in W])
y = fc.split_df(plan).loc[core, plan["affinity_column"]].values.astype(float)

def test_r_real(d, m):
    """Test r of the model's predictions against the REAL affinity (for a null-target model this shows what the trained target leaves of the real signal)."""
    f = Path(d) / f"{m}_primary_test_pred.npy"
    if not f.exists(): return float("nan")
    ids = [s.lower() for s in (Path(d) / f"{m}_primary_test_ids.txt").read_text().split()]
    return float(np.corrcoef(al.strict_subset(np.load(f).ravel()[:, None], ids, core, "pred")[:, 0], y)[0, 1])
def test_r_target(m, suf):
    """Test r on the target the model was trained on, from the training log of t1 (the original reference models have no such log: NaN)."""
    f = LOGDIR / f"train_{m}_mean_primary{suf}.json"
    return float(json.loads(f.read_text())["test"]["pearson_r"]) if f.exists() else float("nan")

dirs = {"real_affinity": (fc.EMB, ""), "shuffled_affinity": (ROOT / "data" / "embeddings_readout_mean_shuffled", "_shuffled"), "size_only_target": (ROOT / "data" / "embeddings_readout_mean_sizeonly", "_sizeonly")}
rep = {}
for name, (d, suf) in dirs.items():
    try: rep[name] = {(m, t): ref_rep(d, m, t, core, plan["pca_dim"]) for m in (A, B) for t in ("primary", "anchor")}
    except FileNotFoundError as e: log(f"target {name}: skipped ({e})")
rows = []
for name, R in rep.items():
    tr, ca, cb = [(R[(A, "primary")], R[(B, "primary")])], [(R[(A, "primary")], R[(A, "anchor")])], [(R[(B, "primary")], R[(B, "anchor")])]
    dtr = np.array([mean_cka(tr, w) for w in W])
    row = dict(target=name, trained_pair_cka=mean_cka(tr), lo=fc.ci(dtr)[0], hi=fc.ci(dtr)[1], floor_cka=floor, trained_minus_floor=mean_cka(tr) - floor,
               tmf_lo=fc.ci(dtr - dfloor)[0], tmf_hi=fc.ci(dtr - dfloor)[1], ceiling_egnn=mean_cka(ca), ceiling_distance_gnn=mean_cka(cb),
               test_r_real_egnn=test_r_real(dirs[name][0], A), test_r_real_distance_gnn=test_r_real(dirs[name][0], B), test_r_target_egnn=test_r_target(A, dirs[name][1]), test_r_target_distance_gnn=test_r_target(B, dirs[name][1]), pr_egnn=spectrum(R[(A, "primary")])["pr"], top1_egnn=spectrum(R[(A, "primary")])["top1"])
    if name != "real_affinity" and "real_affinity" in rep:
        r0 = rep["real_affinity"]; row["cka_egnn_vs_real_trained_egnn"] = al.cka_feature(R[(A, "primary")], r0[(A, "primary")]); row["cka_distance_gnn_vs_real_trained_distance_gnn"] = al.cka_feature(R[(B, "primary")], r0[(B, "primary")])
    rows.append(row); log(f"target {name}: pair CKA {row['trained_pair_cka']:.3f} (floor {floor:.3f})")
T = pd.DataFrame(rows); write_tsv(T, "t4_targets.tsv"); print(T.T.round(3).to_string())
