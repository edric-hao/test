"""c10_pooled_feature_baseline.py -- how much of each representation is simply a function of pooled input features?   (reviewer eCg1: "a simple control based on pooled input features")
Feature sets of cr_features, as in c7 (size2 = atom and ligand-atom count; comp = + element counts of pocket and ligand; full = + degree and edge-distance histograms), z-scored, no message passing involved.
Reports debiased CKA between each embedding and the feature matrix: NumPy sweep base setting (untrained, 5 seeds per architecture, sweep complexes) and the real models
(trained primary and untrained inits, reference protocol, core test set, features from data/graph_cache). Output: c10_pooled_feature_baseline.tsv"""
from cr_common import *
import randnets as rn, sweeplib as sl
from build_graphs import Graphs
from cr_features import features, zmatrix, VARIANTS, graph_arrays

plan = fc.load_plan(); core = fc.core_ids(plan); sw = plan["sweep"]; S = sw["n_seeds"]; W = boot_weights(core, plan, seed_off=303)
rows = []
# ---- NumPy sweep base setting
ids = sl.sweep_ids(plan, core); g = Graphs(); g.rows(ids); items = sl.load_items(g, ids); base = dict(sw["base"])
FA = [features(el, lig.astype(int), xyz, g.n_elem + 1) for xyz, el, lig in items]
for a in rn.ARCHS:
    Es = [sl.Rep(sl.get_embedding(plan, base, a, s, items, g.n_elem), sw["pca_k"], sw["knn_k"]).X for s in range(S)]
    for fs, names in VARIANTS.items():
        M = zmatrix(FA, names); v = [al.cka_feature(E, M) for E in Es]
        rows.append(dict(source="numpy_sweep_base_untrained", model=a, features=fs, n_features=M.shape[1], cka=float(np.mean(v)), sd=float(np.std(v)), ci_lo=np.nan, ci_hi=np.nan))
# ---- real models
FC = []
for p_ in core: cls, lig, xyz, nc = graph_arrays(p_); FC.append(features(cls, lig, xyz, nc))
for fs, names in VARIANTS.items():
    M = zmatrix(FC, names)
    for m in ("egnn", "distance_gnn"):
        for state, tg in (("trained_primary", ["primary"]), ("untrained_5inits", fc.UNTRAINED_TAGS)):
            pl = [(ref_rep(fc.EMB, m, t, core, plan["pca_dim"]), M) for t in tg]; lo, hi = boot_ci(pl, W)
            rows.append(dict(source=f"real_{state}", model=m, features=fs, n_features=M.shape[1], cka=mean_cka(pl), sd=np.nan, ci_lo=lo, ci_hi=hi))
R = pd.DataFrame(rows); write_tsv(R, "c10_pooled_feature_baseline.tsv"); print(R.round(3).to_string())
