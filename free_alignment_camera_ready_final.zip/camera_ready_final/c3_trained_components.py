"""c3_trained_components.py -- leading-component removal on the trained AND untrained reference pairs, top-PC CKA, and prediction agreement vs CKA.
(reviewer r29H; answers "does removing components lower CKA for any pair?" and "does 'outputs agree, geometry diverges' survive?")
Representation: reference protocol (centred PCA-64 fit on train embeddings; columns are components in decreasing variance order), test core set.
For every model pair and every state (trained primary x primary, untrained matched inits, same-architecture ceilings primary x anchor):
   CKA with all 64 components, after removing the top 1 / 2 / 3 components, and on the top 1 / top 2 components alone (top1-only CKA = squared Pearson r).
Cluster-bootstrap 95% CIs (CR_NBOOT draws). Each distinct (state, models, level) is computed once, although a model appears in several pairs (the ceilings of a model are the same in each of its pairs).
Then, per pair, the prediction side: Pearson r and r^2 of the two models' test predictions, the CKA of each embedding with its own prediction,
the R^2 of the prediction regressed on the embedding, and the correlation of the top component with the prediction.
Env: INCLUDE_GNINA=0 skips the voxel model (its 27,648-d train embeddings take about 1.6 GB per load).
Output: camera_ready_out/c3_components.tsv, c3_spectra.tsv, c4_outputs_vs_cka.tsv"""
import os
from cr_common import *

plan = fc.load_plan(); core = fc.core_ids(plan)
models = [m for m in fc.MODELS if m != "gnina" or os.environ.get("INCLUDE_GNINA", "1") == "1"]
pairs = [p for p in fc.PAIRS if p[0] in models and p[1] in models]
tags_u = fc.UNTRAINED_TAGS
W = boot_weights(core, plan)
log(f"core {len(core)} | models {models} | pairs {pairs} | n_boot {len(W)}")
EMBd = fc.EMB
R = {(m, t): ref_rep(EMBd, m, t, core, plan["pca_dim"]) for m in models for t in ["primary", "anchor"] + tags_u}
log("representations ready")

spec = []
for (m, t), X in R.items():
    if t in ("primary", "anchor", "untrained"): spec.append(dict(model=m, tag=t, **spectrum(X)))
write_tsv(pd.DataFrame(spec), "c3_spectra.tsv")

LEVELS = {"all": lambda X: X, "remove_top1": lambda X: X[:, 1:], "remove_top2": lambda X: X[:, 2:], "remove_top3": lambda X: X[:, 3:],
          "top1_only": lambda X: X[:, :1], "top2_only": lambda X: X[:, :2]}
def states(A, B):
    return {"trained_primary": [(R[(A, "primary")], R[(B, "primary")])],
            "untrained_matched_5inits": [(R[(A, t)], R[(B, t)]) for t in tags_u],
            f"ceiling_{A}_primary_x_anchor": [(R[(A, "primary")], R[(A, "anchor")])],
            f"ceiling_{B}_primary_x_anchor": [(R[(B, "primary")], R[(B, "anchor")])]}
rows, memo = [], {}
for A, B in pairs:
    for sname, pl in states(A, B).items():
        for lname, f in LEVELS.items():
            P = [(f(a), f(b)) for a, b in pl]
            if min(p[0].shape[1] for p in P) < 1: continue
            key = (sname, lname) if sname.startswith("ceiling_") else (A, B, sname, lname)
            if key not in memo: lo, hi = boot_ci(P, W); memo[key] = (mean_cka(P), lo, hi)
            cka, lo, hi = memo[key]
            rows.append(dict(pair=f"{A}_x_{B}", state=sname, level=lname, cka=cka, ci_lo=lo, ci_hi=hi))
        log("done", A, B, sname)
C = pd.DataFrame(rows); write_tsv(C, "c3_components.tsv")
print(C[C.level.isin(["all", "remove_top1", "remove_top3", "top1_only"])].round(3).to_string())

# ---- prediction agreement vs CKA
def load_pred(m):
    p = np.load(fc.EMB / plan["agreement"]["pred_pattern"].format(model=m)).ravel()
    ids = [s.lower() for s in (fc.EMB / f"{m}_primary_test_ids.txt").read_text().split()]
    return al.strict_subset(p[:, None], ids, core, f"{m}/pred")[:, 0]
pred = {m: load_pred(m) for m in models}
def r2_reg(X, y):
    Z = np.c_[np.ones(len(X)), X - X.mean(0)]; b = np.linalg.lstsq(Z, y, rcond=None)[0]; return float(1 - ((y - Z @ b) ** 2).sum() / ((y - y.mean()) ** 2).sum())
rows, per = [], []
for A, B in pairs:
    r = float(np.corrcoef(pred[A], pred[B])[0, 1]); XA, XB = R[(A, "primary")], R[(B, "primary")]
    rows.append(dict(pair=f"{A}_x_{B}", pred_pearson_r=r, pred_r_squared=r * r, cka_all_components=al.cka_feature(XA, XB),
                     cka_top1_only=al.cka_feature(XA[:, :1], XB[:, :1]), cka_remove_top1=al.cka_feature(XA[:, 1:], XB[:, 1:])))
for m in models:
    X = R[(m, "primary")]
    per.append(dict(model=m, cka_embedding_vs_own_prediction=al.cka_feature(X, pred[m][:, None]), r2_prediction_on_embedding=r2_reg(X, pred[m]),
                    corr_top1_with_prediction=float(np.corrcoef(X[:, 0], pred[m])[0, 1])))
O = pd.DataFrame(rows); write_tsv(O, "c4_outputs_vs_cka.tsv"); write_tsv(pd.DataFrame(per), "c4_per_model.tsv")
print(O.round(3).to_string()); print(pd.DataFrame(per).round(3).to_string())
