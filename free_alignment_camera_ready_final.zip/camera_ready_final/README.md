# camera_ready_final: extra checks and retraining for the Free Alignment paper

These scripts only ADD files. They never edit `findings/`, `src/`, `config/` or `data/`, so the plan lock, the freeze tag and the code hash of the original runs stay valid.
Settings follow `findings/plan/findings_plan.yaml`: 1000 cluster-bootstrap draws for the real-model analyses (`CR_NBOOT`), 95% percentile intervals, PCA-64 fit on train embeddings (reference protocol).
Permutation nulls in c8 use `CR_NPERM` = 1000 (the plan fixes no CKA permutation count; its n_perm of 50 belongs to the probe panel).

## Run (AWS terminal, same Python environment as the earlier runs)
```
cd <project root>                 # the folder that contains data/ findings/ src/ config/
python3 -m zipfile -e free_alignment_camera_ready_final.zip .
nohup bash camera_ready_final/run_final.sh > run_final.log 2>&1 &
tail -f run_final.log
```
`run_final.sh` waits until `run_all.sh` and `run_extras.sh` (folder `camera_ready/`) have finished. It writes tables to `camera_ready_out_final/`, training logs to `camera_ready_out/logs/`, and a zip `camera_ready_results_final.zip` to the project root.
Switches (environment variables before `bash`): `CR_NBOOT`, `CR_NPERM`, `EXTRA_SEEDS=2`, `INCLUDE_GNINA=0`, `RUN_TRAIN=0`, `RUN_WIDTHS="128"`, `PROJECT_ROOT=...`. Every script also runs on its own, e.g. `python3 camera_ready_final/c2_coord_update.py` (tables then go to `camera_ready_out/` unless `CR_OUT` is set).
Finished training arms are skipped on a rerun and interrupted ones resume.

## Steps and what they answer
| step | question (reviewer) | outputs |
|---|---|---|
| `c5_network_count` | 260 vs 270 (and 825 vs 870) networks | `c5_network_count.tsv` |
| `c1_real_vs_numpy` | real untrained models vs NumPy base on the same 1,200 complexes: CKA, kNN, Procrustes, spectrum (eCg1, 7BsF) | `c1_real_vs_numpy.tsv` |
| `c11_embedding_statistics` | per-dimension mean, SD, offset, norms, skewness, kurtosis, dimension correlation: real untrained vs NumPy base (7BsF) | `c11_embedding_statistics.tsv`, `c11_per_embedding.tsv` |
| `c2_coord_update` | EGNN coordinate update vs frozen coordinates with identical weights; self-test against `findings/randnets.py` (all four) | `c2_coord_update.tsv`, `c2_coord_displacement.tsv` |
| `c3_trained_components` | CKA after removing the top 1/2/3 components and on the top components alone for trained pairs, untrained pairs, ceilings; prediction agreement vs CKA (r29H) | `c3_components.tsv`, `c3_spectra.tsv`, `c4_outputs_vs_cka.tsv`, `c4_per_model.tsv` |
| `c8_alternative_nulls` | trained vs own initialisation, vs the other architecture's untrained network, plain and size-stratified permutation nulls (r29H) | `c8_alternative_nulls.tsv`, `c8_permutation_nulls.tsv` |
| `c7a_composition_sweep` | does the floor of the NumPy sweep survive residualising on composition, degree and distance histograms? (r29H; deterministic, no bootstrap) | `c7_composition_sweep.tsv` |
| `c7b_composition_real` | the same for the real trained pair and untrained floor, with CIs (r29H) | `c7_composition_real.tsv` |
| `c10_pooled_feature_baseline` | CKA between embeddings and pooled input features (eCg1) | `c10_pooled_feature_baseline.tsv` |
| `c9_pca_truncation` | variance kept by the voxel model's PCA-64 and sensitivity to k (r29H) | `c9_pca_variance.tsv`, `c9_pca_truncation.tsv` |
| `c6_torch_on_sweep_inputs` | original torch untrained models on the sweep's inputs (eCg1, 7BsF) | `c6_torch_on_sweep_inputs.tsv`, `c6_input_equivalence.tsv` |
| `t1_train_maxreadout` | retraining: readout (mean, max, sum), target (real, shuffled, size-only), architecture (egnn, distance_gnn, deepsets), width, seeds; `--smoke` for a one-epoch test | `data/embeddings_readout_*`, `camera_ready_out/logs/train_*.json` |
| `t2_readout_alignment` | trained vs untrained floor per readout and width: CI, n_AB, ceilings, kNN, top-component diagnostics, matching NumPy floor (WKPN, r29H, eCg1) | `t2_readout_alignment.tsv` |
| `t4_targets_and_seeds` | trained pair under shuffled-affinity and size-only targets (r29H) | `t4_targets.tsv` |
| `t5_null_targets_vs_init` | how far the null-target models moved from their own initialisation | `t5_null_targets_vs_init.tsv` |
| `t6_no_message_passing` | trained model without message passing (DeepSets) vs both graph models (eCg1) | `t6_no_message_passing.tsv` |
| `t7_seeds_by_readout` | seed variability for the mean and max readouts: all cross pairs, same-architecture CKA, same-readout floor, CIs (r29H, WKPN) | `t7_seed_summary.tsv`, `t7_seed_pairs.tsv` |

Shared modules: `cr_common` (root, embeddings, bootstrap), `cr_models` (reference models with selectable pooling, DeepSets, seeds), `cr_graphs` (graph fallback), `cr_features` (pooled input features for c7 and c10). `preflight.py` lists missing inputs.

## Notes and limits
* Not covered: a third message-passing architecture (7BsF), which is a separate project.
* Retraining differs from notebook_2a in two small ways: the radius graph is built on the GPU (same 5 A cutoff, float32 coordinates), and embeddings are extracted in batches of 8 in float64 instead of batch size 1. The pipeline check (`t1 --readouts mean --arms untrained,untrained_init2`) quantifies the effect.
* The NumPy sweep networks are simplified re-implementations of the torch models (no biases, scaled initialisation, single-vector coordinate gate), so weights cannot be copied between them. c6 therefore compares behaviour on identical inputs.
* c7 residualises on the complexes it evaluates (about 40 covariates for 1,200 sweep complexes). `var_explained_*` shows how much embedding variance the covariates absorb.
* Extra seeds (extra1 to extra8) are additional training seeds that were not pre-registered.
* `src/alignlib.py` in the GitHub copy uses `PCA` without importing it. The scripts patch this in memory only.
* Last-layer coordinate displacement in `c2_coord_displacement.tsv` cannot influence the embedding, because the update after the final layer feeds nothing.
* If `findings_out/graphs.npz` is missing, c1, c2, c6, c7a and c10 fail and the rest still runs. c7b, c10 and the training need `data/graph_cache` (or PDBbind_2020 with rdkit).
* c7a and c6 use the sweep cache under `findings_out/sweep_cache/<plan hash>/`. Missing embeddings are computed in parallel (about 40 s per network at the base setting).
