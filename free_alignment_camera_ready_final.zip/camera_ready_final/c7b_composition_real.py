"""c7b_composition_real.py -- do the REAL untrained and trained models keep their alignment after residualising on the composition of the complex?   (reviewer r29H)
Reference protocol with residualisation BEFORE the train-fit PCA-64 (alignlib.resid_then_pca; each split is residualised within itself), covariates from cr_features computed from data/graph_cache
(variants raw, size2, comp, full). Trained primary pair and the untrained matched floor (5 inits) with cluster-bootstrap CIs (CR_NBOOT draws).   Output: c7_composition_real.tsv"""
from cr_common import *
from cr_features import features, design, VARIANTS, graph_arrays

plan = fc.load_plan(); core = fc.core_ids(plan); W = boot_weights(core, plan, seed_off=99); models = ["egnn", "distance_gnn"]
cache = {}
def feats_for(idlist):
    out = []
    for p_ in idlist:
        if p_ not in cache: cls, lig, xyz, nc = graph_arrays(p_); cache[p_] = features(cls, lig, xyz, nc)
        out.append(cache[p_])
    return out
def reps(model, tag, variant):
    if variant == "raw": return ref_rep(fc.EMB, model, tag, core, plan["pca_dim"])
    Etr, itr = load_emb(fc.EMB, model, tag, "train"); Ete = raw_test(fc.EMB, model, tag, core)
    return al.resid_then_pca(Etr, design(feats_for(itr), VARIANTS[variant]), Ete, design(feats_for(core), VARIANTS[variant]), k=plan["pca_dim"], name=f"{model}/{tag}/{variant}")
rows = []
for v in ["raw"] + list(VARIANTS):
    R = {(m, t): reps(m, t, v) for m in models for t in ["primary"] + fc.UNTRAINED_TAGS}
    for state, pl in (("trained_primary", [(R[("egnn", "primary")], R[("distance_gnn", "primary")])]), ("untrained_matched_5inits", [(R[("egnn", t)], R[("distance_gnn", t)]) for t in fc.UNTRAINED_TAGS])):
        lo, hi = boot_ci(pl, W); rows.append(dict(variant=v, state=state, cka=mean_cka(pl), ci_lo=lo, ci_hi=hi))
    log("real models,", v, "done")
B = pd.DataFrame(rows); write_tsv(B, "c7_composition_real.tsv"); print(B.round(3).to_string())
