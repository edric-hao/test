"""t6_no_message_passing.py -- a trained model WITHOUT message passing as a control for the graph pair.   (reviewer eCg1)
Model 'deepsets' (cr_models.DeepSetsPool): per-atom MLPs on the atom-type embedding, pooled, same readout head; no coordinates and no edges. With mean pooling its embedding depends only on composition fractions.
Trained with t1 (--archs deepsets --readouts mean, all arms) into data/embeddings_readout_mean/deepsets_*.
Reports for deepsets x EGNN and deepsets x Distance-GNN (and, for reference, EGNN x Distance-GNN): trained primary pair CKA, untrained matched floor (5 inits), same-architecture ceilings,
trained minus floor with CI, n_AB (ceiling = the smaller ceiling, undefined when ceiling - floor < 0.05), and the test r of the deepsets model.   Output: t6_no_message_passing.tsv"""
from cr_common import *

plan = fc.load_plan(); core = fc.core_ids(plan); W = boot_weights(core, plan, seed_off=404)
mdir = ROOT / "data" / "embeddings_readout_mean"; tags_u = fc.UNTRAINED_TAGS
def rep(m, t): return ref_rep(mdir if m == "deepsets" else fc.EMB, m, t, core, plan["pca_dim"])
def draws(pairs): return np.array([mean_cka(pairs, w) for w in W])
y = fc.split_df(plan).loc[core, plan["affinity_column"]].values.astype(float)
rows = []
for A, B in (("deepsets", "egnn"), ("deepsets", "distance_gnn"), ("egnn", "distance_gnn")):
    try: tr = [(rep(A, "primary"), rep(B, "primary"))]; fl = [(rep(A, t), rep(B, t)) for t in tags_u]; ca = [(rep(A, "primary"), rep(A, "anchor"))]; cb = [(rep(B, "primary"), rep(B, "anchor"))]
    except FileNotFoundError as e: log(f"{A} x {B}: skipped ({e})"); continue
    dtr, dfl = draws(tr), draws(fl); dce = np.minimum(draws(ca), draws(cb)); ceil = min(mean_cka(ca), mean_cka(cb))
    dn = np.array([n_ab(a, b, c) for a, b, c in zip(dtr, dfl, dce)]); dfn = np.isfinite(dn).mean()
    rows.append(dict(pair=f"{A}_x_{B}", trained_cka=mean_cka(tr), trained_lo=fc.ci(dtr)[0], trained_hi=fc.ci(dtr)[1], floor_cka=mean_cka(fl), floor_lo=fc.ci(dfl)[0], floor_hi=fc.ci(dfl)[1],
                     trained_minus_floor=mean_cka(tr) - mean_cka(fl), tmf_lo=fc.ci(dtr - dfl)[0], tmf_hi=fc.ci(dtr - dfl)[1], ceiling_first=mean_cka(ca), ceiling_second=mean_cka(cb), nAB=n_ab(mean_cka(tr), mean_cka(fl), ceil),
                     nAB_share_defined=float(dfn), nAB_lo=fc.ci(dn)[0] if dfn >= 0.95 else np.nan, nAB_hi=fc.ci(dn)[1] if dfn >= 0.95 else np.nan,
                     pr_first_trained=spectrum(rep(A, "primary"))["pr"], top1_first_trained=spectrum(rep(A, "primary"))["top1"]))
    log(f"{A} x {B}: trained {rows[-1]['trained_cka']:.3f} floor {rows[-1]['floor_cka']:.3f}")
if (mdir / "deepsets_primary_test_pred.npy").exists():
    ids = [s.lower() for s in (mdir / "deepsets_primary_test_ids.txt").read_text().split()]
    r = float(np.corrcoef(al.strict_subset(np.load(mdir / "deepsets_primary_test_pred.npy").ravel()[:, None], ids, core, "pred")[:, 0], y)[0, 1]); rows.append(dict(pair="deepsets_primary_test_prediction", test_r=r))
T = pd.DataFrame(rows); write_tsv(T, "t6_no_message_passing.tsv"); print(T.T.round(3).to_string())
