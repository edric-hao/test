"""t1_train_maxreadout.py -- retrain EGNN and Distance-GNN variants and extract embeddings.   (reviewers WKPN, r29H, eCg1)
Same models, data, split, optimiser and early stopping as notebook_2a / config.yaml (Adam lr 3e-4, batch 32, up to 300 epochs, patience 20 on validation MSE),
with these switchable changes:
  --readouts max|sum|mean   pooling of the atom vectors (mean = the original models). The pooled vector is the input of `readout.0`, which is the embedding.
  --target real|shuffled|sizeonly   real affinity; affinity shuffled within each split; or the OLS size-only prediction (ligand heavy atoms, complex atoms) as the target.
  --arms    primary (seed 20260919), anchor (20260923), untrained (20260919, same initial weights as primary), untrained_init2..5 (20260924..27),
            extra1..extra8 (additional training seeds 20261001..8, not pre-registered).
Gate (as in notebook_2a, real target only): primary validation r >= 0.4 and at least 0.10 above the untrained network; a failed arm is reported, never retrained.
Output embeddings: <root>/data/embeddings_readout_<readout>[_<target>]/<arch>_<arm>_<split>.npy (+ _ids.txt, + <arch>_<arm>_test_pred.npy); logs: camera_ready_out/logs/train_*.json.
With --readouts mean and an untrained arm the embeddings are compared with the original untrained embeddings (pipeline check, logged as CHECK).
Resumable: a finished arm is skipped, an interrupted training resumes from its last epoch checkpoint (valid, but the batch order after the interruption is not bit-identical to an uninterrupted run).
--smoke trains one epoch on a few complexes in a separate folder."""
import argparse, copy, hashlib, json, os, time
os.environ.setdefault("CUBLAS_WORKSPACE_CONFIG", ":4096:8")
from cr_common import *
import torch, torch.nn as nn
from torch.utils.data import Dataset, DataLoader
from scipy.stats import pearsonr
from src import embed_utils as eu, seeds as seedmod
import cr_graphs
from cr_models import make_model, HP, CUTOFF, UNTRAINED_SEEDS, cfg

ap = argparse.ArgumentParser()
ap.add_argument("--readouts", default="max"); ap.add_argument("--archs", default="egnn,distance_gnn", help="egnn, distance_gnn, deepsets (no message passing)")
ap.add_argument("--arms", default="primary,anchor,untrained,untrained_init2,untrained_init3,untrained_init4,untrained_init5")
ap.add_argument("--target", default="real", choices=["real", "shuffled", "sizeonly"], help="real affinity, affinity shuffled within each split, or the OLS size-only prediction as the training target")
ap.add_argument("--hidden", type=int, default=None, help="override the hidden width of the chosen architectures (default: config.yaml); embeddings go to a folder with suffix _h<width>")
ap.add_argument("--smoke", action="store_true"); ap.add_argument("--max-epochs", type=int, default=None); ap.add_argument("--extract-batch", type=int, default=8)
args = ap.parse_args()

plan = fc.load_plan()
SEED = int(cfg["seeds"]["global"]); ANCHOR = int(cfg["seeds"]["anchor"])
EXTRA = {f"extra{i}": 20261000 + i for i in range(1, 9)}     # additional training seeds (not pre-registered), arms extra1..extra8
ARM_SEED = {"primary": SEED, "anchor": ANCHOR, **UNTRAINED_SEEDS, **EXTRA}
DEV = torch.device("cuda" if torch.cuda.is_available() else "cpu")
SUF = ("" if args.target == "real" else f"_{args.target}") + ("" if args.hidden is None else f"_h{args.hidden}") + ("_smoke" if args.smoke else "")
log("device:", DEV, "| smoke" if args.smoke else "")


# ------------------------------------------------------------------ data
sp = fc.split_df(plan); SPLIT = plan["split_column"]; AFF = plan["affinity_column"]
GC = ROOT / "data" / "graph_cache"; GC.mkdir(parents=True, exist_ok=True)
PDB = ROOT / plan["pdbbind_dir"]

YO = {}      # label overrides for --target shuffled / sizeonly
def get_graph(pid):
    p = GC / f"{pid}.pt"
    if not p.exists():
        z, x, y = cr_graphs.build_graph(PDB, pid, sp.loc[pid, AFF]); torch.save({"z": z, "x": x, "y": y}, p); return z, x, (YO[pid] if pid in YO else y)
    try: d = torch.load(p)
    except Exception: d = torch.load(p, weights_only=False)
    return d["z"], d["x"], (YO[pid] if pid in YO else d["y"])

def split_ids(name):
    ids = sp.index[sp[SPLIT] == name].tolist(); ok = []
    for pid in ids:
        if (GC / f"{pid}.pt").exists(): ok.append(pid); continue
        try: get_graph(pid); ok.append(pid)
        except Exception as e: print("skip", pid, str(e)[:80])
    return ok
IDS = {s: split_ids(s) for s in ("train", "val", "test")}
if args.target != "real":
    y_real = sp[AFF].astype(float)
    if args.target == "shuffled":
        rng = np.random.default_rng(int(cfg["seeds"]["permutation"]))
        for s_ in ("train", "val", "test"):
            ids_ = IDS[s_]; YO.update(dict(zip(ids_, rng.permutation(y_real.loc[ids_].values))))
    else:
        cov = pd.read_csv(ROOT / plan["covariates_file"], sep="\t", index_col=0); cov.index = cov.index.astype(str).str.lower()
        Z = lambda ids_: np.c_[np.ones(len(ids_)), cov.loc[ids_, ["ligand_heavy_atom_count", "complex_atom_count"]].values.astype(float)]
        beta = np.linalg.lstsq(Z(IDS["train"]), y_real.loc[IDS["train"]].values, rcond=None)[0]
        for s_ in ("train", "val", "test"): YO.update(dict(zip(IDS[s_], Z(IDS[s_]) @ beta)))
    log(f"target {args.target}: {len(YO)} labels overridden")
if args.smoke: IDS = {"train": IDS["train"][:96], "val": IDS["val"][:32], "test": IDS["test"][:32]}
log({k: len(v) for k, v in IDS.items()})

class DS(Dataset):
    def __init__(self, ids): self.ids = list(ids)
    def __len__(self): return len(self.ids)
    def __getitem__(self, i): z, x, y = get_graph(self.ids[i]); return self.ids[i], z, x, y
def collate(batch):
    pids = [b[0] for b in batch]; z = torch.cat([b[1] for b in batch]); x = torch.cat([b[2] for b in batch])
    bi = torch.cat([torch.full((b[1].shape[0],), i, dtype=torch.long) for i, b in enumerate(batch)])
    return pids, z, x, None, bi, len(batch), torch.tensor([b[3] for b in batch], dtype=torch.float32)

def to_dev(bt):
    """Move a batch to the device and build the radius graph there (float32 coordinates, cutoff 5 A, as in the reference pipeline)."""
    pids, z, x, _, b, ng, y = bt
    z, x, b, y = z.to(DEV), x.to(DEV), b.to(DEV), y.to(DEV)
    return pids, z, x, eu.radius_edges(x, b, cutoff=CUTOFF), b, ng, y
def loader(split, bs, shuffle=False, seed=0):
    g = torch.Generator().manual_seed(seed)
    return DataLoader(DS(IDS[split]), batch_size=bs, shuffle=shuffle, collate_fn=collate, generator=g if shuffle else None, num_workers=0)

@torch.no_grad()
def evaluate(model, ld):
    model.eval(); P, T, tot, n = [], [], 0.0, 0
    for bt in ld:
        _, z, x, ei, b, ng, y = to_dev(bt)
        out = model(z, x, ei, b, ng); tot += nn.functional.mse_loss(out, y, reduction="sum").item(); n += ng; P.append(out.cpu().numpy()); T.append(y.cpu().numpy())
    P, T = np.concatenate(P), np.concatenate(T)
    return dict(val_loss=tot / max(n, 1), pearson_r=float(pearsonr(P, T)[0]) if len(P) > 1 else float("nan"), rmse=float(np.sqrt(np.mean((P - T) ** 2))), n=n)

def train(arch, readout, arm, ckdir):
    hp = HP[arch]; seed = ARM_SEED[arm]; ck = ckdir / f"{arch}_{arm}.pt"
    seedmod.seed_everything(seed); model = make_model(arch, readout, args.hidden).to(DEV)
    if arm.startswith("untrained"): return model, dict(untrained=True, seed=seed)
    opt = torch.optim.Adam(model.parameters(), lr=hp["lr"]); max_ep = args.max_epochs or (1 if args.smoke else hp["max_epochs"]); pat = hp["early_stopping_patience"]
    st = dict(epoch=0, best=float("inf"), best_state=None, ctr=0, hist=[])
    if ck.exists() and not args.smoke:
        c = torch.load(ck, weights_only=False); model.load_state_dict(c["model"]); opt.load_state_dict(c["opt"]); st = c["st"]; log(f"resume {ck.name} at epoch {st['epoch']}")
    trl, vl = loader("train", hp["batch_size"], True, seed), loader("val", hp["batch_size"])
    t0 = time.time()
    while st["epoch"] < max_ep and st["ctr"] < pat:
        model.train(); tl, tn = 0.0, 0
        for bt in trl:
            _, z, x, ei, b, ng, y = to_dev(bt)
            loss = nn.functional.mse_loss(model(z, x, ei, b, ng), y); opt.zero_grad(); loss.backward(); opt.step(); tl += loss.item() * ng; tn += ng
        ev = evaluate(model, vl); st["epoch"] += 1; st["hist"].append(dict(epoch=st["epoch"], train_loss=tl / tn, **ev))
        if ev["val_loss"] < st["best"]: st["best"], st["ctr"], st["best_state"] = ev["val_loss"], 0, copy.deepcopy(model.state_dict()); st["best_epoch"] = st["epoch"]
        else: st["ctr"] += 1
        log(f"{arch}/{readout}/{arm} epoch {st['epoch']} train {tl / tn:.3f} val {ev['val_loss']:.3f} r {ev['pearson_r']:.3f} best@{st.get('best_epoch')} patience {st['ctr']}/{pat}")
        if not args.smoke: torch.save(dict(model=model.state_dict(), opt=opt.state_dict(), st=st), ck)
    model.load_state_dict(st["best_state"]); model.to(DEV)
    return model, dict(seed=seed, epochs_run=st["epoch"], best_epoch=st.get("best_epoch"), seconds=time.time() - t0, best_val_loss=st["best"])

@torch.no_grad()
def extract(arch, readout, model, split):
    m64 = make_model(arch, readout, args.hidden).double().to(DEV); m64.load_state_dict({k: v.double() for k, v in model.state_dict().items()}); m64.eval()
    rows, preds, ids = [], [], []
    for bt in loader(split, args.extract_batch):
        pids, z, x, ei, b, ng, _ = to_dev(bt)
        with eu.PreHeadCapture(m64, "readout.0") as cap: out = m64(z, x.double(), ei, b, ng)
        rows.append(cap.value.cpu().numpy()); preds.append(out.cpu().numpy()); ids += pids
    return np.vstack(rows).astype(np.float64), np.concatenate(preds), ids

for readout in args.readouts.split(","):
    edir = ROOT / "data" / f"embeddings_readout_{readout}{SUF}"; ckdir = ROOT / "data" / f"checkpoints_readout_{readout}{SUF}"; edir.mkdir(parents=True, exist_ok=True); ckdir.mkdir(parents=True, exist_ok=True)
    for arch in args.archs.split(","):
        gate = {}
        for arm in args.arms.split(","):
            done = all((edir / f"{arch}_{arm}_{s}.npy").exists() for s in ("train", "val", "test"))
            jf = LOGDIR / f"train_{arch}_{readout}_{arm}{SUF}.json"
            if done: log(f"{arch}/{readout}/{arm}: embeddings present, skipping"); continue
            model, info = train(arch, readout, arm, ckdir)
            val = evaluate(model, loader("val", 32)); test = evaluate(model, loader("test", 32)); info.update(arm=arm, arch=arch, readout=readout, val=val, test=test)
            log(f"{arch}/{readout}/{arm}: val r {val['pearson_r']:.3f} test r {test['pearson_r']:.3f}")
            for s in ("train", "val", "test"):
                E, P, ids = extract(arch, readout, model, s)
                if readout == "mean" and args.target == "real" and args.hidden is None and arm.startswith("untrained") and not args.smoke:    # pipeline check against the original untrained embeddings
                    E0, i0 = load_emb(fc.EMB, arch, arm, s)
                    if E0 is not None:
                        pos = {p_: j for j, p_ in enumerate(i0)}; keep = [j for j, p_ in enumerate(ids) if p_ in pos]
                        dmax = float(np.abs(E[keep] - E0[[pos[ids[j]] for j in keep]]).max() / max(np.abs(E0).max(), 1e-12)); info[f"max_rel_diff_vs_original_{s}"] = dmax
                        log(f"CHECK {arch}/{arm}/{s}: max relative difference to the original untrained embeddings = {dmax:.2e} ({len(keep)} complexes)")
                np.save(edir / f"{arch}_{arm}_{s}.npy", E); (edir / f"{arch}_{arm}_{s}_ids.txt").write_text("\n".join(ids))
                if s == "test" and (arm in ("primary", "anchor") or arm.startswith("extra")): np.save(edir / f"{arch}_{arm}_test_pred.npy", P)
                info[f"sha256_{s}"] = hashlib.sha256(E.tobytes()).hexdigest()
            jf.write_text(json.dumps(info, indent=2, default=str)); gate[arm] = val["pearson_r"]
        if "primary" in gate and "untrained" in gate and args.target == "real":
            ok = gate["primary"] >= 0.4 and gate["primary"] - gate["untrained"] >= 0.10
            log(f"GATE {arch}/{readout} primary: val r {gate['primary']:.3f} (untrained {gate['untrained']:.3f}) -> {'PASS' if ok else 'FAIL (report it; do not retrain)'}")
log("t1 done")
