"""t5_null_targets_vs_init.py -- how far did the null-target models move from their initial weights?   (companion to t4; run AFTER the t1 null-target trainings have finished)
The arm 'untrained' (seed 20260919) holds the initial weights of the arm 'primary', so CKA(primary, untrained) measures how far training moved the representation.
For the real, shuffled-affinity and size-only targets: per architecture CKA of primary vs its own initialisation, the pair CKA of the two trained models, and the best epoch / epochs run from the training logs.
(The anchor arm starts from a different seed whose initial weights were not saved, so only primary has an exact own-initialisation reference.)   Output: camera_ready_out/t5_null_targets_vs_init.tsv"""
import json
from cr_common import *

plan = fc.load_plan(); core = fc.core_ids(plan); W = boot_weights(core, plan, seed_off=123); A, B = "egnn", "distance_gnn"
dirs = {"real_affinity": (fc.EMB, ""), "shuffled_affinity": (ROOT / "data" / "embeddings_readout_mean_shuffled", "_shuffled"), "size_only_target": (ROOT / "data" / "embeddings_readout_mean_sizeonly", "_sizeonly")}
init = {m: ref_rep(fc.EMB, m, "untrained", core, plan["pca_dim"]) for m in (A, B)}
floor = [(ref_rep(fc.EMB, A, t, core, plan["pca_dim"]), ref_rep(fc.EMB, B, t, core, plan["pca_dim"])) for t in fc.UNTRAINED_TAGS]
def info(m, arm, suf):
    f = LOGDIR / f"train_{m}_mean_{arm}{suf}.json"
    if not f.exists(): return {}
    j = json.loads(f.read_text()); return dict(best_epoch=j.get("best_epoch"), epochs_run=j.get("epochs_run"), val_r=j.get("val", {}).get("pearson_r"))
rows = []
for name, (d, suf) in dirs.items():
    try: R = {m: ref_rep(d, m, "primary", core, plan["pca_dim"]) for m in (A, B)}
    except FileNotFoundError as e: log(f"{name}: skipped ({e})"); continue
    for m in (A, B):
        lo, hi = boot_ci([(R[m], init[m])], W); rows.append(dict(target=name, item=f"{m}: primary vs own initialisation", cka=al.cka_feature(R[m], init[m]), ci_lo=lo, ci_hi=hi, **info(m, "primary", suf)))
    lo, hi = boot_ci([(R[A], R[B])], W); rows.append(dict(target=name, item="pair: egnn primary x distance_gnn primary", cka=al.cka_feature(R[A], R[B]), ci_lo=lo, ci_hi=hi))
lo, hi = boot_ci(floor, W); rows.append(dict(target="untrained", item="pair: untrained floor (5 inits, matched)", cka=mean_cka(floor), ci_lo=lo, ci_hi=hi))
T = pd.DataFrame(rows); write_tsv(T, "t5_null_targets_vs_init.tsv"); print(T.round(3).to_string())
