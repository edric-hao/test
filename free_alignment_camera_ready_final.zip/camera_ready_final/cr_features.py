"""cr_features.py -- pooled input features of a complex, shared by c7 (residualisation) and c10 (pooled-feature baseline).
Blocks: size2 = (atom count, ligand atom count); comp = element-class counts of pocket and ligand; deg = histogram of per-atom neighbour counts within 5 A; dist = histogram of pair distances within 5 A."""
import os
from scipy.spatial import cKDTree
from cr_common import *

EDGE_R = 5.0
VARIANTS = {"size2": ["size2"], "comp": ["size2", "comp"], "full": ["size2", "comp", "deg", "dist"]}

def features(cls, lig, xyz, n_cls):
    n = len(xyz); counts = np.zeros(2 * n_cls); np.add.at(counts, cls * 2 + lig.astype(int), 1)
    pr = cKDTree(xyz).query_pairs(EDGE_R, output_type="ndarray")
    d = np.linalg.norm(xyz[pr[:, 0]] - xyz[pr[:, 1]], axis=1) if len(pr) else np.zeros(0)
    deg = np.bincount(pr.ravel(), minlength=n) if len(pr) else np.zeros(n)
    return dict(size2=np.array([n, lig.sum()], float), comp=counts, deg=np.histogram(deg, bins=[0, 4, 8, 12, 16, 20, 24, 28, 1e9])[0].astype(float),
                dist=np.histogram(d, bins=np.linspace(0, EDGE_R, 11))[0].astype(float))

def zmatrix(F, names):
    """z-scored non-constant columns of the requested feature blocks (one row per complex in F)."""
    M = np.hstack([np.vstack([f[k] for f in F]) for k in names]); M = M[:, M.std(0) > 1e-9]
    return (M - M.mean(0)) / M.std(0)

def design(F, names):
    """Intercept + zmatrix (the design of an OLS residualisation)."""
    M = zmatrix(F, names); return np.c_[np.ones(len(M)), M]

_G = {}
def graph_arrays(pid):
    """(element class, ligand flag, coordinates, number of classes) of a complex from data/graph_cache: 8 element buckets x {protein, ligand} = 16 node types.
    CR_FAKE_GRAPHS=1 (test mode only) reads the graphs from the sweep archive instead."""
    if os.environ.get("CR_FAKE_GRAPHS") == "1":
        if not _G:
            from build_graphs import Graphs
            _G["g"] = Graphs()
        xyz, el, lig = _G["g"].get(pid); return el, lig.astype(int), xyz, _G["g"].n_elem + 1
    import torch
    p = ROOT / "data" / "graph_cache" / f"{pid}.pt"
    try: d = torch.load(p)
    except Exception: d = torch.load(p, weights_only=False)
    z = d["z"].numpy(); return z // 2, z % 2, d["x"].numpy().astype(np.float64), 16
