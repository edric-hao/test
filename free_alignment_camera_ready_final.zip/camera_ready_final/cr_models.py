"""cr_models.py -- the reference EGNN / Distance-GNN of src/embed_utils.py with a selectable pooling (mean = original, max, sum). Shared by t1 and c6."""
import yaml, torch
from cr_common import ROOT
from src import embed_utils as eu

cfg = yaml.safe_load((ROOT / "config" / "config.yaml").read_text())
HP = {"egnn": cfg["training"]["egnn"], "distance_gnn": cfg["training"]["distance_gnn"]}
CUTOFF = float(HP["distance_gnn"].get("cutoff_A", 5.0)); N_RBF = int(HP["distance_gnn"].get("n_rbf", 16)); N_TYPES = 16

def sum_pool(h, batch, n): return h.new_zeros(n, h.size(1)).index_add_(0, batch, h)
def max_pool(h, batch, n):
    return h.new_zeros(n, h.size(1)).scatter_reduce(0, batch[:, None].expand_as(h), h, reduce="amax", include_self=False)
POOL = {"mean": eu.mean_pool, "sum": sum_pool, "max": max_pool}

class EGNNPool(eu.EGNNAffinity):
    def __init__(self, pool, **kw): super().__init__(**kw); self._pool = POOL[pool]
    def forward(self, z, x, edge_index, batch, n_graphs):
        h = self.embed(z)
        for layer in self.layers: h, x = layer(h, x, edge_index)
        return self.readout(self._pool(h, batch, n_graphs)).squeeze(-1)

class DistGNNPool(eu.DistanceGNN):
    def __init__(self, pool, **kw): super().__init__(**kw); self._pool = POOL[pool]
    def forward(self, z, x, edge_index, batch, n_graphs):
        row, col = edge_index
        d = (x[row] - x[col]).norm(dim=-1, keepdim=True); rbf = torch.exp(-self.gamma * (d - self.centers) ** 2); h = self.embed(z)
        for msg, upd in zip(self.msg, self.upd):
            m = msg(torch.cat([h[col], rbf], dim=-1)); agg = torch.zeros_like(h).index_add_(0, row, m); h = h + upd(torch.cat([h, agg], dim=-1))
        return self.readout(self._pool(h, batch, n_graphs)).squeeze(-1)

class DeepSetsPool(torch.nn.Module):
    """Control without message passing: no coordinates, no edges. Per-atom residual MLPs on the atom-type embedding, pooled, then the same readout head.
    With mean pooling the embedding depends on the composition fractions only; with sum pooling on the composition counts."""
    def __init__(self, pool, n_types=16, hidden=64, n_layers=3):
        super().__init__(); nn = torch.nn
        self.embed = nn.Embedding(n_types, hidden)
        self.layers = nn.ModuleList([nn.Sequential(nn.Linear(hidden, hidden), nn.SiLU(), nn.Linear(hidden, hidden)) for _ in range(n_layers)])
        self.readout = nn.Sequential(nn.Linear(hidden, hidden), nn.SiLU(), nn.Linear(hidden, 1)); self._pool = POOL[pool]
    def forward(self, z, x, edge_index, batch, n_graphs):
        h = self.embed(z)
        for layer in self.layers: h = h + layer(h)
        return self.readout(self._pool(h, batch, n_graphs)).squeeze(-1)

HP["deepsets"] = HP["egnn"]      # same optimiser, epochs and early stopping as the EGNN
# seeds of the untrained arms: 'untrained' has the initial weights of 'primary' (global seed); the four other inits are fixed by the pre-registration of the original run
UNTRAINED_SEEDS = {"untrained": int(cfg["seeds"]["global"]), "untrained_init2": 20260924, "untrained_init3": 20260925, "untrained_init4": 20260926, "untrained_init5": 20260927}

def make_model(arch, readout, hidden=None):
    """hidden=None uses the width of config.yaml; any other value changes the width of the chosen architecture."""
    if arch == "deepsets": return DeepSetsPool(readout, n_types=N_TYPES, hidden=hidden or HP["egnn"]["hidden"], n_layers=HP["egnn"]["n_layers"])
    if arch == "egnn": return EGNNPool(readout, n_types=N_TYPES, hidden=hidden or HP["egnn"]["hidden"], n_layers=HP["egnn"]["n_layers"])
    return DistGNNPool(readout, n_types=N_TYPES, hidden=hidden or HP["distance_gnn"]["hidden"], n_layers=HP["distance_gnn"]["n_layers"], n_rbf=N_RBF, cutoff=CUTOFF)

