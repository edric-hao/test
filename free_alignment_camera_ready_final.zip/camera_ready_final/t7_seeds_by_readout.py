"""t7_seeds_by_readout.py -- variability over training seeds for each readout, with bootstrap intervals.   (reviewers r29H, WKPN: "seed variability", "one trained value")
t4 summarises seed pairs for the mean readout only and without intervals. This does it per readout (default mean and max; T7_READOUTS=mean,max,sum) over the arms primary, anchor, extra1..N:
every (EGNN seed i x Distance-GNN seed j) cross-architecture CKA, the same-architecture seed-to-seed CKA, the untrained floor (5 inits) of the SAME readout, and the share of cross pairs
below the floor. Cluster-bootstrap CIs (CR_NBOOT) for the mean cross CKA, the floor and their difference, and for the mean same-architecture CKA. Reference protocol (train-fit PCA-64, core test set).
Needs t1 runs:  --readouts max --arms extra1,extra2   (mean extras come from the main run).   Output: t7_seed_summary.tsv, t7_seed_pairs.tsv"""
import itertools, os
from cr_common import *

plan = fc.load_plan(); core = fc.core_ids(plan); W = boot_weights(core, plan, seed_off=707); A, B = "egnn", "distance_gnn"
rows, prow = [], []
for ro in os.environ.get("T7_READOUTS", "mean,max").split(","):
    d_ro = ROOT / "data" / f"embeddings_readout_{ro}"
    dmain = fc.EMB if ro == "mean" else d_ro
    def folder(arm): return dmain if arm in ("primary", "anchor") or ro != "mean" else d_ro
    def have(arm, d): return all((Path(d) / f"{m}_{arm}_{s}.npy").exists() for m in (A, B) for s in ("train", "test"))
    arms = [a for a in ["primary", "anchor"] + [f"extra{i}" for i in range(1, 9)] if have(a, folder(a))]
    if not all(have(t, dmain) for t in fc.UNTRAINED_TAGS) or len(arms) < 3:
        log(f"readout {ro}: skipped (arms found {arms}; untrained floor present: {all(have(t, dmain) for t in fc.UNTRAINED_TAGS)})"); continue
    R = {(m, a): ref_rep(folder(a), m, a, core, plan["pca_dim"]) for m in (A, B) for a in arms}
    U = {(m, t): ref_rep(dmain, m, t, core, plan["pca_dim"]) for m in (A, B) for t in fc.UNTRAINED_TAGS}
    cross = [(R[(A, a)], R[(B, b)]) for a in arms for b in arms]
    same = [(R[(m, a)], R[(m, b)]) for m in (A, B) for a, b in itertools.combinations(arms, 2)]
    floor = [(U[(A, t)], U[(B, t)]) for t in fc.UNTRAINED_TAGS]
    dc, ds, df = (np.array([mean_cka(p, w) for w in W]) for p in (cross, same, floor))
    oc, os_, of = mean_cka(cross), mean_cka(same), mean_cka(floor)
    cv = [al.cka_feature(a, b) for a, b in cross]; sv = [al.cka_feature(a, b) for a, b in same]
    for (a, b), v in zip([(x, y) for x in arms for y in arms], cv): prow.append(dict(readout=ro, egnn_seed=a, distance_gnn_seed=b, cka=v))
    rows.append(dict(readout=ro, n_seeds=len(arms), n_cross_pairs=len(cv), cross_mean=oc, cross_lo=fc.ci(dc)[0], cross_hi=fc.ci(dc)[1], cross_min=min(cv), cross_max=max(cv), cross_sd=float(np.std(cv, ddof=1)),
                     floor=of, floor_lo=fc.ci(df)[0], floor_hi=fc.ci(df)[1], cross_minus_floor=oc - of, cmf_lo=fc.ci(dc - df)[0], cmf_hi=fc.ci(dc - df)[1],
                     share_cross_below_floor=float((np.array(cv) < of).mean()), same_arch_mean=os_, same_lo=fc.ci(ds)[0], same_hi=fc.ci(ds)[1], same_min=min(sv), same_max=max(sv)))
    log(f"readout {ro}: {len(arms)} seeds {arms} | cross {oc:.3f} [{min(cv):.3f}, {max(cv):.3f}] floor {of:.3f} same-arch {os_:.3f}")
T = pd.DataFrame(rows); write_tsv(T, "t7_seed_summary.tsv"); write_tsv(pd.DataFrame(prow), "t7_seed_pairs.tsv")
if len(T): print(T.T.round(3).to_string())
