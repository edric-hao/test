"""c9_pca_truncation.py -- variance kept by the PCA-64 of the voxel model, and sensitivity of the graph-voxel results to the truncation.   (reviewer r29H, minor point)
The graph models have width 64, so their PCA-64 is a rotation and keeps all variance. The voxel model (27,648-d) is reduced to 64 components.
For k = 16, 32, 64, 128, 256 components (nested: the first k columns of one 256-component PCA per model and tag): cumulative explained variance, and CKA of the trained graph-voxel pairs and of
the untrained matched floor (5 inits). Needs about 5 GB RAM and a few minutes per tag; run it when the GPU job is finished.
Env: C9_KS=16,32,64,128,256.   Output: c9_pca_variance.tsv, c9_pca_truncation.tsv"""
import os
from cr_common import *

plan = fc.load_plan(); core = fc.core_ids(plan); W = boot_weights(core, plan, seed_off=202)
KS = [int(k) for k in os.environ.get("C9_KS", "16,32,64,128,256").split(",")]; KMAX = max(KS); tags = ["primary"] + fc.UNTRAINED_TAGS
G = {}; var = []
for t in tags:
    Etr, _ = load_emb(fc.EMB, "gnina", t, "train"); Ete = raw_test(fc.EMB, "gnina", t, core)
    mu, pca = al.pca_train_fit(Etr, KMAX, name=f"gnina/{t}"); del Etr
    G[t] = pca.transform(Ete - mu); cum = np.cumsum(pca.explained_variance_ratio_)
    for k in KS: var.append(dict(tag=t, k=k, cumulative_explained_variance=float(cum[min(k, len(cum)) - 1])))
    log("gnina PCA", t, "done")
write_tsv(pd.DataFrame(var), "c9_pca_variance.tsv")
Gr = {(m, t): ref_rep(fc.EMB, m, t, core, plan["pca_dim"]) for m in ("egnn", "distance_gnn") for t in tags}
rows = []
for m in ("egnn", "distance_gnn"):
    for k in KS:
        kk = min(k, G["primary"].shape[1])
        tr = [(Gr[(m, "primary")], G["primary"][:, :kk])]; fl = [(Gr[(m, t)], G[t][:, :kk]) for t in fc.UNTRAINED_TAGS]
        for state, pl in (("trained_primary", tr), ("untrained_matched_5inits", fl)):
            lo, hi = boot_ci(pl, W); rows.append(dict(pair=f"{m}_x_gnina", k=kk, state=state, cka=mean_cka(pl), ci_lo=lo, ci_hi=hi))
R = pd.DataFrame(rows); write_tsv(R, "c9_pca_truncation.tsv")
print(pd.DataFrame(var).pivot(index="tag", columns="k", values="cumulative_explained_variance").round(3).to_string()); print(R.round(3).to_string())
