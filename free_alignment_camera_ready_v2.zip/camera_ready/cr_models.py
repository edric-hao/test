"""cr_models.py -- the reference EGNN / Distance-GNN of src/embed_utils.py with a selectable pooling (mean = original, max, sum). Shared by t1 and c6."""
import yaml, torch
from cr_common import ROOT
from src import embed_utils as eu

cfg = yaml.safe_load((ROOT / "config" / "config.yaml").read_text())
HP = {"egnn": cfg["training"]["egnn"], "distance_gnn": cfg["training"]["distance_gnn"]}
CUTOFF = float(HP["distance_gnn"].get("cutoff_A", 5.0)); N_RBF = int(HP["distance_gnn"].get("n_rbf", 16)); N_TYPES = 16

def sum_pool(h, batch, n): return h.new_zeros(n, h.size(1)).index_add_(0, batch, h)
def max_pool(h, batch, n):
    return h.new_zeros(n, h.size(1)).scatter_reduce(0, batch[:, None].expand_as(h), h, reduce="amax", include_self=False)
POOL = {"mean": eu.mean_pool, "sum": sum_pool, "max": max_pool}

class EGNNPool(eu.EGNNAffinity):
    def __init__(self, pool, **kw): super().__init__(**kw); self._pool = POOL[pool]
    def forward(self, z, x, edge_index, batch, n_graphs):
        h = self.embed(z)
        for layer in self.layers: h, x = layer(h, x, edge_index)
        return self.readout(self._pool(h, batch, n_graphs)).squeeze(-1)

class DistGNNPool(eu.DistanceGNN):
    def __init__(self, pool, **kw): super().__init__(**kw); self._pool = POOL[pool]
    def forward(self, z, x, edge_index, batch, n_graphs):
        row, col = edge_index
        d = (x[row] - x[col]).norm(dim=-1, keepdim=True); rbf = torch.exp(-self.gamma * (d - self.centers) ** 2); h = self.embed(z)
        for msg, upd in zip(self.msg, self.upd):
            m = msg(torch.cat([h[col], rbf], dim=-1)); agg = torch.zeros_like(h).index_add_(0, row, m); h = h + upd(torch.cat([h, agg], dim=-1))
        return self.readout(self._pool(h, batch, n_graphs)).squeeze(-1)

def make_model(arch, readout):
    if arch == "egnn": return EGNNPool(readout, n_types=N_TYPES, hidden=HP["egnn"]["hidden"], n_layers=HP["egnn"]["n_layers"])
    return DistGNNPool(readout, n_types=N_TYPES, hidden=HP["distance_gnn"]["hidden"], n_layers=HP["distance_gnn"]["n_layers"], n_rbf=N_RBF, cutoff=CUTOFF)

