"""c6_torch_on_sweep_inputs.py -- same inputs, same weights: the ORIGINAL torch untrained EGNN / Distance-GNN (5 inits) run on the sweep's own 1,200 complexes.   (reviewers eCg1, 7BsF)
The NumPy sweep networks are simplified re-implementations (no biases, scaled initialisation, a single-vector coordinate gate), so their weights cannot be copied from the torch models.
What can be tested on identical inputs is (i) whether the sweep's input pipeline (graphs.npz, 10 element classes + ligand flag) gives the original models the same embeddings as their own pipeline
(graph_cache, 16 node types), and (ii) how the original architecture's floor, spectrum and kNN overlap compare with the NumPy base setting when both see the same complexes.
Element classes are mapped to the 8 reference buckets (C N O S P halogens, other -> OTHER; metals are not separated in the sweep archive).
Output: camera_ready_out/c6_torch_on_sweep_inputs.tsv (same layout as c1), c6_input_equivalence.tsv"""
import torch
from cr_common import *
import randnets as rn, sweeplib as sl
from build_graphs import Graphs
import cr_graphs, cr_models as cm
from src import embed_utils as eu, seeds as seedmod

plan = fc.load_plan(); core = fc.core_ids(plan); ids = sl.sweep_ids(plan, core); sw = plan["sweep"]; S = sw["n_seeds"]; kp, kn = sw["pca_k"], sw["knn_k"]
g = Graphs(); g.rows(ids); items = sl.load_items(g, ids)
elems = plan["graphs"]["elements"]; bucket = np.array([cr_graphs.element_bucket(e) for e in elems] + [7])
DEV = torch.device("cuda" if torch.cuda.is_available() else "cpu")
SEEDS = {"untrained": 20260919, "untrained_init2": 20260924, "untrained_init3": 20260925, "untrained_init4": 20260926, "untrained_init5": 20260927}
tags = fc.UNTRAINED_TAGS[:S]

def batches(bs=8):
    for a in range(0, len(items), bs):
        part = items[a:a + bs]; z = torch.cat([torch.tensor(bucket[el] * 2 + lig.astype(int), dtype=torch.long) for _, el, lig in part])
        x = torch.cat([torch.tensor(xyz, dtype=torch.float32) for xyz, _, _ in part]); b = torch.cat([torch.full((len(el),), i, dtype=torch.long) for i, (_, el, _) in enumerate(part)])
        yield z.to(DEV), x.to(DEV), b.to(DEV), len(part)

@torch.no_grad()
def embed(arch, tag):
    seedmod.seed_everything(SEEDS[tag]); m32 = cm.make_model(arch, "mean")
    m64 = cm.make_model(arch, "mean").double().to(DEV); m64.load_state_dict({k: v.double() for k, v in m32.state_dict().items()}); m64.eval()
    rows = []
    for z, x, b, n in batches():
        ei = eu.radius_edges(x, b, cutoff=cm.CUTOFF)
        with eu.PreHeadCapture(m64, "readout.0") as cap: m64(z, x.double(), ei, b, n)
        rows.append(cap.value.cpu().numpy())
    return np.vstack(rows).astype(np.float64)

E = {(a, t): embed(a, t) for a in rn.ARCHS for t in tags}; log("torch embeddings on sweep inputs done")
rows = []
summarise_sets(rows, "torch_original_on_sweep_inputs", {a: [sl.Rep(E[(a, t)], kp, kn) for t in tags] for a in rn.ARCHS}, S, kn)
eq = []
for a in rn.ARCHS:
    for t in tags:
        E0 = raw_test(fc.EMB, a, t, ids); r0, r1 = sl.Rep(E0, kp, kn), sl.Rep(E[(a, t)], kp, kn); pm = sl.pair_metrics(r0, r1, kn)
        eq.append(dict(arch=a, tag=t, cka_graph_cache_vs_sweep_inputs=pm["cka"], knn=pm["knn"], procrustes=pm["procrustes"], max_rel_diff=float(np.abs(E0 - E[(a, t)]).max() / max(np.abs(E0).max(), 1e-12))))
Q = pd.DataFrame(eq); write_tsv(Q, "c6_input_equivalence.tsv"); print(Q.round(4).to_string())
R = pd.DataFrame(rows); write_tsv(R, "c6_torch_on_sweep_inputs.tsv")
c1 = OUT / "c1_real_vs_numpy.tsv"
if c1.exists(): R = pd.concat([pd.read_csv(c1, sep="\t"), R])
print(R.pivot_table(index=["scope", "metric"], columns="source", values="mean").round(3).to_string())
