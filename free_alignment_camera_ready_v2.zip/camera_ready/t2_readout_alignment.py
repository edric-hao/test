"""t2_readout_alignment.py -- trained versus untrained alignment for each readout (mean = existing reference models, max / sum = retrained by t1).
(reviewers WKPN, r29H, eCg1: "27 floors are compared with one trained value")
Per readout, EGNN x Distance-GNN on the core test set, reference protocol (train-fit PCA-64): trained primary x primary CKA, untrained matched floor (5 inits) and
mismatched floor, same-architecture ceilings (primary x anchor), trained minus floor with a cluster-bootstrap CI, normalised alignment n_AB under the paper's rule
(ceiling = smaller of the two same-architecture ceilings; undefined when ceiling - floor < 0.05; an interval is given only if at most 5% of draws are defined),
mutual kNN, top-component diagnostics and test r of each trained model. For max/sum the matching NumPy sweep floor (same readout, base setting) is added for comparison.
Env: READOUTS=max,sum (default: every retrained readout that has embeddings).   Output: camera_ready_out/t2_readout_alignment.tsv"""
import os, itertools
from cr_common import *
import randnets as rn, sweeplib as sl

plan = fc.load_plan(); core = fc.core_ids(plan); W = boot_weights(core, plan, seed_off=88)
A, B = "egnn", "distance_gnn"; tags_u = fc.UNTRAINED_TAGS
sp = fc.split_df(plan); y = sp.loc[core, plan["affinity_column"]].values.astype(float)
want = os.environ.get("READOUTS", "")
labels = [("mean", fc.EMB)] + [(r, ROOT / "data" / f"embeddings_readout_{r}") for r in (want.split(",") if want else ["max", "sum"])]

def draws(pairs): return np.array([mean_cka(pairs, w) for w in W])
def test_r(d, m):
    f = Path(d) / f"{m}_primary_test_pred.npy"
    if not f.exists(): return float("nan")
    ids = [s.lower() for s in (Path(d) / f"{m}_primary_test_ids.txt").read_text().split()]
    return float(np.corrcoef(al.strict_subset(np.load(f).ravel()[:, None], ids, core, "pred")[:, 0], y)[0, 1])

rows = []
for label, d in labels:
    need = [(m, t) for m in (A, B) for t in ["primary", "anchor"] + tags_u]
    miss = [f"{m}/{t}" for m, t in need if not (Path(d) / f"{m}_{t}_test.npy").exists() or not (Path(d) / f"{m}_{t}_train.npy").exists()]
    if miss: log(f"readout {label}: skipped, {len(miss)} embedding sets missing in {d} (e.g. {miss[:3]})"); continue
    R = {(m, t): ref_rep(d, m, t, core, plan["pca_dim"]) for m, t in need}
    tr = [(R[(A, "primary")], R[(B, "primary")])]
    fl = [(R[(A, t)], R[(B, t)]) for t in tags_u]
    mm = [(R[(A, ta)], R[(B, tb)]) for ta, tb in itertools.permutations(tags_u, 2)]
    ca, cb = [(R[(A, "primary")], R[(A, "anchor")])], [(R[(B, "primary")], R[(B, "anchor")])]
    dtr, dfl, dca, dcb = draws(tr), draws(fl), draws(ca), draws(cb)
    obs_tr, obs_fl, obs_ca, obs_cb = mean_cka(tr), mean_cka(fl), mean_cka(ca), mean_cka(cb)
    ceil = min(obs_ca, obs_cb); dceil = np.minimum(dca, dcb)
    dn = np.array([n_ab(a, b, c) for a, b, c in zip(dtr, dfl, dceil)]); defined = np.isfinite(dn).mean()
    row = dict(readout=label, trained_cka=obs_tr, trained_lo=fc.ci(dtr)[0], trained_hi=fc.ci(dtr)[1], floor_cka=obs_fl, floor_lo=fc.ci(dfl)[0], floor_hi=fc.ci(dfl)[1],
               floor_mismatched=mean_cka(mm), trained_minus_floor=obs_tr - obs_fl, tmf_lo=fc.ci(dtr - dfl)[0], tmf_hi=fc.ci(dtr - dfl)[1],
               ceiling_egnn=obs_ca, ceiling_distance_gnn=obs_cb, ceiling_used=ceil, nAB=n_ab(obs_tr, obs_fl, ceil), nAB_share_defined=float(defined),
               nAB_lo=fc.ci(dn)[0] if defined >= 0.95 else float("nan"), nAB_hi=fc.ci(dn)[1] if defined >= 0.95 else float("nan"),
               trained_knn=al.mutual_knn(R[(A, "primary")], R[(B, "primary")], 10, center=True)[1], floor_knn=float(np.mean([al.mutual_knn(a, b, 10, center=True)[1] for a, b in fl])),
               trained_top1_only=mean_cka([(a[:, :1], b[:, :1]) for a, b in tr]), trained_remove_top1=mean_cka([(a[:, 1:], b[:, 1:]) for a, b in tr]),
               floor_top1_only=mean_cka([(a[:, :1], b[:, :1]) for a, b in fl]), floor_remove_top1=mean_cka([(a[:, 1:], b[:, 1:]) for a, b in fl]),
               test_r_egnn=test_r(d, A), test_r_distance_gnn=test_r(d, B))
    for m in (A, B):
        for nm, X in (("trained", R[(m, "primary")]), ("untrained", R[(m, "untrained")])):
            s = spectrum(X); row[f"{nm}_pr_{m}"] = s["pr"]; row[f"{nm}_top1_{m}"] = s["top1"]
    rows.append(row); log(f"readout {label}: trained {obs_tr:.3f} floor {obs_fl:.3f} ceiling {ceil:.3f} n_AB {row['nAB']:.3f}")
    if label != "mean":    # matching NumPy sweep floor, sweep protocol on the sweep complexes
        from build_graphs import Graphs
        ids = sl.sweep_ids(plan, core); sw = plan["sweep"]; cfg = {**sw["base"], "readout": label}; G = {}
        def emb(arch, s):
            p = sl.emb_path(plan, cfg, arch, s)
            if p.exists(): return np.load(p)
            if not G: g = Graphs(); g.rows(ids); G.update(g=g, items=sl.load_items(g, ids))
            return sl.get_embedding(plan, cfg, arch, s, G["items"], G["g"].n_elem)
        S = sw["n_seeds"]; Rn = {a: [sl.Rep(emb(a, s), sw["pca_k"], sw["knn_k"]) for s in range(S)] for a in rn.ARCHS}
        pm = [sl.pair_metrics(Rn["egnn"][i], Rn["distance_gnn"][i], sw["knn_k"]) for i in range(S)]
        rows.append(dict(readout=f"{label}_numpy_sweep_floor", floor_cka=float(np.mean([p["cka"] for p in pm])), floor_knn=float(np.mean([p["knn"] for p in pm]))))
R_ = pd.DataFrame(rows); write_tsv(R_, "t2_readout_alignment.tsv"); print(R_.T.round(3).to_string())
