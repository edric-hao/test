#!/bin/bash
# run_all.sh -- every check and retraining for the camera-ready, in order of cost, each step logged. A failing step is reported and the next one still runs
# (only preflight stops everything, and a failed smoke test stops the retraining that depends on it).
# Usage (from the folder that contains camera_ready/):   nohup bash camera_ready/run_all.sh > run_all.log 2>&1 &
# Options (environment variables, put them before "bash"):
#   PROJECT_ROOT=/path    project root (folder with data/ findings/ src/); auto-detected when unset
#   RUN_TRAIN=0           skip ALL GPU retraining and the analyses that need it
#   RUN_TRAIN_MAX=0       skip the max-readout retraining        RUN_TRAIN_NULLS=0  skip shuffled / size-only target training
#   RUN_TRAIN_SEEDS=0     skip the extra training seeds           EXTRA_SEEDS=2      number of extra seeds per architecture (1-8)
#   READOUTS=max          readouts to retrain (max,sum)           INCLUDE_GNINA=0    skip the voxel model in c3 and c8
#   CR_NBOOT=200 CR_NPERM=500   bootstrap draws and permutations
HERE="$(cd "$(dirname "$0")" && pwd)"
cd "$HERE" || exit 1
export READOUTS="${READOUTS:-max}"
EXTRA_SEEDS="${EXTRA_SEEDS:-2}"
EXTRA_ARMS=$(python3 -c "print(','.join('extra%d' % i for i in range(1, int('$EXTRA_SEEDS') + 1)))")
mkdir -p "$HERE/logs_tmp"
run() {  # run <name> <command...>
  name="$1"; shift
  echo "=== $(date +%H:%M:%S) START $name"
  "$@" > "$HERE/logs_tmp/$name.log" 2>&1
  rc=$?
  echo "=== $(date +%H:%M:%S) END   $name  exit=$rc  (log: camera_ready/logs_tmp/$name.log)"
  return $rc
}
run preflight python3 preflight.py || { echo "preflight failed, fix the MISSING items:"; tail -30 "$HERE/logs_tmp/preflight.log"; exit 1; }

# ---- analyses that need no training (CPU)
run c5_network_count          python3 c5_network_count.py
run c1_real_vs_numpy          python3 c1_real_vs_numpy.py
run c2_coord_update           python3 c2_coord_update.py
run c3_trained_components     python3 c3_trained_components.py
run c8_alternative_nulls      python3 c8_alternative_nulls.py
run c7_composition            python3 c7_composition_residualisation.py
run c6_torch_on_sweep_inputs  python3 c6_torch_on_sweep_inputs.py

# ---- retraining (GPU), most valuable first
if [ "${RUN_TRAIN:-1}" = "1" ]; then
  # pipeline check: untrained mean-readout models rebuilt here must reproduce the original untrained embeddings (no training, extraction only)
  run t1_pipeline_check python3 t1_train_maxreadout.py --readouts mean --arms untrained,untrained_init2
  if [ "${RUN_TRAIN_MAX:-1}" = "1" ]; then
    if run t1_smoke_readout python3 t1_train_maxreadout.py --smoke --arms primary,untrained --readouts "$READOUTS"; then
      run t1_train_readout python3 t1_train_maxreadout.py --readouts "$READOUTS"
      run t2_readout_alignment python3 t2_readout_alignment.py
    else echo "smoke test (readout) failed: retraining skipped, read camera_ready/logs_tmp/t1_smoke_readout.log"; fi
  fi
  if [ "${RUN_TRAIN_NULLS:-1}" = "1" ]; then
    if run t1_smoke_shuffled python3 t1_train_maxreadout.py --smoke --readouts mean --target shuffled --arms primary && run t1_smoke_sizeonly python3 t1_train_maxreadout.py --smoke --readouts mean --target sizeonly --arms primary; then
      run t1_train_shuffled python3 t1_train_maxreadout.py --readouts mean --target shuffled --arms primary,anchor
      run t1_train_sizeonly python3 t1_train_maxreadout.py --readouts mean --target sizeonly --arms primary,anchor
    else echo "smoke test (null targets) failed: skipped, read camera_ready/logs_tmp/t1_smoke_shuffled.log and t1_smoke_sizeonly.log"; fi
  fi
  if [ "${RUN_TRAIN_SEEDS:-1}" = "1" ]; then
    run t1_train_extra_seeds python3 t1_train_maxreadout.py --readouts mean --arms "$EXTRA_ARMS"
  fi
  run t4_targets_and_seeds python3 t4_targets_and_seeds.py
fi

# ---- collect the small outputs into one zip to download
python3 - <<'PY'
import os, sys, zipfile
sys.path.insert(0, ".")
from cr_common import ROOT, OUT
z = ROOT / "camera_ready_results.zip"
with zipfile.ZipFile(z, "w", zipfile.ZIP_DEFLATED) as f:
    for dp, _, fn in os.walk(OUT):
        for n in sorted(fn): f.write(os.path.join(dp, n), "camera_ready_out/" + os.path.relpath(os.path.join(dp, n), OUT))
    for n in sorted(os.listdir("logs_tmp")): f.write(os.path.join("logs_tmp", n), "logs_tmp/" + n)
print("results zip:", z, round(z.stat().st_size / 1e6, 2), "MB")
PY
echo "ALL STEPS FINISHED $(date +%H:%M:%S)"
