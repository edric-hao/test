"""preflight.py -- checks that everything the camera-ready scripts need is present, and says exactly what is missing. Exit code 1 only for fatal problems."""
import importlib, os, shutil
from cr_common import *
fatal, warn = [], []
def need(ok, msg, fatal_=True):
    print(("OK    " if ok else ("MISSING" if fatal_ else "WARN   ")), msg)
    if not ok: (fatal if fatal_ else warn).append(msg)
print("project root:", ROOT)
plan = fc.load_plan()
for pth in ["findings/fcommon.py", "findings/randnets.py", "findings/sweeplib.py", "findings/build_graphs.py", "src/alignlib.py", "src/embed_utils.py", "src/seeds.py", "config/config.yaml",
            plan["split_file"], plan["cluster_file"], plan["covariates_file"]]:
    need((ROOT / pth).exists(), pth)
need((ROOT / "findings_out" / "graphs.npz").exists(), "findings_out/graphs.npz (only c1 and c2 need it; without it those two steps fail and the rest still runs)", fatal_=False)
for m in fc.MODELS:
    for t in ["primary", "anchor"] + fc.UNTRAINED_TAGS:
        for s in ("train", "test"):
            f = ROOT / "data" / "embeddings" / f"{m}_{t}_{s}.npy"
            if not f.exists(): need(False, f"data/embeddings/{m}_{t}_{s}.npy", fatal_=(m != "gnina"))
    need((ROOT / "data" / "embeddings" / f"{m}_primary_test_pred.npy").exists(), f"{m} test predictions", fatal_=False)
try:
    core = fc.core_ids(plan); print(f"OK     core set: {len(core)} complexes")
except Exception as e: need(False, f"core set: {e}")
import numpy, scipy, sklearn
print("versions: numpy", numpy.__version__, "scipy", scipy.__version__, "sklearn", sklearn.__version__, "(the original run used numpy 1.26.4; the sweep's random weights can depend on the NumPy version)")
try:
    import torch; print("torch", torch.__version__, "| cuda:", torch.cuda.is_available())
    need(torch.cuda.is_available(), "GPU for c6 and the retraining (CPU works but the retraining is far slower)", fatal_=False)
except ImportError: need(False, "torch (needed only for t1 retraining)", fatal_=False)
gc = ROOT / "data" / "graph_cache"; n = sum(1 for f in os.listdir(gc) if f.endswith(".pt")) if gc.exists() else 0
need(n > 0, f"data/graph_cache with {n} cached graphs (else t1 rebuilds them from PDBbind_2020 and needs rdkit)", fatal_=False)
if n == 0:
    try: importlib.import_module("rdkit"); print("OK     rdkit available")
    except ImportError: need(False, "rdkit (needed to rebuild graphs because graph_cache is empty)", fatal_=False)
print("disk free (GB):", round(shutil.disk_usage(ROOT).free / 1e9, 1))
print("\nFATAL:", fatal if fatal else "none"); print("warnings:", warn if warn else "none")
sys.exit(1 if fatal else 0)
