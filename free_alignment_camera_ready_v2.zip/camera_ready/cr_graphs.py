"""cr_graphs.py -- fallback graph builder for the retraining step, identical to notebook_2a (cells 7-8): 16 node types = 8 element buckets x {protein, ligand}.
Used only for complexes missing from data/graph_cache/. Needs rdkit and the PDBbind_2020 folder."""
from pathlib import Path
import torch

ELEMENT_BUCKETS = ["C", "N", "O", "S", "P", "HAL", "METAL", "OTHER"]
HALOGENS = {"F", "CL", "BR", "I"}
METALS = {"ZN", "MG", "CA", "MN", "FE", "NA", "K", "CU", "NI", "CO", "CD", "HG", "MO"}

def element_bucket(sym):
    s = sym.strip().upper()
    if s == "C": return 0
    if s == "N": return 1
    if s == "O": return 2
    if s == "S": return 3
    if s == "P": return 4
    if s in HALOGENS: return 5
    if s in METALS: return 6
    return 7

def node_type(sym, is_ligand): return element_bucket(sym) * 2 + (1 if is_ligand else 0)

def parse_pocket_heavy_atoms(pdb_path):
    out = []
    for line in open(pdb_path):
        if not line.startswith(("ATOM", "HETATM")): continue
        if line[17:20].strip() in ("HOH", "WAT", "H2O"): continue
        el = line[76:78].strip() if len(line) >= 78 else ""
        if not el: el = line[12:16].strip().lstrip("0123456789")[:1]
        if el.upper() in ("H", "D") or not el: continue
        try: out.append((el, float(line[30:38]), float(line[38:46]), float(line[46:54])))
        except ValueError: continue
    return out

def parse_ligand_heavy_atoms(path):
    from rdkit import Chem, RDLogger
    RDLogger.DisableLog("rdApp.*")
    path = str(path)
    m = Chem.SDMolSupplier(path, removeHs=False, sanitize=False)[0] if path.endswith(".sdf") else Chem.MolFromMol2File(path, removeHs=False, sanitize=False)
    if m is None or m.GetNumConformers() == 0: raise ValueError(f"ligand unreadable: {path}")
    conf = m.GetConformer()
    return [(a.GetSymbol(), conf.GetAtomPosition(a.GetIdx()).x, conf.GetAtomPosition(a.GetIdx()).y, conf.GetAtomPosition(a.GetIdx()).z) for a in m.GetAtoms() if a.GetAtomicNum() > 1]

def build_graph(pdbbind_dir, pid, y):
    d = Path(pdbbind_dir) / pid
    pocket = d / f"{pid}_pocket.pdb"; lig = d / f"{pid}_ligand.sdf"
    if not lig.exists(): lig = d / f"{pid}_ligand.mol2"
    if not pocket.exists() or not lig.exists(): raise FileNotFoundError(f"missing pocket/ligand files for {pid}")
    prot, ligs = parse_pocket_heavy_atoms(pocket), parse_ligand_heavy_atoms(lig)
    if not prot or not ligs: raise ValueError(f"empty atom list for {pid}")
    zs = [node_type(e, False) for e, *_ in prot] + [node_type(e, True) for e, *_ in ligs]
    xs = [(x, y_, z) for _, x, y_, z in prot] + [(x, y_, z) for _, x, y_, z in ligs]
    return torch.tensor(zs, dtype=torch.long), torch.tensor(xs, dtype=torch.float32), float(y)
