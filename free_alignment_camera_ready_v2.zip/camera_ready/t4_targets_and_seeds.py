"""t4_targets_and_seeds.py -- trained pairs under null training targets, and variability over training seeds.   (reviewers r29H, WKPN)
Part A: EGNN x Distance-GNN trained on (i) the real affinity, (ii) affinity shuffled within each split, (iii) the OLS size-only prediction. CKA of the pair, same-architecture ceilings
        (primary x anchor), the cross-target CKA with the real-affinity models, test r on the trained target, all against the untrained floor of the reference models (mean readout).
        Needs t1 runs with --target shuffled / sizeonly (folders data/embeddings_readout_mean_shuffled, _sizeonly).
Part B: all (EGNN seed i x Distance-GNN seed j) trained pairs over the seeds primary, anchor and extra1..extraN (data/embeddings_readout_mean from t1 --readouts mean --arms extra1,...),
        with the same-architecture seed-to-seed CKA and the untrained floor.   Output: t4_targets.tsv, t4_seed_pairs.tsv, t4_seed_summary.tsv"""
import itertools, os
from cr_common import *

plan = fc.load_plan(); core = fc.core_ids(plan); W = boot_weights(core, plan, seed_off=66); A, B = "egnn", "distance_gnn"
floor_pairs = [(ref_rep(fc.EMB, A, t, core, plan["pca_dim"]), ref_rep(fc.EMB, B, t, core, plan["pca_dim"])) for t in fc.UNTRAINED_TAGS]
floor = mean_cka(floor_pairs); dfloor = np.array([mean_cka(floor_pairs, w) for w in W])
y = fc.split_df(plan).loc[core, plan["affinity_column"]].values.astype(float)

def test_r(d, m, arm, target_y):
    f = Path(d) / f"{m}_{arm}_test_pred.npy"
    if not f.exists(): return float("nan")
    ids = [s.lower() for s in (Path(d) / f"{m}_{arm}_test_ids.txt").read_text().split()]
    return float(np.corrcoef(al.strict_subset(np.load(f).ravel()[:, None], ids, core, "pred")[:, 0], target_y)[0, 1])

# ---------------- Part A
dirs = {"real_affinity": fc.EMB, "shuffled_affinity": ROOT / "data" / "embeddings_readout_mean_shuffled", "size_only_target": ROOT / "data" / "embeddings_readout_mean_sizeonly"}
rep = {}
for name, d in dirs.items():
    try: rep[name] = {(m, t): ref_rep(d, m, t, core, plan["pca_dim"]) for m in (A, B) for t in ("primary", "anchor")}
    except FileNotFoundError as e: log(f"target {name}: skipped ({e})")
rows = []
for name, R in rep.items():
    tr, ca, cb = [(R[(A, "primary")], R[(B, "primary")])], [(R[(A, "primary")], R[(A, "anchor")])], [(R[(B, "primary")], R[(B, "anchor")])]
    dtr = np.array([mean_cka(tr, w) for w in W])
    row = dict(target=name, trained_pair_cka=mean_cka(tr), lo=fc.ci(dtr)[0], hi=fc.ci(dtr)[1], floor_cka=floor, trained_minus_floor=mean_cka(tr) - floor,
               tmf_lo=fc.ci(dtr - dfloor)[0], tmf_hi=fc.ci(dtr - dfloor)[1], ceiling_egnn=mean_cka(ca), ceiling_distance_gnn=mean_cka(cb),
               test_r_egnn=test_r(dirs[name], A, "primary", y if name == "real_affinity" else np.full(len(core), np.nan)), pr_egnn=spectrum(R[(A, "primary")])["pr"], top1_egnn=spectrum(R[(A, "primary")])["top1"])
    if name != "real_affinity" and "real_affinity" in rep:
        r0 = rep["real_affinity"]; row["cka_egnn_vs_real_trained_egnn"] = al.cka_feature(R[(A, "primary")], r0[(A, "primary")]); row["cka_distance_gnn_vs_real_trained_distance_gnn"] = al.cka_feature(R[(B, "primary")], r0[(B, "primary")])
    rows.append(row); log(f"target {name}: pair CKA {row['trained_pair_cka']:.3f} (floor {floor:.3f})")
T = pd.DataFrame(rows); write_tsv(T, "t4_targets.tsv"); print(T.T.round(3).to_string())

# ---------------- Part B
mdir = ROOT / "data" / "embeddings_readout_mean"
def seed_rep(m, arm):
    d = fc.EMB if arm in ("primary", "anchor") else mdir
    return ref_rep(d, m, arm, core, plan["pca_dim"])
arms = ["primary", "anchor"] + [f"extra{i}" for i in range(1, 9) if all((mdir / f"{m}_extra{i}_{s}.npy").exists() for m in (A, B) for s in ("train", "test"))]
log("seeds available:", arms)
RS = {(m, a): seed_rep(m, a) for m in (A, B) for a in arms}
pairs_ = [dict(egnn_seed=a, distance_gnn_seed=b, cka=al.cka_feature(RS[(A, a)], RS[(B, b)])) for a in arms for b in arms]
same = [dict(arch=m, seed_a=a, seed_b=b, cka=al.cka_feature(RS[(m, a)], RS[(m, b)])) for m in (A, B) for a, b in itertools.combinations(arms, 2)]
P = pd.DataFrame(pairs_); S_ = pd.DataFrame(same); write_tsv(P, "t4_seed_pairs.tsv"); write_tsv(S_, "t4_seed_same_architecture.tsv")
summ = dict(n_seeds=len(arms), n_cross_pairs=len(P), cross_min=P.cka.min(), cross_median=P.cka.median(), cross_max=P.cka.max(), floor=floor, share_cross_pairs_below_floor=float((P.cka < floor).mean()),
            same_arch_min=S_.cka.min(), same_arch_median=S_.cka.median(), same_arch_max=S_.cka.max())
write_tsv(pd.DataFrame([summ]), "t4_seed_summary.tsv"); print(pd.DataFrame([summ]).T.round(3).to_string()); print(P.pivot(index="egnn_seed", columns="distance_gnn_seed", values="cka").round(3).to_string())
