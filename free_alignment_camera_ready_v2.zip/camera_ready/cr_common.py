"""cr_common.py -- shared setup for the camera-ready scripts.

These scripts ADD files next to the existing project. They never edit findings/, src/ or data/, so the plan lock, the
freeze tag and the code hash of the original runs stay valid. All outputs go to <project root>/camera_ready_out/
(tables, logs) and, for the retrained models only, <project root>/data/embeddings_readout_<readout>/.

Project root: PROJECT_ROOT env var, else the current directory, else its parent, else the parent of this folder,
else /home/ec2-user/SageMaker/pdbbind_data. A root is accepted when it has data/embeddings and findings/.
"""
import os, sys, json, time
from pathlib import Path

def _find_root():
    here = Path(__file__).resolve().parent
    cand = []
    if os.environ.get("PROJECT_ROOT"): cand.append(Path(os.environ["PROJECT_ROOT"]))
    cand += [Path.cwd(), Path.cwd().parent, here.parent, Path("/home/ec2-user/SageMaker/pdbbind_data")]
    for p in cand:
        if (p / "data" / "embeddings").exists() and (p / "findings").exists():
            return p.resolve()
    sys.exit("camera_ready: project root not found. Set PROJECT_ROOT=<folder containing data/ findings/ src/>. Tried: "
             + ", ".join(str(c) for c in cand))

ROOT = _find_root()
os.environ["PROJECT_ROOT"] = str(ROOT)
for _p in (str(ROOT / "findings"), str(ROOT)):
    if _p in sys.path: sys.path.remove(_p)
    sys.path.insert(0, _p)

import numpy as np, pandas as pd
import fcommon as fc
al = fc.al
if not hasattr(al, "PCA"):          # the GitHub copy of src/alignlib.py uses PCA without importing it; patched in memory only
    from sklearn.decomposition import PCA as _PCA
    al.PCA = _PCA
OUT = ROOT / "camera_ready_out"; OUT.mkdir(exist_ok=True)
(OUT / "logs").mkdir(exist_ok=True)
N_BOOT = int(os.environ.get("CR_NBOOT", "200"))

def write_tsv(df, name):
    p = OUT / name; df.to_csv(p, sep="\t", index=False); print(f"wrote {p}"); return p

def log(*a):
    print(time.strftime("%H:%M:%S"), *a, flush=True)

# ----------------------------------------------------------------------------- embeddings (any directory)
def load_emb(emb_dir, model, tag, split):
    npy, idf = Path(emb_dir) / f"{model}_{tag}_{split}.npy", Path(emb_dir) / f"{model}_{tag}_{split}_ids.txt"
    if not npy.exists(): return None, None
    E = np.load(npy).astype(np.float64)
    ids = [s.lower() for s in idf.read_text().split()]
    assert len(ids) == E.shape[0], f"{npy.name}: {len(ids)} ids vs {E.shape[0]} rows"
    return E, ids

_REF = {}
def ref_rep(emb_dir, model, tag, core, k=64):
    """Reference-model representation: PCA-k fit on TRAIN embeddings only (centred, no z-score), applied to the core test rows.
    Columns are principal components in order of decreasing train variance."""
    key = (str(emb_dir), model, tag, k, len(core), core[0], core[-1])
    if key in _REF: return _REF[key]
    Etr, _ = load_emb(emb_dir, model, tag, "train")
    Ete, ite = load_emb(emb_dir, model, tag, "test")
    if Etr is None or Ete is None: raise FileNotFoundError(f"missing embeddings {model}/{tag} in {emb_dir}")
    mu, pca = al.pca_train_fit(Etr, k, name=f"{model}/{tag}")
    _REF[key] = pca.transform(al.strict_subset(Ete, ite, core, f"{model}/{tag}") - mu)
    return _REF[key]

def raw_test(emb_dir, model, tag, ids):
    Ete, ite = load_emb(emb_dir, model, tag, "test")
    return al.strict_subset(Ete, ite, ids, f"{model}/{tag}")

# ----------------------------------------------------------------------------- spectrum
def spectrum(X):
    """Participation ratio and share of the leading component of the centred embedding."""
    X = np.asarray(X, np.float64); X = X - X.mean(0)
    ev = np.linalg.svd(X, compute_uv=False) ** 2
    tot = ev.sum()
    if tot <= 0: return dict(pr=0.0, top1=float("nan"), top3=float("nan"))
    return dict(pr=float(tot ** 2 / (ev ** 2).sum()), top1=float(ev[0] / tot), top3=float(ev[:3].sum() / tot))

# ----------------------------------------------------------------------------- bootstrap
def boot_weights(core_ids_, plan, n_boot=None, seed_off=77):
    groups = fc.clusters(plan, core_ids_)
    rng = np.random.default_rng(plan["seed"] + seed_off)
    return [al.boot_weights(len(core_ids_), rng, groups) for _ in range(n_boot or N_BOOT)]

def mean_cka(pairs, w=None):
    v = [al.cka_feature(a, b) if w is None else al.cka_feature_w(a, b, w) for a, b in pairs]
    return float(np.nanmean(v))

def boot_ci(pairs, W, level=0.95):
    """Percentile CI of the mean debiased CKA over `pairs` (list of (XA, XB)); one cluster-bootstrap draw per entry of W."""
    return fc.ci(np.array([mean_cka(pairs, w) for w in W]), level)

def n_ab(obs, floor, ceil, min_gap=0.05):
    """Normalised alignment under the paper's rule: undefined when ceiling - floor < min_gap."""
    gap = ceil - floor
    return float("nan") if gap < min_gap else float((obs - floor) / gap)

# ----------------------------------------------------------------------------- summary of two sets of S representations (shared by c1 and c6)
def add_row(rows, source, scope, metric, vals):
    v = np.asarray(vals, float)
    rows.append(dict(source=source, scope=scope, metric=metric, mean=float(np.nanmean(v)), sd=float(np.nanstd(v)), n=int(np.isfinite(v).sum())))

def summarise_sets(rows, source, R, S, kn):
    """R = {'egnn': [sl.Rep]*S, 'distance_gnn': [sl.Rep]*S}. Matched and all-pairs cross-architecture CKA / kNN / Procrustes, within-architecture values, spectra."""
    import itertools, randnets as rn, sweeplib as sl
    m = [sl.pair_metrics(R["egnn"][i], R["distance_gnn"][i], kn) for i in range(S)]
    a = [sl.pair_metrics(R["egnn"][i], R["distance_gnn"][j], kn) for i in range(S) for j in range(S)]
    for k in ("cka", "knn", "procrustes"):
        add_row(rows, source, "cross_matched", k, [x[k] for x in m]); add_row(rows, source, "cross_all25", k, [x[k] for x in a])
        for arch in rn.ARCHS:
            add_row(rows, source, f"within_{arch}", k, [sl.pair_metrics(R[arch][i], R[arch][j], kn)[k] for i, j in itertools.combinations(range(S), 2)])
    for arch in rn.ARCHS:
        sp = [spectrum(r.X) for r in R[arch]]
        for k in ("pr", "top1", "top3"): add_row(rows, source, f"spectrum_{arch}", k, [s_[k] for s_ in sp])
