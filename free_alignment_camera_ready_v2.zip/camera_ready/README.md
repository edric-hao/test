# camera_ready: extra checks and retraining for the Free Alignment paper

These scripts only ADD files. They never edit `findings/`, `src/`, `config/` or `data/`, so the plan lock, the freeze tag and the code hash of the original runs stay valid.
Results go to `camera_ready_out/` (tables, logs). Retrained models go to `data/embeddings_readout_<readout>[_<target>]/`. `camera_ready_results.zip` in the project root collects the small outputs.

## Run (AWS terminal, same Python environment as the earlier runs)
```
cd <project root>                 # the folder that contains data/ findings/ src/ config/
python3 -m zipfile -e free_alignment_camera_ready.zip .
nohup bash camera_ready/run_all.sh > run_all.log 2>&1 &
tail -f run_all.log
```
Switches (environment variables, placed before `bash`): `RUN_TRAIN=0` (no GPU training at all), `RUN_TRAIN_MAX=0`, `RUN_TRAIN_NULLS=0`, `RUN_TRAIN_SEEDS=0`, `EXTRA_SEEDS=2`, `READOUTS=max,sum`, `INCLUDE_GNINA=0`, `CR_NBOOT=200`, `CR_NPERM=500`, `PROJECT_ROOT=...`.
Every step also runs on its own, for example `python3 camera_ready/c2_coord_update.py`. Finished training arms are skipped on a rerun and interrupted ones resume.
Order: CPU analyses first (c5, c1, c2, c3, c8, c7, c6), then training in order of value: pipeline check, max readout, null targets, extra seeds, then their analyses.

## Steps and what they answer
| step | question (reviewer) | outputs in camera_ready_out/ |
|---|---|---|
| `c5_network_count` | 260 vs 270 (and 825 vs 870) networks | `c5_network_count.tsv` |
| `c1_real_vs_numpy` | real untrained models vs NumPy base on the same 1,200 complexes: CKA, kNN, Procrustes, within-architecture CKA, participation ratio, leading-component share (eCg1, 7BsF) | `c1_real_vs_numpy.tsv` |
| `c2_coord_update` | EGNN coordinate update vs frozen coordinates with identical weights, atom displacement per layer, cross-architecture CKA for both; self-test against `findings/randnets.py` (all four) | `c2_coord_update.tsv`, `c2_coord_displacement.tsv` |
| `c3_trained_components` | CKA after removing the top 1/2/3 components and on the top components alone for trained pairs, untrained pairs and ceilings; prediction r and r^2 vs CKA; embedding vs own prediction (r29H) | `c3_components.tsv`, `c3_spectra.tsv`, `c4_outputs_vs_cka.tsv`, `c4_per_model.tsv` |
| `c8_alternative_nulls` | trained vs own initialisation, trained vs the other architecture's untrained network, plain and size-stratified permutation nulls (r29H) | `c8_alternative_nulls.tsv`, `c8_permutation_nulls.tsv` |
| `c7_composition_residualisation` | does the floor survive residualising on element composition, degree and distance histograms? All settings of the sweep and the real models (r29H) | `c7_composition_sweep.tsv`, `c7_composition_real.tsv` |
| `c6_torch_on_sweep_inputs` | original torch untrained models on the sweep's inputs: do both input pipelines give the same embeddings, and how do spectrum, kNN and floor compare with the NumPy base (eCg1, 7BsF) | `c6_torch_on_sweep_inputs.tsv`, `c6_input_equivalence.tsv` |
| `t1` pipeline check | untrained mean-readout models rebuilt here vs the original untrained embeddings (line `CHECK` in the log) | `logs/train_*.json` |
| `t1` + `t2_readout_alignment` | trained vs untrained floor with max readout (and sum if requested): CI, n_AB, ceilings, kNN, top-component diagnostics, matching NumPy floor (WKPN, r29H, eCg1) | `t2_readout_alignment.tsv` |
| `t1` + `t4_targets_and_seeds` | trained pair under shuffled-affinity and size-only targets; all EGNN-seed x Distance-GNN-seed pairs and the untrained floor (r29H, WKPN) | `t4_targets.tsv`, `t4_seed_pairs.tsv`, `t4_seed_same_architecture.tsv`, `t4_seed_summary.tsv` |

## Notes and limits
* Not covered: a third message-passing architecture (7BsF), which is a separate project.
* Retraining differs from notebook_2a in two small ways: the radius graph is built on the GPU (same 5 A cutoff, float32 coordinates), and embeddings are extracted in batches of 8 in float64 instead of batch size 1. The pipeline check quantifies the effect.
* The NumPy sweep networks are simplified re-implementations of the torch models (no biases, scaled initialisation, single-vector coordinate gate), so weights cannot be copied between them. c6 therefore compares behaviour on identical inputs.
* c7 residualises in-sample on the complexes it evaluates (about 40 covariates for 1,200 complexes). `var_explained_*` in the table shows how much embedding variance the covariates absorb.
* Extra seeds (extra1 to extra8) are additional training seeds that were not pre-registered. Report them as such.
* `src/alignlib.py` in the GitHub copy uses `PCA` without importing it. The scripts patch this in memory only.
* Last-layer coordinate displacement in `c2_coord_displacement.tsv` is listed for completeness but cannot influence the embedding, because the update after the final layer feeds nothing.
* If `findings_out/graphs.npz` is missing, c1, c2, c6, c7 fail and the rest still runs. c7 part B and the training need `data/graph_cache` (or PDBbind_2020 with rdkit).
* c7 and c6 use the sweep cache under `findings_out/sweep_cache/<plan hash>/`. Missing embeddings are computed in parallel, which takes time (about 40 s per network at the base setting).
