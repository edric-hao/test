"""c7_composition_residualisation.py -- does the untrained floor survive residualising on the full composition of the complex?   (reviewer r29H)
Covariates: size2 = (atom count, ligand atom count) as in the paper; comp = size2 + element counts of pocket and ligand; full = comp + degree histogram + edge-distance histogram (5 A).
Part A (NumPy sweep, all settings in findings_out/res_sweep_configs.tsv): untrained cross-architecture matched CKA / kNN for raw embeddings and after OLS residualisation (within the 1,200 complexes).
Part B (real models): reference protocol with residualisation BEFORE the train-fit PCA-64 (alignlib.resid_then_pca), trained pair and untrained floor, features computed from data/graph_cache.
Env: C7_MAX_SETTINGS=N limits part A to the first N settings; C7_SKIP_REAL=1 skips part B.   Output: c7_composition_sweep.tsv, c7_composition_real.tsv"""
import os
from scipy.spatial import cKDTree
from cr_common import *
import randnets as rn, sweeplib as sl

plan = fc.load_plan(); core = fc.core_ids(plan); sw = plan["sweep"]; S = sw["n_seeds"]; kp, kn = sw["pca_k"], sw["knn_k"]
EDGE_R = 5.0

def features(cls, lig, xyz, n_cls):
    n = len(xyz); counts = np.zeros(2 * n_cls); np.add.at(counts, cls * 2 + lig.astype(int), 1)
    pr = cKDTree(xyz).query_pairs(EDGE_R, output_type="ndarray")
    d = np.linalg.norm(xyz[pr[:, 0]] - xyz[pr[:, 1]], axis=1) if len(pr) else np.zeros(0)
    deg = np.bincount(pr.ravel(), minlength=n) if len(pr) else np.zeros(n)
    return dict(size2=np.array([n, lig.sum()], float), comp=counts, deg=np.histogram(deg, bins=[0, 4, 8, 12, 16, 20, 24, 28, 1e9])[0].astype(float),
                dist=np.histogram(d, bins=np.linspace(0, EDGE_R, 11))[0].astype(float))
VARIANTS = {"size2": ["size2"], "comp": ["size2", "comp"], "full": ["size2", "comp", "deg", "dist"]}
def design(F, names):
    """Intercept + z-scored non-constant columns of the requested feature blocks."""
    M = np.hstack([np.vstack([f[k] for f in F]) for k in names]); sd = M.std(0); M = M[:, sd > 1e-9]; M = (M - M.mean(0)) / M.std(0)
    return np.c_[np.ones(len(M)), M]

# ------------------------------------------------------------------ Part A: NumPy sweep
from build_graphs import Graphs
ids = sl.sweep_ids(plan, core); g = Graphs(); g.rows(ids); items = sl.load_items(g, ids)
FA = [features(el, lig.astype(int), xyz, g.n_elem + 1) for xyz, el, lig in items]
ZA = {v: design(FA, n) for v, n in VARIANTS.items()}
cf = next((p_ for p_ in (fc.OUT / "res_r1_settings.tsv", fc.OUT / "res_sweep_configs.tsv") if p_.exists()), None)
log("settings table:", cf)
cfgs = [dict(r) for _, r in pd.read_csv(cf, sep="\t").iterrows()] if cf else [dict(plan["sweep"]["base"])]
cfgs = [{**{k: (int(r[k]) if k in ("width", "depth", "n_rbf") else float(r[k]) if k in ("radius", "gain") else r[k]) for k in rn.CFG_KEYS}} for r in cfgs]
cfgs = cfgs[:int(os.environ.get("C7_MAX_SETTINGS", len(cfgs)))]
# compute, in parallel, only the sweep embeddings that are not cached yet (cache folder = findings_out/sweep_cache/<plan hash>)
from joblib import Parallel, delayed
todo = {}
for cfg in cfgs:
    for a_ in rn.ARCHS:
        for s_ in range(S):
            p_ = sl.emb_path(plan, cfg, a_, s_)
            if not p_.exists(): todo[p_] = (cfg, a_, s_)
log(f"{len(todo)} sweep embeddings missing from the cache" + (" -> computing" if todo else ""))
Parallel(n_jobs=sw["n_jobs"], verbose=5)(delayed(sl.get_embedding)(plan, c_, a_, s_, items, g.n_elem) for c_, a_, s_ in todo.values())
rows = []
for cfg in cfgs:
    Es = {a: [sl.get_embedding(plan, cfg, a, s, items, g.n_elem) for s in range(S)] for a in rn.ARCHS}
    row = dict(cfg_id=rn.cfg_id(cfg, "distance_gnn"), **{k: cfg[k] for k in rn.CFG_KEYS})
    for v in ["raw"] + list(VARIANTS):
        T = (lambda E: E) if v == "raw" else (lambda E, v=v: al.ols_resid(E, ZA[v]))
        reps = {a: [sl.Rep(T(E), kp, kn) for E in Es[a]] for a in rn.ARCHS}
        pm = [sl.pair_metrics(reps["egnn"][i], reps["distance_gnn"][i], kn) for i in range(S)]
        row[f"cka_{v}"] = float(np.mean([p["cka"] for p in pm])); row[f"knn_{v}"] = float(np.mean([p["knn"] for p in pm]))
    for v in VARIANTS:
        ev = [1 - (al.ols_resid(E, ZA[v]) ** 2).sum() / ((E - E.mean(0)) ** 2).sum() for a in rn.ARCHS for E in Es[a]]
        row[f"var_explained_{v}"] = float(np.mean(ev))
    rows.append(row); log(f"{row['cfg_id']}: raw {row['cka_raw']:.3f} size2 {row['cka_size2']:.3f} comp {row['cka_comp']:.3f} full {row['cka_full']:.3f}")
A = pd.DataFrame(rows); write_tsv(A, "c7_composition_sweep.tsv")
print(A[["cfg_id", "cka_raw", "cka_size2", "cka_comp", "cka_full", "var_explained_full"]].round(3).to_string())
print("mean change in floor, full vs raw:", round((A.cka_full - A.cka_raw).mean(), 4), "| min full:", round(A.cka_full.min(), 3))

# ------------------------------------------------------------------ Part B: real models
if os.environ.get("C7_SKIP_REAL") == "1": sys.exit(0)
def graph_arrays(pid):
    if os.environ.get("CR_FAKE_GRAPHS") == "1":               # test mode: take graphs from the sweep archive
        xyz, el, lig = g.get(pid); return el, lig.astype(int), xyz, g.n_elem + 1
    import torch
    p = ROOT / "data" / "graph_cache" / f"{pid}.pt"
    try: d = torch.load(p)
    except Exception: d = torch.load(p, weights_only=False)
    z = d["z"].numpy(); return z // 2, z % 2, d["x"].numpy().astype(np.float64), 16
cache = {}
def feats_for(idlist):
    out = []
    for p_ in idlist:
        if p_ not in cache: cls, lig, xyz, nc = graph_arrays(p_); cache[p_] = features(cls, lig, xyz, nc)
        out.append(cache[p_])
    return out
models = ["egnn", "distance_gnn"]; W = boot_weights(core, plan, seed_off=99); rowsB = []
def reps(model, tag, variant):
    if variant == "raw": return ref_rep(fc.EMB, model, tag, core, plan["pca_dim"])
    Etr, itr = load_emb(fc.EMB, model, tag, "train"); Ete = raw_test(fc.EMB, model, tag, core)
    return al.resid_then_pca(Etr, design(feats_for(itr), VARIANTS[variant]), Ete, design(feats_for(core), VARIANTS[variant]), k=plan["pca_dim"], name=f"{model}/{tag}/{variant}")
for v in ["raw"] + list(VARIANTS):
    R = {(m, t): reps(m, t, v) for m in models for t in ["primary"] + fc.UNTRAINED_TAGS}
    for state, pl in (("trained_primary", [(R[("egnn", "primary")], R[("distance_gnn", "primary")])]), ("untrained_matched_5inits", [(R[("egnn", t)], R[("distance_gnn", t)]) for t in fc.UNTRAINED_TAGS])):
        lo, hi = boot_ci(pl, W); rowsB.append(dict(variant=v, state=state, cka=mean_cka(pl), ci_lo=lo, ci_hi=hi))
    log("real models,", v, "done")
B = pd.DataFrame(rowsB); write_tsv(B, "c7_composition_real.tsv"); print(B.round(3).to_string())
