# Running every experiment on AWS

This package extends the original repository with the 13 additional experiments and a resumable runner. One command per step, all
commands are plain text and contain no wildcard characters.

## What was and was not tested

- Everything under `scripts/`, `run_pipeline.py` and `tests/` ran end to end on synthetic stand-in data (all CPU stages, the
  random-projection extraction path, the report and the multiplicity table). The synthetic numbers are meaningless; they only prove the plumbing.
- Not executed anywhere: the GPU backbones (xrv, resnet50, densenet121, DINOv2, RAD-DINO, BiomedCLIP), `finetune_tb.py`, and all of `aws/`.
  There was no torch, GPU or AWS account in the authoring environment. `aws/` scripts were syntax checked and dry-run.
  Run `python run_pipeline.py --smoke --groups prep,extract,finetune` first (a few minutes, random-init weights, tiny subsets) to catch environment problems cheaply.
  Smoke runs write to `feats_smoke` and `results_smoke`, never to the real directories, so they cannot mark a real stage as finished.
  Note the smoke subsets use a different number of rows from the full manifest, so do not run the analysis groups on smoke features.

## One-time setup (on your computer)

```
cp aws/config.example.sh aws/config.sh      # edit bucket, key pair, local data paths
bash aws/make_bucket.sh
bash aws/iam_setup.sh
bash aws/upload_data.sh
bash aws/upload_code.sh
```

Add `--dry-run` to any of these to print what would happen. Check each dataset licence before putting images in a cloud bucket.

## Data layout the instance expects (created by upload_data.sh)

```
s3://BUCKET/PREFIX/data/belarus/            Belarus TB Portals images (PNG)
s3://BUCKET/PREFIX/data/rsna/               RSNA normals
s3://BUCKET/PREFIX/data/shenzhen/           CHNCXR_xxxx_0 or 1 .png
s3://BUCKET/PREFIX/data/montgomery/         MCUCXR_xxxx_0 or 1 .png
s3://BUCKET/PREFIX/data/malaria/            contains Parasitized/ and Uninfected/
s3://BUCKET/PREFIX/data/belarus_extent.csv  columns basename,extent (A or B)
s3://BUCKET/PREFIX/data/cohort.csv          TCGA glioma table (scripts/glioma_data.py lists the columns it reads)
s3://BUCKET/PREFIX/data/cgga.csv            optional, CGGA clinical table; enables the external check in item 10
```

## Launch, watch, collect

```
bash aws/launch_instance.sh     # GPU instance; it pulls code and data from S3 and runs the pipeline by itself
bash aws/status.sh              # state, per-stage status and the log tail, read from S3 (no SSH needed)
bash aws/download_results.sh    # results and logs (add --feats for the extracted features)
bash aws/terminate.sh           # when finished, if AUTO_SHUTDOWN was 0 or you want the disk gone
```

Results and features are mirrored to S3 every 5 minutes and at the end. If the instance stops or a spot instance is reclaimed, launch
again: finished stages are skipped and features and results are pulled back from S3.
With `AUTO_SHUTDOWN=1` the instance stops itself only after the final upload succeeded; if the upload fails it stays up.

Instance choice: `g5.2xlarge` (one A10G, 8 vCPU) is enough. The CPU stages with joblib use all cores, so a bigger sibling
(`g5.4xlarge`, `g5.8xlarge`) finishes the analysis part sooner at a higher hourly price. Running time and cost were not measured;
the extraction of about 28k malaria cells through six views and four encoders is the longest GPU stage.

## Running parts by hand

```
python run_pipeline.py --list
python run_pipeline.py --dry-run
python run_pipeline.py --groups extract,finetune          # GPU part
python run_pipeline.py --groups analyze,report            # CPU part, from existing features
python run_pipeline.py --only item03,item05 --force
python run_pipeline.py --fresh                            # clean full run (clears the multiplicity registry)
```

## Which stage answers which item

| Item | Stage names | Output |
|---|---|---|
| 1 Loop vs one-shot audits | item01_loop_vs_oneshot | item01_loop_vs_oneshot.json, item01_flag_rates.csv |
| 2 Head-to-head baselines | item02_baselines | item02_baselines.json, item02_flag_rates.csv |
| 3 Broader calibration | item03_calibration_tb_glioma, item03_calibration_malaria | item03_calibration_extended_tb_glioma.json and item03_calibration_extended_malaria.json |
| 4 XRV failure diagnosis | item04_xrv_diagnosis | item04_xrv_diagnosis.json, item04_recommended_preproc.json (reused by items 3 and 5) |
| 5 False-flag bound | item05_false_flag_bound | item05_false_flag_bound.json and .csv |
| 6 Natural negative control | item06_natural_controls | item06_natural_controls.json |
| 7 More encoders | extract_tb_rad_dino, extract_tb_biomedclip (and planted, harmonized variants) feed every TB stage | all TB outputs |
| 8 TB format isolation | item08_tb_format_isolation, E1 and E2 on harmonized features | item08_tb_format_isolation.json |
| 9 Fine-tuned encoder | finetune_xrv_densenet121, finetune_resnet50, item09_finetuned_audit | item09_finetuned_audit.json |
| 10 Glioma external | item10_glioma_external | item10_glioma_external.json |
| 11 Malaria clean-up | item11_malaria_cleanup_ENCODER, item11_mask_validation | item11_malaria_cleanup_ENCODER.json, item11_mask_validation.json, mask_validation/overlay PNGs |
| 12 More ablation seeds | item12_E3_tb_ENCODER, item12_E3_malaria_VIEW, item12_E3_glioma (10, 10 and 30 seeds) | E3_ JSON files |
| 13 Multiplicity | item13_multiplicity | item13_multiplicity.csv and .json |

Stage order matters in two places: item04 writes the recommended XRV preprocessing that items 3 and 5 then use, and item13 must run last
(it reads the test registry that E3 and items 10 and 11 append to).

## Things to read before trusting the numbers

- Item 11: the 201 versus 200 patient mismatch is diagnosed by comparing three parsing rules on the real file names. Read the group diagnostics block at
  the top of the output, decide which rule matches the dataset readme, and state it in the paper.
- Item 10: the CGGA clinical table has no TERT column, so transfer between cohorts uses the shared features only (MGMT and 1p/19q).
- Item 13 counts only the tests that have a p-value in the registry (E3 empirical p-values, the item 6 and item 8 permutation tests, and the item 10 and 11 tests).
  Calibration flag rates carry exact Clopper-Pearson intervals instead of p-values.
- Item 9 needs the GPU fine-tuning to have run; without `ft_` features the stage reports a skip.
- Paper format: AAAI Findings uses its own template and page limit; the additions here are numbers and supplement material, not a reformatting.
