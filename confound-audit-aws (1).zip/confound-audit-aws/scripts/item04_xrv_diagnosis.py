"""ITEM 4  Why does the audit lose power on TorchXRayVision features (flag 0.00 at rho = 1.0, LEACE gain -0.182, cosine about 0.25)?

Runs the planted-marker calibration on the XRV planted features under a grid of pipeline variants, each changing ONE suspect:
  dimension of the PCA space (16..256), scaling (none / z-score), dead columns, outlier clipping, L2 normalisation, whitening,
  PCA fitted on clean+marked vs clean only, ridge shrinkage inside LEACE, and no PCA at all.
For every variant and rho it reports the flag rate of C1 (LEACE gain), C2 (retrained-head drop), the loop and the ORACLE (ablating
the TRUE planted direction), the cosine between the recovered and the true direction, and how much label information a retrained head
still has after erasure.  A reference encoder (e.g. DINOv2) is run with the paper's pipeline for comparison.

Computed diagnosis (printed and saved):
  structural      at rho = 1 the marker equals the label in training, so erasing the marker erases the disease signal for EVERY encoder
                  (oracle gain <= margin and retrained AUC near chance).  Not an XRV defect.
  recovery        recovered-direction cosine is low and the oracle flags where C1 does not: direction recovery is the bottleneck.
  preprocessing   a variant restores power at rho 0.7-0.9 without raising the false-flag rate at rho = 0.5.
The best variant under that rule is written to item04_recommended_preproc.json in the format item03 --preproc_json reads.

  python item04_xrv_diagnosis.py --feats feats/tbplanted_xrv_densenet121.npz --ref dinov2=feats/tbplanted_dinov2_small.npz --reps 40
"""
import argparse
import json

import numpy as np

from audit_lib import AuditConfig, PreCfg
from calib_engine import load_planted_npz, run_planted_calibration
from data_utils import RESULTS, Timer, dump, n_jobs_default, parse_kv

ap = argparse.ArgumentParser()
ap.add_argument("--feats", required=True, help="planted-marker npz of the encoder being diagnosed (XRV)")
ap.add_argument("--tag", default="xrv", help="encoder tag written into the recommended-preprocessing JSON")
ap.add_argument("--ref", nargs="*", default=[], help="tag=path of reference encoders run with the paper's pipeline")
ap.add_argument("--marker", default="corner")
ap.add_argument("--rhos", type=float, nargs="+", default=[0.5, 0.7, 0.8, 0.9, 1.0])
ap.add_argument("--reps", type=int, default=40)
ap.add_argument("--n_jobs", type=int, default=n_jobs_default())
ap.add_argument("--out_tag", default="")
a = ap.parse_args()

cfg = AuditConfig(run_nonlinear=False, boot=100)
V = {
    "paper (raw, PCA64, clean+marked fit)":  PreCfg(),
    "PCA16":                                 PreCfg(pca_k=16),
    "PCA32":                                 PreCfg(pca_k=32),
    "PCA128":                                PreCfg(pca_k=128),
    "PCA256":                                PreCfg(pca_k=256),
    "z-score, PCA64":                        PreCfg(standardize=True),
    "drop dead, z-score, PCA64":             PreCfg(drop_dead=True, standardize=True),
    "drop dead, z-score, clip 6, PCA64":     PreCfg(drop_dead=True, standardize=True, clip=6.0),
    "L2-normalise, PCA64":                   PreCfg(l2norm=True),
    "z-score, PCA64, whiten":                PreCfg(standardize=True, whiten=True),
    "PCA64 fitted on clean only":            PreCfg(pca_fit="clean"),
    "PCA128 + LEACE shrink 0.1":             PreCfg(pca_k=128, leace_shrink=0.1),
    "z-score, PCA256 + LEACE shrink 0.3":    PreCfg(pca_k=256, standardize=True, leace_shrink=0.3),
    "no PCA (dead dropped, z-score) + shrink 0.5": PreCfg(pca_k=None, drop_dead=True, standardize=True, leace_shrink=0.5),
}
FLAGS = ["flag_C1", "flag_C2", "flag_loop", "flag_oracle"]


def rate(s, k):
    f = s["flags"].get(k)
    return f["rate"] if f else float("nan")


def metric(s, k):
    m = s["metrics"].get(k)
    return m["mean"] if m else float("nan")


def run_variant(path, pre):
    Zc, Zm, y, groups = load_planted_npz(path, a.marker)
    by_rho, _ = run_planted_calibration(Zc, Zm, y, a.rhos, a.reps, pre, cfg, groups=groups, n_jobs=a.n_jobs)
    return by_rho


res = {"variants": {}, "reference": {}}
for tag, path in parse_kv(a.ref, "--ref").items():
    with Timer(f"reference {tag} (paper pipeline)"):
        res["reference"][tag] = run_variant(path, PreCfg())
for name, pre in V.items():
    with Timer(f"variant: {name}"):
        try:
            res["variants"][name] = {"pre": pre.as_dict(), "by_rho": run_variant(a.feats, pre)}
        except Exception as e:                               # noqa: BLE001  (e.g. a variant that is degenerate on this data)
            res["variants"][name] = {"pre": pre.as_dict(), "error": repr(e)}
            print(f"  [error] {e!r}")

# ------------------------------------------------------------------ tables
hi = [r for r in map(str, a.rhos) if float(r) >= 0.7]


def table_row(name, b):
    ff = "/".join(f"{rate(b['0.5'], k):.2f}" for k in ("flag_C1", "flag_C2", "flag_loop")) if "0.5" in b else "n/a"
    pw = "/".join(f"{rate(b[r], 'flag_loop'):.2f}" for r in hi if r in b)
    b1 = b.get("1.0", {"flags": {}, "metrics": {}})
    print(f"{name:46s} {ff:>20s} {pw:>26s} {rate(b1, 'flag_C1'):8.2f} {rate(b1, 'flag_oracle'):8.2f} "
          f"{metric(b1, 'cos_to_true'):5.2f} {metric(b1, 'avail_a_after_retrain'):9.2f}")


print(f"\n{'variant':46s} {'FF@.5 (C1/C2/loop)':>20s} {'loop power @ ' + '/'.join(hi):>26s} {'C1@1.0':>8s} {'orac@1.0':>8s} {'cos':>5s} {'avail@1.0':>9s}")
for name, v in res["variants"].items():
    if "by_rho" in v:
        table_row(name, v["by_rho"])
for tag, b in res["reference"].items():
    table_row("REFERENCE " + tag, b)

# ------------------------------------------------------------------ computed diagnosis
diag, base = [], res["variants"].get("paper (raw, PCA64, clean+marked fit)", {}).get("by_rho")
if base:
    margin = cfg.margin
    b1 = base.get("1.0")
    if b1:
        og, c1g = metric(b1, "gain_oracle"), metric(b1, "gain_C1")
        av = metric(b1, "avail_a_after_retrain")
        if og <= margin and av <= 0.65:
            diag.append(f"STRUCTURAL at rho=1.0: the oracle (true-direction) ablation gain is {og:.3f} (<= margin {margin}) and a head retrained after erasure "
                        f"has concordant AUC {av:.3f}. With marker == label in training, erasing the marker erases the disease signal, so no direction "
                        f"estimate can fix this at rho=1.0.")
        else:
            diag.append(f"rho=1.0 is NOT purely structural: oracle gain {og:.3f}, retrained concordant AUC {av:.3f}, C1 gain {c1g:.3f}.")
    mid = [r for r in map(str, a.rhos) if 0.7 <= float(r) <= 0.9 and r in base]
    if mid:
        cos = np.mean([metric(base[r], "cos_to_true") for r in mid])
        c1 = np.mean([rate(base[r], "flag_C1") for r in mid])
        orc = np.mean([rate(base[r], "flag_oracle") for r in mid])
        if cos < 0.5 and orc > c1 + 0.2:
            diag.append(f"RECOVERY at rho 0.7-0.9: mean cosine to the true direction is {cos:.2f} and the oracle flags {orc:.2f} against C1 {c1:.2f}: "
                        f"the direction estimate, not the head, is the bottleneck.")
        else:
            diag.append(f"Direction recovery at rho 0.7-0.9: mean cosine {cos:.2f}, oracle flag {orc:.2f}, C1 flag {c1:.2f}.")

    def objective(b):
        if "0.5" not in b:
            return None
        ff = max(rate(b["0.5"], k) for k in ("flag_C1", "flag_C2", "flag_loop"))
        pw = np.mean([rate(b[r], "flag_loop") for r in hi if r in b])
        return ff, pw

    b0 = objective(base)
    best, best_name = None, None
    for name, v in res["variants"].items():
        if "by_rho" not in v:
            continue
        o = objective(v["by_rho"])
        if o and o[0] <= 0.10 and (best is None or o[1] > best[1]):
            best, best_name = o, name
    if best_name:
        gain = best[1] - (b0[1] if b0 else 0)
        diag.append(f"BEST variant under (false flag <= 0.10, maximise loop power over rho >= 0.7): '{best_name}' power {best[1]:.2f} vs paper pipeline "
                    f"{b0[1] if b0 else float('nan'):.2f} (change {gain:+.2f}); false flag {best[0]:.2f}.")
        pre = res["variants"][best_name]["pre"]
        rec = {a.tag: pre}
        with open(RESULTS / f"item04_recommended_preproc{a.out_tag}.json", "w") as f:
            json.dump(rec, f, indent=2)
        res["recommended"] = {"variant": best_name, "pre": pre, "objective": best}
        if gain > 0.15:
            diag.append("PREPROCESSING matters: rerun item03 for this encoder with --preproc_json item04_recommended_preproc.json.")
res["diagnosis"] = diag
print("\nDIAGNOSIS (computed):\n  " + "\n  ".join(diag))
dump(res, f"item04_xrv_diagnosis{a.out_tag}.json")
