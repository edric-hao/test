"""ITEM 9  Audit of a FINE-TUNED encoder (the paper audits frozen features only).

Input: the npz written by finetune_tb.py (features, the fine-tuned head, the train/val split) and optionally the frozen features of the
same backbone (extract_features.py tb) for a side-by-side comparison.  Reported per fine-tuned model:
  1. the deployed classifier itself: AUC on held-out Belarus/RSNA vs on the source-matched sets it never saw
  2. source decodability in the fine-tuned features, linear vs MLP vs HGB probes, before and after LEACE (fit on the training rows)
  3. the DEPLOYED head applied to LEACE-erased source-matched features (fixed head) vs a random-direction null
  4. the full audit loop (source_case trial) on the fine-tuned features and on the frozen features of the same backbone, same split

  python item09_finetuned_audit.py --manifest feats/tb_manifest.csv --finetuned xrv=feats/ft_xrv_densenet121.npz \
         --frozen xrv=feats/tb_xrv_densenet121.npz
"""
import argparse

import numpy as np
import pandas as pd
from sklearn.ensemble import HistGradientBoostingClassifier
from sklearn.neural_network import MLPClassifier

from audit_lib import AuditConfig, PreCfg, audit_trial, summarize_rows
from calib_engine import source_case_trial
from common import auc_ci, cov_random_direction, lr, project_out
from data_utils import Timer, dump, parse_kv, parse_sources
from erasers import INLP, LEACE
from stats_utils import fast_auc

ap = argparse.ArgumentParser()
ap.add_argument("--manifest", required=True)
ap.add_argument("--finetuned", nargs="+", required=True)
ap.add_argument("--frozen", nargs="*", default=[])
ap.add_argument("--matched_sources", default="shenzhen,montgomery")
ap.add_argument("--audit_reps", type=int, default=10, help="repeats of the audit loop with different null/bootstrap seeds (the split is fixed)")
ap.add_argument("--n_null", type=int, default=100)
ap.add_argument("--inlp_rounds", type=int, default=50)
ap.add_argument("--pca", type=int, default=64)
ap.add_argument("--tag", default="")
a = ap.parse_args()
srcs = parse_sources(a.matched_sources)
cfg, pre = AuditConfig(), PreCfg(pca_k=a.pca)
frozen = parse_kv(a.frozen, "--frozen")
res = {}


def probes(Xtr, ctr, Xte, cte):
    r = {"linear": float(fast_auc(cte, lr().fit(Xtr, ctr).decision_function(Xte)))}
    r["mlp"] = float(fast_auc(cte, MLPClassifier((256,), early_stopping=True, max_iter=200, random_state=0).fit(Xtr, ctr).predict_proba(Xte)[:, 1]))
    r["hgb"] = float(fast_auc(cte, HistGradientBoostingClassifier(max_iter=150).fit(Xtr, ctr).predict_proba(Xte)[:, 1]))
    return r


for tag, path in parse_kv(a.finetuned, "--finetuned").items():
    d = np.load(path, allow_pickle=True)
    man = pd.read_csv(a.manifest)
    y, src = man.label.values, man.source.values
    Z, logit, split, w, b = d["Z"], d["logit"], d["split"].astype(str), d["head_w"], float(d["head_b"])
    if len(Z) != len(man):
        raise SystemExit(f"{path}: {len(Z)} rows but the manifest has {len(man)} (finetune_tb must run on the full manifest)")
    tr, va = np.where(split == "train")[0], np.where(split == "val")[0]
    matched = np.where(np.isin(src, srcs))[0]
    R = {}
    with Timer(f"fine-tuned {tag}"):
        # 1. the deployed classifier
        R["deployed_classifier"] = {"heldout_belarus_rsna": auc_ci(y[va], logit[va], B=500), "source_matched_all": auc_ci(y[matched], logit[matched], B=500)}
        for s in srcs:
            i = np.where(src == s)[0]
            if len(i) > 30 and len(np.unique(y[i])) == 2:
                R["deployed_classifier"][f"matched_{s}"] = auc_ci(y[i], logit[i], B=500)
        # 2. source decodability and erasure (source == TB label inside Belarus/RSNA, as in the paper)
        c = (src == "belarus").astype(int)
        le = LEACE().fit(Z[tr], c[tr])
        inlp = INLP(a.inlp_rounds).fit(Z[tr], c[tr])
        R["source_probe_auc_heldout"] = {"none": probes(Z[tr], c[tr], Z[va], c[va]),
                                         "LEACE": probes(le.transform(Z[tr]), c[tr], le.transform(Z[va]), c[va]),
                                         f"INLP_{a.inlp_rounds}": probes(inlp.transform(Z[tr]), c[tr], inlp.transform(Z[va]), c[va])}
        # 3. the deployed head on erased matched features
        base = fast_auc(y[matched], Z[matched] @ w + b)
        er = fast_auc(y[matched], le.transform(Z[matched]) @ w + b)
        rng = np.random.default_rng(0)
        ng = [fast_auc(y[matched], project_out(Z[matched], cov_random_direction(Z[tr], rng)) @ w + b) - base for _ in range(a.n_null)]
        gain = er - base
        R["deployed_head_on_erased_matched"] = {"auc_before": float(base), "auc_after_LEACE": float(er), "gain": float(gain),
                                                 "null_gain_p95": float(np.percentile(ng, 95)), "null_gain_mean": float(np.mean(ng)),
                                                 "flag": bool(gain > np.percentile(ng, 95) and gain > cfg.margin)}
        # 4. the audit loop, fine-tuned vs frozen, same split
        def loop(Zm, key):
            rows = []
            for rep in range(a.audit_reps):
                t = source_case_trial(Zm, y, tr, va, matched, pre, np.random.default_rng(rep), seed=rep)
                rows.append(audit_trial(t, cfg))
            return summarize_rows(rows)
        R["audit_finetuned"] = loop(Z, "ft")
        if tag in frozen:
            Zf = np.load(frozen[tag], allow_pickle=True)["Z"]
            if len(Zf) == len(Z):
                R["audit_frozen_same_split"] = loop(Zf, "frozen")
    res[tag] = R

    dc = R["deployed_classifier"]
    print(f"\n=== {tag}: deployed fine-tuned classifier  held-out Belarus/RSNA AUC {dc['heldout_belarus_rsna']['auc']:.3f}  ->  "
          f"source-matched AUC {dc['source_matched_all']['auc']:.3f} [{dc['source_matched_all']['lo']:.3f},{dc['source_matched_all']['hi']:.3f}]")
    for k, v in R["source_probe_auc_heldout"].items():
        print(f"   source probe after {k:9s}: linear {v['linear']:.3f}  MLP {v['mlp']:.3f}  HGB {v['hgb']:.3f}")
    h = R["deployed_head_on_erased_matched"]
    print(f"   deployed head on LEACE-erased matched data: AUC {h['auc_before']:.3f} -> {h['auc_after_LEACE']:.3f} (gain {h['gain']:+.3f}, null p95 {h['null_gain_p95']:+.3f}) flag={h['flag']}")
    for key in ("audit_finetuned", "audit_frozen_same_split"):
        if key in R:
            s = R[key]
            fl = {k.replace("flag_", ""): round(v["rate"], 2) for k, v in s["flags"].items()}
            print(f"   {key:26s} flags {fl}; verdicts {s['verdicts']}")
dump({"results": res, "config": {"audit": cfg.__dict__, "pre": pre.as_dict(), "matched_sources": srcs}}, f"item09_finetuned_audit{a.tag}.json")
