"""Small shared helpers for the item scripts: argument parsing, manifest/feature loading, result printing."""
from __future__ import annotations

import json
import os
import time
from pathlib import Path

import numpy as np
import pandas as pd

from common import RESULTS, check_finite, save_json

MATCHED_DEFAULT = ("shenzhen", "montgomery")


def parse_kv(items, what="--feats"):
    """['xrv=path1', 'dino=path2'] -> {'xrv': 'path1', 'dino': 'path2'}  (insertion order kept)."""
    out = {}
    for it in items or []:
        if "=" not in it:
            raise SystemExit(f"{what}: expected tag=path, got {it!r}")
        k, v = it.split("=", 1)
        out[k] = v
    return out


def load_tb(manifest, feats):
    """Returns manifest DataFrame, Z (n x d), H (n x m, NaN->0), Hcols, y, src.  Checks row alignment and finiteness."""
    man = pd.read_csv(manifest)
    d = np.load(feats, allow_pickle=True)
    Z = d["Z"]
    if len(Z) != len(man):
        raise SystemExit(f"{feats}: {len(Z)} feature rows but manifest has {len(man)} rows (extract with the same manifest)")
    check_finite("Z", Z)
    H = np.nan_to_num(d["H"]) if "H" in d.files else np.zeros((len(Z), 0))
    Hcols = list(d["Hcols"]) if "Hcols" in d.files else []
    return man, Z, H, Hcols, man.label.values, man.source.values


def matched_mask(src, matched_sources=MATCHED_DEFAULT):
    return np.isin(src, list(matched_sources))


def parse_sources(s):
    return tuple(x.strip() for x in s.split(",") if x.strip())


def dump(obj, name):
    """save_json into RESULTS and return the path."""
    save_json(obj, name)
    return RESULTS / name


def flag_table(summary_by_key, flag_keys, label="rho", width=9):
    """Print a compact flag-rate table: rows = keys of summary_by_key, columns = flag_keys."""
    head = f"{label:>8s} " + " ".join(f"{k.replace('flag_', ''):>{width}s}" for k in flag_keys) + "   n"
    print(head)
    for key, s in summary_by_key.items():
        cells = []
        for k in flag_keys:
            f = s["flags"].get(k)
            cells.append(f"{f['rate']:{width}.2f}" if f else f"{'-':>{width}s}")
        print(f"{str(key):>8s} " + " ".join(cells) + f"  {s['n_valid']}")


def tidy_rows(domain, encoder, marker, by_rho, extra=None):
    """Flatten {rho: summary} into tidy rows (one per rho x criterion) for CSV export."""
    rows = []
    for rho, s in by_rho.items():
        for k, f in s["flags"].items():
            row = dict(domain=domain, encoder=encoder, marker=marker, rho=rho, criterion=k, k=f["k"], n=f["n"], rate=f["rate"],
                       cp_lo=f["cp_lo"], cp_hi=f["cp_hi"], cp_upper_one_sided=f["cp_upper_one_sided"])
            if extra:
                row.update(extra)
            rows.append(row)
    return rows


def write_csv(rows, name):
    p = RESULTS / name
    pd.DataFrame(rows).to_csv(p, index=False)
    print(f"[saved] {p}")
    return p


class Timer:
    def __init__(self, msg):
        self.msg = msg

    def __enter__(self):
        self.t0 = time.time()
        print(f"[start] {self.msg}", flush=True)
        return self

    def __exit__(self, *exc):
        print(f"[done ] {self.msg}  ({time.time() - self.t0:.0f}s)", flush=True)
        return False


def n_jobs_default():
    try:
        return max(1, int(os.environ.get("N_JOBS", os.cpu_count() or 1)))
    except ValueError:
        return 1


def register_tests(experiment, tests):
    """Append hypothesis tests to results/test_registry.jsonl so item13 can count them and correct p-values.
    tests: list of dicts with keys name, family, p (float or None), n_tests_note (optional)."""
    path = RESULTS / "test_registry.jsonl"
    with open(path, "a") as f:
        for t in tests:
            f.write(json.dumps(dict(experiment=experiment, **t), default=lambda o: o.item() if hasattr(o, "item") else str(o)) + "\n")
