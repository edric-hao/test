"""Frozen-backbone feature extraction (the GPU step).

TB            python extract_features.py tb --manifest tb_manifest.csv --backbone xrv_densenet121 --out feats/tb_xrv.npz [--harmonize [std|strong]]
TB planted    python extract_features.py tb_planted --manifest M --backbone B --out O --markers corner,intensity,texture [--max_per_source N]
Malaria       python extract_features.py malaria --root cell_images --backbone resnet50 --out feats/mal_resnet50.npz --mask adaptive [--mask_k 2.5]
Malaria plant python extract_features.py malaria_planted --root cell_images --backbone resnet50 --out O --markers corner,intensity,texture --max_cells 8000

Backbones: xrv_densenet121 | resnet50 | densenet121 | dinov2_small | rad_dino | biomedclip | random_proj (smoke tests only)
Output formats are identical to the original repository (Z, H, Hcols for TB; Z_<view>, y, names, H, Hcols for malaria;
Z_clean, Z_marked, y, source for planted TB) with the additions documented in each function.
"""
import argparse
import importlib.util
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

import numpy as np
from PIL import Image
try:
    from tqdm import tqdm
except ImportError:                      # progress bars are optional
    def tqdm(it, **kw):
        return it

from backbones import BACKBONES, CHEST_ONLY, get_backbone, run_batches
from imgproc import (HAND_COLS, MARKER_KINDS, VIEWS, adaptive_parasite_mask, default_parasite_mask, harmonize_mode,
                     list_images, load_tb_image, make_views, plant_marker, to_224)


def _load_many(paths, harmonize, workers):
    fn = lambda p: load_tb_image(p, harmonize)
    if workers <= 1:
        return [fn(p) for p in paths]
    with ThreadPoolExecutor(workers) as ex:
        return list(ex.map(fn, paths))


def _parse_markers(s):
    kinds = [k.strip() for k in s.split(",") if k.strip()]
    for k in kinds:
        if k not in MARKER_KINDS:
            raise SystemExit(f"unknown marker {k!r}; choose from {MARKER_KINDS}")
    return kinds


# ------------------------------------------------------------------ TB
def extract_tb(args, bb):
    import pandas as pd
    man = pd.read_csv(args.manifest)
    mode = harmonize_mode(args.harmonize)
    feats, metas = [], []
    for i in tqdm(range(0, len(man), 512)):
        loaded = _load_many(man.path.iloc[i:i + 512].tolist(), mode, args.workers)
        ts = []
        for arr, meta in loaded:
            metas.append(meta)
            ts.append(bb.prep(to_224(arr)))
        feats.append(run_batches(bb, ts, args.batch))
    H = pd.DataFrame(metas).values.astype(np.float32)
    np.savez(args.out, Z=np.concatenate(feats), H=H, Hcols=np.array(list(metas[0].keys())))


def extract_tb_planted(args, bb):
    """Features of CLEAN and MARKED versions of every selected manifest row.
    Output keys: Z_clean, Z_marked_<kind> for each requested marker, Z_marked (= the corner marker, for backward compatibility
    with E6), y, source, markers."""
    import pandas as pd
    man = pd.read_csv(args.manifest)
    man = man[man.source.isin(args.planted_sources.split(","))]
    if args.max_per_source:
        rng = np.random.default_rng(0)
        parts = []
        for _, g in man.groupby("source"):
            keep = np.sort(rng.choice(len(g), size=min(args.max_per_source, len(g)), replace=False))
            parts.append(g.iloc[keep])
        man = pd.concat(parts)
    man = man.reset_index(drop=True)
    man.to_csv(Path(args.out).with_suffix(".manifest.csv"), index=False)
    kinds = _parse_markers(args.markers)
    mode = harmonize_mode(args.harmonize)
    Zc, Zm = [], {k: [] for k in kinds}
    for i in tqdm(range(0, len(man), 256)):
        loaded = _load_many(man.path.iloc[i:i + 256].tolist(), mode, args.workers)
        tc, tm = [], {k: [] for k in kinds}
        for raw, _meta in loaded:
            full = np.asarray(Image.fromarray(raw).resize((512, 512)))
            tc.append(bb.prep(to_224(full)))
            for k in kinds:
                tm[k].append(bb.prep(to_224(plant_marker(full, k))))
        Zc.append(run_batches(bb, tc, args.batch))
        for k in kinds:
            Zm[k].append(run_batches(bb, tm[k], args.batch))
    save = {"Z_clean": np.concatenate(Zc), "y": man.label.values, "source": man.source.values, "markers": np.array(kinds)}
    for k in kinds:
        save[f"Z_marked_{k}"] = np.concatenate(Zm[k])
    if "corner" in kinds:
        save["Z_marked"] = save["Z_marked_corner"]
    np.savez(args.out, **save)


# ------------------------------------------------------------------ Malaria
def _malaria_files(root):
    root = Path(root)
    if not (root / "Parasitized").exists() and (root / "cell_images" / "Parasitized").exists():
        root = root / "cell_images"
    files = sorted(list_images(root / "Parasitized", (".png",)) + list_images(root / "Uninfected", (".png",)))
    if not files:
        raise SystemExit(f"no Parasitized/Uninfected PNG files found under {root}")
    y = np.array([1 if f.parent.name == "Parasitized" else 0 for f in files])
    return files, y


def _mask_fn(args):
    pfn = (lambda rgb: adaptive_parasite_mask(rgb, k=args.mask_k)) if args.mask == "adaptive" else default_parasite_mask
    if args.views_module:
        spec = importlib.util.spec_from_file_location("v", args.views_module)
        m = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(m)
        pfn = m.parasite_mask
    return pfn


def extract_malaria(args, bb):
    files, y = _malaria_files(args.root)
    pfn = _mask_fn(args)
    Z = {v: [] for v in VIEWS}
    hand = []
    buf = {v: [] for v in VIEWS}

    def flush():
        for v in VIEWS:
            if buf[v]:
                Z[v].append(run_batches(bb, buf[v], args.batch))
                buf[v] = []

    for k, f in enumerate(tqdm(files)):
        rgb = np.asarray(Image.open(f).convert("RGB"))
        rng = np.random.default_rng(1000 + k)                        # seeded per cell
        views, hv = make_views(rgb, rng, pfn)
        hand.append(hv)
        for v in VIEWS:
            im = Image.fromarray(views[v]).resize((224, 224), Image.BILINEAR)
            buf[v].append(bb.prep(np.asarray(im)))
        if (k + 1) % 512 == 0:
            flush()
    flush()
    np.savez(args.out, y=y, names=np.array([f.name for f in files]), H=np.stack(hand), Hcols=np.array(HAND_COLS),
             **{f"Z_{v}": np.concatenate(Z[v]) for v in VIEWS})


def extract_malaria_planted(args, bb):
    """Clean and marked FULL-image features for a seeded, class-stratified subset of malaria cells (for planted-shortcut calibration)."""
    files, y = _malaria_files(args.root)
    kinds = _parse_markers(args.markers)
    rng = np.random.default_rng(0)
    if args.max_cells and args.max_cells < len(files):
        keep = []
        for c in (0, 1):
            ids = np.where(y == c)[0]
            n_c = int(round(args.max_cells * len(ids) / len(y)))
            keep.append(rng.choice(ids, size=min(n_c, len(ids)), replace=False))
        keep = np.sort(np.concatenate(keep))
    else:
        keep = np.arange(len(files))
    Zc, Zm = [], {k: [] for k in kinds}
    for i in tqdm(range(0, len(keep), 256)):
        tc, tm = [], {k: [] for k in kinds}
        for j in keep[i:i + 256]:
            rgb = np.asarray(Image.open(files[j]).convert("RGB"))
            tc.append(bb.prep(np.asarray(Image.fromarray(rgb).resize((224, 224), Image.BILINEAR))))
            for k in kinds:
                tm[k].append(bb.prep(np.asarray(Image.fromarray(plant_marker(rgb, k)).resize((224, 224), Image.BILINEAR))))
        Zc.append(run_batches(bb, tc, args.batch))
        for k in kinds:
            Zm[k].append(run_batches(bb, tm[k], args.batch))
    save = {"Z_clean": np.concatenate(Zc), "y": y[keep], "names": np.array([files[j].name for j in keep]), "markers": np.array(kinds)}
    for k in kinds:
        save[f"Z_marked_{k}"] = np.concatenate(Zm[k])
    np.savez(args.out, **save)


def build_parser():
    ap = argparse.ArgumentParser()
    ap.add_argument("task", choices=["tb", "malaria", "tb_planted", "malaria_planted"])
    ap.add_argument("--manifest")
    ap.add_argument("--root")
    ap.add_argument("--backbone", required=True, choices=BACKBONES)
    ap.add_argument("--out", required=True)
    ap.add_argument("--harmonize", nargs="?", const="std", default="none", choices=["none", "std", "strong"])
    ap.add_argument("--views-module", default=None)
    ap.add_argument("--mask", default="hsv", choices=["hsv", "adaptive"])
    ap.add_argument("--mask_k", type=float, default=2.5)
    ap.add_argument("--planted_sources", default="shenzhen,montgomery")
    ap.add_argument("--markers", default="corner")
    ap.add_argument("--max_per_source", type=int, default=0)
    ap.add_argument("--max_cells", type=int, default=0)
    ap.add_argument("--batch", type=int, default=128)
    ap.add_argument("--workers", type=int, default=4, help="threads for image decoding")
    ap.add_argument("--no_pretrained", action="store_true", help="smoke tests only: random-init torch backbones (no weight download)")
    ap.add_argument("--disable_cudnn", action="store_true", help="only if you hit a cuDNN sublibrary error (the code also retries automatically)")
    return ap


if __name__ == "__main__":
    a = build_parser().parse_args()
    Path(a.out).parent.mkdir(parents=True, exist_ok=True)
    if a.task.startswith("malaria") and a.backbone in CHEST_ONLY:
        raise SystemExit(f"{a.backbone} is a chest X-ray model; use resnet50 / densenet121 / dinov2_small / biomedclip for malaria")
    bb = get_backbone(a.backbone, pretrained=not a.no_pretrained, disable_cudnn=a.disable_cudnn)
    {"tb": extract_tb, "malaria": extract_malaria, "tb_planted": extract_tb_planted,
     "malaria_planted": extract_malaria_planted}[a.task](a, bb)
    print(f"[done] {a.task} {a.backbone} -> {a.out}")
