"""ITEM 6  Natural negative (and positive) control for the audit, on real radiographs with no planted marker.

NEGATIVE control  A classifier is trained on source-matched TB data (Shenzhen + Montgomery, both classes in each source), with the
  training set balanced so that P(TB | source) = 0.5 in both sources.  Acquisition source (Shenzhen vs Montgomery) is a real, strongly
  decodable cue, but it carries no label information in the training data, so the audit should NOT flag reliance on it.
  Set a = held-out images whose source agrees with the label (Shenzhen-TB, Montgomery-normal), set b = disagree.  Under no reliance
  AUC(a) = AUC(b).  The audit is run over many resampled splits and the false-flag rate is reported with exact intervals.
POSITIVE control  The Belarus/RSNA-trained head (label == source) must be flagged: same trial as item01's source case.

  python item06_natural_controls.py --manifest feats/tb_manifest.csv --feats xrv=feats/tb_xrv_densenet121.npz ... --reps 100
Extra source-matched sets (a second TB dataset) can be added to the manifest with source names and passed via --matched_sources.
"""
import argparse

import numpy as np
from joblib import Parallel, delayed
from sklearn.model_selection import train_test_split

from audit_lib import AuditConfig, PreCfg, audit_trial, summarize_rows
from calib_engine import balance_by_group, natural_trial, source_case_trial
from data_utils import Timer, dump, flag_table, load_tb, n_jobs_default, parse_kv, parse_sources, register_tests, tidy_rows, write_csv

ap = argparse.ArgumentParser()
ap.add_argument("--manifest", required=True)
ap.add_argument("--feats", nargs="+", required=True)
ap.add_argument("--matched_sources", default="shenzhen,montgomery", help="first source = shortcut value 1, all others = 0")
ap.add_argument("--reps", type=int, default=100)
ap.add_argument("--pos_reps", type=int, default=20)
ap.add_argument("--test_size", type=float, default=0.3)
ap.add_argument("--pca", type=int, default=64)
ap.add_argument("--n_jobs", type=int, default=n_jobs_default())
ap.add_argument("--tag", default="")
a = ap.parse_args()

cfg = AuditConfig()
pre = PreCfg(pca_k=a.pca)
srcs = parse_sources(a.matched_sources)
KEYS = ["flag_probe_only", "flag_S", "flag_C1", "flag_C2", "flag_loop"]


def neg_rep(Z, y, s, idx, rep):
    rng = np.random.default_rng(rep)
    tr, te = train_test_split(idx, test_size=a.test_size, stratify=2 * s[idx] + y[idx], random_state=rep)
    tr = balance_by_group(y, s, tr, rng)
    if len(tr) < 40:
        return {"valid": False}
    return audit_trial(natural_trial(Z, y, s, tr, te, pre, rng, seed=rep, orientation="same"), cfg)


out, tidy, reg = {"config": {"matched_sources": srcs, "reps": a.reps, "audit": cfg.__dict__, "pre": pre.as_dict()}, "negative_control": {}, "positive_control": {}}, [], []
for tag, path in parse_kv(a.feats, "--feats").items():
    man, Z, H, Hc, y, src = load_tb(a.manifest, path)
    idx = np.where(np.isin(src, srcs))[0]
    s = (src == srcs[0]).astype(int)
    if len(idx) < 100 or len(np.unique(s[idx])) < 2:
        print(f"[skip] {tag}: need at least two source-matched sets with both classes")
        continue
    with Timer(f"negative control, {tag} ({len(idx)} matched images, {a.reps} splits)"):
        rows = Parallel(n_jobs=a.n_jobs)(delayed(neg_rep)(Z, y, s, idx, rep) for rep in range(a.reps))
    sm = summarize_rows(rows)
    out["negative_control"][tag] = sm
    print(f"\n=== NEGATIVE control, {tag}: false-flag rate (no reliance expected)")
    flag_table({"matched": sm}, KEYS, label="case")
    f = sm["flags"]
    print("   source decodable (presence AUC):", sm["metrics"].get("pres_auc", {}).get("mean"), "| tax (AUC a - AUC b):",
          sm["metrics"].get("tax", {}).get("mean"), "| loop verdicts:", sm["verdicts"])
    for k in KEYS:
        if k in f:
            print(f"   {k:16s} {f[k]['k']}/{f[k]['n']}  rate {f[k]['rate']:.3f}  exact upper 95% {f[k]['cp_upper_one_sided']:.3f}")
    # the paper's decision: the audit passes the control when the loop (and the ablation criteria) do not flag
    out["negative_control"][tag]["passes"] = bool(f.get("flag_loop", {}).get("cp_upper_one_sided", 1) <= 0.10)
    tidy += tidy_rows("tb_natural_negative", tag, "source", {"matched": sm})

    nat, matched = np.where(np.isin(src, ["belarus", "rsna"]))[0], np.where(np.isin(src, srcs))[0]
    if len(nat) > 100:
        with Timer(f"positive control, {tag}"):
            prow = []
            for rep in range(a.pos_reps):
                tr, te = train_test_split(nat, test_size=0.4, stratify=y[nat], random_state=rep)
                prow.append(audit_trial(source_case_trial(Z, y, tr, te, matched, pre, np.random.default_rng(rep), seed=rep), cfg))
        sp = summarize_rows(prow)
        out["positive_control"][tag] = sp
        print(f"=== POSITIVE control (Belarus/RSNA head), {tag}: flag rate")
        flag_table({"source": sp}, KEYS, label="case")
        tidy += tidy_rows("tb_natural_positive", tag, "source", {"source": sp})
    reg.append(dict(name=f"negative control loop flag {tag}", family="item06", p=None,
                    n_trials=int(a.reps), flags=int(f.get("flag_loop", {}).get("k", 0))))

register_tests("item06", reg)
dump(out, f"item06_natural_controls{a.tag}.json")
write_csv(tidy, f"item06_flag_rates{a.tag}.csv")
