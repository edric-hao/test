"""Image-side processing with NO torch dependency: TB loading/harmonization, planted markers, malaria masks and views.

Everything in this module is unit-testable on a CPU-only machine.
"""
from __future__ import annotations

import io
from pathlib import Path

import numpy as np
from PIL import Image, ImageFilter, ImageOps

IMAGE_SUFFIXES = (".dcm", ".png", ".jpg", ".jpeg")


# ----------------------------------------------------------------------------- file listing (no glob patterns)
def list_images(root, suffixes=(".png", ".jpg", ".jpeg")):
    """Sorted recursive list of image files under root, filtering by suffix (no wildcard patterns)."""
    import os
    out = []
    for dirpath, _dirs, files in os.walk(str(root)):
        for f in files:
            if Path(f).suffix.lower() in suffixes:
                out.append(Path(dirpath) / f)
    return sorted(out)


# ----------------------------------------------------------------------------- TB
def harmonize_mode(value) -> str:
    """Normalize the --harmonize argument to one of: none, std, strong."""
    if value in (None, False, "", "none", "None", "0", "false", "False"):
        return "none"
    if value in (True, "std", "true", "True", "1"):
        return "std"
    if value == "strong":
        return "strong"
    raise ValueError(f"unknown harmonize mode: {value!r}")


def load_tb_image(path, harmonize="none"):
    """Read one TB image (DICOM or PNG/JPEG) -> (uint8 HxW array at native size after windowing/harmonization, metadata dict).

    harmonize: none | std | strong
      std    = histogram equalization + JPEG(q=90) round trip (the paper's harmonization)
      strong = equalization + Gaussian blur + 256px resample + JPEG(q=60) round trip (stress test of residual format cues)
    Metadata (native size and intensity statistics) is computed BEFORE any harmonization.
    """
    mode = harmonize_mode(harmonize)
    p = str(path)
    if p.lower().endswith(".dcm"):
        import pydicom
        ds = pydicom.dcmread(p)
        a = ds.pixel_array.astype(np.float32)
        if getattr(ds, "PhotometricInterpretation", "") == "MONOCHROME1":
            a = a.max() - a
    else:
        im = Image.open(p)
        a = np.asarray(im.convert("L") if im.mode not in ("I;16", "I") else im).astype(np.float32)
    meta = dict(h=a.shape[0], w=a.shape[1], mean=float(a.mean()), std=float(a.std()), maxv=float(a.max()), minv=float(a.min()))
    lo, hi = np.percentile(a, [0.5, 99.5])
    a8 = np.clip((a - lo) / max(hi - lo, 1e-6), 0, 1) * 255
    im8 = Image.fromarray(a8.astype(np.uint8))
    if mode in ("std", "strong"):
        im8 = ImageOps.equalize(im8)
        if mode == "strong":
            im8 = im8.filter(ImageFilter.GaussianBlur(radius=1.0)).resize((256, 256), Image.BILINEAR)
        q = 90 if mode == "std" else 60
        buf = io.BytesIO()
        im8.save(buf, "JPEG", quality=q)
        buf.seek(0)
        im8 = Image.open(buf).convert("L")
    return np.asarray(im8), meta


def to_224(img_u8):
    return np.asarray(Image.fromarray(img_u8).resize((224, 224), Image.BILINEAR))


# ----------------------------------------------------------------------------- planted markers
MARKER_KINDS = ("corner", "intensity", "texture")


def plant_marker(img8, kind="corner", strength=1.0):
    """Known synthetic shortcut applied to a uint8 image (HxW or HxWxC), BEFORE the resize to 224.

    corner    : small bright block + soft corner gradient (the paper's marker)
    intensity : global brightness offset (+32 gray levels) with a mild contrast reduction (scanner-offset style cue)
    texture   : low-amplitude oblique sinusoidal grating (period about h/40 px) plus a faint fixed noise field (acquisition-texture style cue)
    """
    if kind not in MARKER_KINDS:
        raise ValueError(kind)
    a = img8.astype(np.float32).copy()
    h, w = a.shape[:2]
    three = a.ndim == 3

    def bc(m):                                   # broadcast an HxW field over channels
        return m[..., None] if three else m

    yy, xx = np.mgrid[:h, :w].astype(np.float32)
    if kind == "corner":
        y0, y1, x0, x1 = int(.03 * h), int(.09 * h), int(.03 * w), int(.09 * w)
        a[y0:y1, x0:x1] = 255 * strength + a[y0:y1, x0:x1] * (1 - strength)
        a += bc(25 * strength * np.clip(1 - (yy + xx) / (0.6 * (h + w)), 0, 1))
    elif kind == "intensity":
        a = a * (1 - 0.10 * strength) + 32 * strength
    else:  # texture
        period = max(h, w) / 40.0
        grating = np.sin(2 * np.pi * (xx + 0.5 * yy) / period)
        noise = np.random.default_rng(12345).standard_normal((h, w)).astype(np.float32)   # same field for every image of this size
        a += bc(14 * strength * grating + 4 * strength * noise)
    return np.clip(a, 0, 255).astype(np.uint8)


# ----------------------------------------------------------------------------- malaria masks and views
HAND_COLS = ["h", "w", "aspect", "cell_frac", "parasite_frac", "rand_overlap",
             "mR", "mG", "mB", "sR", "sG", "sB", "mH", "mS", "mV", "sH", "sS", "sV"]
VIEWS = ["full", "parasite", "rbc", "randcrop", "gray", "silhouette"]


def default_parasite_mask(rgb):
    """Giemsa-HSV rule (placeholder, not validated against annotations)."""
    from skimage.color import rgb2hsv
    hsv = rgb2hsv(rgb)
    cell = rgb.sum(2) > 30
    return cell & (hsv[..., 1] > 0.45) & (hsv[..., 2] < 0.70) & (hsv[..., 0] > 0.60)


def adaptive_parasite_mask(rgb, k: float = 2.5, opening_iters: int = 1):
    """Per-cell robust threshold on the dark, purple-ish (low green) tail.  k = number of robust SDs below the median green;
    the paper's reported results use k = 2.5 (the default).  Used by the mask sweep in item11."""
    from scipy.ndimage import binary_opening
    cell = rgb.sum(2) > 30
    if cell.sum() < 50:
        return np.zeros(cell.shape, bool)
    g = rgb[..., 1].astype(float)
    gc = g[cell]
    rstd = 1.4826 * np.median(np.abs(gc - np.median(gc))) + 1e-6
    pm = cell & (g < np.median(gc) - k * rstd) & (rgb[..., 2] > rgb[..., 1])
    return binary_opening(pm, iterations=opening_iters) if opening_iters > 0 else pm


def make_views(rgb, rng, pmask_fn):
    """Six image views of one malaria cell plus handcrafted baselines.  Identical logic to the original extraction script."""
    from scipy.ndimage import binary_dilation
    from skimage.color import rgb2hsv
    h, w, _ = rgb.shape
    cell = rgb.sum(2) > 30
    pm = pmask_fn(rgb)
    pmd = binary_dilation(pm, iterations=2)
    views = {"full": rgb}
    par = rgb.copy()
    par[~pmd] = 0
    cy, cx, r = h // 2, w // 2, int(0.35 * min(h, w))
    views["parasite"] = par[max(cy - r, 0):cy + r, max(cx - r, 0):cx + r]
    rbc = rgb.copy()
    rest = cell & ~pmd
    med = np.median(rgb[rest], axis=0) if rest.sum() > 10 else np.array([0, 0, 0])
    rbc[pmd] = med.astype(np.uint8)
    views["rbc"] = rbc
    best, best_ov = None, 2.0
    R = int(0.35 * min(h, w))
    yy, xx = np.mgrid[:h, :w]
    for _ in range(50):
        y0, x0 = rng.integers(R, max(h - R, R + 1)), rng.integers(R, max(w - R, R + 1))
        if abs(y0 - cy) + abs(x0 - cx) < R // 2:
            continue
        circ = (yy - y0) ** 2 + (xx - x0) ** 2 <= R ** 2
        ov = float((circ & pmd).sum()) / max(circ.sum(), 1)
        if ov < best_ov:
            best, best_ov = circ, ov
        if ov == 0:
            break
    if best is None:
        best, best_ov = ((yy - cy) ** 2 + (xx - cx) ** 2 <= R ** 2), 1.0
    rc = rgb.copy()
    rc[~best] = 0
    views["randcrop"] = rc
    g = rgb.mean(2)
    gz = np.zeros_like(g)
    if cell.sum() > 10:
        gz[cell] = (g[cell] - g[cell].mean()) / (g[cell].std() + 1e-6) * 40 + 128
    views["gray"] = np.stack([np.clip(gz, 0, 255).astype(np.uint8)] * 3, 2)
    views["silhouette"] = np.stack([(cell * 255).astype(np.uint8)] * 3, 2)
    hsv = rgb2hsv(rgb)
    px = rgb[cell] if cell.sum() else rgb.reshape(-1, 3)
    hp = hsv[cell] if cell.sum() else hsv.reshape(-1, 3)
    hand = ([h, w, h / w, cell.mean(), pm.sum() / max(cell.sum(), 1), best_ov]
            + list(px.mean(0)) + list(px.std(0)) + list(hp.mean(0)) + list(hp.std(0)))
    return views, np.array(hand, np.float32)
