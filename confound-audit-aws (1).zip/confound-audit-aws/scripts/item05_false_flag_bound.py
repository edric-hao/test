"""ITEM 5  Tighter false-flag bound at rho = 0.5 (marker independent of disease).

The paper's 20 splits resample the same images, so its 0.14 bound is optimistic.  This script reports, for every audit criterion:
  1. all repetitions   N >= 100 random 50/50 splits, each on a fresh random subsample of the pool (default 70% of the images) and
                       fresh marker draws.  Exact Clopper-Pearson two-sided interval and exact one-sided 95% upper bound.
                       (k = 0 of N gives 1 - 0.05^(1/N): 0.0148 for N = 200.)  The subsamples overlap, so this is the optimistic bound.
  2. disjoint folds    the pool is cut into K disjoint image folds, each analysed on its own.  Trials in different folds share no
                       image, so per-fold false-flag rates are independent.  We report the pooled interval and the fold-level spread,
                       and the conservative bound that treats each fold as ONE independent Bernoulli trial.
'any' = C1 or C2 or C3 shows how the false-flag rate grows when criteria are combined.

  python item05_false_flag_bound.py --planted xrv=feats/tbplanted_xrv_densenet121.npz ... --reps 200 --folds 4 --fold_reps 50
"""
import argparse

import numpy as np

from audit_lib import AuditConfig, PreCfg
from calib_engine import load_planted_npz, run_planted_calibration
from data_utils import Timer, dump, n_jobs_default, parse_kv, write_csv
from stats_utils import cp_upper_one_sided, group_kfold_indices, rate_summary

ap = argparse.ArgumentParser()
ap.add_argument("--planted", nargs="+", required=True)
ap.add_argument("--markers", nargs="+", default=["corner"])
ap.add_argument("--reps", type=int, default=200)
ap.add_argument("--frac", type=float, default=0.7)
ap.add_argument("--folds", type=int, default=4)
ap.add_argument("--fold_reps", type=int, default=50)
ap.add_argument("--rho", type=float, default=0.5)
ap.add_argument("--pca", type=int, default=64)
ap.add_argument("--preproc_json")
ap.add_argument("--n_jobs", type=int, default=n_jobs_default())
ap.add_argument("--tag", default="")
a = ap.parse_args()

import json
over = json.load(open(a.preproc_json)) if a.preproc_json else {}
cfg = AuditConfig(run_nonlinear=False)           # nonlinear leakage is not a flag criterion, skip for speed
KEYS = ["flag_probe_only", "flag_S", "flag_C1", "flag_C2", "flag_C3", "flag_loop"]


def disjoint_folds(y, groups, K, seed=0):
    y = np.asarray(y)
    if groups is not None:
        return [te for _tr, te in group_kfold_indices(groups, K, seed)]
    rng = np.random.default_rng(seed)
    folds = [[] for _ in range(K)]
    for c in np.unique(y):
        ids = rng.permutation(np.where(y == c)[0])
        for j, i in enumerate(ids):
            folds[j % K].append(i)
    return [np.sort(np.array(f)) for f in folds]


def flags_of(rows):
    ok = [r for r in rows if r.get("valid")]
    out = {k: [bool(r[k]) for r in ok] for k in KEYS if ok and k in ok[0]}
    out["flag_any"] = [bool(r["flag_C1"] or r["flag_C2"] or r["flag_C3"]) for r in ok]
    return out


out, tidy = {}, []
for tag, path in parse_kv(a.planted, "--planted").items():
    d = dict(PreCfg(pca_k=a.pca).as_dict())
    d.update(over.get("default", {}))
    d.update(over.get(tag, {}))
    pre = PreCfg(**d)
    for mk in a.markers:
        try:
            Zc, Zm, y, groups = load_planted_npz(path, mk)
        except KeyError as e:
            print(f"[skip] {e}")
            continue
        with Timer(f"{tag}/{mk}: {a.reps} subsample repetitions"):
            _, rows_all = run_planted_calibration(Zc, Zm, y, [a.rho], a.reps, pre, cfg, groups=groups, frac=a.frac, n_jobs=a.n_jobs)
        fl_all = flags_of(rows_all)
        folds = disjoint_folds(y, groups, a.folds)
        fold_flags = []
        for k, pool in enumerate(folds):
            with Timer(f"{tag}/{mk}: disjoint fold {k + 1}/{a.folds} (n={len(pool)} images)"):
                _, rows_f = run_planted_calibration(Zc, Zm, y, [a.rho], a.fold_reps, pre, cfg, groups=groups, pool=pool,
                                                    rep_offset=1000 * (k + 1), n_jobs=a.n_jobs)
            fold_flags.append(flags_of(rows_f))
        res = {}
        for key in fl_all:
            pooled = [v for ff in fold_flags for v in ff.get(key, [])]
            per_fold = [float(np.mean(ff[key])) if ff.get(key) else float("nan") for ff in fold_flags]
            fold_any = [bool(np.any(ff[key])) if ff.get(key) else False for ff in fold_flags]
            res[key] = {"all_reps": rate_summary(fl_all[key]), "disjoint_pooled": rate_summary(pooled), "per_fold_rate": per_fold,
                        "folds_with_any_flag": int(sum(fold_any)), "n_folds": len(folds),
                        "conservative_one_sided_upper_per_fold_block": cp_upper_one_sided(int(sum(fold_any)), len(folds))}
            for scope in ("all_reps", "disjoint_pooled"):
                s = res[key][scope]
                tidy.append(dict(encoder=tag, marker=mk, criterion=key, scope=scope, rho=a.rho, **s))
        out.setdefault(tag, {})[mk] = {"pre": pre.as_dict(), "n_images": int(len(y)), "criteria": res}
        print(f"\n=== {tag}/{mk}  false-flag at rho={a.rho}  (all reps N={a.reps}, frac={a.frac}; disjoint folds {a.folds} x {a.fold_reps})")
        print(f"{'criterion':18s} {'flags/N':>9s} {'rate':>6s} {'95% two-sided':>16s} {'upper(1-sided)':>15s} | {'disjoint k/N':>12s} {'upper':>6s}")
        for key, v in res.items():
            s, p = v["all_reps"], v["disjoint_pooled"]
            print(f"{key:18s} {s['k']:4d}/{s['n']:<4d} {s['rate']:6.3f} [{s['cp_lo']:.3f},{s['cp_hi']:.3f}] {s['cp_upper_one_sided']:15.3f} | "
                  f"{p['k']:5d}/{p['n']:<5d} {p['cp_upper_one_sided']:6.3f}")

out["config"] = {"reps": a.reps, "frac": a.frac, "folds": a.folds, "fold_reps": a.fold_reps, "rho": a.rho, "audit": cfg.__dict__}
dump(out, f"item05_false_flag_bound{a.tag}.json")
write_csv(tidy, f"item05_false_flag_bound{a.tag}.csv")
