"""Fine-tune a backbone END TO END on the confounded TB task (Belarus TB vs RSNA normals) and export features for every manifest row.

This is the 'fine-tuned encoder' arm of the audit (item 9).  The deployed classifier is the fine-tuned network itself, so the audit can
ask whether ITS source reliance survives linear erasure and how it behaves on source-matched data it never saw.

  python finetune_tb.py --manifest feats/tb_manifest.csv --backbone xrv_densenet121 --out feats/ft_xrv_densenet121.npz --epochs 4

Output npz keys
  Z         penultimate features (n x dim) of the fine-tuned network for ALL manifest rows (eval mode, fp32)
  logit     the fine-tuned head's logit for all rows
  split     'train' | 'val' (held-out Belarus/RSNA) | 'other' (source-matched sets, never trained on)
  head_w, head_b   the fine-tuned linear head (logit = Z @ head_w + head_b)
  H, Hcols  image metadata (as in extract_features tb)
  val_auc, matched_auc   AUC of the deployed classifier on held-out Belarus/RSNA and on all source-matched rows
Backbones: xrv_densenet121 | resnet50 | densenet121.  Images are cached to <out>.cache.npy so later runs skip decoding.
NOTE: needs a GPU and torch; it was desk-checked but not executed in the authoring environment (no torch there).
"""
import argparse
from pathlib import Path

import numpy as np
import pandas as pd
try:
    from tqdm import tqdm
except ImportError:                      # progress bars are optional
    def tqdm(it, **kw):
        return it

from imgproc import harmonize_mode, load_tb_image, to_224

ap = argparse.ArgumentParser()
ap.add_argument("--manifest", required=True)
ap.add_argument("--backbone", default="xrv_densenet121", choices=["xrv_densenet121", "resnet50", "densenet121"])
ap.add_argument("--out", required=True)
ap.add_argument("--epochs", type=int, default=4)
ap.add_argument("--lr", type=float, default=1e-4, help="backbone learning rate")
ap.add_argument("--head_lr", type=float, default=1e-3)
ap.add_argument("--batch", type=int, default=64)
ap.add_argument("--val_frac", type=float, default=0.3)
ap.add_argument("--seed", type=int, default=0)
ap.add_argument("--harmonize", nargs="?", const="std", default="none", choices=["none", "std", "strong"])
ap.add_argument("--workers", type=int, default=4)
ap.add_argument("--max_per_source", type=int, default=0, help="smoke tests: keep at most this many rows per source")
ap.add_argument("--no_pretrained", action="store_true", help="smoke tests only: random init (no weight download)")
a = ap.parse_args()

import torch
import torch.nn as nn
import torch.nn.functional as F
from concurrent.futures import ThreadPoolExecutor
from sklearn.metrics import roc_auc_score
from sklearn.model_selection import train_test_split

torch.manual_seed(a.seed)
np.random.seed(a.seed)
dev = "cuda" if torch.cuda.is_available() else "cpu"
man = pd.read_csv(a.manifest)
if a.max_per_source:
    man = pd.concat([g.head(a.max_per_source) for _, g in man.groupby("source")]).reset_index(drop=True)
y_all, src = man.label.values.astype(np.float32), man.source.values
out = Path(a.out)
out.parent.mkdir(parents=True, exist_ok=True)

# ------------------------------------------------------------------ image cache (uint8, 224x224, grayscale)
cache = out.with_suffix(".cache.npy")
metas_f = out.with_suffix(".meta.npz")
mode = harmonize_mode(a.harmonize)
if cache.exists() and metas_f.exists() and len(np.load(cache, mmap_mode="r")) == len(man):
    imgs = np.load(cache)
    mm = np.load(metas_f, allow_pickle=True)
    H, Hcols = mm["H"], mm["Hcols"]
else:
    imgs = np.zeros((len(man), 224, 224), np.uint8)
    metas = []

    def _one(p):
        arr, meta = load_tb_image(p, mode)
        return to_224(arr), meta

    with ThreadPoolExecutor(a.workers) as ex:
        for i, (im, meta) in enumerate(tqdm(ex.map(_one, man.path.tolist()), total=len(man), desc="decode")):
            imgs[i] = im
            metas.append(meta)
    H = pd.DataFrame(metas).values.astype(np.float32)
    Hcols = np.array(list(metas[0].keys()))
    np.save(cache, imgs)
    np.savez(metas_f, H=H, Hcols=Hcols)

# ------------------------------------------------------------------ split
nat = np.where(np.isin(src, ["belarus", "rsna"]))[0]
tr_idx, va_idx = train_test_split(nat, test_size=a.val_frac, stratify=y_all[nat], random_state=a.seed)
matched = np.where(~np.isin(src, ["belarus", "rsna"]))[0]
split = np.full(len(man), "other", dtype="<U5")
split[tr_idx], split[va_idx] = "train", "val"

# ------------------------------------------------------------------ model
IMN_M, IMN_S = torch.tensor([0.485, 0.456, 0.406]).view(1, 3, 1, 1), torch.tensor([0.229, 0.224, 0.225]).view(1, 3, 1, 1)


class Net(nn.Module):
    def __init__(self, name, pretrained):
        super().__init__()
        self.name = name
        if name == "xrv_densenet121":
            import torchxrayvision as xrv
            self.backbone = xrv.models.DenseNet(weights="densenet121-res224-all" if pretrained else None)
            self.dim = 1024
        else:
            import torchvision.models as tvm
            if name == "resnet50":
                self.backbone = tvm.resnet50(weights=tvm.ResNet50_Weights.IMAGENET1K_V1 if pretrained else None)
                self.backbone.fc = nn.Identity()
                self.dim = 2048
            else:
                self.backbone = tvm.densenet121(weights=tvm.DenseNet121_Weights.IMAGENET1K_V1 if pretrained else None)
                self.backbone.classifier = nn.Identity()
                self.dim = 1024
        self.head = nn.Linear(self.dim, 1)

    def features(self, x):
        return self.backbone.features2(x) if self.name == "xrv_densenet121" else self.backbone(x)

    def forward(self, x):
        f = self.features(x)
        return self.head(f).squeeze(1), f


def to_input(batch_u8, train=False):
    x = torch.from_numpy(batch_u8).to(dev).float().div(255.0).unsqueeze(1)       # B,1,224,224 in [0,1]
    if train:                                                                    # light augmentation: flip + small shift
        flip = torch.rand(x.shape[0], device=dev) < 0.5
        x = torch.where(flip.view(-1, 1, 1, 1), x.flip(3), x)
        xp = F.pad(x, (8, 8, 8, 8), mode="reflect")
        oy, ox = np.random.randint(0, 17, 2)
        x = xp[:, :, oy:oy + 224, ox:ox + 224]
    if a.backbone == "xrv_densenet121":
        return x * 2048 - 1024
    return (x.repeat(1, 3, 1, 1) - IMN_M.to(dev)) / IMN_S.to(dev)


net = Net(a.backbone, not a.no_pretrained).to(dev)
opt = torch.optim.AdamW([{"params": net.backbone.parameters(), "lr": a.lr}, {"params": net.head.parameters(), "lr": a.head_lr}], weight_decay=1e-4)
steps = a.epochs * int(np.ceil(len(tr_idx) / a.batch))
sched = torch.optim.lr_scheduler.OneCycleLR(opt, max_lr=[a.lr, a.head_lr], total_steps=steps, pct_start=0.15)
pos_weight = torch.tensor(float((y_all[tr_idx] == 0).sum() / max((y_all[tr_idx] == 1).sum(), 1)), dtype=torch.float32, device=dev)
lossf = nn.BCEWithLogitsLoss(pos_weight=pos_weight)


@torch.no_grad()
def run_eval(idx):
    net.eval()
    logits, feats = [], []
    for i in range(0, len(idx), 128):
        lg, f = net(to_input(imgs[idx[i:i + 128]]))
        logits.append(lg.float().cpu().numpy())
        feats.append(f.float().cpu().numpy())
    return (np.concatenate(logits), np.concatenate(feats)) if logits else (np.zeros(0), np.zeros((0, net.dim)))


def safe_auc(yv, s):
    return float(roc_auc_score(yv, s)) if len(np.unique(yv)) == 2 else float("nan")


for ep in range(a.epochs):
    net.train()
    order = np.random.permutation(tr_idx)
    tot = 0.0
    for i in tqdm(range(0, len(order), a.batch), desc=f"epoch {ep + 1}/{a.epochs}"):
        b = np.sort(order[i:i + a.batch])
        if len(b) < 2:
            continue
        lg, _ = net(to_input(imgs[b], train=True))
        loss = lossf(lg, torch.from_numpy(y_all[b]).to(dev))
        opt.zero_grad()
        loss.backward()
        opt.step()
        sched.step()
        tot += float(loss) * len(b)
    lv, _ = run_eval(va_idx)
    lm, _ = run_eval(matched)
    print(f"epoch {ep + 1}: train loss {tot / len(order):.4f} | held-out Belarus/RSNA AUC {safe_auc(y_all[va_idx], lv):.4f} | source-matched AUC {safe_auc(y_all[matched], lm):.4f}",
          flush=True)

# ------------------------------------------------------------------ export
allidx = np.arange(len(man))
logit, Z = run_eval(allidx)
w = net.head.weight.detach().float().cpu().numpy()[0]
b = float(net.head.bias.detach().float().cpu().numpy()[0])
chk = float(np.abs(Z @ w + b - logit).max())
print(f"head consistency check max|Z@w+b - logit| = {chk:.2e}")
np.savez(out, Z=Z, logit=logit, split=split, head_w=w, head_b=b, H=H, Hcols=Hcols,
         val_auc=safe_auc(y_all[va_idx], logit[va_idx]), matched_auc=safe_auc(y_all[matched], logit[matched]))
print(f"[done] fine-tuned {a.backbone} -> {out}")
