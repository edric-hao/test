"""Trial builders and the parallel calibration runner (planted markers, tabular markers, natural shortcuts)."""
from __future__ import annotations

from dataclasses import replace

import numpy as np
from joblib import Parallel, delayed
from sklearn.model_selection import GroupShuffleSplit, train_test_split

from audit_lib import AuditConfig, PreCfg, Trial, audit_trial, fit_preproc, summarize_rows
from common import check_finite
from malaria_groups import groups_from_names


# ----------------------------------------------------------------------------- loading
def load_planted_npz(path, marker="corner"):
    """Returns Z_clean, Z_marked, y, groups (None unless the file carries malaria file names)."""
    d = np.load(path, allow_pickle=True)
    key = f"Z_marked_{marker}"
    if key in d.files:
        Zm = d[key]
    elif marker == "corner" and "Z_marked" in d.files:
        Zm = d["Z_marked"]
    else:
        raise KeyError(f"{path} has no marker {marker!r}; available: {[k for k in d.files if k.startswith('Z_marked')]}")
    check_finite("Z_clean", d["Z_clean"])
    check_finite(key, Zm)
    groups = groups_from_names(d["names"], "prefix") if "names" in d.files else None
    return d["Z_clean"], Zm, d["y"], groups


def tabular_planted_arrays(X, kind="binary", amp=1.0, noise_sd=0.3, seed=0):
    """Append one synthetic shortcut column to tabular data.  kind=binary: 0 (clean) / 1 (marked) exactly.
    kind=shift: seeded Gaussian noise (clean) / the same noise plus amp (marked), a continuous scanner-offset style cue."""
    X = np.asarray(X, float)
    n = len(X)
    if kind == "binary":
        c, m = np.zeros(n), np.ones(n)
    elif kind == "shift":
        noise = np.random.default_rng(seed).standard_normal(n) * noise_sd
        c, m = noise, noise + amp
    else:
        raise ValueError(kind)
    return np.c_[X, c], np.c_[X, m]


# ----------------------------------------------------------------------------- planted trials
def stratified_subsample(y, frac, rng):
    y = np.asarray(y)
    keep = []
    for c in np.unique(y):
        ids = np.where(y == c)[0]
        keep.append(rng.choice(ids, size=max(2, int(round(frac * len(ids)))), replace=False))
    return np.sort(np.concatenate(keep))


def prepare_planted_split(Zc, Zm, y, rep, pre: PreCfg, groups=None, frac=1.0, test_size=0.5, seed_base=0, pool=None):
    """Everything that does not depend on rho: pool selection, train/test split, feature reduction, true planted direction.
    With frac=1, pool=None, groups=None, seed_base=0 and PreCfg(pca_k=64) this reproduces E6 exactly."""
    y = np.asarray(y)
    n = len(y)
    if pool is None:
        pool = np.arange(n)
        if frac < 1.0:
            pool = stratified_subsample(y, frac, np.random.default_rng([seed_base, 10_000 + rep]))
    if groups is None:
        tr, te = train_test_split(pool, test_size=test_size, stratify=y[pool], random_state=rep + seed_base)
    else:
        a, b = next(GroupShuffleSplit(1, test_size=test_size, random_state=rep + seed_base).split(pool, groups=np.asarray(groups)[pool]))
        tr, te = pool[a], pool[b]
    fitpool = np.concatenate([Zc[tr], Zm[tr]]) if pre.pca_fit == "both" else Zc[tr]
    f = fit_preproc(fitpool, pre)
    Zc_p, Zm_p = f(Zc), f(Zm)
    dtrue = (Zm_p[pool] - Zc_p[pool]).mean(0)
    nrm = np.linalg.norm(dtrue)
    dtrue = dtrue / nrm if nrm > 0 else dtrue
    return dict(tr=tr, te=te, Zc_p=Zc_p, Zm_p=Zm_p, dtrue=dtrue, y=y)


def make_planted_trial(sp, rho, rep, seed_base=0) -> Trial:
    """Marker prevalence among positives is rho and among negatives 1-rho (rho=0.5: no association).  Set a draws the marker at the
    training prevalence, set b at the reversed prevalence (1-rho), on the SAME held-out images (paired)."""
    y, tr, te = sp["y"], sp["tr"], sp["te"]
    rng = np.random.default_rng(rep + seed_base)

    def mk(ids, p1):
        return rng.random(len(ids)) < np.where(y[ids] == 1, p1, 1 - p1)

    mtr, mconc, mflip = mk(tr, rho), mk(te, rho), mk(te, 1 - rho)          # draw order identical to E6
    Zc_p, Zm_p = sp["Zc_p"], sp["Zm_p"]
    pick = lambda m, ids: np.where(m[:, None], Zm_p[ids], Zc_p[ids])
    return Trial(Ztr=pick(mtr, tr), ytr=y[tr], mtr=mtr.astype(int), Za=pick(mconc, te), ya=y[te], ma=mconc.astype(int),
                 Zb=pick(mflip, te), yb=y[te], mb=mflip.astype(int), paired=True, rng=rng,
                 seed=rep + 100000 * int(round(rho * 100)), dtrue=sp["dtrue"])


def _planted_rep(Zc, Zm, y, rhos, rep, pre, cfg, groups, frac, test_size, seed_base, pool):
    sp = prepare_planted_split(Zc, Zm, y, rep, pre, groups, frac, test_size, seed_base, pool)
    rows = []
    for rho in rhos:
        r = audit_trial(make_planted_trial(sp, rho, rep, seed_base), cfg)
        r["rho"], r["rep"] = float(rho), int(rep)
        rows.append(r)
    return rows


def run_planted_calibration(Zc, Zm, y, rhos, reps, pre: PreCfg, cfg: AuditConfig, groups=None, frac=1.0, test_size=0.5, seed_base=0,
                            n_jobs=1, pool=None, rep_offset=0):
    """Returns ({str(rho): summarize_rows(...)}, flat list of per-trial rows).  Parallel over repetitions."""
    if pre.leace_shrink > 0 and cfg.leace_shrink == 0:
        cfg = replace(cfg, leace_shrink=pre.leace_shrink)
    jobs = Parallel(n_jobs=n_jobs)(delayed(_planted_rep)(Zc, Zm, y, list(rhos), rep + rep_offset, pre, cfg, groups, frac, test_size,
                                                          seed_base, pool) for rep in range(reps))
    rows = [r for rr in jobs for r in rr]
    out = {}
    for rho in rhos:
        out[str(rho)] = summarize_rows([r for r in rows if r["rho"] == float(rho)])
    return out, rows


# ----------------------------------------------------------------------------- natural trials
def balance_by_group(y, s, idx, rng):
    """Subsample idx so that P(y=1 | s=g) is 0.5 inside every shortcut group g (removes the label-shortcut association)."""
    keep = []
    for g in np.unique(s[idx]):
        ig = idx[s[idx] == g]
        pos, neg = ig[y[ig] == 1], ig[y[ig] == 0]
        k = min(len(pos), len(neg))
        if k == 0:
            continue
        keep.append(rng.choice(pos, k, replace=False))
        keep.append(rng.choice(neg, k, replace=False))
    return np.sort(np.concatenate(keep)) if keep else np.array([], int)


def natural_trial(Z, y, s, tr, te, pre: PreCfg, rng, seed=0, orientation="train_sign") -> Trial:
    """Natural shortcut s (0/1).  Set a = test samples whose s agrees with the training label association, set b = disagree.
    orientation='same' forces concordant = (s == y) (use for balanced training data where the sign is arbitrary)."""
    f = fit_preproc(Z[tr], pre)
    Ztr, Zte = f(Z[tr]), f(Z[te])
    if orientation == "same":
        same = True
    else:
        c = np.corrcoef(s[tr], y[tr])[0, 1] if (np.std(s[tr]) > 0 and np.std(y[tr]) > 0) else 0.0
        same = bool(c >= 0)
    agree = (s[te] == y[te]) if same else (s[te] == 1 - y[te])
    ia, ib = np.where(agree)[0], np.where(~agree)[0]
    return Trial(Ztr=Ztr, ytr=y[tr], mtr=s[tr].astype(int), Za=Zte[ia], ya=y[te][ia], ma=s[te][ia].astype(int),
                 Zb=Zte[ib], yb=y[te][ib], mb=s[te][ib].astype(int), paired=False, rng=rng, seed=seed)


def source_case_trial(Z, y, tr, te_in, matched, pre: PreCfg, rng, seed=0) -> Trial:
    """TB source confound as an audit trial.  Training = Belarus (TB) vs RSNA (normal), so the source label equals the disease label.
    Set a = held-out Belarus/RSNA images (in-distribution), set b = source-matched Shenzhen/Montgomery images (the discordant
    analogue).  The shortcut label of set b is undefined (-1), so paired baselines that need it become inapplicable."""
    f = fit_preproc(Z[tr], pre)
    return Trial(Ztr=f(Z[tr]), ytr=y[tr], mtr=y[tr].astype(int), Za=f(Z[te_in]), ya=y[te_in], ma=y[te_in].astype(int),
                 Zb=f(Z[matched]), yb=y[matched], mb=np.full(len(matched), -1), paired=False, rng=rng, seed=seed)


def run_trials(trial_fns, cfg: AuditConfig, n_jobs=1):
    """trial_fns: list of zero-argument callables returning Trial.  Returns the list of audit rows."""
    def one(fn):
        return audit_trial(fn(), cfg)
    return Parallel(n_jobs=n_jobs)(delayed(one)(fn) for fn in trial_fns)
