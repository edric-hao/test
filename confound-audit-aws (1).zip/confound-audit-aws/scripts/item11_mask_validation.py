"""ITEM 11b  Validate the parasite mask that defines the 'RBC-only' and 'parasite' views.

There are no pixel annotations in the NIH cell-image release, so validation is indirect and is reported as such:
  1. mask area by class: a useful mask should cover far more of Parasitized cells than of Uninfected cells; the uninfected rate is the
     false-positive burden (platelets, stain debris, cell edge)
  2. AUC of mask area alone as a classifier (per setting)
  3. agreement (IoU) between the adaptive mask at k = 2.5 and the other settings and the HSV rule
  4. leftover signal: for the RBC-only view the mask is dilated and filled with the median cell colour; the residual parasite fraction
     after masking is re-measured with a looser mask (k = 1.5) as a leakage proxy
  5. overlay montages (PNG) of random Parasitized and Uninfected cells with the mask boundary, for the supplement and for eyeballing

  python item11_mask_validation.py --root cell_images --n 600 --out_dir results/mask_validation
"""
import argparse
from pathlib import Path

import numpy as np
from PIL import Image

from common import RESULTS
from data_utils import Timer, dump
from imgproc import adaptive_parasite_mask, default_parasite_mask, list_images
from stats_utils import fast_auc

ap = argparse.ArgumentParser()
ap.add_argument("--root", required=True)
ap.add_argument("--n", type=int, default=600, help="cells per class")
ap.add_argument("--ks", default="1.5,2.0,2.5,3.0,3.5")
ap.add_argument("--montage", type=int, default=24, help="cells per class in each montage")
ap.add_argument("--out_dir", default="")
ap.add_argument("--seed", type=int, default=0)
ap.add_argument("--tag", default="")
a = ap.parse_args()

root = Path(a.root)
if not (root / "Parasitized").exists() and (root / "cell_images" / "Parasitized").exists():
    root = root / "cell_images"
cls = {1: list_images(root / "Parasitized", (".png",)), 0: list_images(root / "Uninfected", (".png",))}
rng = np.random.default_rng(a.seed)
pick = {c: [fs[i] for i in rng.choice(len(fs), min(a.n, len(fs)), replace=False)] for c, fs in cls.items()}
out_dir = Path(a.out_dir) if a.out_dir else Path(RESULTS) / "mask_validation"
out_dir.mkdir(parents=True, exist_ok=True)

ks = [float(k) for k in a.ks.split(",")]
settings = {f"adaptive_k{k}": (lambda rgb, k=k: adaptive_parasite_mask(rgb, k=k)) for k in ks}
settings["adaptive_k2.5_noopen"] = lambda rgb: adaptive_parasite_mask(rgb, k=2.5, opening_iters=0)
settings["hsv_rule"] = default_parasite_mask
REF = "adaptive_k2.5"

area = {s: {0: [], 1: []} for s in settings}
iou = {s: [] for s in settings}
resid = []
cache = {0: [], 1: []}
with Timer("masks"):
    for c in (0, 1):
        for f in pick[c]:
            rgb = np.asarray(Image.open(f).convert("RGB"))
            cell = rgb.sum(2) > 30
            den = max(int(cell.sum()), 1)
            ms = {s: fn(rgb) for s, fn in settings.items()}
            for s, m in ms.items():
                area[s][c].append(float(m.sum()) / den)
                u = (m | ms[REF]).sum()
                iou[s].append(float((m & ms[REF]).sum()) / u if u > 0 else 1.0)
            # leftover signal after dilated masking, measured with the loosest adaptive mask
            from scipy.ndimage import binary_dilation
            masked = binary_dilation(ms[REF], iterations=2)
            rgb2 = rgb.copy()
            rest = cell & ~masked
            if rest.sum() > 10:
                rgb2[masked] = np.median(rgb[rest], axis=0).astype(np.uint8)
            resid.append((c, float(adaptive_parasite_mask(rgb2, k=1.5).sum()) / den))
            if len(cache[c]) < a.montage:
                cache[c].append((rgb, ms[REF]))

res = {"n_per_class": {int(c): len(v) for c, v in pick.items()}, "reference": REF, "settings": {}}
print(f"\n{'setting':24s} {'area|Parasitized':>17s} {'area|Uninfected':>16s} {'frac Uninf. with mask':>22s} {'AUC(area)':>10s} {'IoU vs ref':>11s}")
for s in settings:
    ap_, au_ = np.array(area[s][1]), np.array(area[s][0])
    yy = np.r_[np.ones(len(ap_)), np.zeros(len(au_))]
    r = {"area_parasitized_mean": float(ap_.mean()), "area_uninfected_mean": float(au_.mean()), "frac_uninfected_with_any_mask": float((au_ > 0).mean()),
         "frac_parasitized_with_any_mask": float((ap_ > 0).mean()), "auc_mask_area": float(fast_auc(yy, np.r_[ap_, au_])), "iou_vs_reference": float(np.mean(iou[s]))}
    res["settings"][s] = r
    print(f"{s:24s} {r['area_parasitized_mean']:17.4f} {r['area_uninfected_mean']:16.4f} {r['frac_uninfected_with_any_mask']:22.3f} {r['auc_mask_area']:10.3f} {r['iou_vs_reference']:11.3f}")
rs = np.array(resid)
res["residual_after_masking"] = {"parasitized_mean_area_k1.5": float(rs[rs[:, 0] == 1, 1].mean()), "uninfected_mean_area_k1.5": float(rs[rs[:, 0] == 0, 1].mean()),
                                 "auc_residual_area": float(fast_auc(rs[:, 0], rs[:, 1]))}
print(f"\nresidual signal in the RBC-only view (loose k=1.5 mask after masking at {REF}): AUC of residual area {res['residual_after_masking']['auc_residual_area']:.3f}")
print("An AUC near 0.5 means the masked view no longer carries mask-detectable parasite pixels; a value well above 0.5 means the RBC-only view still leaks parasite signal.")


def edge(m):
    from scipy.ndimage import binary_erosion
    return m & ~binary_erosion(m)


def montage(items, path, size=96, cols=8):
    rows = (len(items) + cols - 1) // cols
    canvas = np.zeros((rows * size, cols * size * 2, 3), np.uint8)
    for i, (rgb, m) in enumerate(items):
        im = np.asarray(Image.fromarray(rgb).resize((size, size), Image.BILINEAR))
        mm = np.asarray(Image.fromarray(m.astype(np.uint8) * 255).resize((size, size), Image.NEAREST)) > 0
        ov = im.copy()
        ov[edge(mm)] = (0, 255, 0)
        r, c = divmod(i, cols)
        canvas[r * size:(r + 1) * size, c * size * 2:c * size * 2 + size] = im
        canvas[r * size:(r + 1) * size, c * size * 2 + size:(c + 1) * size * 2] = ov
    Image.fromarray(canvas).save(path)


montage(cache[1], out_dir / f"mask_overlay_parasitized{a.tag}.png")
montage(cache[0], out_dir / f"mask_overlay_uninfected{a.tag}.png")
res["montages"] = [str(out_dir / f"mask_overlay_parasitized{a.tag}.png"), str(out_dir / f"mask_overlay_uninfected{a.tag}.png")]
dump({"results": res, "config": vars(a)}, f"item11_mask_validation{a.tag}.json")
