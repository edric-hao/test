"""ITEM 13  Multiplicity handling.

Reads results/test_registry.jsonl (appended by E3 and items 10 and 11 through data_utils.register_tests), keeps the LATEST entry per
(experiment, name) so reruns do not double count, and reports raw, Holm-adjusted and Benjamini-Hochberg-adjusted p-values
  * over the whole registry (the conservative reading: every test in the paper is one family)
  * within each family (experiment family, the usual reading)
and how many conclusions change.  The registry holds only tests that have a p-value.  Calibration flag rates carry exact binomial
intervals instead (items 3 and 5) and are not p-value tests.

  python item13_multiplicity.py [--alpha 0.05] [--registry results/test_registry.jsonl]
"""
import argparse
import json
from collections import defaultdict

import numpy as np

from common import RESULTS
from data_utils import dump, write_csv
from stats_utils import benjamini_hochberg, holm

ap = argparse.ArgumentParser()
ap.add_argument("--alpha", type=float, default=0.05)
ap.add_argument("--registry", default="")
ap.add_argument("--tag", default="")
a = ap.parse_args()

path = a.registry or str(RESULTS / "test_registry.jsonl")
latest = {}
n_lines = 0
with open(path) as f:
    for line in f:
        line = line.strip()
        if not line:
            continue
        n_lines += 1
        r = json.loads(line)
        latest[(r["experiment"], r["name"])] = r        # later lines overwrite earlier ones
tests = list(latest.values())
valid = [t for t in tests if t.get("p") is not None and not (isinstance(t["p"], float) and np.isnan(t["p"]))]
print(f"registry lines {n_lines}, unique tests {len(tests)}, with a usable p-value {len(valid)}")
if not valid:
    raise SystemExit("no tests with p-values in the registry; run E3, item10 and item11 first")

p = np.array([float(t["p"]) for t in valid])
holm_all, bh_all = holm(p), benjamini_hochberg(p)
fam_holm, fam_bh = np.zeros(len(p)), np.zeros(len(p))
by_fam = defaultdict(list)
for i, t in enumerate(valid):
    by_fam[t.get("family", t["experiment"])].append(i)
for fam, idx in by_fam.items():
    fam_holm[idx], fam_bh[idx] = holm(p[idx]), benjamini_hochberg(p[idx])

rows = []
for i, t in enumerate(valid):
    rows.append(dict(experiment=t["experiment"], family=t.get("family", t["experiment"]), name=t["name"], p_raw=p[i],
                     holm_global=holm_all[i], bh_global=bh_all[i], holm_in_family=fam_holm[i], bh_in_family=fam_bh[i],
                     sig_raw=bool(p[i] < a.alpha), sig_holm_global=bool(holm_all[i] < a.alpha), sig_bh_global=bool(bh_all[i] < a.alpha),
                     sig_holm_family=bool(fam_holm[i] < a.alpha), sig_bh_family=bool(fam_bh[i] < a.alpha)))
rows.sort(key=lambda r: r["p_raw"])
write_csv(rows, f"item13_multiplicity{a.tag}.csv")

summary = {"alpha": a.alpha, "n_tests": len(valid), "n_families": len(by_fam),
           "significant": {"raw": int((p < a.alpha).sum()), "holm_global": int((holm_all < a.alpha).sum()), "bh_global": int((bh_all < a.alpha).sum()),
                           "holm_family": int((fam_holm < a.alpha).sum()), "bh_family": int((fam_bh < a.alpha).sum())},
           "per_family": {fam: {"n": len(idx), "raw": int((p[idx] < a.alpha).sum()), "holm_family": int((fam_holm[idx] < a.alpha).sum()),
                                "bh_family": int((fam_bh[idx] < a.alpha).sum()), "holm_global": int((holm_all[idx] < a.alpha).sum())}
                          for fam, idx in by_fam.items()},
           "lost_under_holm_global": [r["name"] for r in rows if r["sig_raw"] and not r["sig_holm_global"]][:50]}
dump({"summary": summary, "rows": rows}, f"item13_multiplicity{a.tag}.json")

s = summary["significant"]
print(f"\nsignificant at alpha={a.alpha}:  raw {s['raw']}/{len(valid)}   Holm (all tests as one family) {s['holm_global']}   BH (all) {s['bh_global']}   "
      f"Holm within family {s['holm_family']}   BH within family {s['bh_family']}")
print(f"\n{'family':28s} {'n':>4s} {'raw':>5s} {'Holm-fam':>9s} {'BH-fam':>7s} {'Holm-all':>9s}")
for fam, v in summary["per_family"].items():
    print(f"{fam:28s} {v['n']:4d} {v['raw']:5d} {v['holm_family']:9d} {v['bh_family']:7d} {v['holm_global']:9d}")
if summary["lost_under_holm_global"]:
    print("\nsignificant raw but not after global Holm:")
    for n in summary["lost_under_holm_global"][:15]:
        print("   ", n)
