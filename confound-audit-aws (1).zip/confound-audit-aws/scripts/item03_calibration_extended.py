"""ITEM 3  Broader calibration of the audit.

Adds to the paper's single calibration (corner block, TB, flag = LEACE gain):
  * second and third marker types in TB: global intensity offset and an oblique texture grating
  * second and third flag criteria: C2 retrained-head drop after erasure, C3 label information carried by the shortcut direction
    (C1 = the paper's LEACE gain is always reported too, and 'any' = C1 or C2 or C3 shows the cost of combining criteria)
  * planted shortcuts of known prevalence in the MALARIA cell images (patient-grouped splits) and in the GLIOMA tabular data
For every (domain, encoder, marker, rho) the flag rate is reported with an exact Clopper-Pearson interval.  rho = 0.5 is the
false-flag setting, rho >= 0.7 measures power.

  python item03_calibration_extended.py --tb xrv=feats/tbplanted_xrv_densenet121.npz ... --markers corner intensity texture \
      --malaria resnet50=feats/malplanted_resnet50.npz ... --glioma_csv cohort.csv --reps 50
"""
import argparse
import json

import numpy as np

from audit_lib import AuditConfig, PreCfg
from calib_engine import load_planted_npz, run_planted_calibration, tabular_planted_arrays
from data_utils import Timer, dump, flag_table, n_jobs_default, parse_kv, tidy_rows, write_csv
from stats_utils import rate_summary

ap = argparse.ArgumentParser()
ap.add_argument("--tb", nargs="+", default=[])
ap.add_argument("--malaria", nargs="+", default=[])
ap.add_argument("--glioma_csv")
ap.add_argument("--glioma_kinds", nargs="+", default=["binary", "shift"])
ap.add_argument("--markers", nargs="+", default=["corner", "intensity", "texture"])
ap.add_argument("--rhos", type=float, nargs="+", default=[0.5, 0.6, 0.7, 0.8, 0.9, 1.0])
ap.add_argument("--reps", type=int, default=50)
ap.add_argument("--frac", type=float, default=1.0, help="image subsample per repetition (use 0.5 for malaria to save time)")
ap.add_argument("--pca", type=int, default=64)
ap.add_argument("--preproc_json", help='per-encoder PreCfg overrides, e.g. {"xrv": {"pca_k": 128, "standardize": true}}')
ap.add_argument("--n_null", type=int, default=30)
ap.add_argument("--n_null_retrain", type=int, default=20)
ap.add_argument("--n_jobs", type=int, default=n_jobs_default())
ap.add_argument("--tag", default="")
a = ap.parse_args()

cfg = AuditConfig(n_null=a.n_null, n_null_retrain=a.n_null_retrain)
over = json.load(open(a.preproc_json)) if a.preproc_json else {}
KEYS = ["flag_C1", "flag_C2", "flag_C3", "flag_any", "flag_loop"]
out, tidy = {}, []


def pre_for(tag):
    d = PreCfg(pca_k=a.pca).as_dict()
    d.update(over.get("default", {}))
    d.update(over.get(tag, {}))
    return PreCfg(**d)


def add_any(by_rho, rows):
    for rho, s in by_rho.items():
        v = [bool(r["flag_C1"] or r["flag_C2"] or r["flag_C3"]) for r in rows if r.get("valid") and r["rho"] == float(rho)]
        if v:
            s["flags"]["flag_any"] = rate_summary(v)


def run(domain, tag, marker, Zc, Zm, y, groups, pre, frac):
    with Timer(f"{domain} / {tag} / {marker}"):
        by_rho, rows = run_planted_calibration(Zc, Zm, y, a.rhos, a.reps, pre, cfg, groups=groups, frac=frac, n_jobs=a.n_jobs)
    add_any(by_rho, rows)
    out.setdefault(domain, {}).setdefault(tag, {})[marker] = {"pre": pre.as_dict(), "by_rho": by_rho}
    tidy.extend(tidy_rows(domain, tag, marker, by_rho))
    print(f"\n=== {domain} / {tag} / {marker}  (rho=0.5 false-flag rate, others power)")
    flag_table(by_rho, KEYS)


for tag, path in parse_kv(a.tb, "--tb").items():
    for mk in a.markers:
        try:
            Zc, Zm, y, groups = load_planted_npz(path, mk)
        except KeyError as e:
            print(f"[skip] {e}")
            continue
        run("tb", tag, mk, Zc, Zm, y, groups, pre_for(tag), a.frac)

for tag, path in parse_kv(a.malaria, "--malaria").items():
    for mk in a.markers:
        try:
            Zc, Zm, y, groups = load_planted_npz(path, mk)
        except KeyError as e:
            print(f"[skip] {e}")
            continue
        run("malaria", tag, mk, Zc, Zm, y, groups, pre_for(tag), a.frac)

if a.glioma_csv:
    from glioma_data import load_glioma
    D = load_glioma(a.glioma_csv)
    X = D["X"].drop(columns=["grade"]).values.astype(float)      # grade-excluded features, as in the paper's refit
    for kind in a.glioma_kinds:
        Zc, Zm = tabular_planted_arrays(X, kind=kind, amp=1.0, noise_sd=0.3)
        run("glioma", "tabular", kind, Zc, Zm, D["y"], None, PreCfg(pca_k=None), 1.0)

out["config"] = {"audit": cfg.__dict__, "reps": a.reps, "rhos": a.rhos, "frac": a.frac}
dump(out, f"item03_calibration_extended{a.tag}.json")
write_csv(tidy, f"item03_flag_rates{a.tag}.csv")

# one-line-per-cell summary of false flags and power, computed
print("\nSUMMARY  domain/encoder/marker: false-flag (rho=0.5) and mean power (rho>=0.7) per criterion")
for dom, encs in out.items():
    if dom == "config":
        continue
    for tag, mks in encs.items():
        for mk, v in mks.items():
            br = v["by_rho"]
            cells = []
            for k in KEYS:
                if k in br.get("0.5", {}).get("flags", {}):
                    pw = [br[r]["flags"][k]["rate"] for r in br if float(r) >= 0.7 and k in br[r]["flags"]]
                    cells.append(f"{k.replace('flag_', '')}: {br['0.5']['flags'][k]['rate']:.2f}/{np.mean(pw):.2f}")
            print(f"  {dom}/{tag}/{mk}: " + "  ".join(cells))
