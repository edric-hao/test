"""Core audit machinery shared by the item01..item13 scripts.

A Trial packages one train/test situation:
    train features Ztr with label ytr and shortcut label mtr, and two evaluation sets
      set a = "concordant"  (shortcut agrees with the training association; planted case: the held-out images with the marker
                              drawn at the training prevalence)
      set b = "flipped / discordant" (planted case: the SAME held-out images with the marker drawn at the reversed prevalence;
                              natural case: held-out samples whose shortcut disagrees with the training association)
`audit_trial` then runs, on that one trial, every audit variant the paper discusses plus the extensions requested in items 1-3:

  probe_only   presence only: is the shortcut linearly decodable on held-out data?
  S            single-direction ablation of the recovered probe direction, fixed head, vs random-direction null
  C1           LEACE gain on set b vs random-direction null  (the paper's flag criterion)
  C2           retrained-head drop after LEACE erasure vs random-direction erase-and-retrain null  (second criterion, item 3)
  C3           label information carried by the shortcut direction vs random-direction null       (third criterion, item 3)
  loop         the iterative decision procedure (presence -> stratified tax -> ablation controls -> nonlinear-leakage escalation)
  js           Jimenez-Sanchez-style performance-gap test (needs the shortcut annotation)
  short        ShorT-style test (Brown et al. 2023) adapted to frozen features
"""
from __future__ import annotations

import warnings
from dataclasses import dataclass
from typing import Optional

import numpy as np
from sklearn.decomposition import PCA
from sklearn.linear_model import LogisticRegression
from sklearn.neural_network import MLPClassifier

from common import cov_random_direction, lr, project_out, raw_direction
from erasers import INLP, LEACE
from stats_utils import boot_percentile, fast_auc, rate_summary, spearman

warnings.filterwarnings("ignore", category=UserWarning)
warnings.filterwarnings("ignore", message=".*[Cc]onverge.*")
try:                                                   # sklearn ConvergenceWarning is a UserWarning subclass in some versions
    from sklearn.exceptions import ConvergenceWarning
    warnings.filterwarnings("ignore", category=ConvergenceWarning)
except Exception:                                      # noqa: BLE001
    pass


# ----------------------------------------------------------------------------- configuration
@dataclass
class AuditConfig:
    margin: float = 0.02            # minimum effect size for any flag (paper: 0.02)
    n_null: int = 30                # random covariance-matched directions for the fixed-head criteria
    n_null_retrain: int = 20        # random directions for the erase-and-retrain null (C2)
    boot: int = 200                 # bootstrap draws for the tax / presence intervals
    run_nonlinear: bool = True      # MLP probe after linear erasure + INLP escalation in the loop
    mlp_hidden: int = 64
    inlp_rounds: int = 10
    leace_shrink: float = 0.0
    baselines: bool = False         # also compute js and short
    short_alphas: tuple = (0.0, 0.5, 1.0, 2.0, 4.0)
    short_reps: int = 3
    short_min_cell: int = 5
    seed: int = 0


@dataclass
class PreCfg:
    """Feature reduction applied before the audit (the paper uses PCA-64 fitted on the training pool, nothing else)."""
    pca_k: Optional[int] = 64
    standardize: bool = False
    drop_dead: bool = False
    l2norm: bool = False
    whiten: bool = False
    clip: Optional[float] = None
    pca_fit: str = "both"           # planted data only: fit on clean+marked train images ("both", as in E6) or clean only ("clean")
    leace_shrink: float = 0.0       # ridge shrinkage of the covariance inside LEACE (0 = the paper's eraser); copied into AuditConfig by the runners

    def as_dict(self):
        return dict(self.__dict__)


@dataclass
class Trial:
    Ztr: np.ndarray
    ytr: np.ndarray
    mtr: np.ndarray
    Za: np.ndarray
    ya: np.ndarray
    ma: np.ndarray
    Zb: np.ndarray
    yb: np.ndarray
    mb: np.ndarray
    paired: bool
    rng: np.random.Generator
    seed: int = 0
    dtrue: Optional[np.ndarray] = None
    sb_cache: Optional[np.ndarray] = None      # head scores on set b (filled by audit_trial)


# ----------------------------------------------------------------------------- feature reduction
def fit_preproc(pool, cfg: PreCfg):
    """Fit the reduction on `pool` (n x d) and return f(Z) -> reduced features.  Order: drop dead -> standardize -> clip -> L2 -> PCA."""
    P = np.asarray(pool, dtype=np.float64)
    live = np.ones(P.shape[1], bool)
    if cfg.drop_dead:
        live = P.std(0) > 1e-9
    mu = sd = None
    if cfg.standardize:
        mu = P[:, live].mean(0)
        sd = P[:, live].std(0)
        sd = np.where(sd < 1e-9, 1.0, sd)

    def base(Z):
        X = np.asarray(Z, dtype=np.float64)[:, live]
        if cfg.standardize:
            X = (X - mu) / sd
        if cfg.clip is not None:
            X = np.clip(X, -cfg.clip, cfg.clip)
        if cfg.l2norm:
            X = X / (np.linalg.norm(X, axis=1, keepdims=True) + 1e-12)
        return X

    if cfg.pca_k is None:
        return base
    pca = PCA(min(cfg.pca_k, P.shape[0] - 1, int(live.sum())), whiten=cfg.whiten, random_state=0).fit(base(P))
    return lambda Z: pca.transform(base(Z))


# ----------------------------------------------------------------------------- small helpers
def _p95(x):
    return float(np.percentile(np.asarray(x, float), 95))


def _boot_two_sets(ya, sa, yb, sb, B, rng, paired):
    """Bootstrap of AUC(a) - AUC(b).  Paired: resample the same image indices in both sets.  Unpaired: independently."""
    vals = []
    na, nb = len(ya), len(yb)
    for _ in range(B):
        ia = rng.integers(0, na, na)
        ib = ia if paired else rng.integers(0, nb, nb)
        v = fast_auc(ya[ia], sa[ia]) - fast_auc(yb[ib], sb[ib])
        if v == v:
            vals.append(v)
    if len(vals) < max(10, B // 10):
        return float("nan"), float("nan")
    return float(np.percentile(vals, 2.5)), float(np.percentile(vals, 97.5))


def _rank_matched_null(Z, y, head, base_auc, Ztr, rng, k, n):
    """Gain in AUC when k random covariance-matched directions are removed (null for rank-k erasers such as INLP)."""
    out = []
    for _ in range(n):
        X = Z
        for _j in range(k):
            X = project_out(X, cov_random_direction(Ztr, rng))
        out.append(fast_auc(y, head.decision_function(X)) - base_auc)
    return out


# ----------------------------------------------------------------------------- literature baselines
def js_gap_test(t: Trial, sa, cfg: AuditConfig, rb):
    """Jimenez-Sanchez et al. (2023)-style performance-gap test: AUC on shortcut-present positives (vs all negatives) minus AUC on
    shortcut-absent positives.  Planted (paired) trials: stratification by the planted marker on set a.  Natural trials: the
    concordant-vs-discordant AUC gap (identical to the audit's stratified step).  Returns (gap, lo, applicable)."""
    if not t.paired:
        lo, hi = _boot_two_sets(t.ya, sa, t.yb, t.sb_cache, cfg.boot, rb, False)
        gap = fast_auc(t.ya, sa) - fast_auc(t.yb, t.sb_cache)
        return gap, lo, bool(gap == gap)
    pos, neg = t.ya == 1, t.ya == 0
    w, wo = pos & (t.ma == 1), pos & (t.ma == 0)
    if w.sum() < cfg.short_min_cell or wo.sum() < cfg.short_min_cell or neg.sum() < cfg.short_min_cell:
        return float("nan"), float("nan"), False

    def gap_at(i):
        yy, ss, mm = t.ya[i], sa[i], t.ma[i]
        pp, nn = yy == 1, yy == 0
        iw, iwo = pp & (mm == 1), pp & (mm == 0)
        if iw.sum() < 2 or iwo.sum() < 2:
            return float("nan")
        a_w = fast_auc(np.r_[np.ones(iw.sum()), np.zeros(nn.sum())], np.r_[ss[iw], ss[nn]])
        a_wo = fast_auc(np.r_[np.ones(iwo.sum()), np.zeros(nn.sum())], np.r_[ss[iwo], ss[nn]])
        return a_w - a_wo

    gap = gap_at(np.arange(len(t.ya)))
    _, lo, _hi = boot_percentile(gap_at, len(t.ya), cfg.boot, rb)
    return gap, lo, bool(gap == gap)


def short_ff_test(t: Trial, ds, cfg: AuditConfig, rb):
    """ShorT (Brown et al., 2023) adapted to frozen features.  The original trains many multitask networks whose attribute-head
    gradient multiplier changes how strongly the attribute is encoded, then correlates attribute encoding with fairness
    (separation).  Here the encoding strength is manipulated by scaling the shortcut direction by alpha in feature space,
    refitting an UNSTANDARDISED logistic head on each scaled copy of a bootstrap resample of the training set, and measuring
    separation = mean(|TPR gap|, |FPR gap|) between shortcut groups on the union of both evaluation sets.  A positive Spearman
    correlation between alpha and separation (p < 0.05) is a flag.  Not applicable when a (class, shortcut) cell is empty."""
    d = ds / (np.linalg.norm(ds) + 1e-12)
    U = np.vstack([t.Za, t.Zb])
    yU = np.r_[t.ya, t.yb]
    mU = np.r_[t.ma, t.mb]
    ok = (mU == 0) | (mU == 1)
    U, yU, mU = U[ok], yU[ok], mU[ok]
    mc = cfg.short_min_cell
    if min(((yU == c) & (mU == g)).sum() for c in (0, 1) for g in (0, 1)) < mc:
        return float("nan"), float("nan"), False
    s_ref = float(np.sqrt(np.mean(t.Ztr.var(0))) + 1e-12)
    xs, ys = [], []
    n = len(t.ytr)
    boots = [rb.integers(0, n, n) for _ in range(cfg.short_reps)]        # same resamples for every alpha (controls replicate noise)
    for alpha in cfg.short_alphas:
        for ib in boots:
            if len(np.unique(t.ytr[ib])) < 2:
                continue
            m = t.mtr[ib]
            if len(np.unique(m)) < 2:
                continue
            Zs = t.Ztr[ib] + (alpha - 1.0) * np.outer(t.Ztr[ib] @ d, d)
            Us = U + (alpha - 1.0) * np.outer(U @ d, d)
            delta0 = abs(float((t.Ztr[ib] @ d)[m == 1].mean() - (t.Ztr[ib] @ d)[m == 0].mean()))
            head = LogisticRegression(C=1.0, max_iter=1000).fit(Zs, t.ytr[ib])
            pred = head.decision_function(Us) > 0
            gaps = []
            for c in (1, 0):                              # TPR gap for positives, FPR gap for negatives
                r1 = pred[(yU == c) & (mU == 1)].mean()
                r0 = pred[(yU == c) & (mU == 0)].mean()
                gaps.append(abs(r1 - r0))
            xs.append(alpha * delta0 / s_ref)
            ys.append(float(np.mean(gaps)))
    if len(xs) < 8:
        return float("nan"), float("nan"), False
    rho_s, p = spearman(xs, ys)
    return rho_s, p, bool(rho_s == rho_s)


# ----------------------------------------------------------------------------- the audit
def audit_trial(t: Trial, cfg: AuditConfig):
    """Run every audit variant on one trial.  Uses t.rng for the random-direction nulls (first use: the fixed-head null, in the
    same order as the original E6 script) and an independent stream for bootstraps."""
    rb = np.random.default_rng([cfg.seed, t.seed, 424242])
    r = {"valid": False}
    if len(np.unique(t.mtr)) < 2 or len(np.unique(t.ytr)) < 2:
        return r
    head = lr().fit(t.Ztr, t.ytr)
    sa, sb = head.decision_function(t.Za), head.decision_function(t.Zb)
    auc_a, auc_b = fast_auc(t.ya, sa), fast_auc(t.yb, sb)
    if not (auc_a == auc_a and auc_b == auc_b):
        return r
    t.sb_cache = sb
    r.update(valid=True, auc_a=auc_a, auc_b=auc_b, tax=auc_a - auc_b)
    tlo, thi = _boot_two_sets(t.ya, sa, t.yb, sb, cfg.boot, rb, t.paired)
    r.update(tax_lo=tlo, tax_hi=thi)

    # --- presence (probe on the shortcut label)
    probe = lr().fit(t.Ztr, t.mtr)
    pa = probe.decision_function(t.Za)
    pres = fast_auc(t.ma, pa)
    _, plo, _ = boot_percentile(lambda i: fast_auc(t.ma[i], pa[i]), len(t.ma), cfg.boot, rb)
    ds = raw_direction(probe)
    r.update(pres_auc=pres, pres_lo=plo, cos_ds_dc=float(abs(ds @ raw_direction(head))))
    if t.dtrue is not None:
        r["cos_to_true"] = float(abs(ds @ (t.dtrue / (np.linalg.norm(t.dtrue) + 1e-12))))

    # --- fixed-head random-direction null (shared by S and C3).  FIRST use of t.rng, as in the original E6.
    dirs = [cov_random_direction(t.Ztr, t.rng) for _ in range(cfg.n_null)]
    ng = [fast_auc(t.yb, head.decision_function(project_out(t.Zb, d))) - auc_b for d in dirs]
    p95_gain = _p95(ng)
    r["null_gain_p95"] = p95_gain

    # --- S: single recovered direction ablated, fixed head
    gS = fast_auc(t.yb, head.decision_function(project_out(t.Zb, ds))) - auc_b
    r.update(gain_S=gS, flag_S=bool(gS > p95_gain and gS > cfg.margin))
    if t.dtrue is not None:                      # oracle: ablate the TRUE planted direction (diagnostic only, not an audit method)
        gO = fast_auc(t.yb, head.decision_function(project_out(t.Zb, t.dtrue))) - auc_b
        r.update(gain_oracle=gO, flag_oracle=bool(gO > p95_gain and gO > cfg.margin))

    # --- C1: LEACE gain (paper criterion)
    le = LEACE().fit(t.Ztr, t.mtr, shrink=cfg.leace_shrink)
    Ztr_e, Za_e, Zb_e = le.transform(t.Ztr), le.transform(t.Za), le.transform(t.Zb)
    g1 = fast_auc(t.yb, head.decision_function(Zb_e)) - auc_b
    r.update(gain_C1=g1, flag_C1=bool(g1 > p95_gain and g1 > cfg.margin))
    r["resid_linear_presence"] = fast_auc(t.ma, lr().fit(Ztr_e, t.mtr).decision_function(Za_e))

    # --- C2: retrained-head drop after erasure vs erase-and-retrain null
    head2 = lr().fit(Ztr_e, t.ytr)
    a_after = fast_auc(t.ya, head2.decision_function(Za_e))
    drop2 = auc_a - a_after
    nd = []
    for _ in range(cfg.n_null_retrain):
        d = cov_random_direction(t.Ztr, t.rng)
        h = lr().fit(project_out(t.Ztr, d), t.ytr)
        nd.append(auc_a - fast_auc(t.ya, h.decision_function(project_out(t.Za, d))))
    p95_drop = _p95(nd)
    r.update(drop_C2=drop2, null_drop_p95=p95_drop, avail_a_after_retrain=a_after, avail_b_after_retrain=fast_auc(t.yb, head2.decision_function(Zb_e)),
             flag_C2=bool(drop2 > p95_drop and drop2 > cfg.margin))

    # --- C3: does the shortcut direction itself carry label information on set a?
    a3 = abs(fast_auc(t.ya, pa) - 0.5)
    n3 = [abs(fast_auc(t.ya, t.Za @ d) - 0.5) for d in dirs]
    r.update(label_info_C3=a3, null_label_p95=_p95(n3), flag_C3=bool(a3 > _p95(n3) and a3 > cfg.margin))

    # --- nonlinear leakage after linear erasure
    mlp_auc, mlp_lo, incomplete = float("nan"), float("nan"), False
    if cfg.run_nonlinear:
        mlp = MLPClassifier((cfg.mlp_hidden,), early_stopping=True, max_iter=150, random_state=0).fit(Ztr_e, t.mtr)
        pm = mlp.predict_proba(Za_e)[:, 1]
        mlp_auc = fast_auc(t.ma, pm)
        _, mlp_lo, _ = boot_percentile(lambda i: fast_auc(t.ma[i], pm[i]), len(t.ma), cfg.boot, rb)
        incomplete = bool(mlp_lo > 0.5 + cfg.margin)
    r.update(mlp_resid_auc=mlp_auc, mlp_resid_lo=mlp_lo, erasure_incomplete=incomplete)

    # --- the iterative loop
    present = bool(plo > 0.5 + cfg.margin)
    tax_sig = bool(tlo > cfg.margin)
    evidence = bool(r["flag_C1"] or r["flag_C2"])
    inlp_flag = False
    if present and tax_sig and (not evidence) and incomplete:           # escalation: linear erasure left nonlinear leakage
        inlp = INLP(cfg.inlp_rounds).fit(t.Ztr, t.mtr)
        gI = fast_auc(t.yb, head.decision_function(inlp.transform(t.Zb))) - auc_b
        nI = _rank_matched_null(t.Zb, t.yb, head, auc_b, t.Ztr, t.rng, cfg.inlp_rounds, max(10, cfg.n_null // 3))
        inlp_flag = bool(gI > _p95(nI) and gI > cfg.margin)
        r["gain_inlp"] = gI
        evidence = evidence or inlp_flag
    if not present:
        verdict = "no_shortcut_encoded"
    elif not tax_sig:
        verdict = "encoded_not_relied_on"
    elif evidence:
        verdict = "relied_on_localized"
    else:
        verdict = "relied_on_unlocalized"
    r.update(flag_probe_only=present, flag_loop=bool(verdict == "relied_on_localized"), verdict=verdict, flag_inlp=inlp_flag)

    # --- literature baselines (item 2)
    if cfg.baselines:
        gap, glo, app = js_gap_test(t, sa, cfg, rb)
        r.update(js_gap=gap, js_lo=glo, js_applicable=app, flag_js=bool(app and glo > cfg.margin))
        rho_s, p, app2 = short_ff_test(t, ds, cfg, rb)
        r.update(short_rho=rho_s, short_p=p, short_applicable=app2, flag_short=bool(app2 and rho_s > 0 and p < 0.05))
    return r


FLAG_KEYS = ["flag_probe_only", "flag_S", "flag_C1", "flag_C2", "flag_C3", "flag_loop", "flag_js", "flag_short", "flag_oracle"]
METRIC_KEYS = ["auc_a", "auc_b", "tax", "pres_auc", "cos_to_true", "cos_ds_dc", "gain_S", "gain_oracle", "gain_C1", "drop_C2", "avail_a_after_retrain", "avail_b_after_retrain",
               "label_info_C3", "resid_linear_presence", "mlp_resid_auc", "null_gain_p95", "null_drop_p95"]


def summarize_rows(rows, extra_flags=("erasure_incomplete",)):
    """rows: list of audit_trial dicts.  Returns flag rate summaries (Clopper-Pearson) and metric mean/sd over VALID trials.
    Flags of a method that is not applicable on a trial count as False for the rate, and the applicable count is reported."""
    ok = [x for x in rows if x.get("valid")]
    out = {"n_trials": len(rows), "n_valid": len(ok), "flags": {}, "metrics": {}, "verdicts": {}}
    for k in list(FLAG_KEYS) + list(extra_flags):
        vals = [bool(x[k]) for x in ok if k in x]
        if vals:
            out["flags"][k] = rate_summary(vals)
    for k, app in (("flag_js", "js_applicable"), ("flag_short", "short_applicable")):
        if k in out["flags"]:
            out["flags"][k]["applicable_fraction"] = float(np.mean([bool(x.get(app, False)) for x in ok])) if ok else float("nan")
    for k in METRIC_KEYS:
        v = np.array([x[k] for x in ok if k in x and x[k] == x[k]], float)
        if len(v):
            out["metrics"][k] = {"mean": float(v.mean()), "sd": float(v.std()), "n": int(len(v))}
    for x in ok:
        out["verdicts"][x["verdict"]] = out["verdicts"].get(x["verdict"], 0) + 1
    return out
