"""ITEM 2  Head-to-head against published shortcut-detection approaches, on the same data.

Baselines (re-implemented on frozen features, see audit_lib.js_gap_test and audit_lib.short_ff_test; verify against the originals):
  js     Jimenez-Sanchez et al. (2023) style: performance gap between shortcut-present and shortcut-absent cases (needs the shortcut
         annotation), plus the decodability probe (reported here as probe_only, the embedding-inspection analogue).
  short  Brown et al. (2023) ShorT: correlation between how strongly the attribute is encoded and fairness separation across a family
         of models.  The original manipulates encoding with a multitask gradient multiplier; here the attribute direction is scaled.
Compared with: the loop (this paper), the single-direction ablation S and the linear-erasure criterion C1.

Data
  A  planted marker, every rho (ground truth known)
  B  TB source case (Belarus/RSNA-trained head, source-matched evaluation)     shortcut = acquisition source
  C  glioma TCGA, WHO grade -> IDH                                             shortcut = grade (concordant vs discordant)
  D  malaria, high-vs-low saturation (stain) shortcut, patient-grouped split   shortcut = stain intensity
Flag rates are over repeated splits.  A method that cannot be applied (an empty class x shortcut cell) is reported with its applicable
fraction and counts as not flagging.

  python item02_baselines.py --planted xrv=... --manifest M --tb_feats xrv=... --glioma_csv G --malaria_feats mal_resnet50.npz
"""
import argparse

import numpy as np
from sklearn.model_selection import GroupShuffleSplit, train_test_split

from audit_lib import AuditConfig, PreCfg, audit_trial, summarize_rows
from calib_engine import load_planted_npz, natural_trial, run_planted_calibration, source_case_trial
from data_utils import Timer, dump, flag_table, load_tb, matched_mask, n_jobs_default, parse_kv, tidy_rows, write_csv
from malaria_groups import groups_from_names

ap = argparse.ArgumentParser()
ap.add_argument("--planted", nargs="+", default=[])
ap.add_argument("--marker", default="corner")
ap.add_argument("--rhos", type=float, nargs="+", default=[0.5, 0.6, 0.7, 0.8, 0.9, 1.0])
ap.add_argument("--reps", type=int, default=50)
ap.add_argument("--manifest")
ap.add_argument("--tb_feats", nargs="+", default=[])
ap.add_argument("--glioma_csv")
ap.add_argument("--malaria_feats")
ap.add_argument("--malaria_view", default="full")
ap.add_argument("--real_reps", type=int, default=20)
ap.add_argument("--pca", type=int, default=64)
ap.add_argument("--n_jobs", type=int, default=n_jobs_default())
ap.add_argument("--tag", default="")
a = ap.parse_args()

cfg = AuditConfig(baselines=True)
pre = PreCfg(pca_k=a.pca)
METHODS = ["flag_loop", "flag_C1", "flag_S", "flag_probe_only", "flag_js", "flag_short"]
out = {"config": {"audit": cfg.__dict__, "pre": pre.as_dict()}, "planted": {}, "real": {}}
tidy = []

# ------------------------------------------------------------------ A. planted
for tag, path in parse_kv(a.planted, "--planted").items():
    with Timer(f"planted {a.marker} / {tag}"):
        Zc, Zm, y, groups = load_planted_npz(path, a.marker)
        by_rho, _ = run_planted_calibration(Zc, Zm, y, a.rhos, a.reps, pre, cfg, groups=groups, n_jobs=a.n_jobs)
    out["planted"][tag] = by_rho
    tidy += tidy_rows("tb_planted", tag, a.marker, by_rho)
    print(f"\n=== A. planted {a.marker} marker, {tag}: flag rate per method (rho=0.5 is the false-flag rate, rho>=0.7 is power)")
    flag_table(by_rho, METHODS)
    for k in ("flag_js", "flag_short"):
        print(f"   {k} applicable fraction by rho:", {r: round(s["flags"][k]["applicable_fraction"], 2) for r, s in by_rho.items() if k in s["flags"]})

# ------------------------------------------------------------------ B. TB source
def real_case(name, trials):
    rows = [audit_trial(t, cfg) for t in trials]
    s = summarize_rows(rows)
    out["real"].setdefault(name, {})
    return s

if a.tb_feats and a.manifest:
    for tag, path in parse_kv(a.tb_feats, "--tb_feats").items():
        with Timer(f"B. TB source / {tag}"):
            man, Z, H, Hc, y, src = load_tb(a.manifest, path)
            nat, matched = np.where(np.isin(src, ["belarus", "rsna"]))[0], np.where(matched_mask(src))[0]
            trials = []
            for rep in range(a.real_reps):
                tr, te = train_test_split(nat, test_size=0.4, stratify=y[nat], random_state=rep)
                trials.append(source_case_trial(Z, y, tr, te, matched, pre, np.random.default_rng(rep), seed=rep))
            s = real_case(f"tb_source/{tag}", trials)
        out["real"][f"tb_source/{tag}"] = s

# ------------------------------------------------------------------ C. glioma
if a.glioma_csv:
    from glioma_data import load_glioma
    with Timer("C. glioma grade"):
        D = load_glioma(a.glioma_csv)
        X, y, gh = D["X"].values.astype(float), D["y"], D["grade_hi"]
        ci, di = np.where(D["concordant"])[0], np.where(~D["concordant"])[0]
        trials = []
        for rep in range(a.real_reps):
            tr, tec = train_test_split(ci, test_size=0.3, stratify=y[ci], random_state=rep)
            trials.append(natural_trial(X, y, gh, tr, np.concatenate([tec, di]), PreCfg(pca_k=None), np.random.default_rng(rep), seed=rep))
        out["real"]["glioma_grade"] = real_case("glioma_grade", trials)

# ------------------------------------------------------------------ D. malaria
if a.malaria_feats:
    with Timer("D. malaria stain"):
        d = np.load(a.malaria_feats, allow_pickle=True)
        y, Z = d["y"], d[f"Z_{a.malaria_view}"]
        H, cols = np.nan_to_num(d["H"]), list(d["Hcols"])
        sat = H[:, cols.index("mS")]
        s = (sat > np.median(sat)).astype(int)
        g = groups_from_names(d["names"], "prefix")
        trials = []
        for rep in range(a.real_reps):
            tr, te = next(GroupShuffleSplit(1, test_size=0.3, random_state=rep).split(Z, y, g))
            trials.append(natural_trial(Z, y, s, tr, te, pre, np.random.default_rng(rep), seed=rep))
        out["real"]["malaria_stain"] = real_case("malaria_stain", trials)

if out["real"]:
    print("\n=== B-D. real data: share of splits flagged by each method (applicable fraction in the JSON)")
    flag_table({k: v for k, v in out["real"].items()}, METHODS, label="case", width=9)
    for k, v in out["real"].items():
        app = {m.replace("flag_", ""): round(v["flags"][m].get("applicable_fraction", 1.0), 2) for m in ("flag_js", "flag_short") if m in v["flags"]}
        print(f"   {k}: applicable fraction {app}; verdicts {v['verdicts']}; tax {v['metrics'].get('tax', {}).get('mean')}; "
              f"nonlinear leakage after erasure in {v['flags'].get('erasure_incomplete', {}).get('rate')}")

# ------------------------------------------------------------------ computed reading
lines = []
for tag, by_rho in out["planted"].items():
    fa = by_rho.get("0.5", {}).get("flags", {})
    for m in METHODS:
        if m in fa:
            pw = [by_rho[r]["flags"][m]["rate"] for r in by_rho if float(r) >= 0.7 and m in by_rho[r]["flags"]]
            lines.append(f"planted/{tag}: {m.replace('flag_', '')}: false-flag {fa[m]['rate']:.2f} (upper 95% {fa[m]['cp_upper_one_sided']:.2f}), "
                         f"mean power over rho>=0.7 {np.mean(pw):.2f}" if pw else f"planted/{tag}: {m}: false-flag {fa[m]['rate']:.2f}")
for k, v in out["real"].items():
    f = v["flags"]
    if "flag_short" in f and f["flag_short"].get("applicable_fraction", 1) < 0.5:
        lines.append(f"{k}: ShorT-style test is not applicable in {1 - f['flag_short']['applicable_fraction']:.0%} of splits (empty class x shortcut cell)")
    if "flag_js" in f and "flag_loop" in f and f["flag_js"]["rate"] > f["flag_loop"]["rate"] + 0.1:
        lines.append(f"{k}: performance-gap test flags {f['flag_js']['rate']:.2f} but the loop only {f['flag_loop']['rate']:.2f} (gap without ablation support)")
    if "flag_loop" in f and "flag_C1" in f and f["flag_loop"]["rate"] > f["flag_C1"]["rate"] + 0.1:
        lines.append(f"{k}: linear-erasure-only criterion misses what the loop finds ({f['flag_C1']['rate']:.2f} vs {f['flag_loop']['rate']:.2f})")
out["reading"] = lines
print("\nREADING (computed from the numbers above):\n  " + "\n  ".join(lines))
dump(out, f"item02_baselines{a.tag}.json")
write_csv(tidy, f"item02_flag_rates{a.tag}.csv")
