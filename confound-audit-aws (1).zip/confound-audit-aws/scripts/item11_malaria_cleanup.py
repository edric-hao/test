"""ITEM 11a  Malaria clean-up: group definition, patient-level uncertainty, RBC-only vs random crop.

1. Group diagnostics.  The group labels are parsed from file names, so this reports how many files each parsing scheme leaves unparsed and
   how many distinct groups each scheme yields.  Differences between schemes (for example an off-by-one between a strict and a tolerant
   pattern, or names with a 'Re' infix such as C171P132ReThinF) are the usual source of a 201 versus 200 patient mismatch.
2. Patient-grouped out-of-fold scores (balanced GroupKFold, several fold seeds) for every view under every grouping scheme.
3. CLUSTER bootstrap (resampling patients, keeping all of their cells) for each view's AUC and for rbc minus randcrop, with the
   equivalence verdict at the stated margin.  The cell-level bootstrap in E5 treats cells of one patient as independent and is too narrow.
4. The same comparison restricted to cells whose random crop contains no parasite pixels (rand_overlap == 0).

  python item11_malaria_cleanup.py --feats feats/mal_resnet50.npz --tag resnet50
"""
import argparse
import re
from collections import Counter

import numpy as np

from common import lr
from data_utils import Timer, dump, register_tests
from stats_utils import cluster_bootstrap_auc, cluster_bootstrap_auc_diff, fast_auc, group_kfold_indices

ap = argparse.ArgumentParser()
ap.add_argument("--feats", required=True)
ap.add_argument("--tag", default="")
ap.add_argument("--folds", type=int, default=5)
ap.add_argument("--fold_seeds", type=int, default=3)
ap.add_argument("--B", type=int, default=1000)
ap.add_argument("--margin", type=float, default=0.02)
ap.add_argument("--views", default="full,parasite,rbc,randcrop,gray,silhouette")
a = ap.parse_args()

d = np.load(a.feats, allow_pickle=True)
y, names, H, Hcols = d["y"], np.array([str(n) for n in d["names"]]), np.nan_to_num(d["H"]), list(d["Hcols"])
views = [v for v in a.views.split(",") if f"Z_{v}" in d.files]

STRICT = re.compile(r"^(C\d+)(P\d+)thinf", re.I)          # the pattern E5 used; names it rejects fall back to the text before the first underscore
TOLER = re.compile(r"^(C\d+)(P\d+)", re.I)                # accepts 'ReThinF', 'thickF' and any other infix


def scheme_strict_prefix(n):
    m = STRICT.match(n)
    return (m.group(1) + m.group(2)).upper() if m else n.split("_")[0]


def scheme_tolerant_prefix(n):
    m = TOLER.match(n)
    return (m.group(1) + m.group(2)).upper() if m else "UNPARSED:" + n.split("_")[0]


def scheme_patient(n):
    m = TOLER.match(n)
    return m.group(2).upper() if m else "UNPARSED:" + n.split("_")[0]


SCHEMES = {"strict_prefix_as_in_E5": scheme_strict_prefix, "tolerant_prefix": scheme_tolerant_prefix, "patient_P_number": scheme_patient}
G = {k: np.array([f(n) for n in names]) for k, f in SCHEMES.items()}

res = {"n_cells": int(len(y)), "views": views}

# ------------------------------------------------------------------ 1. group diagnostics
diag = {}
unparsed_strict = [n for n in names if not STRICT.match(n)]
unparsed_tol = [n for n in names if not TOLER.match(n)]
diag["n_files_rejected_by_strict_pattern"] = len(unparsed_strict)
diag["n_files_rejected_by_tolerant_pattern"] = len(unparsed_tol)
diag["examples_rejected_by_strict"] = unparsed_strict[:10]
diag["infix_tokens_after_P_number"] = dict(Counter(re.sub(r"^C\d+P\d+", "", n.split("_")[0], flags=re.I) for n in names).most_common(8))
for k, g in G.items():
    u, cnt = np.unique(g, return_counts=True)
    ym = np.array([y[g == x].mean() for x in u])
    diag[k] = {"n_groups": int(len(u)), "cells_per_group_median": float(np.median(cnt)), "cells_per_group_min": int(cnt.min()), "cells_per_group_max": int(cnt.max()),
               "n_singleton_groups": int((cnt == 1).sum()), "frac_single_class_groups": float(((ym == 0) | (ym == 1)).mean()),
               "frac_cells_in_single_class_groups": float(cnt[(ym == 0) | (ym == 1)].sum() / len(y))}
sp, tp = set(G["strict_prefix_as_in_E5"]), set(G["tolerant_prefix"])
diag["groups_only_in_strict"] = sorted(sp - tp)[:20]
diag["groups_only_in_tolerant"] = sorted(tp - sp)[:20]
pat2slides = {}
for n in names:
    m = TOLER.match(n)
    if m:
        pat2slides.setdefault(m.group(2).upper(), set()).add(m.group(1).upper())
multi = {p: sorted(s) for p, s in pat2slides.items() if len(s) > 1}
diag["patients_with_more_than_one_C_token"] = len(multi)
diag["examples_patient_with_multiple_C_tokens"] = dict(list(multi.items())[:5])
diag["groups_split_across_patients_by_prefix"] = int(len(tp) - len(set(G["patient_P_number"])))
res["group_diagnostics"] = diag
print("\n=== 1. group diagnostics")
for k in SCHEMES:
    v = diag[k]
    print(f"  {k:26s} groups {v['n_groups']:4d}  cells/group median {v['cells_per_group_median']:.0f} (min {v['cells_per_group_min']}, max {v['cells_per_group_max']})  "
          f"single-class groups {v['frac_single_class_groups']:.1%}  cells in them {v['frac_cells_in_single_class_groups']:.1%}")
print(f"  files rejected by the strict pattern: {diag['n_files_rejected_by_strict_pattern']}, by the tolerant pattern: {diag['n_files_rejected_by_tolerant_pattern']}")
print(f"  group labels present only under the strict scheme: {diag['groups_only_in_strict'][:6]}; only under the tolerant scheme: {diag['groups_only_in_tolerant'][:6]}")
print(f"  patients whose cells carry more than one C token: {diag['patients_with_more_than_one_C_token']}")
print("  -> Use whichever count matches the dataset readme as the patient count in the paper and state the parsing rule.  The scheme below that is the")
print("     coarsest (patient_P_number) is the strictest leakage control.")


# ------------------------------------------------------------------ 2/3. patient-grouped OOF and cluster bootstrap
def oof(X, g, seed):
    s = np.zeros(len(y))
    for tr, te in group_kfold_indices(g, a.folds, seed):
        if len(np.unique(y[tr])) < 2:
            s[te] = 0.0
            continue
        s[te] = lr().fit(X[tr], y[tr]).decision_function(X[te])
    return s


out = {}
with Timer("patient-grouped OOF + cluster bootstrap"):
    for sk, g in G.items():
        o = {"per_view": {}, "fold_seed_spread": {}}
        scores = {}
        for v in views:
            X = d[f"Z_{v}"]
            per_seed = [oof(X, g, sd) for sd in range(a.fold_seeds)]
            aucs = [fast_auc(y, s) for s in per_seed]
            scores[v] = per_seed[0]
            ci = cluster_bootstrap_auc(y, per_seed[0], g, B=a.B)
            o["per_view"][v] = {**ci, "auc_over_fold_seeds": [float(x) for x in aucs]}
        if "rbc" in scores and "randcrop" in scores:
            dd = cluster_bootstrap_auc_diff(y, scores["rbc"], scores["randcrop"], g, B=a.B)
            dd["margin"] = a.margin
            dd["equivalent_within_margin"] = bool(dd["lo"] > -a.margin and dd["hi"] < a.margin)
            o["rbc_minus_randcrop"] = dd
            if "rand_overlap" in Hcols:
                clean = H[:, Hcols.index("rand_overlap")] == 0
                o["n_cells_randcrop_without_parasite"] = int(clean.sum())
                if clean.sum() > 50 and len(np.unique(y[clean])) == 2:
                    dc = cluster_bootstrap_auc_diff(y[clean], scores["rbc"][clean], scores["randcrop"][clean], g[clean], B=a.B)
                    dc["margin"] = a.margin
                    dc["equivalent_within_margin"] = bool(dc["lo"] > -a.margin and dc["hi"] < a.margin)
                    o["rbc_minus_randcrop_clean_crops_only"] = dc
        out[sk] = o
res["grouped_cv"] = out

print("\n=== 2/3. patient-grouped CV with cluster bootstrap (95% intervals resample groups)")
for sk, o in out.items():
    print(f"  [{sk}] groups={diag[sk]['n_groups']}")
    for v, r in o["per_view"].items():
        sp_ = r["auc_over_fold_seeds"]
        print(f"     {v:11s} AUC {r['auc']:.3f} [{r['lo']:.3f},{r['hi']:.3f}]   across fold seeds {min(sp_):.3f}-{max(sp_):.3f}")
    if "rbc_minus_randcrop" in o:
        r = o["rbc_minus_randcrop"]
        print(f"     rbc - randcrop {r['diff']:+.3f} [{r['lo']:+.3f},{r['hi']:+.3f}]  equivalent within +-{a.margin}: {r['equivalent_within_margin']}")
    if "rbc_minus_randcrop_clean_crops_only" in o:
        r = o["rbc_minus_randcrop_clean_crops_only"]
        print(f"     (parasite-free random crops only, n={o['n_cells_randcrop_without_parasite']}) {r['diff']:+.3f} [{r['lo']:+.3f},{r['hi']:+.3f}]  equivalent: {r['equivalent_within_margin']}")

reg = []
for sk, o in out.items():
    for v, r in o["per_view"].items():
        se = max((r["hi"] - r["lo"]) / (2 * 1.96), 1e-9)
        from scipy.stats import norm
        reg.append(dict(name=f"malaria {sk} {v}: grouped AUC > 0.5", family="item11", p=float(norm.sf((r["auc"] - 0.5) / se))))
register_tests("item11", reg)
dump({"results": res, "config": vars(a)}, f"item11_malaria_cleanup_{a.tag or 'run'}.json")
