"""Statistics helpers shared by the new (item01..item13) scripts.

Nothing here depends on torch.  Everything is plain numpy / scipy.
"""
from __future__ import annotations

import numpy as np
from scipy.stats import beta, rankdata


# ----------------------------------------------------------------------------- AUC
def fast_auc(y, s) -> float:
    """Rank-based AUC (average ranks for ties).  Identical to sklearn roc_auc_score for binary y, but about 10x faster
    for the small arrays used inside bootstrap loops.  Returns NaN when only one class is present."""
    y = np.asarray(y).astype(bool)
    n1 = int(y.sum())
    n0 = len(y) - n1
    if n1 == 0 or n0 == 0:
        return float("nan")
    r = rankdata(np.asarray(s, dtype=float))
    return float((r[y].sum() - n1 * (n1 + 1) / 2.0) / (n1 * n0))


def boot_percentile(stat_fn, n, B=200, rng=None):
    """Percentile bootstrap of stat_fn(idx) over n indices.  Returns (mean, lo95, hi95).  NaN draws are dropped."""
    rng = np.random.default_rng(0) if rng is None else rng
    vals = []
    for _ in range(B):
        v = stat_fn(rng.integers(0, n, n))
        if v == v:  # not NaN
            vals.append(v)
    if len(vals) < max(10, B // 10):
        return float("nan"), float("nan"), float("nan")
    vals = np.asarray(vals)
    return float(vals.mean()), float(np.percentile(vals, 2.5)), float(np.percentile(vals, 97.5))


# ----------------------------------------------------------------------------- binomial intervals
def clopper_pearson(k: int, n: int, alpha: float = 0.05):
    """Exact two-sided (1-alpha) Clopper-Pearson interval for a binomial proportion."""
    if n <= 0:
        return float("nan"), float("nan")
    lo = 0.0 if k == 0 else float(beta.ppf(alpha / 2.0, k, n - k + 1))
    hi = 1.0 if k == n else float(beta.ppf(1.0 - alpha / 2.0, k + 1, n - k))
    return lo, hi


def cp_upper_one_sided(k: int, n: int, alpha: float = 0.05) -> float:
    """Exact one-sided (1-alpha) upper confidence bound for a binomial proportion (k=0 gives 1-alpha**(1/n))."""
    if n <= 0:
        return float("nan")
    if k >= n:
        return 1.0
    return float(beta.ppf(1.0 - alpha, k + 1, n - k))


def cp_lower_one_sided(k: int, n: int, alpha: float = 0.05) -> float:
    if n <= 0:
        return float("nan")
    if k <= 0:
        return 0.0
    return float(beta.ppf(alpha, k, n - k + 1))


def rate_summary(flags, alpha: float = 0.05) -> dict:
    """Flag rate with exact two-sided interval and exact one-sided upper bound.  flags: iterable of bool (NaN-free)."""
    f = np.asarray(list(flags), dtype=bool)
    n, k = int(len(f)), int(f.sum())
    lo, hi = clopper_pearson(k, n, alpha)
    return {"k": k, "n": n, "rate": (k / n) if n else float("nan"), "cp_lo": lo, "cp_hi": hi,
            "cp_upper_one_sided": cp_upper_one_sided(k, n, alpha)}


# ----------------------------------------------------------------------------- multiplicity
def holm(pvals):
    """Holm-Bonferroni adjusted p-values (monotone).  NaN stays NaN and is excluded from the family size."""
    p = np.asarray(pvals, dtype=float)
    out = np.full_like(p, np.nan)
    ok = np.where(~np.isnan(p))[0]
    m = len(ok)
    if m == 0:
        return out
    order = ok[np.argsort(p[ok])]
    running = 0.0
    for rank, i in enumerate(order):
        adj = (m - rank) * p[i]
        running = max(running, adj)
        out[i] = min(1.0, running)
    return out


def benjamini_hochberg(pvals):
    """BH step-up adjusted p-values (q-values).  NaN stays NaN."""
    p = np.asarray(pvals, dtype=float)
    out = np.full_like(p, np.nan)
    ok = np.where(~np.isnan(p))[0]
    m = len(ok)
    if m == 0:
        return out
    order = ok[np.argsort(p[ok])]
    prev = 1.0
    for rank in range(m - 1, -1, -1):
        i = order[rank]
        val = min(prev, p[i] * m / (rank + 1))
        prev = val
        out[i] = min(1.0, val)
    return out


# ----------------------------------------------------------------------------- grouping / folds
def group_kfold_indices(groups, k: int = 5, seed: int = 0):
    """Seeded, size-balanced GroupKFold (no dependence on the sklearn version).  Returns a list of (train_idx, test_idx)."""
    groups = np.asarray(groups)
    uniq, inv = np.unique(groups, return_inverse=True)
    sizes = np.bincount(inv)
    rng = np.random.default_rng(seed)
    order = rng.permutation(len(uniq))
    order = order[np.argsort(-sizes[order], kind="stable")]       # largest first, ties in random order
    fold_of = np.zeros(len(uniq), dtype=int)
    load = np.zeros(k)
    for g in order:
        f = int(np.argmin(load))
        fold_of[g] = f
        load[f] += sizes[g]
    fold = fold_of[inv]
    return [(np.where(fold != f)[0], np.where(fold == f)[0]) for f in range(k)]


def cluster_bootstrap_auc(y, s, groups, B: int = 1000, seed: int = 0):
    """AUC with a percentile bootstrap that resamples GROUPS (patients) with replacement and keeps all of their cells.
    Returns dict(auc, lo, hi, n_groups)."""
    y, s, groups = np.asarray(y), np.asarray(s, dtype=float), np.asarray(groups)
    uniq, inv = np.unique(groups, return_inverse=True)
    members = [np.where(inv == g)[0] for g in range(len(uniq))]
    rng = np.random.default_rng(seed)
    vals = []
    for _ in range(B):
        pick = rng.integers(0, len(uniq), len(uniq))
        idx = np.concatenate([members[g] for g in pick])
        v = fast_auc(y[idx], s[idx])
        if v == v:
            vals.append(v)
    vals = np.asarray(vals)
    return {"auc": fast_auc(y, s), "lo": float(np.percentile(vals, 2.5)) if len(vals) else float("nan"),
            "hi": float(np.percentile(vals, 97.5)) if len(vals) else float("nan"), "n_groups": int(len(uniq))}


def cluster_bootstrap_auc_diff(y, s1, s2, groups, B: int = 1000, seed: int = 0):
    """Paired cluster bootstrap of AUC(s1) - AUC(s2)."""
    y, s1, s2, groups = np.asarray(y), np.asarray(s1, float), np.asarray(s2, float), np.asarray(groups)
    uniq, inv = np.unique(groups, return_inverse=True)
    members = [np.where(inv == g)[0] for g in range(len(uniq))]
    rng = np.random.default_rng(seed)
    vals = []
    for _ in range(B):
        pick = rng.integers(0, len(uniq), len(uniq))
        idx = np.concatenate([members[g] for g in pick])
        a, b = fast_auc(y[idx], s1[idx]), fast_auc(y[idx], s2[idx])
        if a == a and b == b:
            vals.append(a - b)
    vals = np.asarray(vals)
    return {"diff": fast_auc(y, s1) - fast_auc(y, s2), "lo": float(np.percentile(vals, 2.5)),
            "hi": float(np.percentile(vals, 97.5)), "n_groups": int(len(uniq))}


def spearman(x, y):
    """Spearman rank correlation and two-sided p-value.  Returns (nan, nan) when either input is constant."""
    from scipy.stats import spearmanr
    x, y = np.asarray(x, float), np.asarray(y, float)
    ok = ~(np.isnan(x) | np.isnan(y))
    if ok.sum() < 4 or np.ptp(x[ok]) == 0 or np.ptp(y[ok]) == 0:
        return float("nan"), float("nan")
    r = spearmanr(x[ok], y[ok])
    return float(r.correlation), float(r.pvalue)
