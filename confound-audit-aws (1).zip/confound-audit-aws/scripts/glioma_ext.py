"""Glioma extensions for item 10: a CGGA loader and WHO-2021 consistent relabelling of the TCGA discordant set.

CGGA (Chinese Glioma Genome Atlas) clinical tables, e.g. CGGA.mRNAseq_693_clinical / mRNAseq_325_clinical, have columns such as
  CGGA_ID, PRS_type, Histology, Grade (WHO II / III / IV), Gender, Age, IDH_mutation_status (Mutant / Wildtype),
  1p19q_codeletion_status (Codel / Non-codel), MGMTp_methylation_status (methylated / un-methylated)
and no TERT promoter column.  Download them from the CGGA portal (cgga.org.cn) as tab or comma separated text and pass the path;
the separator is sniffed.  The string parsers below normalise punctuation first, because 'un-methylated' contains the substring
'methylated' and would be misread as methylated by a naive test.
"""
from __future__ import annotations

import re
import sys

import numpy as np
import pandas as pd


def _norm(v):
    return re.sub(r"[^a-z0-9]", "", str(v).lower())


def _idh(v):
    if pd.isna(v):
        return np.nan
    s = _norm(v)
    if "wild" in s or s in ("wt", "idhwt", "wildtype"):
        return 0.0
    if "mut" in s:
        return 1.0
    return np.nan


def _codel(v):
    if pd.isna(v):
        return np.nan
    s = _norm(v)
    if s.startswith("non") or "noncodel" in s or "intact" in s:
        return 0.0
    if "codel" in s:
        return 1.0
    return np.nan


def _meth(v):
    if pd.isna(v):
        return np.nan
    s = _norm(v)
    if s.startswith("un") or "unmeth" in s or "notmeth" in s:
        return 0.0
    if "meth" in s:
        return 1.0
    return np.nan


def _sex(v):
    if pd.isna(v):
        return np.nan
    s = _norm(v)
    return 1.0 if s.startswith("m") else 0.0 if s.startswith("f") else np.nan


def _grade_hi(v):
    """1 for WHO grade IV (the cohort-file notion of 'glioblastoma'), 0 for II/III, NaN when unknown."""
    if pd.isna(v):
        return np.nan
    s = str(v).upper()
    m = re.search(r"\b(IV|III|II)\b|\b([234])\b|(?:WHO)?\s?(IV|III|II)$", s)
    if not m:
        return np.nan
    tok = next(g for g in m.groups() if g)
    return 1.0 if tok in ("IV", "4") else 0.0


def _pick(df, names):
    low = {c.lower().replace(" ", "").replace("_", ""): c for c in df.columns}
    for n in names:
        k = n.lower().replace(" ", "").replace("_", "")
        if k in low:
            return low[k]
    return None


def load_cgga(path, impute="zero", add_missing_flags=False, drop=(), verbose=True):
    """Same return structure as glioma_data.load_glioma (X, y, concordant, grade_hi, df, missing), for CGGA clinical tables."""
    df = pd.read_csv(path, sep=None, engine="python")
    c_idh = _pick(df, ["IDH_mutation_status", "IDH_status", "IDH"])
    c_gr = _pick(df, ["Grade", "WHO_grade"])
    if c_idh is None or c_gr is None:
        raise SystemExit(f"{path}: need IDH and Grade columns, found {list(df.columns)}")
    y_raw = df[c_idh].map(_idh)
    df = df[y_raw.notna()].reset_index(drop=True)
    y = df[c_idh].map(_idh).astype(int).values
    gh = df[c_gr].map(_grade_hi)
    keep = gh.notna().values
    df, y, gh = df[keep].reset_index(drop=True), y[keep], gh[keep].astype(int).values
    conc = ((y == 1) & (gh == 0)) | ((y == 0) & (gh == 1))
    cols = {"grade": pd.Series(gh, index=df.index).astype(float)}
    for key, names, fn in [("age", ["Age", "age_at_diagnosis"], pd.to_numeric), ("mgmt", ["MGMTp_methylation_status", "MGMT_status", "MGMT"], _meth),
                           ("codel", ["1p19q_codeletion_status", "codel_1p19q", "1p19q"], _codel), ("tert", ["TERT_promoter_status", "TERT"], _meth),
                           ("sex", ["Gender", "Sex"], _sex)]:
        c = _pick(df, names)
        if c is None:
            cols[key] = pd.Series(np.nan, index=df.index)
        elif key == "tert":
            cols[key] = df[c].map(lambda v: np.nan if pd.isna(v) else (1.0 if "mut" in _norm(v) else 0.0 if ("wt" in _norm(v) or "wild" in _norm(v)) else np.nan))
        elif key == "age":
            cols[key] = pd.to_numeric(df[c], errors="coerce")
        else:
            cols[key] = df[c].map(fn)
    X = pd.DataFrame({k: v for k, v in cols.items() if k not in drop})
    frac = X.isna().mean()
    dead = [k for k in X.columns if k != "grade" and frac[k] >= 0.999]
    if verbose:
        print(f"[cgga] rows={len(df)}  IDH-mut frac={y.mean():.3f}  grade_hi frac={gh.mean():.3f}  concordant frac={conc.mean():.3f}", file=sys.stderr)
        print("[cgga] missing fraction per feature:", {k: round(float(v), 3) for k, v in frac.items()}, file=sys.stderr)
        if dead:
            print("[cgga] dropped all-missing features:", dead, file=sys.stderr)
    X = X.drop(columns=dead)
    miss = X.isna()
    if "age" in X:
        X["age"] = (X["age"] - X["age"].mean()) / (X["age"].std() + 1e-9)
    X = X.fillna(0.0) if impute == "zero" else X.fillna(X.median())
    if add_missing_flags:
        for c in miss.columns[miss.any()]:
            X[c + "_missing"] = miss[c].astype(int)
    return dict(X=X, y=y, concordant=conc, grade_hi=gh, df=df, missing=miss)


def who2021_sets(D):
    """WHO-2021 consistent discordant sets for a cohort with a TERT column (TCGA).
    Under WHO 2021, an IDH-wildtype diffuse astrocytic glioma with a TERT promoter mutation is a glioblastoma whatever its histologic
    grade, and IDH-mutant grade-4 tumours are 'astrocytoma, IDH-mutant, grade 4' and no longer glioblastoma.  Starting from the cohort's
    discordant patients (IDH-wt with low histologic grade, IDH-mut with grade 4):
      upgraded      IDH-wt, low grade, TERT-mutant   -> are glioblastoma under 2021, so their 'discordance' is a labelling artefact
      unknown_tert  IDH-wt, low grade, TERT missing  -> cannot be classified from the available columns
      residual      IDH-wt, low grade, TERT wild type -> still discordant under 2021
      mut_g4        IDH-mut, grade 4                  -> remain valid IDH-mutant cases whose grade is not glioma-type defining
    Returns boolean masks over the cohort's rows."""
    X, y, gh, miss = D["X"], D["y"], D["grade_hi"], D["missing"]
    if "tert" not in X.columns:
        return None
    tert_mut = (X["tert"].values == 1) & ~miss["tert"].values
    tert_missing = miss["tert"].values
    wt_low = (y == 0) & (gh == 0)
    return {"all_discordant": ~D["concordant"],
            "upgraded_to_GBM_2021": wt_low & tert_mut,
            "unknown_tert": wt_low & tert_missing,
            "residual_wt_low_tert_wt": wt_low & ~tert_mut & ~tert_missing,
            "idhmut_grade4": (y == 1) & (gh == 1)}
