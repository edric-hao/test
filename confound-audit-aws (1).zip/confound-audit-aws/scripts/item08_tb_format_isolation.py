"""ITEM 8  TB format isolation and the below-chance Montgomery -> Shenzhen XRV result (AUC 0.356).

For every feature set (encoder x {plain, harmonized}) this script reports
  1. within-source CV AUC and the full source-transfer matrix among the source-matched sets, each with a bootstrap interval and a
     label-permutation p-value, so 'below chance' is a tested statement
  2. Belarus/RSNA-trained detector -> each matched set (the format/population confound of the paper)
  3. diagnostics that discriminate between explanations of a below-chance transfer:
       a. per-domain standardisation (each set z-scored with its own statistics): does the mean shift between sets explain it?
       b. PCA-64 pipeline: is it a high-dimensional / small-n artefact (n < d in the training set)?
       c. cosine between the train-set classifier direction and the test-set oracle direction: do the two sets disagree on the direction?
       d. metadata-only transfer (image size and intensity statistics, no pixels through the encoder): does a format cue flip sign
          between the two sets?  Together with the class-conditional metadata effect sizes in each set.
       e. correlation of the transferred score with each metadata column in the test set
  4. harmonization deltas for tag pairs given with --pairs (e.g. xrv:xrv_h)
A second source-matched TB set can be added to the manifest (any source name) and passed via --matched_sources.

  python item08_tb_format_isolation.py --manifest M --feats xrv=... xrv_h=... dinov2=... dinov2_h=... --pairs xrv:xrv_h dinov2:dinov2_h
"""
import argparse
import itertools

import numpy as np
from sklearn.decomposition import PCA
from sklearn.ensemble import HistGradientBoostingClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import StratifiedKFold, cross_val_predict
from sklearn.preprocessing import StandardScaler

from common import auc_ci, lr, raw_direction
from data_utils import Timer, dump, load_tb, parse_kv, parse_sources, register_tests
from stats_utils import fast_auc

ap = argparse.ArgumentParser()
ap.add_argument("--manifest", required=True)
ap.add_argument("--feats", nargs="+", required=True)
ap.add_argument("--pairs", nargs="*", default=[], help="plain:harmonized tag pairs")
ap.add_argument("--matched_sources", default="shenzhen,montgomery")
ap.add_argument("--perm", type=int, default=1000)
ap.add_argument("--boot", type=int, default=500)
ap.add_argument("--pca", type=int, default=64)
ap.add_argument("--tag", default="")
a = ap.parse_args()
srcs = parse_sources(a.matched_sources)
rng = np.random.default_rng(0)


def perm_p(y, s, B):
    """Two-sided label-permutation p-value for AUC != 0.5."""
    obs = abs(fast_auc(y, s) - 0.5)
    null = np.array([abs(fast_auc(rng.permutation(y), s) - 0.5) for _ in range(B)])
    return float((np.sum(null >= obs) + 1) / (B + 1))


def cv_scores(X, y):
    return cross_val_predict(lr(), X, y, cv=StratifiedKFold(5, shuffle=True, random_state=0), method="decision_function")


def cohen_d(x, y):
    a_, b_ = x[y == 1], x[y == 0]
    sp = np.sqrt((a_.var(ddof=1) * (len(a_) - 1) + b_.var(ddof=1) * (len(b_) - 1)) / max(len(a_) + len(b_) - 2, 1))
    return float((a_.mean() - b_.mean()) / sp) if sp > 0 else 0.0


res, explanations = {}, []
for tag, path in parse_kv(a.feats, "--feats").items():
    man, Z, H, Hc, y, src = load_tb(a.manifest, path)
    R = {"within": {}, "transfer": {}, "belarusRSNA_to": {}, "metadata": {"within": {}, "transfer": {}, "effect_size": {}, "score_corr": {}}}
    ix = {s: np.where(src == s)[0] for s in srcs}
    with Timer(f"{tag}"):
        for s, i in ix.items():
            if len(i) > 50 and len(np.unique(y[i])) == 2:
                R["within"][s] = auc_ci(y[i], cv_scores(Z[i], y[i]), B=a.boot)
                if H.shape[1]:
                    R["metadata"]["within"][s] = auc_ci(y[i], cross_val_predict(HistGradientBoostingClassifier(max_iter=100), H[i], y[i], cv=5,
                                                                               method="predict_proba")[:, 1], B=a.boot)
                    R["metadata"]["effect_size"][s] = {c: cohen_d(H[i][:, j], y[i]) for j, c in enumerate(Hc)}
        # Belarus/RSNA detector -> matched sets
        nat = np.where(np.isin(src, ["belarus", "rsna"]))[0]
        if len(nat) > 100:
            det = lr().fit(Z[nat], y[nat])
            for s, i in ix.items():
                if len(i) > 50:
                    R["belarusRSNA_to"][s] = auc_ci(y[i], det.decision_function(Z[i]), B=a.boot)
        # transfer matrix with diagnostics
        for tr_s, te_s in itertools.permutations([s for s in srcs if s in R["within"]], 2):
            itr, ite = ix[tr_s], ix[te_s]
            m = lr().fit(Z[itr], y[itr])
            sc = m.decision_function(Z[ite])
            T = {"auc": auc_ci(y[ite], sc, B=a.boot), "p_perm_two_sided": perm_p(y[ite], sc, a.perm)}
            T["below_chance"] = bool(T["auc"]["hi"] < 0.5)
            # a. per-domain standardisation (test-set scaler fit on unlabeled test features)
            s1, s2 = StandardScaler().fit(Z[itr]), StandardScaler().fit(Z[ite])
            m_d = LogisticRegression(C=1.0, max_iter=3000).fit(s1.transform(Z[itr]), y[itr])
            T["auc_domain_standardised"] = float(fast_auc(y[ite], m_d.decision_function(s2.transform(Z[ite]))))
            # b. PCA pipeline
            pca = PCA(min(a.pca, len(itr) - 1), random_state=0).fit(Z[itr])
            m_p = lr().fit(pca.transform(Z[itr]), y[itr])
            T["auc_pca"] = float(fast_auc(y[ite], m_p.decision_function(pca.transform(Z[ite]))))
            T["n_train_vs_dim"] = [int(len(itr)), int(Z.shape[1])]
            # c. direction agreement with the test-set oracle
            oracle = lr().fit(Z[ite], y[ite])
            T["cos_train_dir_vs_test_oracle_dir"] = float(raw_direction(m) @ raw_direction(oracle))
            # d./e. metadata-only transfer and score correlations
            if H.shape[1]:
                g = HistGradientBoostingClassifier(max_iter=100).fit(H[itr], y[itr])
                T["metadata_only_auc"] = auc_ci(y[ite], g.predict_proba(H[ite])[:, 1], B=a.boot)
                R["metadata"]["score_corr"][f"{tr_s}->{te_s}"] = {c: float(np.corrcoef(sc, H[ite][:, j])[0, 1]) if H[ite][:, j].std() > 0 else 0.0
                                                                  for j, c in enumerate(Hc)}
            R["transfer"][f"{tr_s}->{te_s}"] = T
            if T["below_chance"]:
                bits = [f"{tag}: {tr_s}->{te_s} AUC {T['auc']['auc']:.3f} [{T['auc']['lo']:.3f},{T['auc']['hi']:.3f}] (perm p={T['p_perm_two_sided']:.3f}) is BELOW chance."]
                bits.append(f"per-domain standardisation gives {T['auc_domain_standardised']:.3f} "
                            f"({'repairs it: mean shift between the sets contributes' if T['auc_domain_standardised'] >= 0.5 else 'does not repair it'});")
                bits.append(f"PCA-{a.pca} pipeline gives {T['auc_pca']:.3f} "
                            f"({'so the full-dimension fit (n=%d < d=%d) matters' % (len(itr), Z.shape[1]) if T['auc_pca'] >= 0.5 and len(itr) < Z.shape[1] else 'no change'});")
                bits.append(f"direction cosine to the test-set oracle {T['cos_train_dir_vs_test_oracle_dir']:+.3f}"
                            f"{' (the two sets prefer opposite directions)' if T['cos_train_dir_vs_test_oracle_dir'] < 0 else ''};")
                if "metadata_only_auc" in T:
                    mo = T["metadata_only_auc"]
                    bits.append(f"metadata-only transfer AUC {mo['auc']:.3f} [{mo['lo']:.3f},{mo['hi']:.3f}]"
                                f"{' (a format cue reverses sign between the sets)' if mo['hi'] < 0.5 else ''}.")
                explanations.append(" ".join(bits))
    res[tag] = R

# harmonization deltas
delta = {}
for pair in a.pairs:
    plain, harm = pair.split(":")
    if plain in res and harm in res:
        d = {}
        for s in srcs:
            if s in res[plain]["belarusRSNA_to"] and s in res[harm]["belarusRSNA_to"]:
                d[f"belarusRSNA_to_{s}"] = {"plain": res[plain]["belarusRSNA_to"][s]["auc"], "harmonized": res[harm]["belarusRSNA_to"][s]["auc"],
                                            "delta": res[harm]["belarusRSNA_to"][s]["auc"] - res[plain]["belarusRSNA_to"][s]["auc"]}
        for k in res[plain]["transfer"]:
            if k in res[harm]["transfer"]:
                d[f"transfer_{k}"] = {"plain": res[plain]["transfer"][k]["auc"]["auc"], "harmonized": res[harm]["transfer"][k]["auc"]["auc"],
                                      "delta": res[harm]["transfer"][k]["auc"]["auc"] - res[plain]["transfer"][k]["auc"]["auc"]}
        delta[pair] = d

print("\nTRANSFER AUC (train -> test), full-feature LR [95% CI]   | domain-std | PCA | metadata-only")
for tag, R in res.items():
    for k, T in R["transfer"].items():
        mo = T.get("metadata_only_auc", {}).get("auc", float("nan"))
        print(f"{tag:14s} {k:26s} {T['auc']['auc']:.3f} [{T['auc']['lo']:.3f},{T['auc']['hi']:.3f}] p={T['p_perm_two_sided']:.3f}"
              f"  | {T['auc_domain_standardised']:.3f} | {T['auc_pca']:.3f} | {mo:.3f}")
print("\nBELARUS/RSNA detector -> matched sets")
for tag, R in res.items():
    print(f"{tag:14s} " + "  ".join(f"{s}: {v['auc']:.3f} [{v['lo']:.3f},{v['hi']:.3f}]" for s, v in R["belarusRSNA_to"].items()))
if delta:
    print("\nHARMONIZATION deltas (harmonized - plain)")
    for pair, d in delta.items():
        print(f"  {pair}: " + "  ".join(f"{k}: {v['delta']:+.3f}" for k, v in d.items()))
print("\nEXPLANATIONS (computed for every below-chance transfer):\n  " + ("\n  ".join(explanations) if explanations else "none: no transfer is significantly below chance"))
register_tests("item08", [dict(name=f"{t}:{k} transfer permutation test", family="item08", p=T["p_perm_two_sided"])
                          for t, R in res.items() for k, T in R["transfer"].items()])
dump({"results": res, "harmonization_delta": delta, "explanations": explanations, "matched_sources": srcs}, f"item08_tb_format_isolation{a.tag}.json")
