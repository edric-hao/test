"""ITEM 1  Does the iterative loop catch anything that one-shot audits miss?

Compares, on the SAME trials:
  probe_only  presence test only (is the shortcut decodable?)
  S           single recovered-direction ablation (one shortcut test, fixed head, random-direction null)
  C1          linear-erasure audit (LEACE gain on the flipped/discordant set; the paper's criterion)
  C2          retrained-head drop after linear erasure
  loop        the full iterative procedure (presence -> stratified tax -> ablation controls -> nonlinear-leakage escalation)
on (a) the planted marker for each rho and (b) the TB source case (Belarus/RSNA-trained head, source-matched evaluation).

Ground truth: planted marker, reliance exists iff rho > 0.5.  TB source: the label equals the source in training, so the head
can only be relying on source; the one-shot linear audit's job is to say whether source was erased, and the MLP probe after
erasure shows whether that conclusion is true (erasure_incomplete).

  python item01_loop_vs_oneshot.py --planted xrv=feats/tbplanted_xrv_densenet121.npz dinov2=... --manifest feats/tb_manifest.csv \
      --tb_feats xrv=feats/tb_xrv_densenet121.npz dinov2=... --reps 50 --src_reps 20
"""
import argparse

import numpy as np
from sklearn.model_selection import train_test_split

from audit_lib import AuditConfig, PreCfg, audit_trial, summarize_rows
from calib_engine import load_planted_npz, run_planted_calibration, source_case_trial
from data_utils import Timer, dump, flag_table, load_tb, matched_mask, n_jobs_default, parse_kv, tidy_rows, write_csv

ap = argparse.ArgumentParser()
ap.add_argument("--planted", nargs="+", default=[], help="tag=path of planted-marker npz files")
ap.add_argument("--marker", default="corner")
ap.add_argument("--rhos", type=float, nargs="+", default=[0.5, 0.6, 0.7, 0.8, 0.9, 1.0])
ap.add_argument("--reps", type=int, default=50)
ap.add_argument("--manifest", help="TB manifest for the source case")
ap.add_argument("--tb_feats", nargs="+", default=[], help="tag=path of TB feature npz files (source case)")
ap.add_argument("--src_reps", type=int, default=20)
ap.add_argument("--pca", type=int, default=64)
ap.add_argument("--n_null", type=int, default=30)
ap.add_argument("--n_jobs", type=int, default=n_jobs_default())
ap.add_argument("--tag", default="")
a = ap.parse_args()

cfg = AuditConfig(n_null=a.n_null)
pre = PreCfg(pca_k=a.pca)
KEYS = ["flag_probe_only", "flag_S", "flag_C1", "flag_C2", "flag_loop"]
out = {"config": {"audit": cfg.__dict__, "pre": pre.as_dict(), "reps": a.reps, "src_reps": a.src_reps, "marker": a.marker}, "planted": {}, "tb_source_case": {}}
tidy = []

for tag, path in parse_kv(a.planted, "--planted").items():
    with Timer(f"planted marker, encoder {tag}"):
        Zc, Zm, y, groups = load_planted_npz(path, a.marker)
        by_rho, rows = run_planted_calibration(Zc, Zm, y, a.rhos, a.reps, pre, cfg, groups=groups, n_jobs=a.n_jobs)
    out["planted"][tag] = by_rho
    tidy += tidy_rows("tb_planted", tag, a.marker, by_rho)
    print(f"\n=== planted {a.marker} marker, {tag}  (flag rate per rho; rho=0.5 is the false-flag rate)")
    flag_table(by_rho, KEYS + ["flag_C3"])
    print("erasure_incomplete rate (MLP still decodes the marker after LEACE):",
          {r: round(s["flags"]["erasure_incomplete"]["rate"], 2) for r, s in by_rho.items() if "erasure_incomplete" in s["flags"]})
    print("loop verdicts at rho=0.8:", by_rho.get("0.8", {}).get("verdicts"), "| rho=1.0:", by_rho.get("1.0", {}).get("verdicts"))

if a.tb_feats:
    if not a.manifest:
        raise SystemExit("--manifest is required with --tb_feats")
    for tag, path in parse_kv(a.tb_feats, "--tb_feats").items():
        with Timer(f"TB source case, encoder {tag}"):
            man, Z, H, Hcols, y, src = load_tb(a.manifest, path)
            nat = np.where(np.isin(src, ["belarus", "rsna"]))[0]
            matched = np.where(matched_mask(src))[0]
            if len(matched) < 50 or len(nat) < 100:
                print(f"[skip] {tag}: manifest lacks Belarus/RSNA or matched rows")
                continue
            rows = []
            for rep in range(a.src_reps):
                tr, te_in = train_test_split(nat, test_size=0.4, stratify=y[nat], random_state=rep)
                t = source_case_trial(Z, y, tr, te_in, matched, pre, np.random.default_rng(rep), seed=rep)
                rows.append(audit_trial(t, cfg))
            s = summarize_rows(rows)
        out["tb_source_case"][tag] = s
        print(f"\n=== TB source case, {tag}: share of splits in which each audit flags source reliance")
        flag_table({"src": s}, KEYS, label="case")
        print("erasure_incomplete rate:", s["flags"].get("erasure_incomplete", {}).get("rate"),
              "| mean MLP residual source AUC after LEACE:", s["metrics"].get("mlp_resid_auc", {}).get("mean"),
              "| mean linear residual:", s["metrics"].get("resid_linear_presence", {}).get("mean"))
        print("in-distribution AUC", s["metrics"].get("auc_a", {}).get("mean"), "-> source-matched AUC", s["metrics"].get("auc_b", {}).get("mean"),
              "| verdicts", s["verdicts"])

# automatic reading of the result (computed, not hard coded)
lines = []
for tag, by_rho in out["planted"].items():
    for rho in [r for r in by_rho if float(r) >= 0.7]:
        f = by_rho[rho]["flags"]
        if "flag_loop" in f and "flag_C1" in f and f["flag_loop"]["rate"] > f["flag_C1"]["rate"] + 0.05:
            lines.append(f"planted/{tag}/rho={rho}: loop flags {f['flag_loop']['rate']:.2f} vs linear-erasure-only {f['flag_C1']['rate']:.2f}")
    f5 = by_rho.get("0.5", {}).get("flags", {})
    if f5:
        lines.append(f"planted/{tag}/rho=0.5 false-flag rates: " + ", ".join(f"{k.replace('flag_', '')}={v['rate']:.2f}" for k, v in f5.items() if k in KEYS))
for tag, s in out["tb_source_case"].items():
    f = s["flags"]
    lines.append(f"tb_source/{tag}: linear-only audit flags {f.get('flag_C1', {}).get('rate')}, loop flags {f.get('flag_loop', {}).get('rate')}, "
                 f"nonlinear leakage after erasure in {f.get('erasure_incomplete', {}).get('rate')} of splits")
out["reading"] = lines
print("\nREADING:\n  " + "\n  ".join(lines))
dump(out, f"item01_loop_vs_oneshot{a.tag}.json")
write_csv(tidy, f"item01_flag_rates{a.tag}.csv")
