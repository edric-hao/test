"""ITEM 10  Glioma external check: does the grade-excluded IDH signal replicate outside TCGA, and does it survive WHO-2021 relabelling?

A. Within-cohort refits (the E4 variants: imputation choices, leave-feature-out, single features, label-permutation null) for TCGA and,
   when supplied, CGGA.  Train on concordant patients, test on held-out concordant and on ALL discordant patients, 20 splits.
B. Cross-cohort transfer on the features the two cohorts share (TCGA lacks age and sex in the cohort file the paper used, CGGA lacks TERT):
   train on every concordant patient of one cohort, evaluate on the concordant and discordant patients of the other, both directions.
C. WHO-2021 consistent discordant sets in TCGA (see glioma_ext.who2021_sets): patients whose 'discordance' disappears under the 2021
   criteria are removed, and the grade-excluded refit is re-scored on what remains, with and without TERT as a feature (TERT is part of the
   2021 GBM definition, so a refit that uses it is partly definitional).

  python item10_glioma_external.py --tcga_csv cohort.csv [--cgga_csv CGGA_clinical.txt]
"""
import argparse

import numpy as np
from sklearn.ensemble import HistGradientBoostingClassifier
from sklearn.model_selection import train_test_split

from common import auc, auc_ci, lr, mean_sd
from data_utils import Timer, dump, register_tests
from glioma_data import load_glioma
from glioma_ext import load_cgga, who2021_sets

ap = argparse.ArgumentParser()
ap.add_argument("--tcga_csv", required=True)
ap.add_argument("--cgga_csv")
ap.add_argument("--splits", type=int, default=20)
ap.add_argument("--tag", default="")
a = ap.parse_args()

LOADERS = {"tcga": (load_glioma, a.tcga_csv)}
if a.cgga_csv:
    LOADERS["cgga"] = (load_cgga, a.cgga_csv)

VARIANTS = {   # name: (columns, imputation, missing flags)
    "no grade, zero-impute":            (["age", "mgmt", "codel", "tert", "sex"], "zero", False),
    "no grade, median-impute":          (["age", "mgmt", "codel", "tert", "sex"], "median", False),
    "no grade, median + missing flags": (["age", "mgmt", "codel", "tert", "sex"], "median", True),
    "no grade, no 1p/19q":              (["age", "mgmt", "tert", "sex"], "zero", False),
    "no grade, no 1p/19q, no TERT":     (["age", "mgmt", "sex"], "zero", False),
    "age only":                         (["age"], "zero", False),
    "1p/19q only":                      (["codel"], "zero", False),
    "TERT only":                        (["tert"], "zero", False),
    "MGMT only":                        (["mgmt"], "zero", False),
}


def model_for(nfeat):
    return HistGradientBoostingClassifier(max_iter=100, max_depth=3) if nfeat > 1 else lr()


def build(cohort, cols, imp, flags):
    loader, path = LOADERS[cohort]
    D = loader(path, impute=imp, add_missing_flags=flags) if cohort == "tcga" else loader(path, impute=imp, add_missing_flags=flags, verbose=False)
    keep = [c for c in D["X"].columns if c.split("_missing")[0] in cols]
    return D["X"][keep].values.astype(float), D, keep


def refit(X, D, splits, eval_sets):
    """eval_sets: {name: boolean mask over rows}.  Returns mean/sd over splits of concordant and per-set AUC, a permutation null and a
    bootstrap interval from the seed-0 fit."""
    y, conc = D["y"], D["concordant"]
    ci = np.where(conc)[0]
    out = {"conc": [], "perm": {k: [] for k in eval_sets}, **{k: [] for k in eval_sets}}
    for sd in range(splits):
        tr, te = train_test_split(ci, test_size=0.3, stratify=y[ci], random_state=sd)
        m = model_for(X.shape[1]).fit(X[tr], y[tr])
        sf = (lambda Z: m.predict_proba(Z)[:, 1]) if hasattr(m, "predict_proba") else m.decision_function
        out["conc"].append(auc(y[te], sf(X[te])))
        mp = model_for(X.shape[1]).fit(X[tr], np.random.default_rng(sd).permutation(y[tr]))
        sp = (lambda Z: mp.predict_proba(Z)[:, 1])
        for k, mask in eval_sets.items():
            idx = np.where(mask)[0]
            out[k].append(auc(y[idx], sf(X[idx])))
            out["perm"][k].append(auc(y[idx], sp(X[idx])))
    tr, _ = train_test_split(ci, test_size=0.3, stratify=y[ci], random_state=0)
    m = model_for(X.shape[1]).fit(X[tr], y[tr])
    res = {"concordant_auc": mean_sd(out["conc"])}
    for k, mask in eval_sets.items():
        idx = np.where(mask)[0]
        res[k] = {"n": int(mask.sum()), "n_idh_mut": int(y[idx].sum()), "auc": mean_sd(out[k]), "perm_null": mean_sd(out["perm"][k]),
                  "auc_boot_seed0": auc_ci(y[idx], m.predict_proba(X[idx])[:, 1] if hasattr(m, "predict_proba") else m.decision_function(X[idx])),
                  "n_pos": int(y[idx].sum())}
    return res


res = {"A_within_cohort": {}, "B_transfer": {}, "C_who2021": {}}

# ------------------------------------------------------------------ A
for cohort in LOADERS:
    with Timer(f"A. within-cohort refits, {cohort}"):
        res["A_within_cohort"][cohort] = {}
        for name, (cols, imp, flags) in VARIANTS.items():
            X, D, keep = build(cohort, cols, imp, flags)
            if X.shape[1] == 0:
                res["A_within_cohort"][cohort][name] = {"skipped": "no usable columns in this cohort"}
                continue
            r = refit(X, D, a.splits, {"discordant": ~D["concordant"]})
            r["columns"] = keep
            res["A_within_cohort"][cohort][name] = r
    print(f"\n=== A. {cohort}: grade-excluded refits (concordant AUC | discordant AUC mean+-sd, seed-0 bootstrap CI | permutation null)")
    for name, r in res["A_within_cohort"][cohort].items():
        if "skipped" in r:
            print(f"  {name:36s} skipped ({r['skipped']})")
            continue
        d = r["discordant"]
        print(f"  {name:36s} conc {r['concordant_auc']['mean']:.3f} | disc {d['auc']['mean']:.3f}+-{d['auc']['sd']:.3f} "
              f"[{d['auc_boot_seed0']['lo']:.3f},{d['auc_boot_seed0']['hi']:.3f}] | null {d['perm_null']['mean']:.3f}  (n_disc={d['n']}, cols={r['columns']})")

# ------------------------------------------------------------------ B
if len(LOADERS) == 2:
    with Timer("B. cross-cohort transfer"):
        data = {c: build(c, ["age", "mgmt", "codel", "tert", "sex"], "zero", False) for c in LOADERS}
        common = [c for c in data["tcga"][2] if c in data["cgga"][2]]
        print(f"\nfeatures shared by both cohorts: {common}")
        if common:
            for src_c, dst_c in (("tcga", "cgga"), ("cgga", "tcga")):
                Xs, Ds, ks = data[src_c]
                Xd, Dd, kd = data[dst_c]
                js, jd = [ks.index(c) for c in common], [kd.index(c) for c in common]
                ci = np.where(Ds["concordant"])[0]
                m = model_for(len(common)).fit(Xs[ci][:, js], Ds["y"][ci])
                sf = (lambda Z: m.predict_proba(Z)[:, 1]) if hasattr(m, "predict_proba") else m.decision_function
                cd, dd = np.where(Dd["concordant"])[0], np.where(~Dd["concordant"])[0]
                r = {"features": common, "train_n": int(len(ci)),
                     "concordant": auc_ci(Dd["y"][cd], sf(Xd[cd][:, jd])), "discordant": auc_ci(Dd["y"][dd], sf(Xd[dd][:, jd])),
                     "n_concordant": int(len(cd)), "n_discordant": int(len(dd))}
                res["B_transfer"][f"{src_c}->{dst_c}"] = r
                print(f"  {src_c}->{dst_c}: concordant AUC {r['concordant']['auc']:.3f} [{r['concordant']['lo']:.3f},{r['concordant']['hi']:.3f}]   "
                      f"discordant AUC {r['discordant']['auc']:.3f} [{r['discordant']['lo']:.3f},{r['discordant']['hi']:.3f}] (n={len(dd)})")
else:
    print("\n[B skipped] pass --cgga_csv for the cross-cohort transfer")

# ------------------------------------------------------------------ C
with Timer("C. WHO-2021 consistent discordant sets (TCGA)"):
    X0, D0, keep0 = build("tcga", ["age", "mgmt", "codel", "tert", "sex"], "zero", False)
    sets = who2021_sets(D0)
    if sets is None:
        print("[C skipped] the TCGA file has no usable TERT column")
    else:
        sizes = {k: int(v.sum()) for k, v in sets.items()}
        eval_sets = {"all_discordant": sets["all_discordant"],
                     "discordant_minus_upgraded": sets["all_discordant"] & ~sets["upgraded_to_GBM_2021"],
                     "discordant_minus_upgraded_minus_unknown_tert": sets["all_discordant"] & ~sets["upgraded_to_GBM_2021"] & ~sets["unknown_tert"],
                     "residual_wt_low_plus_idhmut_g4": sets["residual_wt_low_tert_wt"] | sets["idhmut_grade4"]}
        res["C_who2021"]["set_sizes"] = sizes
        print("  set sizes:", sizes)
        for label, cols in (("with TERT", ["age", "mgmt", "codel", "tert", "sex"]), ("without TERT", ["age", "mgmt", "codel", "sex"])):
            X, D, keep = build("tcga", cols, "zero", False)
            if X.shape[1] == 0:
                continue
            r = refit(X, D, a.splits, eval_sets)
            r["columns"] = keep
            res["C_who2021"][label] = r
            print(f"  features {label} {keep}: concordant AUC {r['concordant_auc']['mean']:.3f}")
            for k in eval_sets:
                v = r[k]
                two = v["n_idh_mut"] not in (0, v["n"])
                print(f"     {k:46s} n={v['n']:4d} (IDH-mut {v['n_idh_mut']:3d})  AUC " +
                      (f"{v['auc']['mean']:.3f}+-{v['auc']['sd']:.3f}  null {v['perm_null']['mean']:.3f}" if two else "undefined (one class)"))

reg = []
from scipy.stats import norm
for cohort, vs in res["A_within_cohort"].items():
    for name, r in vs.items():
        if "discordant" in r:
            d = r["discordant"]
            n1, n0 = d["n_pos"], d["n"] - d["n_pos"]
            if n1 > 0 and n0 > 0:   # one-sided Mann-Whitney z test of AUC > 0.5 on the seed-0 fit (null variance of the U statistic)
                z = (d["auc_boot_seed0"]["auc"] - 0.5) / np.sqrt((n1 + n0 + 1) / (12.0 * n1 * n0))
                reg.append(dict(name=f"glioma {cohort} {name}: discordant AUC > 0.5", family="item10", p=float(norm.sf(z))))
register_tests("item10", reg)
dump({"results": res, "splits": a.splits}, f"item10_glioma_external{a.tag}.json")
