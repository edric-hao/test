"""Frozen-backbone wrappers.  torch is imported lazily, so importing this module (and everything that only needs the numpy
backbone) works on a CPU-only machine without torch installed.

Backbones
  xrv_densenet121  TorchXRayVision DenseNet-121 (densenet121-res224-all), 1024-d, chest X-ray only
  resnet50         torchvision ResNet-50 (IMAGENET1K_V1), 2048-d
  densenet121      torchvision DenseNet-121 (IMAGENET1K_V1), 1024-d
  dinov2_small     facebook/dinov2-small CLS token, 384-d
  rad_dino         microsoft/rad-dino CLS token (medical, chest X-ray DINOv2), 768-d
  biomedclip       microsoft BiomedCLIP ViT-B/16 image tower via open_clip, 512-d
  random_proj      numpy-only block-statistics + fixed random projection (smoke tests only, never use for results)
"""
from __future__ import annotations

import numpy as np

IMN_M = np.array([0.485, 0.456, 0.406], np.float32)
IMN_S = np.array([0.229, 0.224, 0.225], np.float32)
CLIP_M = np.array([0.48145466, 0.4578275, 0.40821073], np.float32)
CLIP_S = np.array([0.26862954, 0.26130258, 0.27577711], np.float32)

BACKBONES = ["xrv_densenet121", "resnet50", "densenet121", "dinov2_small", "rad_dino", "biomedclip", "random_proj"]
CHEST_ONLY = {"xrv_densenet121"}


def make_prep(kind, mean=None, std=None):
    """Return prep(img_u8) -> float32 CHW array for a 224x224 uint8 image (HxW or HxWx3)."""
    def prep(img):
        if kind == "xrv":
            g = img if img.ndim == 2 else img.mean(2)
            return ((g.astype(np.float32) / 255.0) * 2048 - 1024)[None]
        a = img if img.ndim == 3 else np.stack([img] * 3, 2)
        a = a.astype(np.float32) / 255.0
        if kind == "raw":
            return a.transpose(2, 0, 1)
        return ((a - mean) / std).transpose(2, 0, 1)
    return prep


class Backbone:
    """name, prep(img_u8)->CHW float32, encode(batch NCHW float32)->(n, dim) float32."""
    def __init__(self, name, prep, encode, device="cpu"):
        self.name, self.prep, self.encode, self.device = name, prep, encode, device


def _random_proj_backbone(seed=0, dim=128):
    rng = np.random.default_rng(seed)
    q, _ = np.linalg.qr(rng.standard_normal((512, 512)))
    W = q[:, :dim].astype(np.float32)

    def encode(x):                       # x: N x 3 x 224 x 224 in [0,1]
        g = x.mean(1)                    # N x 224 x 224
        n = g.shape[0]
        blocks = g.reshape(n, 16, 14, 16, 14)
        mean = blocks.mean((2, 4)).reshape(n, -1)       # 256 block means (intensity, corner blocks)
        std = blocks.std((2, 4)).reshape(n, -1)         # 256 block stds (texture)
        f = np.concatenate([mean, 4.0 * std], 1)
        return np.maximum(f @ W, 0).astype(np.float32)

    return Backbone("random_proj", make_prep("raw"), encode)


def get_backbone(name, pretrained=True, disable_cudnn=False):
    if name == "random_proj":
        return _random_proj_backbone()
    import torch
    dev = "cuda" if torch.cuda.is_available() else "cpu"
    if disable_cudnn:
        torch.backends.cudnn.enabled = False

    if name == "xrv_densenet121":
        import torchxrayvision as xrv
        m = xrv.models.DenseNet(weights="densenet121-res224-all" if pretrained else None).eval().to(dev)
        fn, prep = m.features2, make_prep("xrv")
    elif name in ("resnet50", "densenet121"):
        import torchvision.models as tvm
        if name == "resnet50":
            m = tvm.resnet50(weights=tvm.ResNet50_Weights.IMAGENET1K_V1 if pretrained else None)
            m.fc = torch.nn.Identity()
        else:
            m = tvm.densenet121(weights=tvm.DenseNet121_Weights.IMAGENET1K_V1 if pretrained else None)
            m.classifier = torch.nn.Identity()
        m = m.eval().to(dev)
        fn, prep = m, make_prep("imn", IMN_M, IMN_S)
    elif name in ("dinov2_small", "rad_dino"):
        from transformers import AutoModel
        repo = "facebook/dinov2-small" if name == "dinov2_small" else "microsoft/rad-dino"
        m = AutoModel.from_pretrained(repo).eval().to(dev)
        mean, std = IMN_M, IMN_S
        if name == "rad_dino":                               # use the model's own normalisation when its processor is available
            try:
                from transformers import AutoImageProcessor
                proc = AutoImageProcessor.from_pretrained(repo)
                mean = np.asarray(proc.image_mean, np.float32)
                std = np.asarray(proc.image_std, np.float32)
                print(f"[rad_dino] normalisation from processor: mean={mean.tolist()} std={std.tolist()}")
            except Exception as e:                           # noqa: BLE001
                print(f"[rad_dino] processor unavailable ({e}); falling back to ImageNet normalisation")
        fn, prep = (lambda x: m(pixel_values=x).last_hidden_state[:, 0]), make_prep("imn", mean, std)
    elif name == "biomedclip":
        import open_clip
        model, _, _pre = open_clip.create_model_and_transforms("hf-hub:microsoft/BiomedCLIP-PubMedBERT_256-vit_base_patch16_224")
        m = model.eval().to(dev)
        fn, prep = m.encode_image, make_prep("imn", CLIP_M, CLIP_S)
    else:
        raise ValueError(f"unknown backbone {name!r}; choose from {BACKBONES}")

    def encode(batch):
        x = torch.from_numpy(batch).to(dev)
        with torch.no_grad():
            try:
                o = fn(x)
            except RuntimeError as e:
                if "cudnn" in str(e).lower() and torch.backends.cudnn.enabled:
                    print("[warn] cuDNN runtime error; disabling cuDNN and retrying (slower)")
                    torch.backends.cudnn.enabled = False
                    o = fn(x)
                else:
                    raise
        return o.float().cpu().numpy()          # fp32 on purpose: fp16 overflowed to inf in DenseNet features

    return Backbone(name, prep, encode, dev)


def run_batches(bb, tensors, bs=128):
    """Encode a list of CHW float32 arrays in batches.  Non-finite features are zeroed with a warning."""
    out = []
    for i in range(0, len(tensors), bs):
        x = np.stack(tensors[i:i + bs]).astype(np.float32)
        o = np.asarray(bb.encode(x), dtype=np.float32)
        if not np.isfinite(o).all():
            print(f"[warn] non-finite features in batch starting {i}; zeroing them (inspect those images)")
            o = np.nan_to_num(o, nan=0.0, posinf=0.0, neginf=0.0)
        out.append(o)
    return np.concatenate(out) if out else np.zeros((0, 1), np.float32)
