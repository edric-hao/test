"""Unit tests for the statistics and erasure code. Run: python tests/test_units.py   (no pytest needed)"""
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "scripts"))
from scipy.stats import beta, binomtest
from sklearn.metrics import roc_auc_score

from erasers import LEACE
from stats_utils import (benjamini_hochberg, clopper_pearson, cluster_bootstrap_auc, cp_lower_one_sided, cp_upper_one_sided, fast_auc,
                         group_kfold_indices, holm, rate_summary)

fails = []


def check(name, cond, info=""):
    print(("PASS " if cond else "FAIL ") + name + (f"  {info}" if info and not cond else ""))
    if not cond:
        fails.append(name)


rng = np.random.default_rng(0)

# fast_auc equals sklearn, including ties and a constant score
for trial in range(20):
    n = int(rng.integers(20, 400))
    y = rng.integers(0, 2, n)
    s = np.round(rng.standard_normal(n), 1) if trial % 2 else rng.standard_normal(n)
    if len(np.unique(y)) == 2:
        check(f"fast_auc vs sklearn #{trial}", abs(fast_auc(y, s) - roc_auc_score(y, s)) < 1e-12)
check("fast_auc constant scores = 0.5", abs(fast_auc(np.array([0, 1, 0, 1]), np.ones(4)) - 0.5) < 1e-12)
check("fast_auc single class = nan", np.isnan(fast_auc(np.zeros(5, int), rng.standard_normal(5))))

# Clopper-Pearson against scipy's exact binomial CI
for k, n in [(0, 50), (1, 50), (25, 50), (49, 50), (50, 50), (7, 200)]:
    lo, hi = clopper_pearson(k, n)
    ref = binomtest(k, n).proportion_ci(confidence_level=0.95, method="exact")
    check(f"clopper_pearson {k}/{n}", abs(lo - ref.low) < 1e-9 and abs(hi - ref.high) < 1e-9, f"{(lo, hi)} vs {(ref.low, ref.high)}")
check("one-sided upper bound k=0 equals 1-alpha^(1/n)", abs(cp_upper_one_sided(0, 100) - (1 - 0.05 ** (1 / 100))) < 1e-9)
check("one-sided lower bound k=n equals alpha^(1/n)", abs(cp_lower_one_sided(100, 100) - 0.05 ** (1 / 100)) < 1e-9)
r = rate_summary([True] * 3 + [False] * 97)
check("rate_summary", r["k"] == 3 and r["n"] == 100 and r["cp_lo"] < 0.03 < r["cp_hi"])

# Holm and BH on a textbook example
p = np.array([0.01, 0.04, 0.03, 0.005])
check("Holm", np.allclose(holm(p), [0.03, 0.06, 0.06, 0.02]), str(holm(p)))
check("BH", np.allclose(benjamini_hochberg(p), [0.02, 0.04, 0.04, 0.02]), str(benjamini_hochberg(p)))
pn = np.array([0.01, np.nan, 0.04])
check("Holm ignores NaN in the family size", np.allclose(holm(pn)[[0, 2]], [0.02, 0.04]) and np.isnan(holm(pn)[1]))

# group k-fold: disjoint groups, every row used once, reasonably balanced
g = np.repeat(np.arange(37), rng.integers(5, 40, 37))
folds = group_kfold_indices(g, 5, seed=3)
seen = np.concatenate([te for _, te in folds])
check("group_kfold covers each row once", len(seen) == len(g) and len(np.unique(seen)) == len(g))
check("group_kfold keeps groups whole", all(not (set(g[tr]) & set(g[te])) for tr, te in folds))
sizes = [len(te) for _, te in folds]
check("group_kfold balanced", max(sizes) / min(sizes) < 1.3, str(sizes))

# cluster bootstrap interval is wider than the naive one when labels are mostly cluster-level and clusters carry a shared score offset
G = 30
gid = np.repeat(np.arange(G), 40)
yc = rng.integers(0, 2, G)
yy = np.where(rng.random(len(gid)) < 0.85, yc[gid], 1 - yc[gid])
sc_ = rng.standard_normal(G)[gid] * 2 + rng.standard_normal(len(gid))
cb = cluster_bootstrap_auc(yy, sc_, gid, B=400)
nb = cluster_bootstrap_auc(yy, sc_, np.arange(len(gid)), B=400)
check("cluster CI wider than cell-level CI under clustering", (cb["hi"] - cb["lo"]) > 1.5 * (nb["hi"] - nb["lo"]), f"{cb} {nb}")

# LEACE: after erasure a linear probe cannot decode the concept; cross-covariance is zero; dead columns untouched
n, d = 4000, 30
c = rng.integers(0, 2, n)
Z = rng.standard_normal((n, d)) @ rng.standard_normal((d, d)) * 0.3
Z[:, :4] += np.outer(c, [2.0, 1.5, 1.0, 0.5])
Z[:, 7] = 0.0                                                    # dead column
Z[:, 8] = 3.0
le = LEACE().fit(Z, c)
E = le.transform(Z)
cc = np.abs(((E - E.mean(0)).T @ (c - c.mean())) / n).max()
check("LEACE zero cross-covariance with the concept", cc < 1e-8, f"{cc:.2e}")
from sklearn.linear_model import LogisticRegression
a_before = roc_auc_score(c, LogisticRegression(max_iter=500).fit(Z, c).decision_function(Z))
a_after = roc_auc_score(c, LogisticRegression(max_iter=500).fit(E, c).decision_function(E))
check("LEACE: probe AUC high before, near chance after", a_before > 0.9 and a_after < 0.56, f"{a_before:.3f} {a_after:.3f}")
check("LEACE leaves dead columns unchanged", np.allclose(E[:, 7], 0.0) and np.allclose(E[:, 8], 3.0))
check("LEACE idempotent", np.abs(le.transform(E) - E).max() < 1e-8)

print("\n%d failure(s)" % len(fails))
sys.exit(1 if fails else 0)
