"""Synthetic stand-ins for EVERY input the pipeline reads (smoke tests only; the numbers are meaningless).

  python make_synthetic_full.py OUTDIR [--images]

Feature level (fast, always written):
  tb_manifest.csv, tb_<enc>.npz (Z,H,Hcols), tbplanted_<enc>.npz (Z_clean, Z_marked_<kind>, Z_marked, y, source),
  mal_<enc>.npz, malplanted_<enc>.npz, glioma_tcga.csv, glioma_cgga.csv        for enc in synA, synB
Image level (with --images): tiny PNG trees for the extraction smoke test: tb_images/, malaria/Parasitized|Uninfected, belarus_extent.csv
Structure deliberately mimics the paper: zero-variance (dead) columns, a source cue that survives linear erasure (variance
difference, so LEACE removes the mean shift but an MLP still decodes it), a metadata cue whose sign flips between the two
source-matched sets, malaria patient signatures with some file names lacking the P token.
"""
import argparse
from pathlib import Path

import numpy as np
import pandas as pd

D = 96


def tb_manifest(n_bel=500, n_rsna=1500, n_sz=260, n_mg=110):
    rows = [(f"b{i}.png", 1, "belarus", "A" if i % 2 else "B") for i in range(n_bel)]
    rows += [(f"r{i}.png", 0, "rsna", "") for i in range(n_rsna)]
    rows += [(f"s{i}.png", i % 2, "shenzhen", "") for i in range(n_sz)]
    rows += [(f"m{i}.png", (i // 2) % 2, "montgomery", "") for i in range(n_mg)]
    return pd.DataFrame(rows, columns=["path", "label", "source", "extent"])


def tb_features(man, rng, enc_seed):
    n = len(man)
    y, src = man.label.values, man.source.values
    base = np.random.default_rng(enc_seed)
    fmt = np.zeros(D); fmt[0:5] = 3.0
    dis = np.zeros(D); dis[10:14] = 0.7
    ext = np.zeros(D); ext[20:23] = 0.8
    dom = np.zeros(D); dom[50:60] = 1.2
    perm = base.permutation(D)                                   # a different feature basis per synthetic encoder
    Z = rng.standard_normal((n, D))
    Z += np.outer(src == "belarus", fmt) + np.outer(y, dis) + np.outer(man.extent.values == "B", ext) + np.outer(src == "montgomery", dom)
    Z[:, 70:75] *= np.where(src == "belarus", 3.0, 1.0)[:, None]  # variance cue: survives LEACE, decodable by an MLP
    Z[:, 112:] = 0.0                                              # dead columns (as in the 1024-d XRV features)
    Z = Z[:, perm]
    isb = src == "belarus"
    mean_int = np.where(isb, 110, 100) + 6 * np.where(src == "shenzhen", y, np.where(src == "montgomery", -y, 0)) + rng.normal(0, 4, n)
    H = np.c_[np.where(isb, 2500, np.where(src == "rsna", 1024, np.where(src == "shenzhen", 2000, 4020))) + rng.integers(0, 3, n),
              np.where(isb, 2000, np.where(src == "rsna", 1024, np.where(src == "shenzhen", 2000, 4892))) + rng.integers(0, 3, n),
              mean_int, rng.random(n) + 20, np.full(n, 255.0), np.zeros(n)]
    return Z.astype(np.float32), H.astype(np.float32), np.array(["h", "w", "mean", "std", "maxv", "minv"]), perm


def fake_finetune(man, Z, H, Hc):
    """Mimics the finetune_tb.py output format: a linear head fitted on a train split of Belarus/RSNA, never on the matched sets."""
    from sklearn.linear_model import LogisticRegression
    from sklearn.model_selection import train_test_split
    y, src = man.label.values, man.source.values
    nat = np.where(np.isin(src, ["belarus", "rsna"]))[0]
    tr, va = train_test_split(nat, test_size=0.3, stratify=y[nat], random_state=0)
    split = np.full(len(man), "other", dtype="<U5")
    split[tr], split[va] = "train", "val"
    m = LogisticRegression(max_iter=500).fit(Z[tr], y[tr])
    w, b = m.coef_[0].astype(np.float32), float(m.intercept_[0])
    logit = (Z @ w + b).astype(np.float32)
    ok = np.isin(src, ["shenzhen", "montgomery"])
    from sklearn.metrics import roc_auc_score
    return dict(Z=Z, logit=logit, split=split, head_w=w, head_b=b, H=H, Hcols=Hc, val_auc=roc_auc_score(y[va], logit[va]),
                matched_auc=roc_auc_score(y[ok], logit[ok]))


def planted(man, rng, perm):
    m = man[man.source.isin(["shenzhen", "montgomery"])].reset_index(drop=True)
    n = len(m)
    dis = np.zeros(D); dis[10:14] = 0.7
    Zc = rng.standard_normal((n, D)) + np.outer(m.label.values, dis)
    Zc[:, 112:] = 0.0
    out = {"Z_clean": Zc[:, perm].astype(np.float32), "y": m.label.values, "source": m.source.values, "markers": np.array(["corner", "intensity", "texture"])}
    for kind, (lo, hi, amp) in {"corner": (40, 50, 0.8), "intensity": (60, 70, 0.5), "texture": (80, 90, 0.6)}.items():
        v = np.zeros(D); v[lo:hi] = amp
        out[f"Z_marked_{kind}"] = (Zc + v)[:, perm].astype(np.float32)
    out["Z_marked"] = out["Z_marked_corner"]
    return out


def malaria(rng, enc_seed, n=3000, planted_too=True, n_pat=40):
    pat = rng.integers(0, n_pat, n)
    pinf = rng.random(n_pat) * 0.9 + 0.05
    pinf[:8] = 0.0                                                # a few patients with no infected cell (bystander test needs them)
    y = (rng.random(n) < pinf[pat]).astype(int)
    sig = rng.standard_normal((n_pat, D)) * 0.8
    true = np.zeros(D); true[:6] = 0.7
    names = np.array([f"C{p + 1}P{p + 1}ThinF_IMG_2015_{i}_cell_{i}.png" if p < n_pat - 1 else f"C{p + 1}_thinF_IMG_2015_{i}_cell_{i}.png"
                      for i, p in enumerate(pat)])               # last patient lacks the P token (parsing edge case)
    d = {"y": y, "names": names}
    for v, (ps, ts) in {"full": (1, 1), "parasite": (0.5, 1.5), "rbc": (1, 0.3), "randcrop": (1, 0.3), "gray": (0.4, 0.2), "silhouette": (0.2, 0.0)}.items():
        d[f"Z_{v}"] = (rng.standard_normal((n, D)) + ps * sig[pat] + ts * np.outer(y, true)).astype(np.float32)
    cols = ["h", "w", "aspect", "cell_frac", "parasite_frac", "rand_overlap", "mR", "mG", "mB", "sR", "sG", "sB", "mH", "mS", "mV", "sH", "sS", "sV"]
    Hm = rng.random((n, len(cols)))
    Hm[:, 0] = 100 + 5 * pat + y * 3 + rng.integers(0, 4, n)
    Hm[:, 4] = np.where(y == 1, rng.random(n) * 0.3 + 0.1, rng.random(n) * 0.05)   # parasite_frac separates classes
    Hm[:, 5] = (rng.random(n) < 0.1) * 0.05
    Hm[:, 13] += 0.1 * pat / n_pat
    d["H"], d["Hcols"] = Hm.astype(np.float32), np.array(cols)
    pl = None
    if planted_too:
        m = 1500
        ids = np.sort(rng.choice(n, m, replace=False))
        Zc = d["Z_full"][ids]
        pl = {"Z_clean": Zc, "y": y[ids], "names": names[ids], "markers": np.array(["corner", "intensity", "texture"])}
        for kind, (lo, hi, amp) in {"corner": (40, 50, 0.8), "intensity": (60, 70, 0.5), "texture": (80, 90, 0.6)}.items():
            v = np.zeros(D); v[lo:hi] = amp
            pl[f"Z_marked_{kind}"] = (Zc + v).astype(np.float32)
    return d, pl


def glioma_tcga(rng, m=1100):
    grade = rng.choice([2, 3, 4], m, p=[.3, .2, .5])
    idh = (((grade < 4) & (rng.random(m) < .85)) | ((grade == 4) & (rng.random(m) < .07))).astype(int)
    codel = ((idh == 1) & (grade < 4) & (rng.random(m) < .4))
    tert = (codel | ((idh == 0) & (rng.random(m) < .6)))
    mgmt = rng.random(m) < (.4 + .3 * idh)
    sub = np.where(idh == 0, "IDHwt", np.where(codel, "IDHmut-codel", "IDHmut-non-codel"))
    df = pd.DataFrame(dict(idh_status=np.where(idh == 1, "Mutant", "WT"), who_grade_raw=[f"G{g}" for g in grade],
                           age_at_diagnosis=np.nan, mgmt_methylation_status=np.where(mgmt, "Methylated", "Unmethylated"),
                           idh_1p19q_subtype=sub, tert_promoter_status=np.where(tert, "Mutant", "WT"), sex=np.nan))
    df.loc[rng.random(m) < .2, "mgmt_methylation_status"] = np.nan
    df.loc[rng.random(m) < .6, "tert_promoter_status"] = np.nan
    df.loc[rng.random(m) < .1, "idh_status"] = np.nan
    return df


def glioma_cgga(rng, m=700):
    grade = rng.choice(["WHO II", "WHO III", "WHO IV"], m, p=[.3, .3, .4])
    g4 = grade == "WHO IV"
    idh = (((~g4) & (rng.random(m) < .75)) | (g4 & (rng.random(m) < .12))).astype(int)
    codel = (idh == 1) & (~g4) & (rng.random(m) < .35)
    age = 50 - 12 * idh + rng.normal(0, 10, m)
    return pd.DataFrame({"CGGA_ID": [f"CGGA_{i}" for i in range(m)], "PRS_type": "Primary", "Histology": np.where(g4, "GBM", "A"), "Grade": grade,
                         "Gender": rng.choice(["Male", "Female"], m), "Age": age,
                         "IDH_mutation_status": np.where(idh == 1, "Mutant", "Wildtype"),
                         "1p19q_codeletion_status": np.where(codel, "Codel", "Non-codel"),
                         "MGMTp_methylation_status": np.where(rng.random(m) < (.4 + .2 * idh), "methylated", "un-methylated")})


def images(out, rng):
    from PIL import Image
    man = tb_manifest(40, 80, 30, 20)
    d = out / "tb_images"
    d.mkdir(parents=True, exist_ok=True)
    rows = []
    yy, xx = np.mgrid[:64, :64]
    for i, r in man.iterrows():
        size = {"belarus": 80, "rsna": 64, "shenzhen": 72, "montgomery": 96}[r.source]
        base = {"belarus": 120, "rsna": 100, "shenzhen": 110, "montgomery": 90}[r.source]
        a = rng.normal(base, 25, (size, size))
        if r.label == 1:
            cy, cx = rng.integers(size // 4, 3 * size // 4, 2)
            a += 60 * np.exp(-(((np.mgrid[:size, :size][0] - cy) ** 2 + (np.mgrid[:size, :size][1] - cx) ** 2) / 60.0))
        sub = d / r.source
        sub.mkdir(exist_ok=True)
        stem = {"belarus": f"bel_{i}", "rsna": f"rsna_{i}", "shenzhen": f"CHNCXR_{i:04d}_{r.label}", "montgomery": f"MCUCXR_{i:04d}_{r.label}"}[r.source]
        p = sub / f"{stem}.png"
        Image.fromarray(np.clip(a, 0, 255).astype(np.uint8)).save(p)
        rows.append((stem, r.extent))
    pd.DataFrame([x for x in rows if x[1] in ("A", "B")], columns=["basename", "extent"]).to_csv(out / "belarus_extent.csv", index=False)
    mal = out / "malaria"
    for cls in ("Parasitized", "Uninfected"):
        (mal / cls).mkdir(parents=True, exist_ok=True)
    for i in range(120):
        p = i % 12
        cls = "Parasitized" if rng.random() < (0.1 + 0.08 * p) else "Uninfected"
        s = 70 + rng.integers(0, 20)
        yy, xx = np.mgrid[:s, :s]
        cell = ((yy - s / 2) ** 2 + (xx - s / 2) ** 2) < (s * 0.42) ** 2
        img = np.zeros((s, s, 3), np.float32)
        img[cell] = np.array([220, 140, 170]) + rng.normal(0, 6, (cell.sum(), 3))
        if cls == "Parasitized":
            sp = ((yy - s * 0.4) ** 2 + (xx - s * 0.55) ** 2) < (s * 0.12) ** 2
            img[sp & cell] = np.array([90, 40, 140])
        name = f"C{p + 1}P{p + 1}ThinF_IMG_2015_{i}_cell_{i}.png"
        Image.fromarray(np.clip(img, 0, 255).astype(np.uint8)).save(mal / cls / name)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("out")
    ap.add_argument("--images", action="store_true")
    ap.add_argument("--seed", type=int, default=0)
    a = ap.parse_args()
    out = Path(a.out)
    out.mkdir(parents=True, exist_ok=True)
    rng = np.random.default_rng(a.seed)
    man = tb_manifest()
    man.to_csv(out / "tb_manifest.csv", index=False)
    for k, enc in enumerate(["synA", "synB"]):
        r = np.random.default_rng(a.seed + 10 + k)
        Z, H, Hc, perm = tb_features(man, r, 100 + k)
        np.savez(out / f"tb_{enc}.npz", Z=Z, H=H, Hcols=Hc)
        np.savez(out / f"ft_{enc}.npz", **fake_finetune(man, Z, H, Hc))      # stands in for finetune_tb.py output (no torch needed)
        np.savez(out / f"tbplanted_{enc}.npz", **planted(man, r, perm))
        d, pl = malaria(r, 200 + k)
        np.savez(out / f"mal_{enc}.npz", **d)
        np.savez(out / f"malplanted_{enc}.npz", **pl)
    glioma_tcga(rng).to_csv(out / "glioma_tcga.csv", index=False)
    glioma_cgga(rng).to_csv(out / "glioma_cgga.csv", index=False)
    if a.images:
        images(out, rng)
    print("synthetic written to", out)


if __name__ == "__main__":
    main()
