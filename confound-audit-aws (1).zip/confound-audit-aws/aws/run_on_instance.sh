#!/usr/bin/env bash
# Runs ON the instance, started by the launch user-data. Pulls code state, data and any earlier features/results from S3,
# runs the resumable pipeline, mirrors results to S3 every few minutes, then (optionally) stops the instance.
set -u
. "$HOME/aws_env.sh"                     # written by user-data: S3_BUCKET S3_PREFIX PIPELINE_GROUPS EXTRA_PIPELINE_ARGS RUN_SMOKE AUTO_SHUTDOWN
S3_ROOT="s3://${S3_BUCKET}/${S3_PREFIX}"
WORK="$HOME/confound-audit"
DATA="$HOME/data"
LOG="$HOME/run.log"
export WORK
mkdir -p "$WORK" "$DATA"
cd "$WORK" || exit 1
exec >> "$LOG" 2>&1
echo "=== run_on_instance started $(date -u +%FT%TZ)"
nvidia-smi || echo "no nvidia-smi"

aws s3 cp "$S3_ROOT/code/confound-audit.tgz" "$HOME/code.tgz" --only-show-errors && tar -xzf "$HOME/code.tgz" -C "$WORK"
bash "$WORK/aws/bootstrap_instance.sh"
PYENV="$(cat "$WORK/.pyenv" 2>/dev/null || echo /usr)"
PY="$PYENV/bin/python"

# data
aws s3 sync "$S3_ROOT/data" "$DATA" --only-show-errors
# earlier features and results, so a restarted or spot-interrupted instance resumes instead of recomputing
mkdir -p "$WORK/feats" "$WORK/results"
aws s3 sync "$S3_ROOT/feats" "$WORK/feats" --only-show-errors
aws s3 sync "$S3_ROOT/results" "$WORK/results" --only-show-errors

# paths for the pipeline
export BELARUS="$DATA/belarus" RSNA="$DATA/rsna" SHENZHEN="$DATA/shenzhen" MONTGOMERY="$DATA/montgomery" MALARIA="$DATA/malaria"
[ -f "$DATA/belarus_extent.csv" ] && export EXTENT_CSV="$DATA/belarus_extent.csv"
[ -f "$DATA/cohort.csv" ] && export GLIOMA_CSV="$DATA/cohort.csv"
[ -f "$DATA/cgga.csv" ] && export CGGA_CSV="$DATA/cgga.csv"
export FEATS_DIR="$WORK/feats" RESULTS_DIR="$WORK/results" HF_HOME="$HOME/hf_cache" N_JOBS="$(nproc)"

push() {
  aws s3 sync "$WORK/results" "$S3_ROOT/results" --only-show-errors
  aws s3 sync "$WORK/feats" "$S3_ROOT/feats" --only-show-errors
  aws s3 cp "$LOG" "$S3_ROOT/logs/run.log" --only-show-errors
}
( while true; do sleep 300; push; done ) &
SYNCER=$!

SMOKE=""
if [ "${RUN_SMOKE:-0}" = "1" ]; then SMOKE="--smoke"; fi
"$PY" "$WORK/run_pipeline.py" --groups "$PIPELINE_GROUPS" $SMOKE ${EXTRA_PIPELINE_ARGS:-}
RC=$?
echo "=== pipeline exit code $RC at $(date -u +%FT%TZ)"

kill "$SYNCER" 2>/dev/null
if push; then
  echo "=== final sync ok"
  echo "$RC" > "$HOME/pipeline.rc"
  aws s3 cp "$HOME/pipeline.rc" "$S3_ROOT/logs/pipeline.rc" --only-show-errors
  if [ "${AUTO_SHUTDOWN:-0}" = "1" ]; then
    echo "=== stopping the instance"
    aws s3 cp "$LOG" "$S3_ROOT/logs/run.log" --only-show-errors
    sudo shutdown -h now
  fi
else
  echo "=== FINAL SYNC FAILED: the instance stays up so results are not lost; fix the S3 access and run: aws s3 sync $WORK/results $S3_ROOT/results"
fi
