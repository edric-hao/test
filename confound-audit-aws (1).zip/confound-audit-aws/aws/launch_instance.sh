#!/usr/bin/env bash
# Launch the GPU instance; on boot it pulls the code package from S3 and runs the pipeline. Usage: bash aws/launch_instance.sh [--dry-run]
. "$(dirname "$0")/common.sh"
need_aws

# 1. AMI: the newest AWS Deep Learning AMI (GPU, PyTorch, Ubuntu 22.04) found through the public SSM parameters; AMI_ID in config.sh overrides
AMI="$AMI_ID"
if [ -z "$AMI" ]; then
  if [ "$DRY" = "1" ]; then
    AMI="ami-RESOLVED-AT-LAUNCH"
  else
    LINE="$(aws ssm get-parameters-by-path --path /aws/service/deeplearning/ami/x86_64 --recursive \
      --query "Parameters[?contains(Name, 'gpu-pytorch') && contains(Name, 'ubuntu-22.04') && contains(Name, 'latest')].[Name,Value]" --output text | sort -V | tail -n 1)"
    AMI="$(echo "$LINE" | cut -f2)"
    echo "AMI parameter: $(echo "$LINE" | cut -f1)"
  fi
fi
[ -n "$AMI" ] || { echo "could not resolve a Deep Learning AMI; set AMI_ID in aws/config.sh (console: EC2, AMIs, Public images, owner amazon, 'Deep Learning OSS Nvidia Driver AMI GPU PyTorch')" >&2; exit 2; }
echo "AMI: $AMI"

# 2. user-data: write the environment, then start the run in the background as the ubuntu user
UD="$(mktemp)"
cat > "$UD" <<UDEOF
#!/bin/bash
cat > /home/ubuntu/aws_env.sh <<ENVEOF
export S3_BUCKET="${S3_BUCKET}"
export S3_PREFIX="${S3_PREFIX}"
export AWS_DEFAULT_REGION="${AWS_REGION}"
export PIPELINE_GROUPS="${PIPELINE_GROUPS}"
export EXTRA_PIPELINE_ARGS="${EXTRA_PIPELINE_ARGS}"
export RUN_SMOKE="${RUN_SMOKE}"
export AUTO_SHUTDOWN="${AUTO_SHUTDOWN}"
ENVEOF
chown ubuntu:ubuntu /home/ubuntu/aws_env.sh
sudo -u ubuntu -H bash -c 'mkdir -p /home/ubuntu/confound-audit/aws && aws s3 cp ${S3_ROOT}/code/confound-audit.tgz /home/ubuntu/code0.tgz --region ${AWS_REGION} && tar -xzf /home/ubuntu/code0.tgz -C /home/ubuntu/confound-audit && nohup bash /home/ubuntu/confound-audit/aws/run_on_instance.sh > /home/ubuntu/boot.log 2>&1 &'
UDEOF

# 3. run-instances
BDM='[{"DeviceName":"/dev/sda1","Ebs":{"VolumeSize":'"${VOLUME_GB}"',"VolumeType":"gp3","DeleteOnTermination":true}}]'
CMD=(aws ec2 run-instances --image-id "$AMI" --instance-type "$INSTANCE_TYPE" --key-name "$KEY_NAME"
     --iam-instance-profile "Name=$INSTANCE_PROFILE" --block-device-mappings "$BDM" --user-data "file://$UD"
     --instance-initiated-shutdown-behavior "$SHUTDOWN_BEHAVIOR" --count 1
     --tag-specifications "ResourceType=instance,Tags=[{Key=Name,Value=confound-audit},{Key=project,Value=confound-audit}]"
     --query "Instances[0].InstanceId" --output text)
if [ -n "$SECURITY_GROUP_ID" ]; then CMD+=(--security-group-ids "$SECURITY_GROUP_ID"); fi
if [ -n "$SUBNET_ID" ]; then CMD+=(--subnet-id "$SUBNET_ID"); fi
if [ "$USE_SPOT" = "1" ]; then CMD+=(--instance-market-options "MarketType=spot,SpotOptions={SpotInstanceType=one-time}"); fi

if [ "$DRY" = "1" ]; then
  echo "[dry-run] ${CMD[@]}"
  echo "[dry-run] user-data would be:"; cat "$UD"
  exit 0
fi
ID="$("${CMD[@]}")" || { echo "run-instances failed" >&2; exit 1; }
echo "launched $ID"
echo "$ID" > "$HERE/.last_instance_id"
echo "watch progress:   bash aws/status.sh"
echo "fetch results:    bash aws/download_results.sh"
