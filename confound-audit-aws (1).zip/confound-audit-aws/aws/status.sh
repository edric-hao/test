#!/usr/bin/env bash
# Progress without SSH: instance state, the pipeline status file and the tail of the run log, all read from S3 / EC2.
. "$(dirname "$0")/common.sh"
need_aws
ID="${1:-$(cat "$HERE/.last_instance_id" 2>/dev/null)}"
if [ -n "$ID" ] && [ "$ID" != "--dry-run" ]; then
  aws ec2 describe-instances --instance-ids "$ID" --query "Reservations[0].Instances[0].[InstanceId,State.Name,InstanceType,PublicIpAddress]" --output text
fi
echo "---- pipeline status (stage, status)"
aws s3 cp "$S3_ROOT/results/PIPELINE_STATUS.json" - 2>/dev/null | python3 -c "
import json,sys
try:
    d=json.load(sys.stdin)
except Exception:
    print('(no status file yet)'); sys.exit()
for k,v in d.items(): print(f'{k:46s} {v.get(\"status\",\"\"):8s} {v.get(\"reason\",\"\")}')
"
echo "---- run.log (last 25 lines, updated every 5 minutes)"
aws s3 cp "$S3_ROOT/logs/run.log" - 2>/dev/null | tail -n 25
echo "---- exit code file (appears when the pipeline has finished)"
aws s3 cp "$S3_ROOT/logs/pipeline.rc" - 2>/dev/null || echo "(not finished)"
