#!/usr/bin/env bash
# Download results (and, with --feats, the extracted features) from S3 into ./results_from_aws . Usage: bash aws/download_results.sh [--feats]
. "$(dirname "$0")/common.sh"
need_aws
OUT="$REPO/results_from_aws"
mkdir -p "$OUT"
aws s3 sync "$S3_ROOT/results" "$OUT/results" --only-show-errors
aws s3 sync "$S3_ROOT/logs" "$OUT/logs" --only-show-errors
for arg in "$@"; do
  if [ "$arg" = "--feats" ]; then aws s3 sync "$S3_ROOT/feats" "$OUT/feats" --only-show-errors; fi
done
echo "downloaded to $OUT"
