#!/usr/bin/env bash
# Package this repository (without feats, results, caches) and upload it. Usage: bash aws/upload_code.sh [--dry-run]
. "$(dirname "$0")/common.sh"
need_aws
TARBALL="$(mktemp -d)/confound-audit.tgz"
tar -czf "$TARBALL" -C "$REPO" --exclude=feats --exclude=results --exclude=__pycache__ --exclude=.git --exclude=paths.sh --exclude=aws/config.sh .
echo "code package: $(du -h "$TARBALL" | cut -f1)"
doit aws s3 cp "$TARBALL" "$S3_ROOT/code/confound-audit.tgz" --only-show-errors
