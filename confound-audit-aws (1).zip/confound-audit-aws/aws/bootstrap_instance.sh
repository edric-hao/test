#!/usr/bin/env bash
# Runs ON the instance (called by run_on_instance.sh). Prepares a Python environment with torch + every extra package the extraction
# needs. The Deep Learning AMI ships a CUDA PyTorch environment; if it is not where expected a venv with pip torch is created.
set -u
WORK="${WORK:-$HOME/confound-audit}"
cd "$WORK" || exit 1
PYENV=""
for cand in /opt/pytorch /opt/conda/envs/pytorch; do
  if [ -x "$cand/bin/python" ]; then PYENV="$cand"; break; fi
done
if [ -z "$PYENV" ]; then
  python3 -m venv "$HOME/venv" && PYENV="$HOME/venv"
  "$PYENV/bin/pip" install --quiet torch torchvision
fi
echo "python environment: $PYENV"
"$PYENV/bin/pip" install --quiet -r requirements.txt || echo "WARNING: pip install -r requirements.txt reported errors"
"$PYENV/bin/python" - <<'PYEOF'
import torch, sys
print("python", sys.version.split()[0], "| torch", torch.__version__, "| cuda available:", torch.cuda.is_available(),
      "| device:", torch.cuda.get_device_name(0) if torch.cuda.is_available() else "none")
PYEOF
echo "$PYENV" > "$WORK/.pyenv"
