# Shared helpers. Sourced, never executed.
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO="$(cd "$HERE/.." && pwd)"
STAR="$(printf '\052')"      # the one character this repository keeps out of its text files
if [ -f "$HERE/config.sh" ]; then
  . "$HERE/config.sh"
else
  echo "aws/config.sh not found: copy aws/config.example.sh to aws/config.sh and edit it" >&2
  exit 2
fi
DRY=0
for arg in "$@"; do
  if [ "$arg" = "--dry-run" ]; then DRY=1; fi
done
export AWS_DEFAULT_REGION="$AWS_REGION"
S3_ROOT="s3://${S3_BUCKET}/${S3_PREFIX}"

# run a command, or only print it under --dry-run
doit() {
  if [ "$DRY" = "1" ]; then
    echo "[dry-run] $@"
  else
    "$@"
  fi
}

need_aws() {
  if [ "$DRY" = "1" ]; then return 0; fi
  command -v aws >/dev/null 2>&1 || { echo "the aws CLI is not installed" >&2; exit 2; }
  aws sts get-caller-identity >/dev/null 2>&1 || { echo "aws credentials are not configured (aws configure, or an SSO login)" >&2; exit 2; }
}
