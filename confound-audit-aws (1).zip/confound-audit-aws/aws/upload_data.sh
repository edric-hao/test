#!/usr/bin/env bash
# Upload the datasets from this computer to s3://BUCKET/PREFIX/data/ . Directories are synced whole, files are copied.
# Medical images are sensitive: check each dataset licence allows cloud storage before uploading. Usage: bash aws/upload_data.sh [--dry-run]
. "$(dirname "$0")/common.sh"
need_aws
up_dir() {   # name, local dir
  if [ -n "$2" ] && [ -d "$2" ]; then doit aws s3 sync "$2" "$S3_ROOT/data/$1" --only-show-errors; echo "uploaded $1"; else echo "skipping $1 (not set or not a directory)"; fi
}
up_file() {  # name, local file
  if [ -n "$2" ] && [ -f "$2" ]; then doit aws s3 cp "$2" "$S3_ROOT/data/$1" --only-show-errors; echo "uploaded $1"; else echo "skipping $1 (not set or not a file)"; fi
}
up_dir belarus "$LOCAL_BELARUS"
up_dir rsna "$LOCAL_RSNA"
up_dir shenzhen "$LOCAL_SHENZHEN"
up_dir montgomery "$LOCAL_MONTGOMERY"
up_dir malaria "$LOCAL_MALARIA"
up_file belarus_extent.csv "$LOCAL_EXTENT_CSV"
up_file cohort.csv "$LOCAL_GLIOMA_CSV"
up_file cgga.csv "$LOCAL_CGGA_CSV"
echo "data is under $S3_ROOT/data/"
