# Copy to aws/config.sh and edit. Sourced by every script in aws/.
export AWS_REGION=us-east-1
export S3_BUCKET=CHANGE-ME-unique-bucket-name
export S3_PREFIX=confound-audit
export KEY_NAME=CHANGE-ME-ec2-keypair-name

# Instance. g5.2xlarge = 1 x A10G (24 GB), 8 vCPU, 32 GB RAM. Use g5.4xlarge or g5.8xlarge for more CPU cores in the analysis stages.
export INSTANCE_TYPE=g5.2xlarge
export VOLUME_GB=600
export INSTANCE_PROFILE=confound-audit-ec2
export SECURITY_GROUP_ID=
export SUBNET_ID=
export AMI_ID=
export USE_SPOT=0
export SHUTDOWN_BEHAVIOR=stop

# What to run on the instance (comma separated: prep,extract,finetune,analyze,report). Everything is resumable.
export PIPELINE_GROUPS=prep,extract,finetune,analyze,report
export EXTRA_PIPELINE_ARGS=
export RUN_SMOKE=0
export AUTO_SHUTDOWN=1

# Local data to upload with aws/upload_data.sh (leave a variable empty to skip it).
export LOCAL_BELARUS=
export LOCAL_RSNA=
export LOCAL_SHENZHEN=
export LOCAL_MONTGOMERY=
export LOCAL_EXTENT_CSV=
export LOCAL_MALARIA=
export LOCAL_GLIOMA_CSV=
export LOCAL_CGGA_CSV=
