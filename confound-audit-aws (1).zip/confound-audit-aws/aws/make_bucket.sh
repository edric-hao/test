#!/usr/bin/env bash
# One-time: create the S3 bucket (private, default encryption). Usage: bash aws/make_bucket.sh [--dry-run]
. "$(dirname "$0")/common.sh"
need_aws
if [ "$AWS_REGION" = "us-east-1" ]; then
  doit aws s3api create-bucket --bucket "$S3_BUCKET"
else
  doit aws s3api create-bucket --bucket "$S3_BUCKET" --create-bucket-configuration "LocationConstraint=$AWS_REGION"
fi
doit aws s3api put-public-access-block --bucket "$S3_BUCKET" --public-access-block-configuration "BlockPublicAcls=true,IgnorePublicAcls=true,BlockPublicPolicy=true,RestrictPublicBuckets=true"
doit aws s3api put-bucket-encryption --bucket "$S3_BUCKET" --server-side-encryption-configuration '{"Rules":[{"ApplyServerSideEncryptionByDefault":{"SSEAlgorithm":"AES256"}}]}'
