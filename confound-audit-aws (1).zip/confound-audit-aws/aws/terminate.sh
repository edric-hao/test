#!/usr/bin/env bash
# Terminate the last launched instance (its disk is deleted; results live in S3). Usage: bash aws/terminate.sh [instance-id] [--dry-run]
. "$(dirname "$0")/common.sh"
need_aws
ID="${1:-}"
if [ "$ID" = "--dry-run" ] || [ -z "$ID" ]; then ID="$(cat "$HERE/.last_instance_id" 2>/dev/null)"; fi
if [ -z "$ID" ] && [ "$DRY" = "1" ]; then ID="i-EXAMPLE"; fi
[ -n "$ID" ] || { echo "no instance id given and none recorded" >&2; exit 2; }
doit aws ec2 terminate-instances --instance-ids "$ID" --output text
