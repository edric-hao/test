#!/usr/bin/env bash
# One-time: create the EC2 role + instance profile that lets the instance read/write s3://BUCKET/PREFIX only.
# Needs an AWS identity allowed to create IAM roles. Safe to run twice.   Usage: bash aws/iam_setup.sh [--dry-run]
. "$(dirname "$0")/common.sh"
need_aws
POLICY="$(mktemp)"
sed -e "s|__BUCKET__|${S3_BUCKET}|g" -e "s|__PREFIX__|${S3_PREFIX}|g" -e "s|__ALL__|${STAR}|g" "$HERE/iam_policy.json" > "$POLICY"
echo "policy to attach:"; cat "$POLICY"
doit aws iam create-role --role-name "$INSTANCE_PROFILE" --assume-role-policy-document "file://$HERE/iam_trust.json" || echo "(role may already exist)"
doit aws iam put-role-policy --role-name "$INSTANCE_PROFILE" --policy-name confound-audit-s3 --policy-document "file://$POLICY"
doit aws iam create-instance-profile --instance-profile-name "$INSTANCE_PROFILE" || echo "(instance profile may already exist)"
doit aws iam add-role-to-instance-profile --instance-profile-name "$INSTANCE_PROFILE" --role-name "$INSTANCE_PROFILE" || echo "(role may already be attached)"
rm -f "$POLICY"
echo "done. IAM changes can take about 10 seconds to propagate before the first launch."
