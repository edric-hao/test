#!/usr/bin/env python3
"""Resumable stage runner for every experiment (the original E1-E9 plus the 13 additional items).

  python run_pipeline.py --list                       # stages, groups, status
  python run_pipeline.py --dry-run                    # print every command, run nothing
  python run_pipeline.py                              # run everything that is not finished
  python run_pipeline.py --groups extract,finetune    # GPU part only
  python run_pipeline.py --groups analyze,report      # CPU part only
  python run_pipeline.py --only item03,item05         # stages whose name contains one of these words
  python run_pipeline.py --force --only item04        # rerun a finished stage
  python run_pipeline.py --smoke                      # tiny sizes, random-init backbones (checks the plumbing, numbers are meaningless)

Groups: prep, extract, finetune, analyze, report.   A stage is finished when its recorded status is ok AND its declared outputs exist.
Failures never stop the run: the stage is logged, stages that need its outputs report 'skipped (missing input)', and the final
table lists everything.  Status is kept in results/PIPELINE_STATUS.json and per-stage logs in results/logs/.

Paths come from environment variables (see paths.sh.example): BELARUS RSNA SHENZHEN MONTGOMERY EXTENT_CSV MALARIA GLIOMA_CSV, optional CGGA_CSV.
Features go to FEATS_DIR (default ./feats), results to RESULTS_DIR (default ./results).
"""
import argparse
import json
import os
import subprocess
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parent
SCRIPTS = ROOT / "scripts"
PY = sys.executable

ap = argparse.ArgumentParser()
ap.add_argument("--groups", default="prep,extract,finetune,analyze,report")
ap.add_argument("--only", default="", help="comma separated words; run stages whose name contains any of them")
ap.add_argument("--skip", default="", help="comma separated words; skip stages whose name contains any of them")
ap.add_argument("--force", action="store_true")
ap.add_argument("--dry-run", action="store_true", dest="dry")
ap.add_argument("--list", action="store_true")
ap.add_argument("--smoke", action="store_true")
ap.add_argument("--fresh", action="store_true", help="delete the test registry and status file first (a clean full run)")
ap.add_argument("--feats_dir", default=os.environ.get("FEATS_DIR", str(ROOT / "feats")))
ap.add_argument("--results_dir", default=os.environ.get("RESULTS_DIR", str(ROOT / "results")))
ap.add_argument("--tb_encoders", default="xrv_densenet121,dinov2_small,resnet50,rad_dino,biomedclip")
ap.add_argument("--mal_encoders", default="resnet50,densenet121,dinov2_small,biomedclip")
ap.add_argument("--mal_planted_encoders", default="resnet50,dinov2_small")
ap.add_argument("--ft_encoders", default="xrv_densenet121,resnet50")
ap.add_argument("--n_jobs", type=int, default=int(os.environ.get("N_JOBS", os.cpu_count() or 1)))
ap.add_argument("--workers", type=int, default=min(8, os.cpu_count() or 4), help="image decode threads in extraction")
ap.add_argument("--batch", type=int, default=128)
args = ap.parse_args()

if args.smoke:      # a smoke run must never leave 'finished' stages behind in the real directories
    if args.feats_dir == str(ROOT / "feats"):
        args.feats_dir = str(ROOT / "feats_smoke")
    if args.results_dir == str(ROOT / "results"):
        args.results_dir = str(ROOT / "results_smoke")
FEATS = Path(args.feats_dir)
RES = Path(args.results_dir)
FEATS.mkdir(parents=True, exist_ok=True)
RES.mkdir(parents=True, exist_ok=True)
(RES / "logs").mkdir(exist_ok=True)
STATUS_F = RES / "PIPELINE_STATUS.json"
os.environ["RESULTS_DIR"] = str(RES)
os.environ.setdefault("HF_HOME", str(Path.home() / "hf_cache"))
if args.fresh and not args.dry:
    for f in (RES / "test_registry.jsonl", STATUS_F):
        if f.exists():
            f.unlink()

E = os.environ.get
TBE = [x for x in args.tb_encoders.split(",") if x]
MALE = [x for x in args.mal_encoders.split(",") if x]
MALPE = [x for x in args.mal_planted_encoders.split(",") if x]
FTE = [x for x in args.ft_encoders.split(",") if x]
S = args.smoke
MANIFEST = FEATS / "tb_manifest.csv"
PM = "resnet50" if "resnet50" in MALE else (MALE[0] if MALE else "resnet50")                # primary malaria encoder
XR = "xrv_densenet121" if "xrv_densenet121" in TBE else (TBE[0] if TBE else "xrv_densenet121")   # encoder item 4 diagnoses


def sc(full, small):
    return small if S else full


class Skip(Exception):
    pass


def need(*paths):
    miss = [str(p) for p in paths if not Path(p).exists()]
    if miss:
        raise Skip("missing input: " + ", ".join(Path(m).name for m in miss))


def need_env(*names):
    miss = [n for n in names if not E(n)]
    if miss:
        raise Skip("environment variable not set: " + ", ".join(miss))


def tbf(enc, kind=""):
    return FEATS / f"tb_{enc}{kind}.npz"


def py(script, *a):
    return [PY, str(SCRIPTS / script)] + [str(x) for x in a]


def kv(items):
    return [f"{t}={p}" for t, p in items]


# ----------------------------------------------------------------------------- stage registry
STAGES = []   # dicts: name, group, build() -> cmd list (may raise Skip), outputs (list of paths), gpu


def stage(name, group, build, outputs=(), gpu=False):
    STAGES.append(dict(name=name, group=group, build=build, outputs=[Path(o) for o in outputs], gpu=gpu))


def extract_common():
    c = ["--workers", args.workers, "--batch", args.batch]
    if S:
        c += ["--no_pretrained"]
    return c


# ---- prep
def b_manifest():
    need_env("BELARUS", "RSNA", "SHENZHEN", "MONTGOMERY")
    c = py("make_tb_manifest.py", "--belarus_dir", E("BELARUS"), "--rsna_dir", E("RSNA"), "--shenzhen_dir", E("SHENZHEN"),
           "--montgomery_dir", E("MONTGOMERY"), "--out", MANIFEST)
    if E("EXTENT_CSV"):
        c += ["--extent_csv", E("EXTENT_CSV")]
    return c


stage("prep_manifest", "prep", b_manifest, [MANIFEST])


# ---- extraction
def tb_extract(enc, kind, harm):
    def build():
        need(MANIFEST)
        c = py("extract_features.py", "tb", "--manifest", MANIFEST, "--backbone", enc, "--out", tbf(enc, kind)) + extract_common()
        if S:
            c += ["--max_per_source", 40]
        if harm:
            c += ["--harmonize", harm]
        return c
    return build


def tbp_extract(enc):
    def build():
        need(MANIFEST)
        c = py("extract_features.py", "tb_planted", "--manifest", MANIFEST, "--backbone", enc, "--out", FEATS / f"tbplanted_{enc}.npz",
               "--markers", "corner,intensity,texture") + extract_common()
        if S:
            c += ["--max_per_source", 40]
        return c
    return build


for enc in TBE:
    stage(f"extract_tb_{enc}", "extract", tb_extract(enc, "", None), [tbf(enc)], gpu=True)
    stage(f"extract_tbplanted_{enc}", "extract", tbp_extract(enc), [FEATS / f"tbplanted_{enc}.npz"], gpu=True)
    stage(f"extract_tb_{enc}_harm", "extract", tb_extract(enc, "_harm", "std"), [tbf(enc, "_harm")], gpu=True)
    stage(f"extract_tb_{enc}_strong", "extract", tb_extract(enc, "_strong", "strong"), [tbf(enc, "_strong")], gpu=True)


def mal_extract(enc):
    def build():
        need_env("MALARIA")
        c = py("extract_features.py", "malaria", "--root", E("MALARIA"), "--backbone", enc, "--mask", "adaptive", "--out", FEATS / f"mal_{enc}.npz") + extract_common()
        if S:
            c += ["--max_cells", 300]
        return c
    return build


def malp_extract(enc):
    def build():
        need_env("MALARIA")
        return py("extract_features.py", "malaria_planted", "--root", E("MALARIA"), "--backbone", enc, "--out", FEATS / f"malplanted_{enc}.npz",
                  "--markers", "corner,intensity,texture", "--max_cells", sc(8000, 300)) + extract_common()
    return build


for enc in MALE:
    stage(f"extract_mal_{enc}", "extract", mal_extract(enc), [FEATS / f"mal_{enc}.npz"], gpu=True)
for enc in MALPE:
    stage(f"extract_malplanted_{enc}", "extract", malp_extract(enc), [FEATS / f"malplanted_{enc}.npz"], gpu=True)


# ---- fine-tuning (item 9)
def ft_build(enc):
    def build():
        need(MANIFEST)
        c = py("finetune_tb.py", "--manifest", MANIFEST, "--backbone", enc, "--out", FEATS / f"ft_{enc}.npz",
               "--epochs", sc(4, 1), "--workers", args.workers)
        if S:
            c += ["--no_pretrained", "--max_per_source", 40]
        return c
    return build


for enc in FTE:
    stage(f"finetune_{enc}", "finetune", ft_build(enc), [FEATS / f"ft_{enc}.npz"], gpu=True)


# ---- analysis, original experiments
def per_enc(script, prefix, outprefix, enc_list, extra=()):
    for enc in enc_list:
        def build(enc=enc):
            need(MANIFEST, tbf(enc))
            return py(script, "--manifest", MANIFEST, "--feats", tbf(enc), "--tag", enc, *extra)
        stage(f"{prefix}_{enc}", "analyze", build, [RES / f"{outprefix}_{enc}.json"])


per_enc("E1_tb_source_matched.py", "E1", "E1_tb", TBE)
per_enc("E2_leace_vs_inlp.py", "E2", "E2_erasers", TBE)
for enc in TBE:
    def b6(enc=enc):
        need(FEATS / f"tbplanted_{enc}.npz")
        return py("E6_planted_shortcut_calibration.py", "--feats", FEATS / f"tbplanted_{enc}.npz", "--tag", enc, "--reps", sc(20, 3), "--n_null", sc(30, 5))
    stage(f"E6_{enc}", "analyze", b6, [RES / f"E6_planted_{enc}.json"])
for enc in TBE:
    def b1h(enc=enc):
        need(MANIFEST, tbf(enc, "_harm"))
        return py("E1_tb_source_matched.py", "--manifest", MANIFEST, "--feats", tbf(enc, "_harm"), "--tag", f"{enc}_harm")
    stage(f"E1_{enc}_harm", "analyze", b1h, [RES / f"E1_tb_{enc}_harm.json"])
    def b2h(enc=enc):
        need(MANIFEST, tbf(enc, "_harm"))
        return py("E2_leace_vs_inlp.py", "--manifest", MANIFEST, "--feats", tbf(enc, "_harm"), "--tag", f"{enc}_harm")
    stage(f"E2_{enc}_harm", "analyze", b2h, [RES / f"E2_erasers_{enc}_harm.json"])

for enc in MALE:
    def b5(enc=enc):
        need(FEATS / f"mal_{enc}.npz")
        return py("E5_malaria_patient_split.py", "--feats", FEATS / f"mal_{enc}.npz", "--tag", enc)
    stage(f"E5_{enc}", "analyze", b5, [RES / f"E5_malaria_{enc}.json"])
    def b9(enc=enc):
        need(FEATS / f"mal_{enc}.npz")
        return py("E9_patient_state.py", "--feats", FEATS / f"mal_{enc}.npz", "--tag", enc)
    stage(f"E9_{enc}", "analyze", b9, [RES / f"E9_patientstate_{enc}.json"])


def b5p():
    need(FEATS / f"mal_{PM}.npz")
    return py("E5_malaria_patient_split.py", "--feats", FEATS / f"mal_{PM}.npz", "--tag", f"{PM}_pnum", "--group_by", "pnum")


stage(f"E5_{PM}_pnum", "analyze", b5p, [RES / f"E5_malaria_{PM}_pnum.json"])


def b4():
    need_env("GLIOMA_CSV")
    return py("E4_glioma_leakage.py", "--csv", E("GLIOMA_CSV"), "--tag", "tcga", "--splits", sc(20, 3))


stage("E4_glioma", "analyze", b4, [RES / "E4_glioma_tcga.json"])

# ---- item 12: E3 with more seeds, parallel over seeds
E3_SEEDS = dict(tb=sc(10, 2), malaria=sc(10, 2), glioma=sc(30, 3))


def e3_tb(enc):
    def build():
        need(MANIFEST, tbf(enc))
        return py("E3_ablation_controls.py", "tb", "--manifest", MANIFEST, "--feats", tbf(enc), "--tag", enc, "--seeds", E3_SEEDS["tb"],
                  "--n_null_fixed", sc(200, 20), "--n_null_retrain", sc(30, 4), "--n_jobs", args.n_jobs)
    return build


for enc in TBE[:3]:
    stage(f"item12_E3_tb_{enc}", "analyze", e3_tb(enc), [RES / f"E3_tb_{enc}.json"])


def e3_mal(view):
    def build():
        need(FEATS / f"mal_{PM}.npz")
        return py("E3_ablation_controls.py", "malaria", "--feats", FEATS / f"mal_{PM}.npz", "--view", view, "--tag", f"{PM}_{view}",
                  "--seeds", E3_SEEDS["malaria"], "--n_null_fixed", sc(200, 20), "--n_null_retrain", sc(30, 4), "--n_jobs", args.n_jobs)
    return build


for view in ("full", "rbc"):
    stage(f"item12_E3_malaria_{view}", "analyze", e3_mal(view), [RES / f"E3_malaria_{PM}_{view}.json"])


def e3_gl():
    need_env("GLIOMA_CSV")
    return py("E3_ablation_controls.py", "glioma", "--csv", E("GLIOMA_CSV"), "--tag", "tcga", "--seeds", E3_SEEDS["glioma"],
              "--n_null_fixed", sc(200, 20), "--n_null_retrain", sc(30, 4), "--n_jobs", args.n_jobs)


stage("item12_E3_glioma", "analyze", e3_gl, [RES / "E3_glioma_tcga.json"])

# ---- E7 / E8 transport and CKA (the original pairs plus the new encoders against dinov2_small)
PAIRS = [("xrv_densenet121", "dinov2_small"), ("dinov2_small", "xrv_densenet121"), ("resnet50", "dinov2_small"), ("dinov2_small", "resnet50"),
         ("rad_dino", "dinov2_small"), ("biomedclip", "dinov2_small")]
for a_, b_ in PAIRS:
    if a_ in TBE and b_ in TBE:
        def b7(a_=a_, b_=b_):
            need(MANIFEST, tbf(a_), tbf(b_))
            return py("E7_eraser_transport.py", "--manifest", MANIFEST, "--featsA", tbf(a_), "--featsB", tbf(b_), "--tag", f"{a_}_to_{b_}")
        stage(f"E7_{a_}_to_{b_}", "analyze", b7, [RES / f"E7_transport_{a_}_to_{b_}.json"])
if not any(a_ in TBE and b_ in TBE for a_, b_ in PAIRS) and len(TBE) >= 2:   # custom encoder lists (and the smoke fixture): pair the first two
    PAIRS = [(TBE[0], TBE[1]), (TBE[1], TBE[0])]
    for a_, b_ in PAIRS:
        def b7x(a_=a_, b_=b_):
            need(MANIFEST, tbf(a_), tbf(b_))
            return py("E7_eraser_transport.py", "--manifest", MANIFEST, "--featsA", tbf(a_), "--featsB", tbf(b_), "--tag", f"{a_}_to_{b_}")
        stage(f"E7_{a_}_to_{b_}", "analyze", b7x, [RES / f"E7_transport_{a_}_to_{b_}.json"])
CKA_PAIRS = PAIRS[0:1] + PAIRS[2:3] + PAIRS[4:] if len(PAIRS) >= 6 else PAIRS[0:1]
for a_, b_ in CKA_PAIRS:
    if a_ in TBE and b_ in TBE:
        def b8(a_=a_, b_=b_):
            need(MANIFEST, tbf(a_), tbf(b_))
            return py("E8_cka_blindness.py", "--manifest", MANIFEST, "--featsA", tbf(a_), "--featsB", tbf(b_), "--tag", f"{a_}_{b_}", "--n", sc(3000, 500))
        stage(f"E8_{a_}_{b_}", "analyze", b8, [RES / f"E8_cka_{a_}_{b_}.json"])


# ---- the 13 additional items
def avail(paths_by_tag):
    return [(t, p) for t, p in paths_by_tag if Path(p).exists()]


TB_TAGPATH = lambda: avail([(e, tbf(e)) for e in TBE])
TBP_TAGPATH = lambda: avail([(e, FEATS / f"tbplanted_{e}.npz") for e in TBE])
MALP_TAGPATH = lambda: avail([(e, FEATS / f"malplanted_{e}.npz") for e in MALPE])
MAL_TAGPATH = lambda: avail([(e, FEATS / f"mal_{e}.npz") for e in MALE])
REPS = sc(50, 3)
NNULL = sc(30, 5)


def b_item01():
    tbp, tb = TBP_TAGPATH(), TB_TAGPATH()
    if not tbp:
        raise Skip("no planted TB features")
    need(MANIFEST)
    return py("item01_loop_vs_oneshot.py", "--planted", *kv(tbp), "--manifest", MANIFEST, "--tb_feats", *kv(tb), "--reps", REPS,
              "--src_reps", sc(20, 3), "--n_null", NNULL, "--n_jobs", args.n_jobs)


stage("item01_loop_vs_oneshot", "analyze", b_item01, [RES / "item01_loop_vs_oneshot.json"])


def b_item02():
    tbp, tb = TBP_TAGPATH(), TB_TAGPATH()
    if not tbp:
        raise Skip("no planted TB features")
    need(MANIFEST)
    c = py("item02_baselines.py", "--planted", *kv(tbp), "--manifest", MANIFEST, "--tb_feats", *kv(tb), "--reps", REPS,
           "--real_reps", sc(20, 3), "--n_jobs", args.n_jobs)
    if E("GLIOMA_CSV"):
        c += ["--glioma_csv", E("GLIOMA_CSV")]
    if (FEATS / f"mal_{PM}.npz").exists():
        c += ["--malaria_feats", FEATS / f"mal_{PM}.npz"]
    return c


stage("item02_baselines", "analyze", b_item02, [RES / "item02_baselines.json"])


def b_item03_tb():
    tbp = TBP_TAGPATH()
    if not tbp:
        raise Skip("no planted TB features")
    c = py("item03_calibration_extended.py", "--tb", *kv(tbp), "--reps", REPS, "--n_null", NNULL, "--n_null_retrain", sc(20, 3), "--n_jobs", args.n_jobs, "--tag", "_tb_glioma")
    if E("GLIOMA_CSV"):
        c += ["--glioma_csv", E("GLIOMA_CSV")]
    rec = RES / "item04_recommended_preproc.json"
    if rec.exists():
        c += ["--preproc_json", rec]
    return c


def b_item03_mal():
    malp = MALP_TAGPATH()
    if not malp:
        raise Skip("no planted malaria features")
    c = py("item03_calibration_extended.py", "--malaria", *kv(malp), "--reps", REPS, "--frac", 0.5, "--n_null", NNULL, "--n_null_retrain", sc(20, 3),
           "--n_jobs", args.n_jobs, "--tag", "_malaria")
    return c


stage("item03_calibration_tb_glioma", "analyze", b_item03_tb, [RES / "item03_calibration_extended_tb_glioma.json"])
stage("item03_calibration_malaria", "analyze", b_item03_mal, [RES / "item03_calibration_extended_malaria.json"])


def b_item04():
    p = FEATS / f"tbplanted_{XR}.npz"
    need(p)
    ref = avail([(e, FEATS / f"tbplanted_{e}.npz") for e in TBE if e != XR])
    c = py("item04_xrv_diagnosis.py", "--feats", p, "--tag", XR, "--reps", sc(40, 3), "--n_jobs", args.n_jobs)
    if ref:
        c += ["--ref", *kv(ref)]
    return c


stage("item04_xrv_diagnosis", "analyze", b_item04, [RES / "item04_xrv_diagnosis.json", RES / "item04_recommended_preproc.json"])


def b_item05():
    tbp = TBP_TAGPATH() + MALP_TAGPATH()
    if not tbp:
        raise Skip("no planted features")
    tags = [f"{t}={p}" for t, p in TBP_TAGPATH()] + [f"mal_{t}={p}" for t, p in MALP_TAGPATH()]
    c = py("item05_false_flag_bound.py", "--planted", *tags, "--markers", "corner", "intensity", "texture", "--reps", sc(200, 6), "--fold_reps", sc(50, 3),
           "--n_jobs", args.n_jobs)
    rec = RES / "item04_recommended_preproc.json"
    if rec.exists():
        c += ["--preproc_json", rec]
    return c


stage("item05_false_flag_bound", "analyze", b_item05, [RES / "item05_false_flag_bound.json"])


def b_item06():
    need(MANIFEST)
    tb = TB_TAGPATH()
    if not tb:
        raise Skip("no TB features")
    return py("item06_natural_controls.py", "--manifest", MANIFEST, "--feats", *kv(tb), "--reps", sc(100, 5), "--pos_reps", sc(20, 3), "--n_jobs", args.n_jobs)


stage("item06_natural_controls", "analyze", b_item06, [RES / "item06_natural_controls.json"])


def b_item08():
    need(MANIFEST)
    plain = avail([(e, tbf(e)) for e in TBE])
    harm = avail([(f"{e}_h", tbf(e, "_harm")) for e in TBE])
    strong = avail([(f"{e}_s", tbf(e, "_strong")) for e in TBE])
    if not plain:
        raise Skip("no TB features")
    pairs = [f"{e}:{e}_h" for e in TBE if (tbf(e, "_harm")).exists()] + [f"{e}:{e}_s" for e in TBE if (tbf(e, "_strong")).exists()]
    return py("item08_tb_format_isolation.py", "--manifest", MANIFEST, "--feats", *kv(plain + harm + strong), "--pairs", *pairs, "--perm", sc(1000, 50), "--boot", sc(500, 50))


stage("item08_tb_format_isolation", "analyze", b_item08, [RES / "item08_tb_format_isolation.json"])


def b_item09():
    need(MANIFEST)
    ft = avail([(e, FEATS / f"ft_{e}.npz") for e in FTE])
    if not ft:
        raise Skip("no fine-tuned features (run the finetune group)")
    fro = [(e, p) for e, p in TB_TAGPATH() if e in dict(ft)]
    c = py("item09_finetuned_audit.py", "--manifest", MANIFEST, "--finetuned", *kv(ft), "--audit_reps", sc(10, 2), "--n_null", sc(100, 10), "--inlp_rounds", sc(50, 5))
    if fro:
        c += ["--frozen", *kv(fro)]
    return c


stage("item09_finetuned_audit", "analyze", b_item09, [RES / "item09_finetuned_audit.json"])


def b_item10():
    need_env("GLIOMA_CSV")
    c = py("item10_glioma_external.py", "--tcga_csv", E("GLIOMA_CSV"), "--splits", sc(20, 3))
    if E("CGGA_CSV"):
        c += ["--cgga_csv", E("CGGA_CSV")]
    return c


stage("item10_glioma_external", "analyze", b_item10, [RES / "item10_glioma_external.json"])


def mk_item11(enc):
    def build():
        need(FEATS / f"mal_{enc}.npz")
        return py("item11_malaria_cleanup.py", "--feats", FEATS / f"mal_{enc}.npz", "--tag", enc, "--B", sc(1000, 100), "--fold_seeds", sc(3, 2))
    return build


for enc in MALE:
    stage(f"item11_malaria_cleanup_{enc}", "analyze", mk_item11(enc), [RES / f"item11_malaria_cleanup_{enc}.json"])


def b_item11m():
    need_env("MALARIA")
    return py("item11_mask_validation.py", "--root", E("MALARIA"), "--n", sc(600, 40), "--montage", sc(24, 8))


stage("item11_mask_validation", "analyze", b_item11m, [RES / "item11_mask_validation.json"])

# ---- report
stage("report_make_report", "report", lambda: py("make_report.py"), [])
stage("item13_multiplicity", "report", lambda: py("item13_multiplicity.py"), [RES / "item13_multiplicity.json"])


# ----------------------------------------------------------------------------- engine
def load_status():
    try:
        return json.loads(STATUS_F.read_text())
    except Exception:
        return {}


def save_status(st):
    tmp = STATUS_F.with_suffix(".tmp")
    tmp.write_text(json.dumps(st, indent=2))
    tmp.replace(STATUS_F)


def selected(s):
    groups = set(args.groups.split(","))
    if s["group"] not in groups:
        return False
    if args.only and not any(w in s["name"] for w in args.only.split(",") if w):
        return False
    if args.skip and any(w in s["name"] for w in args.skip.split(",") if w):
        return False
    return True


def finished(s, st):
    rec = st.get(s["name"])
    return bool(rec and rec.get("status") == "ok" and all(o.exists() for o in s["outputs"]))


def main():
    st = load_status()
    if args.list:
        print(f"{'stage':44s} {'group':9s} {'gpu':4s} status")
        for s in STAGES:
            print(f"{s['name']:44s} {s['group']:9s} {'yes' if s['gpu'] else '':4s} {st.get(s['name'], {}).get('status', '-')}"
                  f"{' (done)' if finished(s, st) else ''}")
        return 0
    todo = [s for s in STAGES if selected(s)]
    print(f"{len(todo)} stages selected of {len(STAGES)}; features {FEATS}; results {RES}; smoke={S}; dry_run={args.dry}")
    summary = []
    for s in todo:
        name = s["name"]
        if finished(s, st) and not args.force:
            summary.append((name, "done earlier", 0.0))
            print(f"[skip ] {name}: finished earlier")
            continue
        try:
            cmd = s["build"]()
        except Skip as e:
            summary.append((name, f"skipped ({e})", 0.0))
            print(f"[skip ] {name}: {e}")
            if not args.dry:
                st[name] = {"status": "skipped", "reason": str(e), "time": time.time()}
                save_status(st)
            continue
        text = " ".join(str(c) for c in cmd)
        if args.dry:
            print(f"[dry  ] {name}\n        {text}")
            summary.append((name, "dry-run", 0.0))
            continue
        print(f"[run  ] {name}\n        {text}", flush=True)
        t0 = time.time()
        with open(RES / "logs" / f"{name}.log", "w") as lf:
            lf.write(text + "\n\n")
            lf.flush()
            rc = subprocess.call(cmd, cwd=str(SCRIPTS), stdout=lf, stderr=subprocess.STDOUT)
        dt = time.time() - t0
        missing = [o.name for o in s["outputs"] if not o.exists()]
        ok = rc == 0 and not missing
        status = "ok" if ok else "failed"
        reason = "" if ok else (f"exit code {rc}" if rc else f"outputs not written: {missing}")
        st[name] = {"status": status, "seconds": round(dt, 1), "reason": reason, "time": time.time()}
        save_status(st)
        summary.append((name, status + (f" ({reason})" if reason else ""), dt))
        print(f"[{status:5s}] {name} in {dt:.0f}s" + (f"  -> see {RES / 'logs' / (name + '.log')}" if not ok else ""), flush=True)
    print("\n==== summary")
    for n, r, dt in summary:
        print(f"  {n:44s} {r:70s} {dt:8.0f}s")
    bad = [n for n, r, _ in summary if r.startswith("failed")]
    print(f"\n{len(bad)} failed" + (": " + ", ".join(bad) if bad else ""))
    return 1 if bad else 0


if __name__ == "__main__":
    sys.exit(main())
