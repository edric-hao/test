#!/usr/bin/env bash
# Moves scripts that are NOT part of the final package into obsolete_scripts/ (nothing is deleted).
# These are the old builders (superseded by the fixed versions in the package's data_construction/) and old run scripts.
set -u
cd "$(dirname "$0")"
mkdir -p obsolete_scripts
for f in 01_build_dataset1_pft.py 01_build_dataset2_virulence.py 01_build_dataset3_captp.py utils_dataset.py \
         01_prep_dataset1_pft_proxy.py 01_prep_dataset4_signal.py fill_missing_embeddings.py fix_before_rerun.sh \
         migrate_steering_field.py run_esm2_large.sh run_esm2_small.sh run_overnight_d4.sh run_overnight_t4.sh run_probing.sh; do
  if [ -f scripts/$f ]; then mv scripts/$f obsolete_scripts/ && echo "moved scripts/$f"; fi
done
echo "--- scripts/ now:"; ls scripts
