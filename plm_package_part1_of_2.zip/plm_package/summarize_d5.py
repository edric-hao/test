"""Run from the project root: python summarize_d5.py   (prints what survived the folding gates)"""
import json
import pandas as pd
f = pd.read_csv("data/raw/dataset5/folded.csv")
s = pd.read_csv("data/splits/dataset5/stress_test.csv")
print("folded:", len(f), "designs from", f.parent_pdb.nunique(), "parents")
print("pLDDT  : min %.1f  median %.1f  max %.1f" % (f.plddt.min(), f.plddt.median(), f.plddt.max()))
print("TM     : min %.2f  median %.2f  max %.2f" % (f.tm_score.min(), f.tm_score.median(), f.tm_score.max()))
print("passed gates (pLDDT>=70 and TM>=0.5):", int(((f.plddt >= 70) & (f.tm_score >= 0.5)).sum()), "of", len(f))
print("\nper parent  folded -> kept   median pLDDT   median TM")
g = f.groupby("parent_pdb")
kept = s.parent_pdb.value_counts()
for p, d in g:
    print(f"{p:6s} {len(d):4d} -> {int(kept.get(p, 0)):3d}     {d.plddt.median():6.1f}      {d.tm_score.median():.2f}")
print("\nkept designs: identity to D1  min %.2f  median %.2f  max %.2f" % (s.max_identity_d1.min(), s.max_identity_d1.median(), s.max_identity_d1.max()))
print("kept designs: identity to parent median %.2f" % s.identity_to_parent.median())
print(json.dumps(json.load(open("data/raw/dataset5/build_report.json"))["per_parent"], indent=0))
