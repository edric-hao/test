"""Patch scripts/01_build_dataset5_proteinmpnn.py in place (idempotent):
  --no-novelty-filter     step 3 keeps ALL designs and records toxin_hit / max_identity_d1 (no design is dropped)
  --fold-per-parent N     step 4 folds only the N designs per parent with the LOWEST identity to D1
Usage: python apply_d5_patch.py scripts/01_build_dataset5_proteinmpnn.py"""
import sys
p = sys.argv[1]
s = open(p).read()
if "--no-novelty-filter" in s:
    print("already patched"); sys.exit(0)

def rep(old, new):
    global s
    assert s.count(old) == 1, f"anchor not found exactly once: {old[:60]!r}"
    s = s.replace(old, new)

rep('    p.add_argument("--min-tm", type=float, default=0.5)\n',
    '    p.add_argument("--no-novelty-filter", action="store_true",\n'
    '                   help="step 3: keep every design; toxin_hit and max_identity_d1 are annotations, not filters")\n'
    '    p.add_argument("--fold-per-parent", type=int, default=None,\n'
    '                   help="step 4: fold only the N designs per parent with the lowest max_identity_d1")\n'
    '    p.add_argument("--min-tm", type=float, default=0.5)\n')
rep('    keep = designs[(~designs.toxin_hit) & (designs.max_identity_d1 < a.max_identity)].copy()\n',
    '    if a.no_novelty_filter:\n'
    '        keep = designs.copy()\n'
    '    else:\n'
    '        keep = designs[(~designs.toxin_hit) & (designs.max_identity_d1 < a.max_identity)].copy()\n')
rep('    path = os.path.join(a.output_dir, "folded.csv")\n',
    '    path = os.path.join(a.output_dir, "folded.csv")\n'
    '    if a.fold_per_parent:\n'
    '        novel = (novel.sort_values(["parent_pdb", "max_identity_d1", "design_id"])\n'
    '                 .groupby("parent_pdb").head(a.fold_per_parent).reset_index(drop=True))\n'
    '        print(f"[step4] folding {len(novel)} designs ({a.fold_per_parent} lowest-identity per parent)")\n')
open(p, "w").write(s)
print("patched")
