#!/usr/bin/env bash
# ESM-2 3B: pretrained embeddings + pretrained probes ONLY (forward passes; no training). Run from the project root
# after the ESMFold job has finished (GPU must be free):   bash run_3b_pretrained.sh 2>&1 | tee logs/3b.log
# Resumable: a dataset whose probe_results.json already exists is skipped.
set -uo pipefail
cd "$(dirname "$0")"
unset HF_HOME            # reuse the 3B weights already in ~/.cache/huggingface (no second download)
mkdir -p logs
echo "GPU:"; nvidia-smi --query-gpu=memory.used,memory.total --format=csv,noheader
echo "RAM:"; free -g | head -2
for D in pft virulence peptide_tox signal_peptide; do
  E=results/embeddings/pretrained/esm2_3b/$D
  P=results/probes/pretrained/esm2_3b/$D
  if [ -f "$P/probe_results.json" ]; then echo "[skip] $D (probes exist)"; continue; fi
  echo "=== $(date +%H:%M:%S) $D : extract ==="
  START=$(date +%s)
  python scripts/02_extract_embeddings.py --model-id facebook/esm2_t36_3B_UR50D --dataset $D --output-dir $E --batch-size 2 || { echo "!! extraction failed for $D"; continue; }
  echo "extract seconds for $D: $(( $(date +%s) - START ))"
  echo "=== $(date +%H:%M:%S) $D : probes ==="
  START=$(date +%s)
  python scripts/03_linear_probe.py --embeddings-dir $E --output-dir $P --dataset $D --save-directions || echo "!! probes failed for $D"
  echo "probe seconds for $D: $(( $(date +%s) - START ))"
done
echo "=== done $(date +%H:%M:%S) ==="
