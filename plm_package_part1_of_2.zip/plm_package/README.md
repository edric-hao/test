# plm_harm — probing "harm" in ESM-2 representations (corrected, re-runnable package)

Four binary tasks on **frozen, hash-verified splits** (`data/splits`, `data/MANIFEST.sha256`):

| id | folder | task | negatives |
|----|--------|------|-----------|
| D1 | `pft` | pore-forming toxin (TCDB 1.C) | UniProt transmembrane, matched on length/TM/hydrophobicity |
| D2 | `virulence` | virulence factor (KW-0843) | housekeeping proteins (ribosomal / DNA-repair) from the same taxa |
| D3 | `peptide_tox` | peptide toxicity (official CAPTP split) | CAPTP non-toxic peptides |
| D4 | `signal_peptide` | signal peptide — **non-harm control** | no signal peptide |
| D5 | (optional, not shipped) | ProteinMPNN "stealth toxin" stress test, one-class | – |

Models: ESM-2 8M / 35M / 150M / 650M (3B only with `SKIP_3B=0` / `--include-3b`).

## Run

```bash
pip install -r requirements.txt
bash scripts/install_biotools.sh            # mmseqs2 + BLAST+ (required)
python tests/torch_smoke.py                 # FIRST, on the GPU box: never executed by the package author (no torch there)
python -m unittest discover -s tests        # 26 CPU unit tests
python tests/synthetic_e2e.py               # wiring test of every non-torch stage on fabricated embeddings
bash scripts/run_full_pipeline.sh           # resumable; refuses results made from other data (manifest stamp)
bash scripts/run_multiseed.sh               # seeds 1-4 for 8M/35M -> scripts/14_seed_variance.py
# optional D5:  bash scripts/setup_dataset5.sh; python scripts/01_build_dataset5_proteinmpnn.py; python scripts/eval_dataset5.py
```

## Layout
```
data/splits/<ds>/{train,val,test}.csv   FROZEN (id, sequence, label [, in_test2 for D3 test])  — do not edit
data/MANIFEST.sha256                    sha256 of the 12 split files (scripts/verify_data.py)
data/provenance/                        length-policy report, k-mer homology audit, builder side tables (not used by code)
data_construction/                      builders for D1–D3 (REFERENCE ONLY; need network; not re-run by the pipeline)
scripts/                                pipeline (numbered), shared libs (plm_common, embed_utils, d5_helpers), verify_*.py
tests/                                  unit tests, synthetic E2E, torch smoke test
```

## What each stage does (and how it avoids contamination)
* **Selection protocol.** Probe layer = argmax **validation** AUROC (`plm_common.best_layer_by_val`; raises if val AUROC is missing). Fine-tuning early-stops/checkpoints on **val** AUROC; test is predicted once. Probe directions, thresholds and scalers are fit on **train** only.
* **02/04/13/extract_finetuned** all use `embed_utils.extract_representations` — one definition of CLS (token 0) and mean pooling (residue tokens only; `<cls>`, `<eos>`, padding excluded), identical for pretrained and fine-tuned models. All sequences ≤1022 so truncation never occurs; windowing exists only for external sequences (D5).
* **03** MM and LR probe at every layer, CLS and mean pooling. Layer 0 `<cls>` is a constant vector in ESM-2 → flagged `mm_degenerate`, AUROC 0.5, never selected.
* **05** (a) classifier-head ablation of the final-layer MM direction; (b) per-layer **linear-erasure** test (erase direction → refit LR → AUROC drop) against random-direction and label-shuffled-direction nulls. (An MM probe cannot be refit after erasing its own direction — the old design was vacuous.)
* **06** cross-task transfer: direction of task *i* scored on task *j* test embeddings from the **same backbone** (pretrained: one shared model; fine-tuned: backbone *i* applied to every task via `13`). Test rows of *j* homologous to train of *i* (from `12`) are excluded. Cosine geometry only in the shared pretrained space, with chance SD 1/√D.
* **08** PLM vs BLAST on D3: signed nearest-neighbour BLAST score (best hit by bit score; identity over the whole query), per identity bin; BLAST annotations live in `results/d3_blast/`, never in the splits.
* **09** "steering" = linear read-out coupling: a direction is added to the CLS state *before the final LayerNorm* and the change in other probes' projections is measured against random and label-shuffled directions. Because nothing downstream is computed, this is a **geometric** statement (gamma-weighted cosine), not behavioural steering; each record stores the cosine so it can be compared to the geometric prediction.
* **07** scaling: Spearman ρ(log-params, AUROC) is **descriptive** (n≤4 models ⇒ min two-sided p = 0.083); compare size differences with the seed SD from `14`.
* **11** shortcut baselines (length, GBM-length, composition, first-30, dipeptide, composition residualised on length) — trained on train, C chosen on val, evaluated once on test. Report next to every probe number.
* **12** homology audit (mmseqs2 30 % id / 50 % cov; k-mer fallback): never edits splits; writes per-pair exclusions consumed by `06`.
* **verify_data.py / verify_consistency.py** fail the run if any result derives from other split files.

## Known limitations (state these in the paper)
1. **D2 is a functional-category contrast** (virulence vs ribosomal/DNA-repair housekeeping): high AUROC does not show a "harm" signal; see `11` baselines.
2. **D3 is homologous by construction** (official CAPTP split; at the k-mer criterion 44 % of test rows resemble a train/val row). Report D3 stratified by BLAST identity bin (`08`), not only overall. D3 `val` is a random 10 % of train, so val-based layer choice is optimistic there.
3. **Small test sets** (D1 n=99, D2 n=274, D4 n=275): report the bootstrap CIs from `10`; CIs treat test sequences as independent.
4. **Single seed** for 150M/650M; seed variance only for 8M/35M. ESM-2 pretraining (UniRef50) may contain test sequences — unavoidable, mention it.
5. **D5** is one-class: report detection rate only next to D1 TPR/FPR, shuffled-sequence control and AUROC vs D1 negatives; CIs are parent-clustered and wide when there are few parent structures. The D5 builder needs ProteinMPNN, ESMFold, BLAST+, network — it was written and unit-tested only for its pure helpers.
6. Dataset builders in `data_construction/` fetch live UniProt/TCDB and will not reproduce byte-identical data; the frozen splits (not the builders) are the experimental input.
7. In the authoring environment torch/transformers/mmseqs/BLAST were unavailable: those stages were reviewed statically and covered by `tests/torch_smoke.py`, which **you must run once** before trusting a full run.
