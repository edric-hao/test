#!/usr/bin/env bash
# Adds ESM-2 3B as a clearly separate, disclosed analysis. Writes to *_with3b directories only: the main
# (no-3B) bootstrap/scaling outputs are never overwritten. CPU only. Run from the project root:
#   bash include_3b.sh
set -uo pipefail
cd "$(dirname "$0")"
echo "=== 1. which 3B results exist (per dataset) ==="
for D in pft virulence peptide_tox signal_peptide; do
  F=results/esm2_3b/$D
  echo "$D  test_results: $(stat -c %y $F/test_results.json 2>/dev/null | cut -c1-16)  provenance: $(ls $F/provenance.json 2>/dev/null | wc -l)  embeddings: $(ls $F/embeddings 2>/dev/null | wc -l)  pretrained-probes: $(ls results/probes/pretrained/esm2_3b/$D/probe_results.json 2>/dev/null | wc -l)"
done
echo "=== 2. bootstrap CIs and scaling WITH 3B (separate directories) ==="
for P in cls mean; do
  python scripts/10_bootstrap_ci.py --pooling $P --results-root results --output-dir results/bootstrap_ci_with3b --include-3b || echo "!! 10 $P failed"
  python scripts/07_scaling_curve.py --pooling $P --results-root results --output-dir results/scaling_curve_with3b --include-3b || echo "!! 07 $P failed"
done
echo "=== 3. pack WITH 3B ==="
INC3B=1 ZIPNAME=teammate_pack_v2_with3b.zip bash finalize_cpu.sh 2>&1 | tail -8
