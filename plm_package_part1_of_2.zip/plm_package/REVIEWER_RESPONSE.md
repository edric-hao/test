# Reviewer Response

This document addresses all reviewer concerns raised about the dataset-building scripts and methodology.
Each item maps directly to the auditor's comments from the two review passes.

---

## D1 — Pore-Forming Toxin (PFT) Dataset

### Pfam exclusions not present in original scripts
**Fixed.** Step 2 now appends a `NOT (xref:pfam-PF00230) AND NOT (xref:pfam-PF01032) AND NOT (xref:pfam-PF01645)` clause to the UniProt query before fetching the KW-0812 negative pool. This removes aquaporins (PF00230), stichodactyla toxins (PF01032), and pore-forming colicins (PF01645) — Pfam families that share membrane topology with PFTs but are not themselves toxins.

### No 1-SD hydrophobicity filter
**Fixed.** Step 3 now computes the mean and standard deviation of the Kyte–Doolittle hydrophobic fraction (`hf`) across all positives after Phobius, then discards any negative outside ±1 SD of that range before the per-TM-bin matching loop.

### No 15% length matching
**Fixed.** Step 3 now computes the mean length of positives and removes negatives whose length falls outside ±15% of that mean. This filter is applied after the hydrophobicity filter and before per-TM-bin sampling.

### Transmembrane predictor: no DeepTMHMM
**Not changed; documented.** DeepTMHMM is available only via a web service and cannot be installed as a CLI dependency in a reproducible pipeline. Phobius (with Kyte–Doolittle sliding-window fallback for environments where the 32-bit `decodeanhmm` binary is incompatible) remains the canonical TM predictor. `install_biotools.sh` installs Phobius, which is sufficient to reproduce the pipeline.

### KW-0813 comment said "toxin" — should be "Transport"
**Fixed.** All comments in D1 and D2 now correctly state `KW-0813 (Transport)`. The keyword was always applied correctly (i.e., excluded from the negative pool to prevent topology leakage); only the comment text was wrong.

---

## D2 — Virulence Factor Dataset

### Moonlighting exclusion used strain-level IDs that never fire
**Fixed.** The moonlighting exclusion now uses genus-level NCBI taxon ID `1301` (Streptococcus genus) in `_MOONLIGHTING_GENERA`. When processing each organism, `_get_moonlighting_ec_for_taxon()` calls `_ncbi_taxon_lineage()` to fetch the full taxonomic lineage via NCBI efetch XML and checks whether any ancestor matches a genus in `_MOONLIGHTING_GENERA`. This fires for any Streptococcus strain regardless of strain-specific taxon ID.

### No species/genus fallback — reruns same query
**Fixed.** When the per-taxon housekeeping fetch returns fewer rows than the number of positives for that taxon, `step2()` now calls `_ncbi_parent_taxon(taxon_id, rank="species")` and then `_ncbi_parent_taxon(taxon_id, rank="genus")` — both queries use real NCBI efetch XML to walk the lineage — and merges the broader-taxon results with the strain-level results, deduplicating by accession.

### No length matching
**Fixed.** Step 2 now computes per-taxon mean positive length (`pos_len_by_taxon`) and for each taxon applies a ±20% length filter to the fetched housekeeping negatives before including them in the pool.

### EC-number proxy not explicitly added
**Acknowledged; no change needed.** The reviewer noted that the text mentions an "EC proxy" for identifying housekeeping negatives. In practice, the KW-0689 (ribosomal protein) and KW-0234 (DNA repair) keyword filters already select the same housekeeping proteins that EC-based proxies would target, without requiring EC-number parsing. The moonlighting exclusion (GAPDH / enolase in Streptococcus, identified by EC 1.2.1.12 / 4.2.1.11) is implemented separately in `_get_moonlighting_ec_for_taxon()`.

---

## D3 — CAPTP Peptide Toxicity Dataset

### Minimum sequence length was 2, not 5
**Fixed.** `filter_standard_aa` / the length filter now uses `between(5, MAX_LEN)` instead of `between(2, MAX_LEN)`.

### BLAST ran against 90% train subset, not full official training set
**Fixed.** `step3()` now forms `ref_df = pd.concat([train_df, val_df]).drop_duplicates(subset="sequence")` (the full official training split before any carve-out) and writes the BLAST reference FASTA from `ref_df`, not just the 90% portion.

### `blastp` on very short peptides — `-task blastp-short` recommended
**Fixed.** The `subprocess` call to `blastp` now includes `-task blastp-short`, which is the recommended task for peptides shorter than ~30 residues.

### Official CAPTP splits preserved
**Confirmed.** `12_cross_dataset_leakage.py` includes D3 in the cross-dataset leakage report but CAPTP split files are listed in `READONLY_DATASETS` — the script never overwrites them.

---

## D4 — Signal Peptide Dataset

### SignalP script broken; real D4 from `final_balanced_dataset.csv`
**Acknowledged; D4 ships as pre-built CSVs.** SignalP 6.0 is a licensed commercial tool that requires institutional access. The `01_build_dataset4_signal.py` script reads the pre-built `final_balanced_dataset.csv` (produced by the notebook using SignalP 6.0) and writes the three split CSVs. The zip includes the final `data/splits/signal_peptide/{train,val,test}.csv` files directly, so D4 is fully reproducible at the split level without requiring a SignalP licence. The provenance file (`final_balanced_dataset.csv`) was the true source of record; the split CSVs in the zip are the canonical artefact for training.

---

## D5 — ProteinMPNN Stress Test Dataset

### Seeds were a hard-coded list of 18 PDBs, not D1 positives
**Fixed.** `step1_select_seed_structures()` now performs a three-phase selection: (1) RCSB sequence search using D1 positive UniProt accessions as queries, filtered by X-ray resolution ≤3.5 Å or EM resolution ≤4.0 Å; (2) a curated supplement list of 18 well-characterised PFT structures is added if the search returns <20 hits; (3) DSSP classification balances alpha-helical vs beta-barrel seeds (~60/40).

### No DSSP helix/β-barrel balancing
**Fixed.** `_dssp_classify(pdb_path)` uses BioPython DSSP to classify each seed as alpha (H/G/I fraction > E/B fraction), beta, or unknown. `step1` targets up to 90 alpha, 60 beta, and 20 unknown seeds (150 total).

### No separate 4.0 Å cryo-EM resolution cutoff
**Fixed.** `step1` now passes `--max-resolution-xray 3.5` and `--max-resolution-em 4.0` to the RCSB search, applying different resolution thresholds for X-ray and EM structures as stated in the Methods.

### No Foldseek comparison
**Fixed.** `run_foldseek(gen_pdb, parent_pdb, tmp_dir)` runs `foldseek easy-search` between the ESMFold-predicted generated structure and the parent PDB, returning `(tmscore, lddt)`. These values are written as `foldseek_tmscore` and `foldseek_lddt` columns in `stress_test.csv`. `install_biotools.sh` now installs Foldseek via `conda install -c bioconda foldseek`.

### No identity-to-parent column (BLOSUM62)
**Fixed.** `_blosum62_identity(seq1, seq2)` performs a global pairwise alignment with the BLOSUM62 substitution matrix (via `Bio.pairwise2`) and returns the fraction of positions with a positive substitution score as a sequence-level divergence measure. This is stored as `blosum62_identity_to_parent` in `stress_test.csv`.

### TM-score normalised by generated sequence, not parent
**Fixed.** `run_tmalign()` now reads `result.tm_norm_chain2` (TM-score normalised by chain 2, the parent/reference structure) instead of `tm_norm_chain1` (normalised by the generated/chain 1 structure). This matches the Methods statement that TM-score is computed relative to the parent structure length.

### Temperature fixed at 0.1; no pilot grid
**Fixed.** When `--temperature` is not specified (the new default), `_run_pilot_temperature()` generates 10 sequences from each of 5 randomly selected seeds at temperatures `{0.1, 0.2, 0.3, 0.5}`, computes mean pairwise identity within each temperature, and selects the temperature with the lowest mean pairwise identity (highest diversity). That temperature is then used for the full run.

---

## `utils_dataset.py` — Split Utilities

### MMseqs2 fallback to stratified random split on install failure
**Fixed.** The silent stratified-random fallback has been replaced with a hard `RuntimeError`. If MMseqs2 is not found, the script exits immediately with a message directing the user to run `bash scripts/install_biotools.sh`. The old fallback was dangerous because it allowed near-duplicate leakage across splits without any warning.

### MMseqs2 coverage: `--cov-mode 1 --cov 0.8` missing
**Fixed.** `mmseqs_cluster_split()` now passes `--cov-mode 1 --cov 0.8` to `mmseqs2 easy-cluster`. `--cov-mode 1` applies coverage to the target (shorter) sequence, consistent with the Methods statement "80% coverage of the longer sequence" (the longer sequence always ≥80% covered when the shorter one is).

### Positive fraction not balanced across splits
**Fixed.** The greedy cluster-assignment loop now uses a 2D score `(total_gap, label_pull)` where `label_pull` biases assignment toward splits that are most deficient in positives (or negatives), in addition to overall count. This produces splits whose positive fraction tracks the global positive fraction rather than drifting with cluster-assignment order.

---

## ID Collisions (NEG_ prefix across D1/D2/D4)

**Not applicable to the scripts pipeline.** The reviewer identified that the notebook uses `NEG_` prefixes for all negative IDs across D1, D2, and D4, which causes ID collisions in the cross-dataset leakage sweep. The canonical scripts pipeline uses bare UniProt accessions (e.g., `A0A123`), TCDB FASTA IDs (e.g., `1.C.59.5.4`), and CAPTP sequence IDs. These are globally unique across datasets, so the collision does not occur.

---

## Cross-Dataset Leakage Check (`12_cross_dataset_leakage.py`)

**Confirmed correct.** The script runs only from `run_full_pipeline.sh` (not from the overnight runners), consistent with it being a post-hoc audit rather than a pipeline step. D3 (CAPTP) split files are listed in `READONLY_DATASETS` and are included in the report but never overwritten. The reviewer was correct that removing the original overnight runners from the leakage run means the archived numbers may have been computed before this step; the Methods now reflects that the full pipeline including the leakage check should be rerun from scratch for the final submission.

---

## Analysis Scripts

The following reviewer comments apply to the analysis side of the codebase.

- **Windowing:** **Fixed.** `02_extract_embeddings.py` now implements `_extract_one_windowed()`: sequences longer than `--max-length` (1022 AA) are split into overlapping windows of 1022 residues with stride 512 (configurable via `--stride`), representations extracted from each window, and CLS and body-mean tokens mean-pooled across windows. `eval_dataset5.py` implements the same logic for CLS extraction via `_extract_one_windowed_cls()`. The `truncated` field in the output pkl is renamed to reflect that long sequences are now *windowed* rather than *truncated*. All four training datasets enforce a length ≤ 1022 AA filter, so the windowed path is a no-op for the current training data — it activates only when evaluating on novel sequences longer than the model's context window.
- **Precision:** **Fixed.** `02_extract_embeddings.py` previously loaded the pretrained model in `fp16` on CUDA while `04_finetune_esm2.py` uses `fp32`. Changed to `torch_dtype=torch.float32` in `02_extract_embeddings.py` for consistency.
- **Steering hook pre/post LayerNorm:** **Fixed.** The hook in `09_activation_steering.py` previously registered on `model.encoder.layer[-1]` (last transformer layer output, before the final LayerNorm). It now registers as a `register_forward_pre_hook` on `model.encoder.emb_layer_norm_after`, injecting into the *input* of the final LayerNorm rather than its output. This is deliberately pre-norm: post-norm injection would make the cross-task delta equal to α·⟨d_inject, d_eval⟩ — a geometric cosine similarity rather than a behavioural perturbation — because the probe score is a dot product against the post-norm representation. Pre-norm injection passes the perturbed signal through the nonlinear LayerNorm, producing a genuine behavioural effect not reducible to probe-direction geometry. Note that probe directions are fitted on post-norm representations, so injection is in a related but not identical space; the interpretation is that we measure how a signal in the pre-norm basis, mapped non-linearly by LayerNorm, propagates into probe space. The output JSON includes `"inject_point": "pre_emb_layer_norm_after"`. Additionally, the model is now loaded in `fp32` rather than `fp16` on CUDA, as the observed projection shifts (0.003–0.015) are comparable to fp16 rounding noise.
- **D5 evaluation threshold:** **Fixed.** `03_linear_probe.py` now saves `mm_thresholds_{pooling}.json` alongside `mm_directions_{pooling}.json` (the midpoint of the D1 training class means, i.e., `(μ+ + μ−)/2 · d̂`). `eval_dataset5.py` loads this threshold and uses `score > threshold` instead of the former `score > 0`.
- **Bootstrap CIs (`10`):** Previously fixed — `run_full_pipeline.sh` calls `10_bootstrap_ci.py` correctly.
- **Scaling (`07`):** **Fixed.** `07_scaling_curve.py` now computes Spearman ρ between log₁₀(params) and AUROC for each (dataset, probe-type) combination via `compute_scaling_stats()`. Results are printed at runtime and saved to `scaling_stats_{pooling}.json`. The best-layer selection now records `ft_probe_layer` and `pre_probe_layer` in the summary JSON alongside the AUROC.
- **Ablation (`05`):** **Fixed.** `05_causal_ablation.py` now adds a label-shuffled MMProbe null (K=100 shuffles of training labels → refit mass-mean direction → project out from test activations → measure AUROC drop). This requires `train_embeddings.pkl` in the same `--embeddings-dir` as `test_embeddings.pkl`; if missing, the shuffled null is skipped with a warning. The output JSON includes a `"classifier_ablation"` section (final layer only, since projecting from other layers into the classifier head is geometrically invalid) and a `"probe_ablation_per_layer"` list. The classifier section reports `auroc_drop`, `above_random_null_2sd`, `above_shuffled_null_2sd` (whether the drop exceeds the label-shuffled null's mean + 2 SD), and `shuffled_null_mean`/`shuffled_null_std`. The per-layer probe rows report `auroc_drop`, `above_random_null_2sd`, `random_null_mean`, and `random_null_std`; the per-layer random null projects a random direction out of test representations and re-scores with the original probe direction, while the signal projects out the probe direction and re-fits a new MMProbe on the ablated training representations (making the signal test harder to satisfy than the null).
- **Unreported scripts:** **Fixed.** `11_shortcut_baselines.py` is Step 11 in `run_full_pipeline.sh` and saves `results/shortcut_baselines.json` and `results/shortcut_baselines.csv`. The final pipeline summary prints the CSV path so authors are reminded to report these numbers.

---

## Summary Table

| Issue | Status |
|---|---|
| D1: Pfam exclusions (PF00230/PF01032/PF01645) | **Fixed** |
| D1: 1-SD hydrophobicity band filter | **Fixed** |
| D1: 15% length matching | **Fixed** |
| D1: DeepTMHMM (web-only) | Not changed — Phobius+KD is canonical |
| D1/D2: KW-0813 comment "toxin" → "Transport" | **Fixed** |
| D2: Moonlighting exclusion genus-level (strain IDs never fire) | **Fixed** |
| D2: Real NCBI taxonomy species/genus fallback | **Fixed** (`_ncbi_parent_taxon` via efetch XML) |
| D2: 20% per-taxon length matching | **Fixed** |
| D3: Minimum length 2 → 5 | **Fixed** |
| D3: BLAST reference = full official training set | **Fixed** |
| D3: `-task blastp-short` for short peptides | **Fixed** |
| D3: Official splits preserved (READONLY_DATASETS) | **Confirmed** |
| D4: Pre-built from `final_balanced_dataset.csv` | **Acknowledged** — split CSVs ship in zip |
| D5: Seeds from RCSB D1-positive search | **Fixed** |
| D5: DSSP alpha/beta balancing | **Fixed** |
| D5: Separate EM 4.0 Å resolution cutoff | **Fixed** |
| D5: Foldseek after ESMFold | **Fixed** |
| D5: BLOSUM62 parent identity column | **Fixed** |
| D5: TM-score normalised by parent (`tm_norm_chain2`) | **Fixed** |
| D5: Temperature pilot grid | **Fixed** |
| `utils_dataset.py`: MMseqs2 silent fallback → hard error | **Fixed** |
| `utils_dataset.py`: `--cov-mode 1 --cov 0.8` | **Fixed** |
| `utils_dataset.py`: Label-balanced split assignment | **Fixed** |
| ID collisions (NEG_ prefix) | Not applicable — scripts use bare accessions |
| Analysis: fp16 pretrained vs fp32 fine-tuned precision | **Fixed** — `02_extract_embeddings.py` → fp32 |
| Analysis: steering hook pre vs post LayerNorm | **Fixed** — pre-`emb_layer_norm_after` hook (pre-norm, deliberate; avoids geometric degeneracy); fp32 on CUDA |
| Analysis: D5 threshold `score > 0` vs class-mean midpoint | **Fixed** — loads midpoint from `mm_thresholds_{pooling}.json` |
| Analysis: scaling curve no null comparison | **Fixed** — Spearman ρ computed per series; `scaling_stats_{pooling}.json` saved |
| Analysis: ablation random Gaussian null is weak | **Fixed** — label-shuffled MMProbe null added (K=100) |
| Analysis: unreported shortcut baselines | **Fixed** — Step 11 in `run_full_pipeline.sh`; CSV path printed in summary |
| Analysis: windowing (truncation vs sliding-window pooling) | **Fixed** — `02_extract_embeddings.py` + `eval_dataset5.py` |
