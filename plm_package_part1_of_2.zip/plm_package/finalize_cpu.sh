#!/usr/bin/env bash
# CPU-only finishing steps; safe to run while ESMFold uses the GPU. Run from the project root:
#   bash finalize_cpu.sh
# ESM-2 3B files are left OUT of the zip unless INC3B=1 (3B is excluded from the paper by default).
# Does NOT delete or move anything. Writes: results/seed_variance.json (+ scaling plots), teammate_pack_v2.zip
set -uo pipefail
cd "$(dirname "$0")"
echo "=== 1. seed variance (seed 42 + seeds 1-4) ==="
python scripts/14_seed_variance.py --models esm2_8m esm2_35m || echo "!! 14 failed"
echo "=== 2. scaling curves (error bars from seed variance) ==="
for P in cls mean; do
  python scripts/07_scaling_curve.py --pooling $P --results-root results --output-dir results/scaling_curve || echo "!! 07 $P failed"
done
echo "=== 3. consistency check of all results ==="
python scripts/verify_consistency.py --results-root results || echo "!! consistency check reported problems"
echo "=== 4. scripts in scripts/ that are not part of the final package (REVIEW, nothing is moved) ==="
KEEP="00_harmonize_length_policy.py 01_build_dataset5_proteinmpnn.py 02_extract_embeddings.py 03_linear_probe.py 04_finetune_esm2.py 05_causal_ablation.py 06_cross_task_analysis.py 07_scaling_curve.py 08_blast_vs_plm.py 09_activation_steering.py 10_bootstrap_ci.py 11_shortcut_baselines.py 12_cross_dataset_leakage.py 13_cross_task_ft_extract.py 13_leakage_sensitivity.py 14_seed_variance.py annotate_d3_blast.py d5_helpers.py embed_utils.py eval_dataset5.py extract_finetuned_embeddings.py install_biotools.sh plm_common.py run_full_pipeline.sh run_multiseed.sh setup_dataset5.sh verify_consistency.py verify_data.py zip_results.py"
for f in scripts/*; do
  b=$(basename "$f")
  case "$b" in __pycache__) continue;; esac
  case " $KEEP " in *" $b "*) ;; *) echo "EXTRA: $f";; esac
done
echo "=== 5. teammate pack v2 (non-D5; small result files only) ==="
ZIPNAME=${ZIPNAME:-teammate_pack_v2.zip}
rm -f "$ZIPNAME"
{ find results results_seed1 results_seed2 results_seed3 results_seed4 -type f 2>/dev/null
  for f in $KEEP; do case "$f" in 01_build_dataset5_proteinmpnn.py|eval_dataset5.py|d5_helpers.py|setup_dataset5.sh) continue;; esac; ls scripts/$f 2>/dev/null; done
  ls README.md CHANGES.md requirements.txt RESULTS_STATUS.md 2>/dev/null
  find data/splits data/provenance -type f 2>/dev/null
  ls data/MANIFEST.sha256 2>/dev/null; } \
 | grep -Ev '(^|/)(dataset5|embeddings|checkpoint[^/]*|__pycache__|pilot|pmpnn|pdb|blast)(/|$)' \
 | grep -Ev '\.(pkl|bin|pt|pth|safetensors|npy|npz|zip|log)$' \
 | grep -Ev '(^|/)(config\.json|tokenizer_config\.json|special_tokens_map\.json|vocab\.txt|trainer_state\.json|generation_config\.json|mm_directions_[a-z]+\.json|d5_helpers\.py|eval_dataset5\.py|01_build_dataset5_proteinmpnn\.py|setup_dataset5\.sh)$' \
 | grep -Ev '^results/\.|dataset5' \
 | { if [ "${INC3B:-0}" = "1" ]; then cat; else grep -Ev 'esm2_3b|with3b'; fi; } \
 | zip -q -@ "$ZIPNAME"
ls -la "$ZIPNAME"
echo "files in zip: $(unzip -Z1 "$ZIPNAME" | wc -l)"
echo "largest 5:"; unzip -Zl "$ZIPNAME" | sort -k4 -n -r | head -5 | awk '{print $4, $10}'
