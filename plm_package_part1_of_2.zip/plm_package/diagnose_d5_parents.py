"""Run from the project root:  python diagnose_d5_parents.py
Compares what ProteinMPNN wrote per parent with what reached designs.csv and why designs were rejected."""
import glob
import os
import sys

import pandas as pd

sys.path.insert(0, "scripts")
import d5_helpers as H  # noqa: E402

des = pd.read_csv("data/raw/dataset5/designs.csv")
counts = des.parent_pdb.value_counts().to_dict()
print("parents in designs.csv:", sorted(counts))
print(f"{'parent':8s}{'samples':>8s}{'parsed':>8s}{'unique':>8s}{'slash':>7s}{'badres':>8s}{'in_csv':>8s}")
for f in sorted(glob.glob("data/raw/dataset5/pmpnn/*/seqs/*.fa")):
    parent = f.split("/")[-3]
    text = open(f).read()
    recs = [(h, s.upper()) for h, s in H.parse_fasta(text) if "sample=" in h]
    ok = H.parse_pmpnn_designed(text)
    slash = sum(1 for rec in recs if "/" in rec[1])
    badres = sum(1 for rec in recs if "/" not in rec[1] and not set(rec[1]) <= H.STANDARD)
    print(f"{parent:8s}{len(recs):8d}{len(ok):8d}{len(set(ok)):8d}{slash:7d}{badres:8d}{counts.get(parent, 0):8d}")
