"""
Synthetic end-to-end run of every NON-torch stage on the real frozen splits, with fabricated embeddings that carry a
planted label signal.  It verifies WIRING (file layouts, CLI flags, cross-script contracts, stale-result detection),
not scientific results; the numbers it produces mean nothing and are discarded.

    python tests/synthetic_e2e.py
Torch-dependent stages (02, 04, 05-A, 09, 13, eval_dataset5, extract_finetuned_embeddings) are exercised by
tests/torch_smoke.py on a machine with torch + transformers.
"""
import json
import os
import pickle
import subprocess
import sys
import tempfile

import numpy as np
import pandas as pd

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(ROOT, "scripts"))
from plm_common import DATASETS, SPLITS, seq_hash, splits_manifest  # noqa: E402

DATA = os.path.join(ROOT, "data", "splits")
MODELS = {"esm2_8m": 16, "esm2_35m": 20, "esm2_150m": 24, "esm2_650m": 28}
NL = 3


def run(args, cwd=ROOT):
    r = subprocess.run([sys.executable] + args, cwd=cwd, capture_output=True, text=True)
    if r.returncode != 0:
        raise SystemExit(f"FAILED: {' '.join(args)}\n{r.stdout[-1500:]}\n{r.stderr[-1500:]}")
    return r.stdout


def make_emb(df, d, rng, dirs, strength):
    y = df["label"].astype(int).to_numpy()
    out = {}
    for pool in ("cls", "mean"):
        X = rng.standard_normal((len(df), NL, d)).astype(np.float32)
        X[:, 1:, :] += (strength * (2 * y[:, None, None] - 1) * dirs[None, 1:, :]).astype(np.float32)
        if pool == "cls":  # real ESM-2: the <cls> hidden state at layer 0 is identical for every sequence
            X[:, 0, :] = X[0, 0, :]
        out[pool] = X
    out.update(labels=y.tolist(), ids=[str(i) for i in df["id"]], seq_sha256=seq_hash(df["sequence"]), windowed=[False] * len(df))
    return out


def dump(obj, path):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "wb") as f:
        pickle.dump(obj, f)


def main():
    rng = np.random.default_rng(0)
    R = tempfile.mkdtemp(prefix="synth_results_")
    dfs = {(ds, sp): pd.read_csv(os.path.join(DATA, ds, f"{sp}.csv")) for ds in DATASETS for sp in SPLITS}
    for mi, (m, d) in enumerate(MODELS.items()):
        base = rng.standard_normal((NL, d))
        for ds in DATASETS:
            shared = base + 0.3 * rng.standard_normal((NL, d))
            fine = {sp: make_emb(dfs[(ds, sp)], d, rng, shared, 0.35 + 0.1 * mi) for sp in SPLITS}
            pre = {sp: make_emb(dfs[(ds, sp)], d, rng, shared, 0.15 + 0.05 * mi) for sp in SPLITS}
            for sp in SPLITS:
                dump(pre[sp], f"{R}/embeddings/pretrained/{m}/{ds}/{sp}_embeddings.pkl")
                dump(fine[sp], f"{R}/{m}/{ds}/embeddings/{sp}_embeddings.pkl")
            te = dfs[(ds, "test")]
            prob = 1 / (1 + np.exp(-(te["label"].to_numpy() * 2 - 1) * rng.normal(0.5, 1.0, len(te))))
            pd.DataFrame({"id": te["id"], "label": te["label"], "prob": prob}).to_csv(f"{R}/{m}/{ds}/test_predictions.csv", index=False)
            from sklearn.metrics import roc_auc_score
            json.dump({"test_roc_auc": float(roc_auc_score(te["label"], prob)), "best_val_roc_auc": 0.8, "n_test": len(te)},
                      open(f"{R}/{m}/{ds}/test_results.json", "w"))
            json.dump({"split_sha256": splits_manifest(DATA, [ds])}, open(f"{R}/{m}/{ds}/provenance.json", "w"))
            for sd in (1, 2):
                os.makedirs(f"{R}_seed{sd}/{m}/{ds}", exist_ok=True)
                json.dump({"test_roc_auc": float(roc_auc_score(te["label"], prob)) + 0.01 * sd},
                          open(f"{R}_seed{sd}/{m}/{ds}/test_results.json", "w"))
        for ti in DATASETS:           # cross_task_ft: backbone ti applied to every eval task
            for tj in DATASETS:
                dump(make_emb(dfs[(tj, "test")], d, rng, base, 0.2), f"{R}/cross_task_ft/{m}/{ti}/{tj}/test_embeddings.pkl")
    # fake BLAST annotation aligned with test.csv
    te = dfs[("peptide_tox", "test")]
    q = rng.uniform(0, 1, len(te))
    pd.DataFrame({"id": te["id"], "label": te["label"], "has_hit": q > 0.2,
                  "blast_hit_label": np.where(q > 0.2, rng.integers(0, 2, len(te)), -1), "blast_pident": 100 * q,
                  "blast_aln_len": 10, "blast_qcov": q, "blast_qident": q, "blast_bitscore": 50 * q,
                  "identity_bin": np.where(q >= .5, "high_identity", np.where(q >= .25, "medium_identity", "low_identity"))}
                 ).to_csv(f"{R}/d3_blast/test_blast.csv", index=False) if os.makedirs(f"{R}/d3_blast", exist_ok=True) is None else None

    print("== leakage audit (kmer)");   run(["scripts/12_cross_dataset_leakage.py", "--method", "kmer", "--output-dir", f"{R}/leakage"])
    print("== shortcut baselines");     run(["scripts/11_shortcut_baselines.py", "--output-dir", R])
    for m in MODELS:
        for ds in DATASETS:
            run(["scripts/03_linear_probe.py", "--embeddings-dir", f"{R}/embeddings/pretrained/{m}/{ds}", "--dataset", ds,
                 "--output-dir", f"{R}/probes/pretrained/{m}/{ds}", "--save-directions"])
            run(["scripts/03_linear_probe.py", "--embeddings-dir", f"{R}/{m}/{ds}/embeddings", "--dataset", ds,
                 "--output-dir", f"{R}/probes/finetuned/{m}/{ds}", "--save-directions"])
        for sp in ("pretrained", "finetuned"):
            run(["scripts/06_cross_task_analysis.py", "--model-short", m, "--space", sp, "--results-root", R, "--output-dir", f"{R}/cross_task/{sp}/{m}"])
        run(["scripts/08_blast_vs_plm.py", "--model-short", m, "--results-root", R, "--blast-csv", f"{R}/d3_blast/test_blast.csv"])
    for pool in ("cls", "mean"):
        run(["scripts/10_bootstrap_ci.py", "--pooling", pool, "--results-root", R, "--output-dir", f"{R}/bootstrap_ci", "--n-boot", "100"])
        run(["scripts/07_scaling_curve.py", "--pooling", pool, "--results-root", R, "--output-dir", f"{R}/scaling_curve"])
    run(["scripts/14_seed_variance.py", "--models", *MODELS, "--base", R, "--output", f"{R}/seed_variance.json"])
    out = run(["scripts/verify_consistency.py", "--results-root", R])
    print(out.strip().splitlines()[-1])

    # --- contract checks on produced files ---
    xt = json.load(open(f"{R}/cross_task/pretrained/esm2_8m/transfer_matrix.json")) if os.path.exists(
        f"{R}/cross_task/pretrained/esm2_8m/transfer_matrix.json") else None
    produced = sorted(os.listdir(f"{R}/cross_task/pretrained/esm2_8m"))
    assert produced, "06 produced nothing"
    ci = json.load(open(f"{R}/bootstrap_ci/bootstrap_ci_cls.json")) if os.path.exists(f"{R}/bootstrap_ci/bootstrap_ci_cls.json") else None
    print("06 outputs:", produced)
    print("10 outputs:", sorted(os.listdir(f"{R}/bootstrap_ci")))
    print("07 outputs:", sorted(os.listdir(f"{R}/scaling_curve")))

    # --- stale-result detection must fire when a split changes ---
    tmp_data = tempfile.mkdtemp(prefix="synth_data_")
    import shutil
    shutil.copytree(DATA, os.path.join(tmp_data, "splits"))
    p = os.path.join(tmp_data, "splits", "pft", "test.csv")
    df = pd.read_csv(p); df.loc[0, "label"] = 1 - df.loc[0, "label"]; df.to_csv(p, index=False)
    r = subprocess.run([sys.executable, "scripts/verify_consistency.py", "--results-root", R, "--data-dir", os.path.join(tmp_data, "splits")],
                       cwd=ROOT, capture_output=True, text=True)
    assert r.returncode == 1 and "FAIL" in r.stdout, "stale-result detection did not fire"
    print("stale-result detection OK (exit 1 when a split changed)")
    shutil.rmtree(R, ignore_errors=True); shutil.rmtree(tmp_data, ignore_errors=True)
    for sd in (1, 2):
        shutil.rmtree(f"{R}_seed{sd}", ignore_errors=True)
    print("SYNTHETIC E2E OK")


if __name__ == "__main__":
    main()
