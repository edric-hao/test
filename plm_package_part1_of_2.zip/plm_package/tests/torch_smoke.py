"""
Torch-dependent smoke tests on a TINY randomly-initialised ESM-2 (CPU, ~1 min).  NOT runnable in an environment
without torch + transformers (the authoring sandbox had neither, so this file has never been executed by the author:
run it first on your GPU machine, `python tests/torch_smoke.py`, before launching the pipeline).

Checks
  1. extraction is padding-invariant (batched == one-by-one), CLS == token 0, mean excludes <cls>/<eos>/pad;
  2. window pooling for sequences longer than max_len equals the mean of manually cut windows;
  3. the steering hook changes the CLS output only for alpha>0 and moves the projection on d_src positively;
  4. 04_finetune_esm2.py runs end-to-end on a tiny task (2 epochs), writes test_results/provenance/embeddings, its
     stored test AUROC is reproduced by extract_finetuned_embeddings.py, and the pretrained-style extraction of the
     fine-tuned backbone has the same shape/ids as the CSV.
"""
import json
import os
import subprocess
import sys
import tempfile

import numpy as np
import pandas as pd
import torch
from transformers import EsmConfig, EsmForSequenceClassification, EsmModel, EsmTokenizer

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(ROOT, "scripts"))
import embed_utils as E  # noqa: E402
from plm_common import check_embeddings_match, load_pkl  # noqa: E402

VOCAB = ["<cls>", "<pad>", "<eos>", "<unk>", "L", "A", "G", "V", "S", "E", "R", "T", "I", "D", "P", "K", "Q", "N", "F", "Y",
         "M", "H", "W", "C", "X", "B", "U", "Z", "O", ".", "-", "<null_1>", "<mask>"]
AA = "ACDEFGHIKLMNPQRSTVWY"


def tiny(tmp):
    vf = os.path.join(tmp, "vocab.txt")
    open(vf, "w").write("\n".join(VOCAB) + "\n")
    tok = EsmTokenizer(vf)
    cfg = EsmConfig(vocab_size=len(VOCAB), hidden_size=32, num_hidden_layers=3, num_attention_heads=4, intermediate_size=64,
                    pad_token_id=1, mask_token_id=32, max_position_embeddings=64, position_embedding_type="rotary")
    torch.manual_seed(0)
    return tok, cfg


def rnd(rng, n):
    return "".join(rng.choice(list(AA), n))


def main():
    rng = np.random.default_rng(0)
    with tempfile.TemporaryDirectory() as tmp:
        tok, cfg = tiny(tmp)
        bb = EsmModel(cfg, add_pooling_layer=False).eval()
        dev = torch.device("cpu")
        seqs = [rnd(rng, n) for n in (8, 15, 11, 20)]
        c_b, m_b, w = E.extract_representations(bb, tok, seqs, dev, batch_size=4, max_len=30)
        c_1, m_1, _ = E.extract_representations(bb, tok, seqs, dev, batch_size=1, max_len=30)
        np.testing.assert_allclose(c_b, c_1, atol=1e-4); np.testing.assert_allclose(m_b, m_1, atol=1e-4)
        assert not any(w)
        enc = tok([seqs[0]], return_tensors="pt")
        with torch.no_grad():
            hs = torch.stack(bb(**enc, output_hidden_states=True).hidden_states)[:, 0]  # (L+1,T,D)
        np.testing.assert_allclose(c_1[0], hs[:, 0].numpy(), atol=1e-4)
        np.testing.assert_allclose(m_1[0], hs[:, 1:-1].mean(1).numpy(), atol=1e-4)
        print("1. extraction padding-invariance, CLS and residue-mean definitions OK")

        long = rnd(rng, 50)
        c_l, m_l, w = E.extract_representations(bb, tok, [long], dev, batch_size=2, max_len=30, stride=15)
        assert w == [True]
        starts = E.window_starts(50, 30, 15)
        parts = [E.extract_representations(bb, tok, [long[s:s + 30]], dev, 1, 30)[:2] for s in starts]
        np.testing.assert_allclose(c_l[0], np.mean([p[0][0] for p in parts], 0), atol=1e-4)
        np.testing.assert_allclose(m_l[0], np.mean([p[1][0] for p in parts], 0), atol=1e-4)
        print("2. window pooling OK")

        import importlib
        st = importlib.import_module("09_activation_steering")
        d = np.random.default_rng(1).standard_normal(32); d /= np.linalg.norm(d)
        base = st.final_cls(bb, tok, seqs, dev, 0.0, None, 4)
        same = st.final_cls(bb, tok, seqs, dev, 0.0, d, 4)
        inj = st.final_cls(bb, tok, seqs, dev, 5.0, d, 4)
        np.testing.assert_allclose(base, same, atol=1e-6)
        assert ((inj - base) @ d).mean() > 0
        print("3. steering hook OK")

        # 4. tiny end-to-end fine-tune
        mdir = os.path.join(tmp, "tiny_model")
        EsmForSequenceClassification(cfg).save_pretrained(mdir); tok.save_pretrained(mdir)
        data = os.path.join(tmp, "splits", "toy"); os.makedirs(data)
        for sp, n in (("train", 96), ("val", 32), ("test", 32)):
            y = np.arange(n) % 2
            seq = [("K" * 6 if yy else "D" * 6) + rnd(rng, 10) for yy in y]
            pd.DataFrame({"id": [f"{sp}{i}" for i in range(n)], "sequence": seq, "label": y}).to_csv(f"{data}/{sp}.csv", index=False)
        out = os.path.join(tmp, "ft")
        env = dict(os.environ, PYTHONPATH=os.path.join(ROOT, "scripts"))
        subprocess.run([sys.executable, "scripts/04_finetune_esm2.py", "--model-id", mdir, "--dataset", "toy", "--data-dir",
                        os.path.join(tmp, "splits"), "--output-dir", out, "--epochs", "2", "--batch-size", "16", "--lr", "1e-3",
                        "--max-length", "30", "--extract-embeddings", "--num-workers", "0"], cwd=ROOT, check=True, env=env)
        for f in ("test_results.json", "provenance.json", "test_predictions.csv", "embeddings/test_embeddings.pkl"):
            assert os.path.exists(os.path.join(out, f)), f
        for sp in ("train", "val", "test"):
            check_embeddings_match(load_pkl(f"{out}/embeddings/{sp}_embeddings.pkl"), pd.read_csv(f"{data}/{sp}.csv"), sp)
        subprocess.run([sys.executable, "scripts/extract_finetuned_embeddings.py", "--model-dir", out, "--dataset", "toy",
                        "--data-dir", os.path.join(tmp, "splits"), "--max-length", "30"], cwd=ROOT, check=True, env=env)
        print("4. tiny fine-tune + stored-vs-recomputed AUROC check OK:", json.load(open(f"{out}/test_results.json")))
    print("TORCH SMOKE OK")


if __name__ == "__main__":
    main()
