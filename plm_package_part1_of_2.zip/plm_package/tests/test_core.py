"""Unit tests (stdlib unittest; also collected by pytest).  Run:  python -m unittest discover -s tests -v
No torch / network / bioinformatics binaries required."""
import importlib
import os
import sys
import tempfile
import unittest

import numpy as np
import pandas as pd

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(ROOT, "scripts"))
import plm_common as C  # noqa: E402
import embed_utils as E  # noqa: E402
import d5_helpers as H  # noqa: E402


def mod(name):
    return importlib.import_module(name)


def planted(n=300, d=24, strength=3.0, seed=0):
    rng = np.random.default_rng(seed)
    y = rng.integers(0, 2, n)
    u = C.unit(rng.standard_normal(d))
    X = rng.standard_normal((n, d)) + strength * y[:, None] * u[None, :]
    return X, y, u


class TestCommon(unittest.TestCase):
    def test_unit_and_project_out(self):
        rng = np.random.default_rng(0)
        X = rng.standard_normal((50, 10))
        d = C.unit(rng.standard_normal(10))
        Z = C.project_out(X, d)
        self.assertLess(np.abs(Z @ d).max(), 1e-10)
        self.assertAlmostEqual(np.linalg.norm(d), 1.0)
        with self.assertRaises(ValueError):
            C.unit(np.zeros(5))

    def test_auroc_single_class_raises(self):
        with self.assertRaises(ValueError):
            C.auroc([1, 1, 1], [0.1, 0.2, 0.3])

    def test_mm_probe_recovers_direction_and_threshold(self):
        X, y, u = planted()
        p = C.MMProbe().fit(X, y)
        self.assertGreater(abs(p.direction @ u), 0.9)
        self.assertGreater(C.auroc(y, p.score(X)), 0.95)
        s = p.score(X)
        self.assertAlmostEqual(p.threshold, (s[y == 1].mean() + s[y == 0].mean()) / 2)

    def test_constant_layer0_cls_is_degenerate_not_a_crash(self):
        X = np.tile(np.random.default_rng(0).standard_normal(8), (40, 1))
        y = np.arange(40) % 2
        p = C.MMProbe().fit(X, y)
        self.assertTrue(p.degenerate)
        self.assertAlmostEqual(C.auroc(y, p.score(X)), 0.5)
        with self.assertRaises(ValueError):
            C.mm_direction(X, y)
        a03 = mod("03_linear_probe")
        r = a03.probe_all_layers(np.stack([X, X + np.outer(y, np.ones(8))], 1), y, np.stack([X, X + np.outer(y, np.ones(8))], 1), y,
                                 np.stack([X, X + np.outer(y, np.ones(8))], 1), y)
        self.assertTrue(r[0]["mm_degenerate"] and not r[1]["mm_degenerate"])
        self.assertEqual(C.best_layer_by_val(r)["layer"], 1)

    def test_lr_probe_fit_uses_only_train_statistics(self):
        X, y, _ = planted()
        pr = C.LRProbe().fit(X[:200], y[:200])
        np.testing.assert_allclose(pr.scaler.mean_, X[:200].mean(0))

    def test_best_layer_by_val_uses_val_not_test_and_raises_without_val(self):
        recs = [{"layer": 0, "mm_val_auroc": 0.6, "mm_auroc": 0.99},
                {"layer": 1, "mm_val_auroc": 0.9, "mm_auroc": 0.5},
                {"layer": 2, "mm_val_auroc": 0.9, "mm_auroc": 0.7}]
        self.assertEqual(C.best_layer_by_val(recs)["layer"], 1)  # tie -> lowest layer
        with self.assertRaises(ValueError):
            C.best_layer_by_val([{"layer": 0, "mm_auroc": 0.9}])
        with self.assertRaises(ValueError):
            C.best_layer_by_val([])

    def test_check_embeddings_match(self):
        df = pd.DataFrame({"id": ["a", "b", "c"], "sequence": ["AAAA", "CCCC", "DDDD"], "label": [0, 1, 1]})
        emb = {"cls": np.zeros((3, 2, 4)), "labels": [0, 1, 1], "ids": ["a", "b", "c"], "seq_sha256": C.seq_hash(df["sequence"])}
        self.assertTrue(C.check_embeddings_match(emb, df))
        bad = dict(emb, labels=[1, 1, 1])
        with self.assertRaises(ValueError):
            C.check_embeddings_match(bad, df)
        bad = dict(emb, ids=["a", "c", "b"])
        with self.assertRaises(ValueError):
            C.check_embeddings_match(bad, df)
        df2 = df.copy(); df2.loc[0, "sequence"] = "AAAC"
        with self.assertRaises(ValueError):
            C.check_embeddings_match(emb, df2)
        with self.assertRaises(ValueError):
            C.check_embeddings_match(emb, df.iloc[:2])


class TestEmbedUtils(unittest.TestCase):
    def test_residue_mask_excludes_cls_eos_pad(self):
        am = np.array([[1, 1, 1, 1, 1, 0, 0], [1, 1, 1, 0, 0, 0, 0]])
        m = E.residue_mask(am)
        np.testing.assert_array_equal(m[0], [0, 1, 1, 1, 0, 0, 0])
        np.testing.assert_array_equal(m[1], [0, 1, 0, 0, 0, 0, 0])

    def test_window_starts_cover_every_residue(self):
        for L in [10, 1022, 1023, 1500, 2044, 3000, 6000]:
            starts = E.window_starts(L, 1022, 511)
            covered = np.zeros(L, bool)
            for s in starts:
                covered[s:s + 1022] = True
            self.assertTrue(covered.all(), L)
            self.assertLessEqual(max(starts) + 1022, max(L, 1022))
            self.assertEqual(starts, sorted(set(starts)))


class TestAblation(unittest.TestCase):
    def test_erasure_signal_beats_nulls_and_is_seeded(self):
        a05 = mod("05_causal_ablation")
        X, y, u = planted(n=400, d=16, strength=2.0, seed=1)
        # signal lives ONLY in direction u: erasing u must destroy it; random directions must not
        Xtr, ytr, Xte, yte = X[:300], y[:300], X[300:], y[300:]
        r = a05.erasure_layer(Xtr, ytr, Xte, yte, C.mm_direction(Xtr, ytr), 8, np.random.default_rng(0))
        self.assertGreater(r["lr_auroc_original"], 0.9)
        self.assertGreater(r["auroc_drop"], 0.25)
        self.assertGreater(r["auroc_drop"], r["random_null"]["null_mean"] + 0.2)
        self.assertTrue(r["random_null"]["above_null_2sd"])
        r2 = a05.erasure_layer(Xtr, ytr, Xte, yte, C.mm_direction(Xtr, ytr), 8, np.random.default_rng(0))
        self.assertEqual(r["auroc_drop"], r2["auroc_drop"])

    def test_erasing_direction_orthogonal_to_signal_changes_nothing(self):
        a05 = mod("05_causal_ablation")
        X, y, u = planted(n=400, d=16, strength=2.0, seed=2)
        rng = np.random.default_rng(0)
        o = rng.standard_normal(16)
        o = C.unit(o - (o @ u) * u)
        r = a05.erasure_layer(X[:300], y[:300], X[300:], y[300:], o, 5, np.random.default_rng(0))
        self.assertLess(abs(r["auroc_drop"]), 0.05)


class TestCrossTask(unittest.TestCase):
    def test_transfer_matrix_exclusions_and_polarity(self):
        a06 = mod("06_cross_task_analysis")
        rng = np.random.default_rng(0)
        d = C.unit(rng.standard_normal(8))
        ys = {t: rng.integers(0, 2, 60) for t in "AB"}
        Xs = {"A": rng.standard_normal((60, 8)) + 3 * ys["A"][:, None] * d, "B": rng.standard_normal((60, 8)) - 3 * ys["B"][:, None] * d}
        raw, pol, n_eval, n_excl = a06.transfer_matrix(lambda t: (d, 0), lambda ti, tj: ((lambda L, X=Xs[tj]: X), ys[tj]),
                                                       ["A", "B"], {"A->B": [0, 1, 2]})
        self.assertGreater(raw[0, 0], 0.9)
        self.assertLess(raw[0, 1], 0.1)          # opposite polarity
        self.assertGreater(pol[0, 1], 0.9)       # polarity-free fixes it
        self.assertEqual(n_excl[0, 1], 3)
        self.assertEqual(n_eval[0, 1], 57)
        self.assertEqual(n_excl[0, 0], 0)        # diagonal never excluded


class TestBlast(unittest.TestCase):
    def test_parse_best_hit_and_annotate(self):
        ab = mod("annotate_d3_blast")
        tsv = "q0\tr1\t90.0\t10\t10\t30.0\t1e-5\nq0\tr0\t95.0\t5\t10\t50.0\t1e-9\nq1\tr0\t40.0\t10\t20\t20.0\t1e-2\n"
        best = ab.parse_blast_tsv(tsv)
        self.assertEqual(best.set_index("qseqid").loc["q0", "sseqid"], "r0")  # higher bitscore wins
        test = pd.DataFrame({"id": ["t0", "t1", "t2"], "label": [1, 0, 1]})
        ref = pd.DataFrame({"label": [0, 1]})
        out = ab.annotate(test, ref, best)
        self.assertEqual(out["blast_hit_label"].tolist(), [0, 0, -1])
        self.assertAlmostEqual(out.loc[0, "blast_qident"], 0.95 * 5 / 10)
        self.assertAlmostEqual(out.loc[1, "blast_qident"], 0.40 * 10 / 20)
        self.assertEqual(out["identity_bin"].tolist(), ["medium_identity", "low_identity", "low_identity"])
        self.assertFalse(out.loc[2, "has_hit"])

    def test_nn_score_is_signed(self):
        a08 = mod("08_blast_vs_plm")
        df = pd.DataFrame({"blast_hit_label": [1, 0, -1], "blast_qident": [0.8, 0.6, 0.0]})
        np.testing.assert_allclose(a08.blast_nn_score(df), [0.8, -0.6, 0.0])


class TestLeakageAudit(unittest.TestCase):
    def test_analyse_assigns_pairs_and_within(self):
        a12 = mod("12_cross_dataset_leakage")
        rows = [dict(ds="pft", split="train", idx=0, seq="x"), dict(ds="pft", split="test", idx=0, seq="x"),
                dict(ds="virulence", split="test", idx=3, seq="x"), dict(ds="virulence", split="val", idx=1, seq="x"),
                dict(ds="peptide_tox", split="test", idx=5, seq="x")]
        rep, excl = a12.analyse(rows, [[0, 1, 2], [3, 4]])
        self.assertEqual(rep["within_dataset_test_rows_similar_to_train_or_val"].get("pft"), 1)
        self.assertEqual(excl["pft->virulence"], [3])
        self.assertNotIn("virulence->peptide_tox", excl or {})  # val rows never create cross-task exclusions
        self.assertEqual(excl.get("virulence->peptide_tox"), None)

    def test_within_rows_and_sensitivity(self):
        a12, a13 = mod("12_cross_dataset_leakage"), mod("13_leakage_sensitivity")
        rows = [dict(ds="pft", split="train", idx=0, seq="x"), dict(ds="pft", split="test", idx=7, seq="x"),
                dict(ds="virulence", split="train", idx=0, seq="x"), dict(ds="virulence", split="test", idx=2, seq="x")]
        w = a12.within_rows(rows, [[0, 1], [2, 3], [1, 2]])
        self.assertEqual(w["pft"], [7])
        self.assertEqual(w["virulence"], [2])          # cross-dataset pair [1,2] must not add to the other dataset
        self.assertEqual(w["peptide_tox"], [])
        X, y, _ = planted(n=400, strength=3.0, seed=1)
        Xtr, ytr, Xte, yte = X[:200], y[:200], X[200:], y[200:]
        r = a13.sensitivity(Xtr, ytr, Xte, yte, flagged=[0, 1, 2], n_boot=100)
        self.assertEqual((r["n_all"], r["n_flagged"], r["n_clean"]), (200, 3, 197))
        self.assertGreater(r["auroc_all"], 0.9)
        # flagging every positive test row leaves a single-class remainder -> graceful None, no crash
        r2 = a13.sensitivity(Xtr, ytr, Xte, yte, flagged=list(np.where(yte == 1)[0]), n_boot=10)
        self.assertIsNone(r2["auroc_clean"])

    def test_summarise_identity_bins(self):
        a5 = mod("eval_dataset5")
        rng = np.random.default_rng(0)
        s_d5 = np.r_[rng.normal(2, .1, 6), rng.normal(-2, .1, 6)]
        ident = np.r_[np.full(6, 0.2), np.full(6, 0.45)]
        parents = np.array(list("AABBCC") + list("DDEEFF"))
        r = a5.summarise(s_d5, parents, rng.normal(2, 1, 20), rng.normal(-2, 1, 20), rng.normal(-2, 1, 20), 0.0,
                         n_boot=50, identity=ident)
        self.assertEqual(r["by_identity_to_d1"]["0.00-0.30"]["detection_rate"], 1.0)
        self.assertEqual(r["by_identity_to_d1"]["0.40-1.00"]["detection_rate"], 0.0)
        self.assertIsNone(r["by_identity_to_d1"]["0.30-0.40"]["detection_rate"])
        self.assertNotIn("by_identity_to_d1", a5.summarise(s_d5, parents, rng.normal(2, 1, 20), rng.normal(-2, 1, 20),
                                                           rng.normal(-2, 1, 20), 0.0, n_boot=50))

    def test_kmer_groups(self):
        a12 = mod("12_cross_dataset_leakage")
        s = "ACDEFGHIKLMNPQRSTVWY" * 3
        rows = [dict(seq=s), dict(seq=s[:50] + "W" * 10), dict(seq="W" * 60)]
        g = a12.groups_from_kmers(rows)
        self.assertIn([0, 1], g)
        self.assertNotIn([0, 2], g)


class TestD5(unittest.TestCase):
    def test_parse_pmpnn_skips_native_and_multichain(self):
        txt = ">1ABC, score=1\nMKVL\n>T=0.1, sample=1, score=0.5\nMKVA\n>T=0.1, sample=2\nMK/VA\n>T=0.1, sample=3\nMKXA\n"
        self.assertEqual(H.parse_pmpnn_designed(txt), ["MKVA"])

    def test_identity_nw(self):
        self.assertEqual(H.identity_nw("ACDE", "ACDE"), 1.0)
        self.assertLess(H.identity_nw("AAAA", "CCCC"), 0.1)
        self.assertAlmostEqual(H.identity_nw("ACDEFGHIK", "ACDEFGHIC"), 8 / 9)

    def test_temperature_uses_within_parent_identity(self):
        # parents differ completely from each other but are identical inside -> must NOT look diverse
        same_inside = {0.1: [["AAAA", "AAAA"], ["CCCC", "CCCC"]], 0.5: [["AAAA", "AAAC"], ["CCCC", "CCCD"]]}
        T, summ = H.choose_temperature(same_inside, 0.9)
        self.assertEqual(T, 0.5)
        self.assertAlmostEqual(summ[0.1], 1.0)

    def test_pdb_helpers(self):
        def atom(ch, n, aa, x):
            return f"ATOM  {n:5d}  CA  {aa} {ch}{n:4d}    {x:8.3f}{0:8.3f}{0:8.3f}  1.00 50.00           C"
        pdb = "\n".join([atom("A", i, "ALA", float(i)) for i in range(1, 41)] + [atom("B", i, "GLY", float(i)) for i in range(1, 41)])
        ch, seq, xyz = H.first_chain(pdb)
        self.assertEqual((ch, seq, xyz.shape), ("A", "A" * 40, (40, 3)))
        self.assertEqual(H.ss_class(pdb, "A"), "unknown")
        self.assertAlmostEqual(H.mean_bfactor_ca(pdb), 50.0)

    def test_resolution_rules(self):
        self.assertTrue(H.passes_resolution(3.0, "X-RAY DIFFRACTION", 3.5, 4.0))
        self.assertFalse(H.passes_resolution(3.8, "X-RAY DIFFRACTION", 3.5, 4.0))
        self.assertTrue(H.passes_resolution(3.8, "ELECTRON MICROSCOPY", 3.5, 4.0))
        self.assertFalse(H.passes_resolution(None, "X-RAY DIFFRACTION", 3.5, 4.0))

    def test_wilson(self):
        lo, hi = H.wilson(5, 18)
        self.assertTrue(0.12 < lo < 0.13 and 0.50 < hi < 0.52)

    def test_eval_summary(self):
        ev = mod("eval_dataset5")
        rng = np.random.default_rng(0)
        r = ev.summarise(rng.normal(2, 1, 60), np.repeat(list("ABCDEF"), 10), rng.normal(2, 1, 80), rng.normal(-2, 1, 80),
                         rng.normal(-2, 1, 60), 0.0, 200)
        self.assertGreater(r["d5_detection_rate"], 0.9)
        self.assertLess(r["shuffled_d5_detection_rate"], 0.1)
        lo, hi = r["d5_detection_ci_parent_bootstrap"]
        self.assertTrue(lo <= r["d5_detection_rate"] <= hi)
        self.assertEqual(r["n_parents"], 6)


class TestShortcutBaselines(unittest.TestCase):
    def test_comp_resid_coefficients_come_from_train_only(self):
        a11 = mod("11_shortcut_baselines")
        tr = ["ACDEFGHIKL" * 3, "AAAAACCCCCDDDDD" * 2, "MKVLLQRST" * 4, "WWYYFFLLIIVV" * 3]
        va = ["ACDE" * 5]
        te1 = ["AAAA" * 10]
        te2 = ["WWWW" * 3, "CCCCDDDD" * 5]
        t1 = a11.features("comp_resid", tr, va, te1)
        t2 = a11.features("comp_resid", tr, va, te2)
        np.testing.assert_allclose(t1[0], t2[0])   # train features independent of the test set
        np.testing.assert_allclose(t1[1], t2[1])   # val features independent of the test set


class TestData(unittest.TestCase):
    def test_frozen_data_passes_all_checks(self):
        vd = mod("verify_data")
        self.assertEqual(vd.check(os.path.join(ROOT, "data", "splits")), [])
        want = [l.strip() for l in open(os.path.join(ROOT, "data", "MANIFEST.sha256")) if l.strip()]
        self.assertEqual(want, vd.manifest_lines(os.path.join(ROOT, "data", "splits")))

    def test_verify_detects_corruption(self):
        import shutil
        vd = mod("verify_data")
        with tempfile.TemporaryDirectory() as tmp:
            dst = os.path.join(tmp, "splits")
            shutil.copytree(os.path.join(ROOT, "data", "splits"), dst)
            p = os.path.join(dst, "pft", "test.csv")
            df = pd.read_csv(p)
            df.loc[0, "sequence"] = df.loc[0, "sequence"] + "X"
            df.to_csv(p, index=False)
            self.assertTrue(any("non-standard" in e for e in vd.check(dst)))
            tr = pd.read_csv(os.path.join(dst, "pft", "train.csv"))
            pd.concat([pd.read_csv(os.path.join(dst, "pft", "val.csv")).iloc[:0], tr.iloc[:1].assign(id="zzz")]).to_csv(
                os.path.join(dst, "pft", "val.csv"), index=False)
            self.assertTrue(any("more than one split" in e or "both classes" in e for e in vd.check(dst)))


if __name__ == "__main__":
    unittest.main()
