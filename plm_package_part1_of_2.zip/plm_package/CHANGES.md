# Changes relative to the original code (and what they invalidate)

| Original problem | Result it contaminated | Fix |
|---|---|---|
| MM probe "refit" after erasing its own direction (vacuous: class means coincide) | per-layer ablation | `05`: LR-refit erasure + random & label-shuffled nulls; classifier-head ablation with nulls |
| Directions and test embeddings from different backbones; leakage across datasets | cross-task transfer, cosine | `06`/`13`: shared backbone per matrix, leakage exclusions (`12`), cosine only in shared pretrained space with chance level |
| BLAST baseline used positive hits only / BLAST columns stored in split CSVs (hit label from train) | PLM-vs-BLAST | `annotate_d3_blast.py` + `08`: signed NN score, best hit by bit score, side-file annotation |
| D4 had sequences up to 6000 aa (windowed in pretrained, truncated in fine-tuned) and non-standard residues occurring only in positives | all D4 results | `00_harmonize_length_policy.py`: ≤1022 aa, standard residues only (D4: 149 long + 10 non-standard rows removed) |
| D5 pooled identity across parents, kept multi-chain `/` sequences, pilot on wrong statistic, no references | D5 | `01_build_dataset5_proteinmpnn.py`, `eval_dataset5.py`, `d5_helpers.py` rewritten (see README) |
| Pretrained embeddings were window-pooled while fine-tuned ones were truncated at 1022 (different inputs for long D4 sequences); separate extraction code paths | CLS-vs-mean pooling claim | one `embed_utils` implementation for every model and pooling; length policy makes truncation/windowing equivalent; claim must be re-derived from the new run |
| Steering read as behavioural evidence although nothing downstream of the injection is computed; only an isotropic-random null; no geometric reference | steering interpretation | documented as a gamma-weighted-cosine (geometric) effect, random + label-shuffled nulls, cosine stored per record |
| Scaling statistics over ≤5 model sizes, single seed | scaling statistics | descriptive only (no p-value claims); seed SD from `14` |
| Layer selection could fall back to test AUROC | all probe tables | raises if val AUROC is missing |
| Fine-tuning script: no provenance linking a checkpoint to the split files it used | all fine-tuned outputs | `04` rewritten: val-AUROC early stopping, test predicted once, gradient check on trainable parameters, `provenance.json` with split hashes, dynamic padding |
| Dataset builders: silent fallbacks (no cd-hit / Phobius → heuristics), truncated-id collisions | D1–D3 construction | hard failures, row-index ids; D3 builder writes no BLAST columns |
| Duplicate ids in D1 | – | made unique (`#dupN`); sequences/labels unchanged |
| No guard against mixing result versions | everything | `MANIFEST.sha256`, `verify_data.py`, results stamp, `verify_consistency.py` |

Removed: all `run_overnight_*`, `run_esm2_*`, `run_probing.sh`, `fix_before_rerun.sh`, `migrate_steering_field.py`, `01_prep_dataset*_proxy/signal.py`, `REVIEWER_RESPONSE.md`, stale `meta.csv`/`.build_version` files and the stale D5 CSV.
