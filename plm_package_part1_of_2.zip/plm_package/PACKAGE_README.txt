PLM harm-detection package - PART 1 of 2  (extract BOTH parts into the same folder; they merge into plm_package/)

Part 1 contains: code (scripts/, tests/), frozen splits + provenance (data/), docs (README.md, RESULTS_STATUS.md - read
RESULTS_STATUS.md first), environment record (env_*.txt, requirements.txt), and ALL results: results/ (all five models,
ablation, steering, cross-task, BLAST, bootstrap CIs, scaling curves, leakage, D5, probes) and results_seed1..4/.
Probe direction vectors (mm_directions_*.json) for esm2_8m..esm2_650m are included here.

Part 2 contains: the probe direction vectors for esm2_3b (results/probes/{pretrained,finetuned}/esm2_3b/*/mm_directions_*.json)
and logs/ (all run logs).

What works from Part 1 alone: reading every result; verify_data.py; verify_consistency.py; 07_scaling_curve.py,
14_seed_variance.py, 11_shortcut_baselines.py, 12 (k-mer), 15_finetuned_leakage_sensitivity.py; tests/.
Needs Part 2 as well: any 3B re-analysis that reads its probe directions (D5, cross-task, ablation, steering for 3B).
Not shipped in either part (size): model weights and embedding pickles.
