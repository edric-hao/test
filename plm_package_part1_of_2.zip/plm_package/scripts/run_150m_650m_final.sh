#!/bin/bash
# Regenerate ESM-2 150M and 650M fine-tuned results with the FINAL pipeline, then add seeds 1-4.
# Run from the repo root on the GPU box:  bash scripts/run_150m_650m_final.sh
# Step A moves the old pre-fix outputs to old_prefix_150m_650m/ (run_full_pipeline.sh would otherwise skip them
# because test_results.json already exists).  Nothing is deleted.
set -euo pipefail
cd "$(dirname "$0")/.."
PY=${PY:-python}
BK=old_prefix_150m_650m
mkdir -p "$BK"

echo "=== A. back up pre-fix fine-tuned outputs and everything derived from them"
for M in esm2_150m esm2_650m; do
  for P in "results/$M" "results/probes/finetuned/$M" "results/ablation/$M" "results/cross_task/finetuned/$M" \
           "results/blast_vs_plm/$M" "results/dataset5/${M}_d5_results.json"; do
    if [ -e "$P" ]; then mkdir -p "$BK/$(dirname "$P")"; mv "$P" "$BK/$P"; echo "moved $P"; fi
  done
done

echo "=== B. seed 42, final pipeline (fine-tune + embeddings + fine-tuned probes + ablation + cross-task + steering + BLAST + CIs)"
$PY scripts/verify_data.py
MODELS="esm2_150m esm2_650m" bash scripts/run_full_pipeline.sh

echo "=== C. D5 on the regenerated D1 fine-tuned probes"
$PY scripts/eval_dataset5.py

echo "=== D. seeds 1-4 for 150M and 650M, then seed SD for all four sizes"
MODELS="esm2_150m esm2_650m" bash scripts/run_multiseed.sh

echo "=== E. rebuild scaling with seed error bars and the consistency check"
for P in cls mean; do $PY scripts/07_scaling_curve.py --pooling $P --results-root results --output-dir results/scaling_curve; done
$PY scripts/verify_consistency.py --results-root results
echo "DONE. Zip with scripts/zip_results.py and send back."
