"""
Stratified bootstrap CIs (resampling test sequences within class) for:
  pre_probe  : pretrained MM probe at its VAL-selected layer
  ft_probe   : fine-tuned  MM probe at its VAL-selected layer
  ft_cls     : fine-tuned classifier probability (results/<model>/<ds>/test_predictions.csv)
and PAIRED bootstrap CIs (identical resamples) for the differences ft_probe - pre_probe and ft_cls - pre_probe.
Resampling treats test sequences as independent; test splits are cluster-separated from train but sequences inside
the test split may still be homologous, so the CIs are somewhat optimistic.

    python scripts/10_bootstrap_ci.py --pooling cls   (and --pooling mean)
"""
import argparse
import json
import os

import numpy as np
import pandas as pd

from plm_common import (DATASETS, MODELS, MODELS_WITH_3B, auroc, best_layer_by_val, check_embeddings_match,
                        load_json, load_pkl, unit)


def probe_scores(root, stage, model, ds, pooling, test_df):
    pdir = os.path.join(root, "probes", stage, model, ds)
    layer = best_layer_by_val(load_json(os.path.join(pdir, "probe_results.json"))[pooling], "mm")["layer"]
    d = unit(load_json(os.path.join(pdir, f"mm_directions_{pooling}.json"))[str(layer)])
    path = (os.path.join(root, "embeddings", "pretrained", model, ds, "test_embeddings.pkl") if stage == "pretrained"
            else os.path.join(root, model, ds, "embeddings", "test_embeddings.pkl"))
    emb = load_pkl(path)
    check_embeddings_match(emb, test_df, path)
    return np.asarray(emb[pooling][:, layer, :], dtype=np.float64) @ d, layer


def paired_bootstrap(y, scores, n_boot, rng):
    """scores: dict name -> array. Returns dict name -> array of bootstrap AUROCs (same resamples for all)."""
    pos, neg = np.where(y == 1)[0], np.where(y == 0)[0]
    out = {k: np.empty(n_boot) for k in scores}
    for b in range(n_boot):
        idx = np.concatenate([rng.choice(pos, len(pos)), rng.choice(neg, len(neg))])
        for k, s in scores.items():
            out[k][b] = auroc(y[idx], s[idx])
    return out


def ci(x, alpha=0.05):
    return [float(np.percentile(x, 100 * alpha / 2)), float(np.percentile(x, 100 * (1 - alpha / 2)))]


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--results-root", default="results")
    p.add_argument("--data-dir", default="data/splits")
    p.add_argument("--output-dir", default="results/bootstrap_ci")
    p.add_argument("--pooling", default="cls", choices=["cls", "mean"])
    p.add_argument("--n-boot", type=int, default=2000)
    p.add_argument("--seed", type=int, default=42)
    p.add_argument("--include-3b", action="store_true")
    a = p.parse_args()
    R = a.results_root
    rng = np.random.default_rng(a.seed)
    rows = []
    for m in (MODELS_WITH_3B if a.include_3b else MODELS):
        for ds in DATASETS:
            test = pd.read_csv(os.path.join(a.data_dir, ds, "test.csv"))
            y = test["label"].astype(int).to_numpy()
            sc, layers = {}, {}
            for key, stage in (("pre_probe", "pretrained"), ("ft_probe", "finetuned")):
                try:
                    sc[key], layers[key] = probe_scores(R, stage, m, ds, a.pooling, test)
                except FileNotFoundError:
                    print(f"SKIP {m}/{ds}/{key}: files missing")
            pp = os.path.join(R, m, ds, "test_predictions.csv")
            if os.path.exists(pp):
                pred = pd.read_csv(pp)
                if [str(i) for i in pred["id"]] != [str(i) for i in test["id"]]:
                    raise ValueError(f"{pp} rows differ from test.csv (stale run?)")
                sc["ft_cls"] = pred["prob"].to_numpy()
            if not sc:
                continue
            boots = paired_bootstrap(y, sc, a.n_boot, rng)
            row = {"model": m, "dataset": ds, "pooling": a.pooling, "n_test": len(y), "n_pos": int(y.sum()),
                   "n_boot": a.n_boot, "probe_layers": layers}
            for k in sc:
                row[k] = {"auroc": auroc(y, sc[k]), "ci95": ci(boots[k])}
            for lhs in ("ft_probe", "ft_cls"):
                if lhs in sc and "pre_probe" in sc:
                    diff = boots[lhs] - boots["pre_probe"]
                    row[f"{lhs}_minus_pre_probe"] = {"diff": row[lhs]["auroc"] - row["pre_probe"]["auroc"], "ci95": ci(diff)}
            rows.append(row)
            print(m, ds, {k: round(row[k]["auroc"], 3) for k in sc})
    os.makedirs(a.output_dir, exist_ok=True)
    with open(os.path.join(a.output_dir, f"bootstrap_ci_{a.pooling}.json"), "w") as f:
        json.dump(rows, f, indent=2)


if __name__ == "__main__":
    main()
