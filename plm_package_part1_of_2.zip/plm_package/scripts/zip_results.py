"""
zip_results.py — package the results directory for download from SageMaker.

Excludes:
  - *.npy, *.pkl  (large embedding files)
  - *.safetensors, *.bin  (model checkpoint weights)
  - config.json, tokenizer_config.json, vocab.txt,
    special_tokens_map.json, training_args.bin  (HF checkpoint artifacts)

Includes everything else under results/:
  - test_results.json, probe_results.json, ablation_cls.json
  - steering_results.json, blast_vs_plm.json
  - scaling_summary_cls.json, scaling_*.png
  - bootstrap_ci/ (if 10_bootstrap_ci.py has been run)
  - training_args.json, training_log.json, any probe PNG figures

Run from project root on SageMaker:
    python scripts/zip_results.py

Output: results_archive.zip in the project root. Download via JupyterLab file browser.
"""

import zipfile
import os
from pathlib import Path

ROOT = Path(os.environ.get("PROJECT_ROOT", ".")).resolve()
RESULTS = ROOT / "results"
OUT = ROOT / "results_archive.zip"

SKIP_EXTS = {".npy", ".pkl", ".safetensors", ".bin"}
SKIP_NAMES = {"config.json", "tokenizer_config.json", "vocab.txt",
              "special_tokens_map.json", "training_args.bin"}

if not RESULTS.exists():
    print(f"No results/ directory at {RESULTS}")
    raise SystemExit(1)

added = 0
skipped = 0

with zipfile.ZipFile(OUT, "w", zipfile.ZIP_DEFLATED) as zf:
    for p in sorted(RESULTS.rglob("*")):
        if not p.is_file():
            continue
        if p.suffix in SKIP_EXTS or p.name in SKIP_NAMES:
            skipped += 1
            continue
        rel = p.relative_to(ROOT)
        arc_name = "/".join(rel.parts)  # forward slashes for Linux unzip
        zf.write(p, arc_name)
        print(f"  {arc_name}  ({p.stat().st_size:,} bytes)")
        added += 1

size_mb = OUT.stat().st_size / 1_048_576
print(f"\nAdded {added} files  (skipped {skipped} large/checkpoint files)")
print(f"Saved: {OUT}  ({size_mb:.1f} MB)")
print("Download via JupyterLab file browser → right-click → Download.")
