"""
Dataset 5 -- ProteinMPNN "stealth toxin" stress test (one-class; all label=1).

Question: does a probe trained on D1 still fire on sequences that keep a pore-forming-toxin BACKBONE but have no
detectable sequence homology to known toxins or to ANY D1 sequence?

Design (every choice below fixes a defect of the earlier version):
  1. Seeds  : curated PDB entries; ONE chain per entry (first chain with >=30 residues); RCSB resolution check
              (X-ray and cryo-EM cut-offs applied by experimental method); chain-only PDB is written so ProteinMPNN
              never emits multi-chain ('/') sequences.
  2. Pilot  : the sampling temperature is chosen from a grid on a few parents, using pairwise identity computed
              WITHIN each parent (designs on the same backbone), never pooled across parents.
  3. Design : N sequences per parent, fixed seed; the native/input record of the .fa file is discarded.
  4. Novelty: a design is kept only if blastp finds (a) no UniProt-toxin hit at e<=evalue and (b) no hit with
              identity >= max-identity against ANY D1 sequence (train+val+test), since D5 is evaluated with
              probes trained on D1 and every D1 sequence is "known" to the pipeline.
  5. Fold   : ESMFold; keep mean pLDDT >= min-plddt AND TM-score (normalised by PARENT length) >= min-tm.
              (TM-score of a low-confidence prediction is meaningless, hence the pLDDT gate.)
  6. Balance: at most --max-per-parent designs per parent (highest pLDDT first) so one parent cannot dominate;
              parent identity (global NW) and parent-level metadata are recorded.  Evaluation is parent-clustered.

Requires (not installable in the offline authoring sandbox, see install_biotools.sh / setup_dataset5.sh):
  ProteinMPNN repo, NCBI BLAST+, torch + fair-esm (ESMFold), tmtools, requests.
Steps are cached in --output-dir; use --step N to run a single step, 0 = all.
"""
import argparse
import json
import os
import subprocess
import sys
import time

import numpy as np
import pandas as pd

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import d5_helpers as H  # noqa: E402

# Curated PFT structures spanning beta-barrel / alpha-helical / CDC / MACPF / actinoporin / Cry families.
CURATED_PDBS = [
    "7AHL", "1PRE", "1QOY", "2WCD", "1ACC", "1PFO", "4CDB", "5JZT",
    "6MYI", "4OEB", "4MJT", "3LIM", "1IAZ", "1GWY", "2C9K", "1DLC",
]


def parse_args():
    p = argparse.ArgumentParser()
    p.add_argument("--d1-dir", default="data/splits/pft", help="D1 split dir (train/val/test.csv); ALL are 'known'")
    p.add_argument("--output-dir", default="data/raw/dataset5")
    p.add_argument("--output-csv", default="data/splits/dataset5/stress_test.csv")
    p.add_argument("--n-seqs-per-parent", type=int, default=40)
    p.add_argument("--max-per-parent", type=int, default=10)
    p.add_argument("--temperature", type=float, default=None, help="skip the pilot and use this temperature")
    p.add_argument("--temps", type=float, nargs="+", default=[0.1, 0.2, 0.3, 0.5])
    p.add_argument("--pilot-parents", type=int, default=5)
    p.add_argument("--pilot-n", type=int, default=8)
    p.add_argument("--max-resolution-xray", type=float, default=3.5)
    p.add_argument("--max-resolution-em", type=float, default=4.0)
    p.add_argument("--blast-toxin-evalue", type=float, default=1e-3)
    p.add_argument("--max-identity", type=float, default=0.25, help="max identity to any D1 sequence (fraction)")
    p.add_argument("--no-novelty-filter", action="store_true",
                   help="step 3: keep every design; toxin_hit and max_identity_d1 are annotations, not filters")
    p.add_argument("--fold-per-parent", type=int, default=None,
                   help="step 4: fold only the N designs per parent with the lowest max_identity_d1")
    p.add_argument("--min-tm", type=float, default=0.5)
    p.add_argument("--min-plddt", type=float, default=70.0)
    p.add_argument("--seed", type=int, default=42)
    p.add_argument("--step", type=int, default=0)
    p.add_argument("--proteinmpnn-path", default="ProteinMPNN")
    p.add_argument("--uniprot-toxin-db", default="data/raw/uniprot_toxin_seqs.fasta")
    return p.parse_args()


def _get(url, timeout=30, retries=3):
    import requests
    for k in range(retries):
        try:
            r = requests.get(url, timeout=timeout)
            if r.status_code == 200:
                return r
        except requests.RequestException:
            pass
        time.sleep(2 * (k + 1))
    return None


# --------------------------------------------------------------------------- step 1
def step1_seeds(a):
    path = os.path.join(a.output_dir, "seeds.csv")
    pdb_dir = os.path.join(a.output_dir, "pdb")
    os.makedirs(pdb_dir, exist_ok=True)
    rows, rejected = [], []
    for pid in CURATED_PDBS:
        r = _get(f"https://data.rcsb.org/rest/v1/core/entry/{pid}")
        if r is None:
            rejected.append((pid, "no RCSB entry json")); continue
        res, method = H.rcsb_resolution(r.json())
        if not H.passes_resolution(res, method, a.max_resolution_xray, a.max_resolution_em):
            rejected.append((pid, f"resolution {res} / {method}")); continue
        r = _get(f"https://files.rcsb.org/download/{pid}.pdb")
        if r is None:
            rejected.append((pid, "no pdb file")); continue
        text = r.text
        fc = H.first_chain(text, min_len=30)
        if fc is None:
            rejected.append((pid, "no chain >=30 aa")); continue
        chain, seq, xyz = fc
        # chain-only PDB (ATOM lines of the chosen chain, first model) so ProteinMPNN sees a single chain
        keep = []
        for line in text.splitlines():
            if line.startswith("ENDMDL"):
                break
            if line.startswith("ATOM") and line[21] == chain and line[16] in (" ", "A"):
                keep.append(line)
        chain_pdb = os.path.join(pdb_dir, f"{pid}_{chain}.pdb")
        with open(chain_pdb, "w") as f:
            f.write("\n".join(keep) + "\nEND\n")
        rows.append({"parent_pdb": pid, "chain": chain, "sequence": seq, "length": len(seq),
                     "resolution": res, "method": method, "ss_class": H.ss_class(text, chain),
                     "pdb_path": chain_pdb})
    df = pd.DataFrame(rows)
    df.to_csv(path, index=False)
    json.dump(rejected, open(os.path.join(a.output_dir, "seeds_rejected.json"), "w"), indent=2)
    print(f"[step1] {len(df)} seeds kept, {len(rejected)} rejected")
    return df


# --------------------------------------------------------------------------- step 2
def _run_pmpnn(a, pdb_path, out_folder, n, temp, seed):
    os.makedirs(out_folder, exist_ok=True)
    cmd = [sys.executable, os.path.join(a.proteinmpnn_path, "protein_mpnn_run.py"), "--pdb_path", pdb_path,
           "--out_folder", out_folder, "--num_seq_per_target", str(n), "--sampling_temp", str(temp),
           "--seed", str(seed), "--batch_size", "1"]
    r = subprocess.run(cmd, capture_output=True, text=True)
    if r.returncode != 0:
        raise RuntimeError(f"ProteinMPNN failed for {pdb_path}: {r.stderr[-500:]}")
    fa = os.path.join(out_folder, "seqs", os.path.splitext(os.path.basename(pdb_path))[0] + ".fa")
    return H.parse_pmpnn_designed(open(fa).read())


def step2_design(a, seeds):
    path = os.path.join(a.output_dir, "designs.csv")
    temp = a.temperature
    if temp is None:
        per_parent = {t: [] for t in a.temps}
        for _, s in seeds.head(a.pilot_parents).iterrows():
            for t in a.temps:
                per_parent[t].append(_run_pmpnn(a, s.pdb_path, os.path.join(a.output_dir, "pilot", f"T{t}", s.parent_pdb),
                                                a.pilot_n, t, a.seed))
        temp, summ = H.choose_temperature(per_parent)
        json.dump({"chosen": temp, "mean_within_parent_identity": {str(k): v for k, v in summ.items()}},
                  open(os.path.join(a.output_dir, "temperature_pilot.json"), "w"), indent=2)
        print(f"[step2] pilot temperature {temp}  {summ}")
    rows = []
    for _, s in seeds.iterrows():
        seqs = _run_pmpnn(a, s.pdb_path, os.path.join(a.output_dir, "pmpnn", s.parent_pdb), a.n_seqs_per_parent, temp, a.seed)
        for q in dict.fromkeys(seqs):  # de-duplicate, keep order
            rows.append({"parent_pdb": s.parent_pdb, "sequence": q, "temperature": temp,
                         "identity_to_parent": H.identity_nw(q, s.sequence)})
    df = pd.DataFrame(rows).drop_duplicates("sequence").reset_index(drop=True)
    df["design_id"] = [f"d5_{i:05d}" for i in range(len(df))]
    df.to_csv(path, index=False)
    print(f"[step2] {len(df)} unique designs")
    return df


# --------------------------------------------------------------------------- step 3
def _blast(a, queries, subject_fasta, evalue, tag):
    """Return {query_id: (best_pident_fraction, best_evalue)} over all hits (absent = no hit)."""
    wd = os.path.join(a.output_dir, "blast"); os.makedirs(wd, exist_ok=True)
    q = os.path.join(wd, f"{tag}_q.fa"); out = os.path.join(wd, f"{tag}.tsv"); db = os.path.join(wd, f"{tag}_db")
    with open(q, "w") as f:
        for i, s in queries:
            f.write(f">{i}\n{s}\n")
    subprocess.run(["makeblastdb", "-in", subject_fasta, "-dbtype", "prot", "-out", db], check=True, capture_output=True)
    subprocess.run(["blastp", "-query", q, "-db", db, "-evalue", str(evalue), "-outfmt", "6 qseqid pident evalue",
                    "-max_target_seqs", "500", "-out", out, "-num_threads", "4"], check=True, capture_output=True)
    best = {}
    for line in open(out):
        qid, pid, ev = line.split("\t")[:3]
        pid, ev = float(pid) / 100.0, float(ev)
        if qid not in best or pid > best[qid][0]:
            best[qid] = (pid, ev)
    return best


def step3_novelty(a, designs):
    path = os.path.join(a.output_dir, "novel.csv")
    qs = list(zip(designs.design_id, designs.sequence))
    tox = _blast(a, qs, a.uniprot_toxin_db, a.blast_toxin_evalue, "toxin")
    d1 = pd.concat([pd.read_csv(os.path.join(a.d1_dir, f"{sp}.csv")) for sp in ("train", "val", "test")])
    d1_fa = os.path.join(a.output_dir, "blast", "d1_all.fa"); os.makedirs(os.path.dirname(d1_fa), exist_ok=True)
    with open(d1_fa, "w") as f:
        for i, s in zip(d1["id"], d1["sequence"]):
            f.write(f">{i}\n{s}\n")
    # e-value 10: we want ANY detectable similarity to D1, then threshold on identity ourselves
    k1 = _blast(a, qs, d1_fa, 10.0, "d1")
    designs["toxin_hit"] = designs.design_id.map(lambda i: i in tox)
    designs["max_identity_d1"] = designs.design_id.map(lambda i: k1.get(i, (0.0, None))[0])
    if a.no_novelty_filter:
        keep = designs.copy()
    else:
        keep = designs[(~designs.toxin_hit) & (designs.max_identity_d1 < a.max_identity)].copy()
    keep.to_csv(path, index=False)
    print(f"[step3] {len(designs)} -> {len(keep)} novel (toxin hits {int(designs.toxin_hit.sum())}, "
          f">= {a.max_identity:.0%} to D1: {int((designs.max_identity_d1 >= a.max_identity).sum())})")
    return keep


# --------------------------------------------------------------------------- step 4
def step4_fold(a, novel, seeds):
    import torch
    from transformers import EsmForProteinFolding
    from tmtools import tm_align
    path = os.path.join(a.output_dir, "folded.csv")
    if a.fold_per_parent:
        novel = (novel.sort_values(["parent_pdb", "max_identity_d1", "design_id"])
                 .groupby("parent_pdb").head(a.fold_per_parent).reset_index(drop=True))
        print(f"[step4] folding {len(novel)} designs ({a.fold_per_parent} lowest-identity per parent)")
    model = EsmForProteinFolding.from_pretrained("facebook/esmfold_v1", low_cpu_mem_usage=True).eval()
    if torch.cuda.is_available():
        model = model.cuda()
        model.esm = model.esm.half()   # memory saving on a T4
    model.trunk.set_chunk_size(64)     # avoids OOM on long sequences
    seed_xyz = {r.parent_pdb: H.pdb_chains(open(r.pdb_path).read())[r.chain][1] for r in seeds.itertuples()}
    seed_seq = dict(zip(seeds.parent_pdb, seeds.sequence))
    seed_ss = dict(zip(seeds.parent_pdb, seeds.ss_class))
    rows = []
    for r in novel.itertuples():
        with torch.no_grad():
            pdb = model.infer_pdb(r.sequence)
        plddt = H.mean_bfactor_ca(pdb)
        if plddt <= 1.0 + 1e-6:  # some versions store 0-1
            plddt *= 100.0
        chains = H.pdb_chains(pdb)
        ch = next(iter(chains))
        xyz = chains[ch][1]
        tm = tm_align(xyz, seed_xyz[r.parent_pdb], r.sequence, seed_seq[r.parent_pdb]).tm_norm_chain2
        rows.append({**r._asdict(), "plddt": plddt, "tm_score": float(tm), "ss_class": seed_ss[r.parent_pdb]})
    df = pd.DataFrame(rows).drop(columns=["Index"])
    df.to_csv(path, index=False)
    return df


# --------------------------------------------------------------------------- step 5
def step5_write(a, folded):
    ok = folded[(folded.plddt >= a.min_plddt) & (folded.tm_score >= a.min_tm)]
    ok = ok.sort_values(["parent_pdb", "plddt"], ascending=[True, False]).groupby("parent_pdb").head(a.max_per_parent)
    out = pd.DataFrame({
        "id": ok.design_id, "sequence": ok.sequence, "label": 1, "parent_pdb": ok.parent_pdb,
        "parent_ss_class": ok.ss_class, "tm_score": ok.tm_score.round(4), "plddt": ok.plddt.round(2),
        "identity_to_parent": ok.identity_to_parent.round(4), "max_identity_d1": ok.max_identity_d1.round(4),
        "temperature": ok.temperature, "length": ok.sequence.str.len()})
    os.makedirs(os.path.dirname(a.output_csv), exist_ok=True)
    out.to_csv(a.output_csv, index=False)
    rep = {"n_final": len(out), "n_parents": int(out.parent_pdb.nunique()),
           "per_parent": out.parent_pdb.value_counts().to_dict(), "thresholds": vars(a)}
    json.dump(rep, open(os.path.join(a.output_dir, "build_report.json"), "w"), indent=2, default=str)
    print(f"[step5] wrote {a.output_csv}: {len(out)} designs from {out.parent_pdb.nunique()} parents")
    if out.parent_pdb.nunique() < 5:
        print("WARNING: fewer than 5 parents -- parent-clustered CIs will be very wide; report accordingly")


def main():
    a = parse_args()
    os.makedirs(a.output_dir, exist_ok=True)
    rd = lambda n: pd.read_csv(os.path.join(a.output_dir, n))
    s = a.step
    seeds = step1_seeds(a) if s in (0, 1) else rd("seeds.csv")
    if s in (0, 2):
        designs = step2_design(a, seeds)
    elif s > 2:
        designs = rd("designs.csv")
    if s in (0, 3):
        novel = step3_novelty(a, designs)
    elif s > 3:
        novel = rd("novel.csv")
    if s in (0, 4):
        folded = step4_fold(a, novel, seeds)
    elif s > 4:
        folded = rd("folded.csv")
    if s in (0, 5):
        step5_write(a, folded)


if __name__ == "__main__":
    main()
