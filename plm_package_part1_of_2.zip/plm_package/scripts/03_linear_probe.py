"""
Train MMProbe and LRProbe at every layer on TRAIN, report AUROC/MCC on val and test, save MM directions.
Layer selection downstream is by VAL AUROC only.

    python scripts/03_linear_probe.py --embeddings-dir results/embeddings/pretrained/esm2_8m/pft \
        --output-dir results/probes/pretrained/esm2_8m/pft --dataset pft --pooling both --save-directions
"""
import argparse
import json
import os

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from sklearn.metrics import matthews_corrcoef

from plm_common import (LRProbe, MMProbe, SPLITS, auroc, check_embeddings_match, best_layer_by_val,
                        load_pkl, splits_manifest)


def probe_all_layers(train_X, train_y, val_X, val_y, test_X, test_y):
    results = []
    for layer in range(train_X.shape[1]):
        tr, va, te = train_X[:, layer, :], val_X[:, layer, :], test_X[:, layer, :]
        mm = MMProbe().fit(tr, train_y)
        lr = LRProbe().fit(tr, train_y)
        results.append({
            "layer": layer,
            "mm_val_auroc": auroc(val_y, mm.score(va)),
            "mm_auroc": auroc(test_y, mm.score(te)),
            "mm_mcc": float(matthews_corrcoef(test_y, mm.predict(te))),
            "mm_threshold": mm.threshold,
            "lr_val_auroc": auroc(val_y, lr.predict_proba(va)),
            "lr_auroc": auroc(test_y, lr.predict_proba(te)),
            "lr_mcc": float(matthews_corrcoef(test_y, lr.predict(te))),
            "mm_degenerate": bool(mm.degenerate),
            "mm_direction": mm.direction,
        })
    return results


def plot_results(results, pooling, out_dir, dataset):
    layers = [r["layer"] for r in results]
    fig, axes = plt.subplots(1, 2, figsize=(12, 4))
    for ax, metric, label in [(axes[0], "auroc", "AUROC"), (axes[1], "mcc", "MCC")]:
        ax.plot(layers, [r[f"mm_{metric}"] for r in results], "o-", label="MMProbe")
        ax.plot(layers, [r[f"lr_{metric}"] for r in results], "s--", label="LRProbe")
        if metric == "auroc":
            ax.axhline(0.5, color="gray", linestyle=":")
        ax.set_xlabel("Layer"); ax.set_ylabel(label); ax.set_title(f"{dataset} - {pooling} - {label}"); ax.legend()
    plt.tight_layout()
    plt.savefig(os.path.join(out_dir, f"probe_{pooling}_{dataset}.png"), dpi=120)
    plt.close()


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--embeddings-dir", required=True)
    p.add_argument("--output-dir", required=True)
    p.add_argument("--dataset", required=True)
    p.add_argument("--data-dir", default="data/splits", help="used to verify embeddings match the CSVs")
    p.add_argument("--pooling", default="both", choices=["cls", "mean", "both"])
    p.add_argument("--save-directions", action="store_true")
    a = p.parse_args()
    os.makedirs(a.output_dir, exist_ok=True)

    emb = {}
    for sp in SPLITS:
        emb[sp] = load_pkl(os.path.join(a.embeddings_dir, f"{sp}_embeddings.pkl"))
        df = pd.read_csv(os.path.join(a.data_dir, a.dataset, f"{sp}.csv"))
        check_embeddings_match(emb[sp], df, f"{a.dataset}/{sp}")
    y = {sp: np.asarray(emb[sp]["labels"]).astype(int) for sp in SPLITS}

    poolings = ["cls", "mean"] if a.pooling == "both" else [a.pooling]
    out = {}
    for pooling in poolings:
        res = probe_all_layers(emb["train"][pooling], y["train"], emb["val"][pooling], y["val"],
                               emb["test"][pooling], y["test"])
        b = best_layer_by_val(res, "mm")
        print(f"[{a.dataset}/{pooling}] best MM layer by val = {b['layer']}  val={b['mm_val_auroc']:.4f}  "
              f"test={b['mm_auroc']:.4f}")
        plot_results(res, pooling, a.output_dir, a.dataset)
        if a.save_directions:
            with open(os.path.join(a.output_dir, f"mm_directions_{pooling}.json"), "w") as f:
                json.dump({r["layer"]: r["mm_direction"].tolist() for r in res}, f)
            with open(os.path.join(a.output_dir, f"mm_thresholds_{pooling}.json"), "w") as f:
                json.dump({r["layer"]: r["mm_threshold"] for r in res}, f)
        out[pooling] = [{k: v for k, v in r.items() if k != "mm_direction"} for r in res]
    out["_meta"] = {"dataset": a.dataset, "embeddings_dir": a.embeddings_dir,
                    "n": {sp: len(y[sp]) for sp in SPLITS},
                    "split_sha256": {k: v for k, v in splits_manifest(a.data_dir, [a.dataset]).items()}}
    with open(os.path.join(a.output_dir, "probe_results.json"), "w") as f:
        json.dump(out, f, indent=2)


if __name__ == "__main__":
    main()
