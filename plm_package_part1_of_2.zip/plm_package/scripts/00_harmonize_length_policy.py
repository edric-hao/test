#!/usr/bin/env python3
"""
Enforce ONE sequence policy on every dataset's split files:  MIN <= len <= 1022 residues AND only the 20 standard
amino acids (ambiguous/rare codes X, U, B, Z, O occurred only in D4 POSITIVES, i.e. a label-correlated token shortcut),
and make ids unique within a dataset (TCDB accessions are shared by several sequences in D1).

Why: D4 (built in the notebook) keeps sequences up to 6000 residues (windowed), while D1-D3 are
capped at 1022.  Fine-tuning and fine-tuned-embedding extraction TRUNCATE at 1022, whereas
pretrained extraction windows - so for D4's 149 long sequences the pretrained and fine-tuned
representations were computed over different inputs, and the 'control' task had a different length
regime from the harm tasks.  Filtering everything to <=1022 makes truncation, windowing and
fine-tuning equivalent (windowing remains only for D5 / external sequences).

Idempotent. Pass --backup-dir to keep a copy of the files before the first modification.
Run BEFORE the leakage check and before any embedding/fine-tuning step.
"""
import argparse, os, shutil, json
import pandas as pd

DATASETS = {"pft": 20, "virulence": 20, "peptide_tox": 5, "signal_peptide": 20}
SPLITS = ["train", "val", "test"]
STD = set("ACDEFGHIKLMNPQRSTVWY")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data-dir", default="data/splits")
    ap.add_argument("--max-len", type=int, default=1022)
    ap.add_argument("--report", default="data/provenance/length_policy_report.json")
    ap.add_argument("--backup-dir", default=None)
    a = ap.parse_args()

    backup = a.backup_dir
    report = {}
    if os.path.exists(a.report):  # idempotent re-runs must not erase the record of the first (modifying) run
        report = json.load(open(a.report))
    for ds, min_len in DATASETS.items():
        d = os.path.join(a.data_dir, ds)
        if not os.path.isdir(d):
            continue
        if backup and not os.path.exists(os.path.join(backup, ds)):
            shutil.copytree(d, os.path.join(backup, ds))
        frames = {}
        for sp in SPLITS:
            path = os.path.join(d, f"{sp}.csv")
            if not os.path.exists(path):
                continue
            df = pd.read_csv(path)
            L = df["sequence"].str.len()
            keep = (L >= min_len) & (L <= a.max_len) & df["sequence"].apply(lambda q: set(q) <= STD)
            if (~keep).any():
                lab = df.loc[~keep, "label"].value_counts().to_dict()
                report[f"{ds}/{sp}"] = {"dropped": int((~keep).sum()), "by_label": {str(k): int(v) for k, v in lab.items()},
                                        "kept": int(keep.sum())}
                print(f"  {ds}/{sp}: dropped {int((~keep).sum())} (labels {lab}), kept {int(keep.sum())}")
                df = df[keep].reset_index(drop=True)
                df.to_csv(path, index=False)
            frames[sp] = df
        # unique ids within a dataset: later occurrences of an id get a deterministic suffix
        seen = {}
        for sp in SPLITS:
            if sp not in frames:
                continue
            df, changed, ids = frames[sp], False, []
            for i in df["id"].astype(str):
                seen[i] = seen.get(i, 0) + 1
                ids.append(i if seen[i] == 1 else f"{i}#dup{seen[i] - 1}")
                changed |= seen[i] > 1
            if changed:
                df = df.copy()
                df["id"] = ids
                df.to_csv(os.path.join(d, f"{sp}.csv"), index=False)
                report.setdefault(f"{ds}/{sp}", {})["ids_made_unique"] = True
                print(f"  {ds}/{sp}: ids made unique")
    os.makedirs(os.path.dirname(a.report), exist_ok=True)
    json.dump(report, open(a.report, "w"), indent=2)
    print("length policy enforced; report ->", a.report)


if __name__ == "__main__":
    main()
