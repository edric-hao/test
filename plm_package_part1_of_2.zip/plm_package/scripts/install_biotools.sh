#!/usr/bin/env bash
# Bioinformatics tools. mmseqs2 + BLAST+ are REQUIRED for the pipeline (homology audit, D3 BLAST baseline);
# cd-hit and Phobius are only needed to rebuild datasets (data_construction/).
set -euo pipefail
if command -v conda >/dev/null; then
  conda install -y -c conda-forge -c bioconda mmseqs2 blast cd-hit
elif command -v apt-get >/dev/null; then
  sudo apt-get update && sudo apt-get install -y mmseqs2 ncbi-blast+ cd-hit
else
  echo "Install mmseqs2, NCBI BLAST+ (and optionally cd-hit) manually." >&2; exit 1
fi
echo "Phobius (dataset rebuild only) requires a licence-gated download: https://software.sbc.su.se/phobius.html"
for t in mmseqs blastp makeblastdb; do command -v $t >/dev/null && echo "ok: $t" || echo "MISSING: $t"; done
