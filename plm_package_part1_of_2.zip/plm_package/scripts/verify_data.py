"""
Integrity checks on the frozen split files + SHA256 manifest handling.

    python scripts/verify_data.py                 # check the splits against data/MANIFEST.sha256 and run all sanity checks
    python scripts/verify_data.py --write-manifest   # (re)write the manifest - only do this deliberately

Checks per dataset: required columns, no extra label-derived columns, binary labels, both classes in every split,
unique ids within a dataset, standard amino acids only, length policy (MIN..1022), no exact duplicate sequences
(within or across splits of one dataset), no sequence with conflicting labels.
Exit status 1 on any failure.
"""
import argparse
import os
import sys

import pandas as pd

from plm_common import DATASETS, SPLITS, MAX_LEN, sha256_file

MIN_LEN = {"pft": 20, "virulence": 20, "peptide_tox": 5, "signal_peptide": 20}
ALLOWED_COLS = {"id", "sequence", "label", "in_test2", "truncated_by_esm"}
STD = set("ACDEFGHIKLMNPQRSTVWY")


def check(data_dir):
    errs = []
    for ds in DATASETS:
        dfs = {}
        for sp in SPLITS:
            p = os.path.join(data_dir, ds, f"{sp}.csv")
            if not os.path.exists(p):
                errs.append(f"missing {p}")
                continue
            df = pd.read_csv(p)
            extra = set(df.columns) - ALLOWED_COLS
            if extra or not {"id", "sequence", "label"} <= set(df.columns):
                errs.append(f"{ds}/{sp}: unexpected columns {sorted(extra)} or missing required ones")
            if not set(df["label"].unique()) <= {0, 1} or df["label"].nunique() < 2:
                errs.append(f"{ds}/{sp}: labels must be binary with both classes present")
            if df["sequence"].isna().any() or not all(set(s) <= STD for s in df["sequence"]):
                errs.append(f"{ds}/{sp}: non-standard residues or empty sequences")
            L = df["sequence"].str.len()
            if (L < MIN_LEN[ds]).any() or (L > MAX_LEN).any():
                errs.append(f"{ds}/{sp}: length outside [{MIN_LEN[ds]}, {MAX_LEN}]")
            if df["sequence"].duplicated().any():
                errs.append(f"{ds}/{sp}: duplicate sequences inside split")
            dfs[sp] = df
        if len(dfs) == 3:
            allr = pd.concat([d.assign(split=k) for k, d in dfs.items()], ignore_index=True)
            if allr["id"].duplicated().any():
                errs.append(f"{ds}: ids not unique across splits")
            dup = allr[allr["sequence"].duplicated(keep=False)]
            if len(dup):
                errs.append(f"{ds}: {dup['sequence'].nunique()} sequences appear in more than one split")
    return errs


def manifest_lines(data_dir):
    out = []
    for ds in DATASETS:
        for sp in SPLITS:
            p = os.path.join(data_dir, ds, f"{sp}.csv")
            out.append(f"{sha256_file(p)}  splits/{ds}/{sp}.csv")
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data-dir", default="data/splits")
    ap.add_argument("--manifest", default="data/MANIFEST.sha256")
    ap.add_argument("--write-manifest", action="store_true")
    a = ap.parse_args()
    errs = check(a.data_dir)
    if a.write_manifest and not errs:
        with open(a.manifest, "w") as f:
            f.write("\n".join(manifest_lines(a.data_dir)) + "\n")
        print("manifest written:", a.manifest)
    elif not a.write_manifest:
        if not os.path.exists(a.manifest):
            errs.append(f"{a.manifest} missing")
        else:
            want = [l.strip() for l in open(a.manifest) if l.strip()]
            if want != manifest_lines(a.data_dir):
                errs.append("split files differ from MANIFEST.sha256 (data changed since freezing)")
    for e in errs:
        print("FAIL:", e)
    if errs:
        sys.exit(1)
    print("data OK")


if __name__ == "__main__":
    main()
