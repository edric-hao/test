"""
Two complementary ablation analyses on a FINE-TUNED model's representations.

Part A  (CLS pooling only)  classifier-head ablation, final layer.
    Project the final-layer MM direction out of the test CLS vectors and re-score them with the model's own
    classifier head. Compared against two nulls: K random unit directions and K label-shuffled MM directions.

Part B  per-layer LINEAR ERASURE test.
    For layer l let d_l be the MM direction (fit on train). Remove d_l from train and test representations,
    refit a standardised logistic-regression probe on the erased train reps and score the erased test reps.
        drop_l = AUROC_LR(original) - AUROC_LR(erased)
    Nulls use the IDENTICAL procedure with K random directions and K label-shuffled MM directions.
    (A mass-mean probe CANNOT be refit after erasing its own direction - the erased class means coincide by
    construction - which is why an LR probe is the read-out here.)
    A small drop means label information is also carried by other directions; it is not evidence that the MM
    direction is unimportant to the classifier (Part A tests that).

    python scripts/05_causal_ablation.py --model-dir results/esm2_8m/pft \
        --embeddings-dir results/esm2_8m/pft/embeddings \
        --directions-file results/probes/finetuned/esm2_8m/pft/mm_directions_cls.json \
        --output-dir results/ablation/esm2_8m/pft --pooling cls
"""
import argparse
import json
import os

import numpy as np

from plm_common import LRProbe, auroc, load_json, load_pkl, mm_direction, project_out, unit


def empirical_p(observed, null):
    null = np.asarray(null)
    return float((1 + np.sum(null >= observed)) / (1 + len(null)))


def null_summary(drop, null_drops):
    mu, sd = float(np.mean(null_drops)), float(np.std(null_drops))
    return {"null_mean": mu, "null_std": sd, "above_null_2sd": bool(drop > mu + 2 * sd),
            "empirical_p": empirical_p(drop, null_drops)}


def erasure_layer(Xtr, ytr, Xte, yte, d_hat, k_null, rng):
    """Erasure test for one layer (see module docstring). Returns a dict."""
    base = auroc(yte, LRProbe().fit(Xtr, ytr).predict_proba(Xte))

    def erased_auroc(d):
        pr = LRProbe().fit(project_out(Xtr, d), ytr)
        return auroc(yte, pr.predict_proba(project_out(Xte, d)))

    drop = base - erased_auroc(d_hat)
    rand_drops, shuf_drops = [], []
    for _ in range(k_null):
        r = unit(rng.standard_normal(Xtr.shape[1]))
        rand_drops.append(base - erased_auroc(r))
        ys = rng.permutation(ytr)
        shuf_drops.append(base - erased_auroc(mm_direction(Xtr, ys)))
    return {"lr_auroc_original": base, "lr_auroc_erased": base - drop, "auroc_drop": float(drop),
            "random_null": null_summary(drop, rand_drops), "shuffled_null": null_summary(drop, shuf_drops)}


def classifier_ablation(model, Xte_last, yte, Xtr_last, ytr, d_final, k_null, seed):
    """Part A. Needs torch + the fine-tuned model (head = model.classifier)."""
    import torch

    device = next(model.parameters()).device

    def probs(X):
        out = []
        for s in range(0, len(X), 256):
            xb = torch.tensor(np.asarray(X[s:s + 256]), dtype=torch.float32, device=device).unsqueeze(1)
            with torch.no_grad():
                out.append(torch.softmax(model.classifier(xb), -1)[:, 1].cpu().numpy())
        return np.concatenate(out)

    model.eval()
    base = auroc(yte, probs(Xte_last))
    drop = base - auroc(yte, probs(project_out(Xte_last, d_final)))
    rng = np.random.default_rng(seed)
    rand = [base - auroc(yte, probs(project_out(Xte_last, unit(rng.standard_normal(Xte_last.shape[1])))))
            for _ in range(k_null)]
    shuf = [base - auroc(yte, probs(project_out(Xte_last, mm_direction(Xtr_last, rng.permutation(ytr)))))
            for _ in range(k_null)]
    return {"baseline_auroc": base, "ablated_auroc": base - drop, "auroc_drop": float(drop),
            "random_null": null_summary(drop, rand), "shuffled_null": null_summary(drop, shuf)}


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--model-dir", required=True)
    p.add_argument("--embeddings-dir", required=True)
    p.add_argument("--directions-file", required=True)
    p.add_argument("--output-dir", required=True)
    p.add_argument("--pooling", default="cls", choices=["cls", "mean"])
    p.add_argument("--k-null", type=int, default=20, help="random + shuffled null draws (Part A)")
    p.add_argument("--k-null-layer", type=int, default=10, help="null draws per layer (Part B; each is an LR fit)")
    p.add_argument("--seed", type=int, default=0)
    a = p.parse_args()
    os.makedirs(a.output_dir, exist_ok=True)

    dirs = {int(k): np.asarray(v) for k, v in load_json(a.directions_file).items()}
    tr = load_pkl(os.path.join(a.embeddings_dir, "train_embeddings.pkl"))
    te = load_pkl(os.path.join(a.embeddings_dir, "test_embeddings.pkl"))
    Xtr_all, Xte_all = tr[a.pooling], te[a.pooling]
    ytr, yte = np.asarray(tr["labels"]).astype(int), np.asarray(te["labels"]).astype(int)
    last = Xte_all.shape[1] - 1
    out = {"pooling": a.pooling}

    if a.pooling == "cls":
        import torch
        from transformers import EsmForSequenceClassification
        model = EsmForSequenceClassification.from_pretrained(a.model_dir).to(
            torch.device("cuda" if torch.cuda.is_available() else "cpu"))
        res = classifier_ablation(model, Xte_all[:, last, :], yte, Xtr_all[:, last, :], ytr,
                                  unit(dirs[last]), a.k_null, a.seed)
        out["classifier_ablation"] = {"probe_layer": last, **res}
        print(f"[classifier] AUROC {res['baseline_auroc']:.4f} -> {res['ablated_auroc']:.4f}  "
              f"drop {res['auroc_drop']:+.4f}  p_rand={res['random_null']['empirical_p']:.3f} "
              f"p_shuf={res['shuffled_null']['empirical_p']:.3f}")
    else:
        out["classifier_ablation"] = None  # classifier head was trained on CLS; invalid for mean pooling

    rng = np.random.default_rng(a.seed)
    rows = []
    for layer in sorted(dirs):
        if not np.any(dirs[layer]):  # degenerate layer (constant <cls> representation at layer 0): nothing to erase
            rows.append({"layer": layer, "skipped": "degenerate: class means coincide (constant representation)"})
            print(f"[erasure] layer {layer:>2}  skipped (degenerate)")
            continue
        r = erasure_layer(Xtr_all[:, layer, :], ytr, Xte_all[:, layer, :], yte, unit(dirs[layer]),
                          a.k_null_layer, rng)
        rows.append({"layer": layer, **r})
        print(f"[erasure] layer {layer:>2}  LR AUROC {r['lr_auroc_original']:.4f} -> {r['lr_auroc_erased']:.4f}  "
              f"drop {r['auroc_drop']:+.4f}  p_rand={r['random_null']['empirical_p']:.3f}")
    out["erasure_per_layer"] = rows
    with open(os.path.join(a.output_dir, f"ablation_{a.pooling}.json"), "w") as f:
        json.dump(out, f, indent=2)


if __name__ == "__main__":
    main()
