"""
Sensitivity analysis: do the probe results depend on test rows that are homologous to train/val of the same dataset?

For each dataset/pooling the layer is the one chosen by VAL AUROC in probe_results.json (never by test). The MMProbe
is refit on TRAIN at that layer and scored on (a) all test rows, (b) test rows NOT listed in
results/leakage/flagged_test_rows.json. Descriptive only: nothing is selected or tuned on the reduced set, and no
split file is changed. Reports n, class counts, AUROC (all / clean) and a 95% bootstrap CI of the difference.

    python scripts/13_leakage_sensitivity.py --model esm2_8m \
        --embeddings-template "results/embeddings/pretrained/{model}/{dataset}" \
        --probes-template "results/probes/pretrained/{model}/{dataset}"
"""
import argparse
import json
import os

import numpy as np
import pandas as pd

from plm_common import (DATASETS, MMProbe, auroc, best_layer_by_val, check_embeddings_match, load_json, load_pkl)


def sensitivity(train_X, train_y, test_X, test_y, flagged, n_boot=1000, seed=0):
    """AUROC of an MMProbe fit on train, on all test rows vs. test rows not in `flagged` (indices into test)."""
    test_y = np.asarray(test_y)
    keep = np.ones(len(test_y), bool)
    keep[np.asarray(sorted(flagged), dtype=int)] = False
    probe = MMProbe().fit(train_X, train_y)
    s = probe.score(test_X)
    out = {"n_all": int(len(test_y)), "n_flagged": int((~keep).sum()), "n_clean": int(keep.sum()),
           "auroc_all": auroc(test_y, s)}
    if keep.sum() == 0 or len(np.unique(test_y[keep])) < 2:
        out.update(auroc_clean=None, delta=None, delta_ci95=None, note="clean subset single-class or empty")
        return out
    out["auroc_clean"] = auroc(test_y[keep], s[keep])
    out["delta"] = out["auroc_clean"] - out["auroc_all"]
    rng, d = np.random.default_rng(seed), []
    n = len(test_y)
    for _ in range(n_boot):
        i = rng.integers(0, n, n)
        k = keep[i]
        if len(np.unique(test_y[i])) < 2 or len(np.unique(test_y[i][k])) < 2:
            continue
        d.append(auroc(test_y[i][k], s[i][k]) - auroc(test_y[i], s[i]))
    out["delta_ci95"] = [float(np.percentile(d, 2.5)), float(np.percentile(d, 97.5))] if len(d) >= 50 else None
    return out


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--model", required=True)
    p.add_argument("--embeddings-template", default="results/embeddings/pretrained/{model}/{dataset}")
    p.add_argument("--probes-template", default="results/probes/pretrained/{model}/{dataset}")
    p.add_argument("--flagged", default="results/leakage/flagged_test_rows.json")
    p.add_argument("--data-dir", default="data/splits")
    p.add_argument("--output", default=None)
    p.add_argument("--n-boot", type=int, default=1000)
    a = p.parse_args()
    flagged_all = load_json(a.flagged)["rows"]
    res = {"flagged_source": a.flagged, "model": a.model, "datasets": {}}
    for ds in DATASETS:
        edir = a.embeddings_template.format(model=a.model, dataset=ds)
        pdir = a.probes_template.format(model=a.model, dataset=ds)
        if not (os.path.isdir(edir) and os.path.exists(os.path.join(pdir, "probe_results.json"))):
            print(f"[skip] {ds}: missing embeddings or probe_results.json"); continue
        pr = load_json(os.path.join(pdir, "probe_results.json"))
        emb = {sp: load_pkl(os.path.join(edir, f"{sp}_embeddings.pkl")) for sp in ("train", "test")}
        for sp in emb:
            check_embeddings_match(emb[sp], pd.read_csv(os.path.join(a.data_dir, ds, f"{sp}.csv")), f"{ds}/{sp}")
        res["datasets"][ds] = {}
        for pooling in ("cls", "mean"):
            if pooling not in pr:
                continue
            L = best_layer_by_val(pr[pooling], "mm")["layer"]
            r = sensitivity(emb["train"][pooling][:, L, :], np.asarray(emb["train"]["labels"]).astype(int),
                            emb["test"][pooling][:, L, :], np.asarray(emb["test"]["labels"]).astype(int),
                            flagged_all.get(ds, []), a.n_boot)
            r["layer_by_val"] = int(L)
            res["datasets"][ds][pooling] = r
            print(f"[{ds}/{pooling}] L{L} n_flagged={r['n_flagged']}/{r['n_all']} "
                  f"AUROC all={r['auroc_all']:.4f} clean={r['auroc_clean']}")
    out = a.output or os.path.join(os.path.dirname(a.flagged), f"sensitivity_{a.model}.json")
    json.dump(res, open(out, "w"), indent=2)
    print("wrote", out)


if __name__ == "__main__":
    main()
