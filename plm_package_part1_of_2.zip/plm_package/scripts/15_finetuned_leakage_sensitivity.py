"""
Sensitivity of the FINE-TUNED classifier to homologous test rows.

13_leakage_sensitivity.py re-scores the PRETRAINED probes without the test rows that 12_cross_dataset_leakage.py
flagged as similar to train/val of the same dataset. This script does the same for the fine-tuned classifier, using only
results/<model>/<dataset>/test_predictions.csv and results/leakage/flagged_test_rows.json (no embeddings or weights
needed). Nothing is selected or tuned on the reduced set and no split file is changed.

For every model/dataset: AUROC on all test rows, AUROC on the rows NOT flagged, the difference, and a 95% bootstrap CI
of the difference (resampling test rows; rows are treated as independent). Extra seeds (results_seed*/) are summarised
as the mean and SD of the same difference.

    python scripts/15_finetuned_leakage_sensitivity.py [--results-root results] [--data-dir data/splits]
"""
import argparse
import glob
import json
import os

import numpy as np
import pandas as pd

from plm_common import DATASETS, MODELS_WITH_3B, auroc, load_json


def read_predictions(path, test_df):
    pred = pd.read_csv(path)
    if [str(i) for i in pred["id"]] != [str(i) for i in test_df["id"]]:
        raise ValueError(f"{path}: rows differ from test.csv (stale run?)")
    return pred["label"].astype(int).to_numpy(), pred["prob"].to_numpy(dtype=float)


def clean_mask(n, flagged):
    keep = np.ones(n, bool)
    keep[np.asarray(sorted(flagged), dtype=int)] = False
    return keep


def delta_ci(y, s, keep, n_boot=1000, seed=0):
    rng, d, n = np.random.default_rng(seed), [], len(y)
    for _ in range(n_boot):
        i = rng.integers(0, n, n)
        k = keep[i]
        if len(np.unique(y[i])) < 2 or len(np.unique(y[i][k])) < 2:
            continue
        d.append(auroc(y[i][k], s[i][k]) - auroc(y[i], s[i]))
    return [float(np.percentile(d, 2.5)), float(np.percentile(d, 97.5))] if len(d) >= 50 else None


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--results-root", default="results")
    p.add_argument("--data-dir", default="data/splits")
    p.add_argument("--flagged", default=None, help="default: <results-root>/leakage/flagged_test_rows.json")
    p.add_argument("--output-dir", default=None, help="default: <results-root>/leakage")
    p.add_argument("--models", nargs="+", default=MODELS_WITH_3B)
    p.add_argument("--n-boot", type=int, default=1000)
    a = p.parse_args()
    R = a.results_root
    flagged_path = a.flagged or os.path.join(R, "leakage", "flagged_test_rows.json")
    out_dir = a.output_dir or os.path.join(R, "leakage")
    flagged = load_json(flagged_path)
    seed_roots = sorted(glob.glob(R + "_seed*"))
    out = {"flagged_source": flagged_path, "flagged_method": flagged.get("method"), "flagged_params": flagged.get("params"),
           "n_boot": a.n_boot, "models": {}}
    for m in a.models:
        for ds in DATASETS:
            test = pd.read_csv(os.path.join(a.data_dir, ds, "test.csv"))
            keep = clean_mask(len(test), flagged["rows"][ds])
            path = os.path.join(R, m, ds, "test_predictions.csv")
            if not os.path.exists(path):
                continue
            y, s = read_predictions(path, test)
            if len(np.unique(y[keep])) < 2:
                continue
            e = {"n_all": int(len(y)), "n_flagged": int((~keep).sum()), "n_clean": int(keep.sum()),
                 "n_clean_pos": int(y[keep].sum()), "n_clean_neg": int((1 - y[keep]).sum()),
                 "auroc_all": auroc(y, s), "auroc_clean": auroc(y[keep], s[keep])}
            e["delta"] = e["auroc_clean"] - e["auroc_all"]
            e["delta_ci95"] = delta_ci(y, s, keep, a.n_boot)
            deltas = {}
            for sr in seed_roots:
                sp = os.path.join(sr, m, ds, "test_predictions.csv")
                if os.path.exists(sp):
                    ys, ss = read_predictions(sp, test)
                    deltas[sr.rsplit("seed", 1)[1]] = auroc(ys[keep], ss[keep]) - auroc(ys, ss)
            if deltas:
                v = np.array(list(deltas.values()))
                e["extra_seeds_delta"] = {"per_seed": deltas, "mean": float(v.mean()), "sd": float(v.std(ddof=1))}
            out["models"].setdefault(m, {})[ds] = e
    os.makedirs(out_dir, exist_ok=True)
    with open(os.path.join(out_dir, "finetuned_sensitivity.json"), "w") as f:
        json.dump(out, f, indent=2)
    lines = ["| dataset | model | clean rows (pos/neg) | AUROC all | AUROC clean | change [95% CI] | extra seeds: mean change (SD) |",
             "|---|---|---|---|---|---|---|"]
    for ds in DATASETS:
        for m in a.models:
            e = out["models"].get(m, {}).get(ds)
            if not e:
                continue
            ci = e["delta_ci95"]
            sd = e.get("extra_seeds_delta")
            lines.append(f"| {ds} | {m} | {e['n_clean']} ({e['n_clean_pos']}/{e['n_clean_neg']}) | {e['auroc_all']:.3f} | "
                         f"{e['auroc_clean']:.3f} | {e['delta']:+.3f} [{ci[0]:+.3f}, {ci[1]:+.3f}] | "
                         + (f"{sd['mean']:+.3f} ({sd['sd']:.3f})" if sd else "n/a") + " |")
    with open(os.path.join(out_dir, "finetuned_sensitivity.md"), "w") as f:
        f.write("Fine-tuned classifier test AUROC on all rows vs rows not flagged as homologous to train/val "
                f"({flagged.get('method')}, {flagged.get('params')}).\n\n" + "\n".join(lines) + "\n")
    print("\n".join(lines))


if __name__ == "__main__":
    main()
