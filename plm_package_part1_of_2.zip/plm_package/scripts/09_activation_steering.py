"""
Linear read-out sensitivity ("steering") of the PRETRAINED model's final-layer CLS representation.

A direction d_src (unit MM direction of task `src`, final layer, fit on train) is added with strength alpha to
the CLS hidden state at the INPUT of the final LayerNorm (emb_layer_norm_after); we measure the change in the
projection of the resulting final CLS vector on each task's probe direction d_eval, on neutral sequences
(signal-peptide test negatives).

Interpretation (be careful in the paper): LayerNorm is locally affine, so to first order
    delta_proj ~ (alpha / sigma) * d_eval^T diag(gamma) (I - 11^T/D) d_src
i.e. a gamma-weighted cosine between the two directions. This experiment therefore measures how the probe
read-outs are coupled in representation space (a geometric property), NOT downstream behaviour of the network:
nothing after the injection point is computed. Each record stores cos(d_src, d_eval) so the reported delta can be
compared against the geometric prediction.

Nulls (mean/SD over K draws of the same alpha):
  * random   : isotropic random unit directions
  * shuffled : MM directions fitted on the source task's TRAIN embeddings with permuted labels
               (matched to the statistics of real MM directions; needs results/embeddings/pretrained/.../train)
z-scores are reported against both.

    python scripts/09_activation_steering.py --model-id facebook/esm2_t6_8M_UR50D --model-short esm2_8m
"""
import argparse
import json
import os

import numpy as np
import pandas as pd
import torch
from transformers import AutoTokenizer, EsmModel

from plm_common import DATASETS, MAX_LEN, load_json, load_pkl, mm_direction, unit

ALPHAS = [0.0, 1.0, 2.0, 5.0]


def final_cls(model, tok, seqs, device, alpha, direction, batch_size):
    handle = None
    if direction is not None and alpha != 0.0:
        d_t = torch.tensor(direction, dtype=torch.float32, device=device)

        def hook(module, args):
            hs = args[0].clone()
            hs[:, 0, :] += alpha * d_t
            return (hs,) + tuple(args[1:])

        handle = model.encoder.emb_layer_norm_after.register_forward_pre_hook(hook)
    out = []
    try:
        for i in range(0, len(seqs), batch_size):
            enc = tok(seqs[i:i + batch_size], return_tensors="pt", truncation=True, max_length=MAX_LEN + 2, padding=True)
            enc = {k: v.to(device) for k, v in enc.items()}
            with torch.no_grad():
                out.append(model(**enc).last_hidden_state[:, 0, :].float().cpu().numpy())
    finally:
        if handle is not None:
            handle.remove()
    return np.concatenate(out).astype(np.float64)


def zscore(x, null):
    null = np.asarray(null, dtype=np.float64)
    return float((x - null.mean()) / (null.std() + 1e-12)) if len(null) else None


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--model-id", required=True)
    p.add_argument("--model-short", required=True)
    p.add_argument("--results-root", default="results")
    p.add_argument("--data-dir", default="data/splits")
    p.add_argument("--output-dir", default=None)
    p.add_argument("--n-null", type=int, default=20)
    p.add_argument("--max-neutral", type=int, default=100)
    p.add_argument("--batch-size", type=int, default=16)
    p.add_argument("--seed", type=int, default=42)
    a = p.parse_args()
    R, m = a.results_root, a.model_short
    out_dir = a.output_dir or os.path.join(R, "steering", m)
    os.makedirs(out_dir, exist_ok=True)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

    dirs, train = {}, {}
    for t in DATASETS:
        pd_dir = os.path.join(R, "probes", "pretrained", m, t)
        raw = load_json(os.path.join(pd_dir, "mm_directions_cls.json"))
        last = max(int(k) for k in raw)
        dirs[t] = unit(raw[str(last)])
        e = load_pkl(os.path.join(R, "embeddings", "pretrained", m, t, "train_embeddings.pkl"))
        train[t] = (np.asarray(e["cls"][:, -1, :], dtype=np.float64), np.asarray(e["labels"]).astype(int))
        # the final-layer CLS saved by 02 is the quantity probed here; its direction must match the saved one
        if abs(float(mm_direction(*train[t]) @ dirs[t]) - 1.0) > 1e-4:
            raise ValueError(f"saved final-layer direction for {t} does not equal MM direction of train embeddings")

    neutral = pd.read_csv(os.path.join(a.data_dir, "signal_peptide", "test.csv"))
    seqs = neutral.loc[neutral["label"] == 0, "sequence"].head(a.max_neutral).tolist()
    tok = AutoTokenizer.from_pretrained(a.model_id)
    model = EsmModel.from_pretrained(a.model_id, torch_dtype=torch.float32, add_pooling_layer=False).to(device).eval()
    base = final_cls(model, tok, seqs, device, 0.0, None, a.batch_size)
    base_proj = {t: float((base @ d).mean()) for t, d in dirs.items()}

    rng = np.random.default_rng(a.seed)
    records = []

    def run(kind, source, d_src, src_task=None):
        cache = {0.0: base}
        for alpha in ALPHAS:
            if alpha not in cache:
                cache[alpha] = final_cls(model, tok, seqs, device, alpha, d_src, a.batch_size)
            for t, d_eval in dirs.items():
                records.append({"kind": kind, "source": source, "source_task": src_task, "eval_task": t,
                                "alpha": alpha, "delta": float((cache[alpha] @ d_eval).mean()) - base_proj[t],
                                "cos_src_eval": float(d_src @ d_eval)})

    for t, d in dirs.items():
        run("probe", t, d, t)
    for k in range(a.n_null):
        run("random", f"random_{k}", unit(rng.standard_normal(len(next(iter(dirs.values()))))))
    for t in dirs:
        X, y = train[t]
        for k in range(a.n_null):
            run("shuffled", f"shuffled_{t}_{k}", mm_direction(X, rng.permutation(y)), t)

    for r in records:
        if r["kind"] != "probe":
            continue
        rnd = [q["delta"] for q in records if q["kind"] == "random" and q["eval_task"] == r["eval_task"] and q["alpha"] == r["alpha"]]
        shf = [q["delta"] for q in records if q["kind"] == "shuffled" and q["source_task"] == r["source_task"]
               and q["eval_task"] == r["eval_task"] and q["alpha"] == r["alpha"]]
        r["z_vs_random"], r["z_vs_shuffled"] = zscore(r["delta"], rnd), zscore(r["delta"], shf)

    json.dump({"model": m, "model_id": a.model_id, "inject_point": "input of emb_layer_norm_after, CLS position",
               "interpretation": "linear read-out sensitivity (gamma-weighted cosine), not downstream behaviour",
               "alphas": ALPHAS, "n_neutral": len(seqs), "n_null": a.n_null,
               "baseline_mean_projection": base_proj, "records": records},
              open(os.path.join(out_dir, "steering_results.json"), "w"), indent=2)
    for r in records:
        if r["kind"] == "probe" and r["alpha"] == max(ALPHAS):
            print(f"{r['source']:>15} -> {r['eval_task']:<15} delta={r['delta']:+.4f} cos={r['cos_src_eval']:+.3f} "
                  f"z_rand={r['z_vs_random']:+.1f} z_shuf={r['z_vs_shuffled']:+.1f}")


if __name__ == "__main__":
    main()
