"""
BLAST nearest-neighbour annotation of the D3 (peptide_tox) TEST set, written to a SEPARATE file so the split
CSVs used for training/evaluation never change.

Reference DB = train + val (the full official CAPTP training data). This is conservative for the PLM-vs-BLAST
comparison (BLAST sees 10% more reference sequences than the probes, which train on `train` only).
For every query the BEST hit (highest bit score; ties -> higher identity) is kept.

  blast_qident = (pident/100 * alignment_length) / query_length    identity over the WHOLE query (<=1)
  identity_bin : high >= 0.50 , medium >= 0.25 , low otherwise (including no hit)

Output: results/d3_blast/test_blast.csv  (row i == row i of data/splits/peptide_tox/test.csv)

    python scripts/annotate_d3_blast.py
"""
import argparse
import io
import os
import subprocess
import tempfile

import numpy as np
import pandas as pd

COLS = ["qseqid", "sseqid", "pident", "length", "qlen", "bitscore", "evalue"]


def parse_blast_tsv(text):
    """Parse '-outfmt 6 qseqid sseqid pident length qlen bitscore evalue'; return best hit per query."""
    if not text.strip():
        return pd.DataFrame(columns=COLS)
    df = pd.read_csv(io.StringIO(text), sep="\t", header=None, names=COLS)
    df = df.sort_values(["qseqid", "bitscore", "pident"], ascending=[True, False, False], kind="stable")
    return df.drop_duplicates("qseqid", keep="first").reset_index(drop=True)


def identity_bin(qident):
    if qident is None or pd.isna(qident):
        return "low_identity"
    if qident >= 0.5:
        return "high_identity"
    if qident >= 0.25:
        return "medium_identity"
    return "low_identity"


def annotate(test_df, ref_df, best):
    """Join best hits back to test rows (query ids are 'q<row index>', reference ids 'r<row index>')."""
    ref_label = {f"r{i}": int(l) for i, l in enumerate(ref_df["label"])}
    b = best.set_index("qseqid") if len(best) else pd.DataFrame(columns=COLS).set_index("qseqid")
    rows = []
    for i in range(len(test_df)):
        q = f"q{i}"
        if q in b.index:
            h = b.loc[q]
            qident = min(1.0, float(h["pident"]) / 100.0 * float(h["length"]) / float(h["qlen"]))
            rows.append({"id": test_df["id"].iloc[i], "label": int(test_df["label"].iloc[i]),
                         "has_hit": True, "blast_hit_label": ref_label[h["sseqid"]],
                         "blast_pident": float(h["pident"]), "blast_aln_len": int(h["length"]),
                         "blast_qcov": min(1.0, float(h["length"]) / float(h["qlen"])), "blast_qident": qident,
                         "blast_bitscore": float(h["bitscore"]), "identity_bin": identity_bin(qident)})
        else:
            rows.append({"id": test_df["id"].iloc[i], "label": int(test_df["label"].iloc[i]), "has_hit": False,
                         "blast_hit_label": -1, "blast_pident": np.nan, "blast_aln_len": 0, "blast_qcov": 0.0,
                         "blast_qident": 0.0, "blast_bitscore": 0.0, "identity_bin": "low_identity"})
    return pd.DataFrame(rows)


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--data-dir", default="data/splits/peptide_tox")
    p.add_argument("--output", default="results/d3_blast/test_blast.csv")
    p.add_argument("--evalue", type=float, default=1e-3)
    p.add_argument("--threads", type=int, default=4)
    a = p.parse_args()
    train, val, test = (pd.read_csv(os.path.join(a.data_dir, f"{s}.csv")) for s in ("train", "val", "test"))
    ref = pd.concat([train, val], ignore_index=True)
    conflict = ref.groupby("sequence")["label"].nunique()
    if (conflict > 1).any():
        raise ValueError("reference contains identical sequences with conflicting labels")
    ref = ref.drop_duplicates("sequence").reset_index(drop=True)
    with tempfile.TemporaryDirectory() as tmp:
        rf, qf, db = (os.path.join(tmp, n) for n in ("ref.fa", "q.fa", "db"))
        with open(rf, "w") as f:
            f.writelines(f">r{i}\n{s}\n" for i, s in enumerate(ref["sequence"]))
        with open(qf, "w") as f:
            f.writelines(f">q{i}\n{s}\n" for i, s in enumerate(test["sequence"]))
        subprocess.run(["makeblastdb", "-in", rf, "-dbtype", "prot", "-out", db], check=True, capture_output=True)
        res = subprocess.run(["blastp", "-query", qf, "-db", db, "-task", "blastp-short", "-evalue", str(a.evalue),
                              "-max_target_seqs", str(len(ref)), "-max_hsps", "1", "-num_threads", str(a.threads),
                              "-outfmt", "6 qseqid sseqid pident length qlen bitscore evalue"],
                             check=True, capture_output=True, text=True)
    out = annotate(test, ref, parse_blast_tsv(res.stdout))
    os.makedirs(os.path.dirname(a.output), exist_ok=True)
    out.to_csv(a.output, index=False)
    print(out["identity_bin"].value_counts().to_dict(), "no-hit:", int((~out["has_hit"]).sum()), "->", a.output)


if __name__ == "__main__":
    main()
