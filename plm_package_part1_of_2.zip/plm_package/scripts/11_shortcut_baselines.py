"""
Non-PLM shortcut baselines, trained on TRAIN only (same data the probes see), regularisation chosen on VAL,
evaluated once on TEST with bootstrap 95% CIs.

  length       : logistic regression on log(length)
  length_gbm   : gradient boosting on length (captures non-monotone length effects)
  composition  : LR on 20-aa frequencies
  first30      : LR on aa frequencies of the first 30 residues
  dipeptide    : LR on 400 dipeptide frequencies
  comp_resid   : composition residualised on log(length) (coefficients from TRAIN) -> LR

Also reports the point-biserial length-label correlation and class-wise mean lengths (train).
    python scripts/11_shortcut_baselines.py
"""
import argparse
import csv
import json
import os

import numpy as np
import pandas as pd
from scipy.stats import pointbiserialr
from sklearn.ensemble import HistGradientBoostingClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.preprocessing import StandardScaler

from plm_common import DATASETS, auroc

AA = list("ACDEFGHIKLMNPQRSTVWY")
DI = [a + b for a in AA for b in AA]
CS = [0.01, 0.1, 1.0, 10.0]


def freq(seq, n=None):
    s = seq[:n] if n else seq
    L = max(len(s), 1)
    return [s.count(a) / L for a in AA]


def dipeptide(seq):
    counts = dict.fromkeys(DI, 0)
    for i in range(len(seq) - 1):
        counts[seq[i:i + 2]] = counts.get(seq[i:i + 2], 0) + 1
    L = max(len(seq) - 1, 1)
    return [counts[k] / L for k in DI]


def features(mode, tr, va, te):
    f = {"length": lambda s: [np.log(len(s))], "length_gbm": lambda s: [len(s)],
         "composition": freq, "first30": lambda s: freq(s, 30), "dipeptide": dipeptide}
    if mode == "comp_resid":
        parts = [np.array([freq(s) for s in x], float) for x in (tr, va, te)]
        logs = [np.log([max(len(s), 1) for s in x]) for x in (tr, va, te)]
        mu, var = logs[0].mean(), logs[0].var()
        betas = np.array([np.cov(logs[0], parts[0][:, j])[0, 1] / var for j in range(20)]) if var > 1e-12 else np.zeros(20)
        return [P - np.outer(l - mu, betas) for P, l in zip(parts, logs)]
    return [np.array([f[mode](s) for s in x], float) for x in (tr, va, te)]


def fit_predict(mode, Xtr, ytr, Xva, yva, Xte):
    if mode == "length_gbm":
        return HistGradientBoostingClassifier(random_state=0).fit(Xtr, ytr).predict_proba(Xte)[:, 1], None
    sc = StandardScaler().fit(Xtr)
    best = None
    for C in CS:
        clf = LogisticRegression(C=C, max_iter=5000).fit(sc.transform(Xtr), ytr)
        v = auroc(yva, clf.predict_proba(sc.transform(Xva))[:, 1])
        if best is None or v > best[0]:
            best = (v, C, clf)
    return best[2].predict_proba(sc.transform(Xte))[:, 1], best[1]


def boot_ci(y, s, rng, n=1000):
    pos, neg = np.where(y == 1)[0], np.where(y == 0)[0]
    v = [auroc(y[i], s[i]) for i in (np.concatenate([rng.choice(pos, len(pos)), rng.choice(neg, len(neg))]) for _ in range(n))]
    return [float(np.percentile(v, 2.5)), float(np.percentile(v, 97.5))]


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--data-dir", default="data/splits")
    p.add_argument("--output-dir", default="results")
    a = p.parse_args()
    rng = np.random.default_rng(0)
    modes = ["length", "length_gbm", "composition", "first30", "dipeptide", "comp_resid"]
    results = {}
    for ds in DATASETS:
        tr, va, te = (pd.read_csv(os.path.join(a.data_dir, ds, f"{s}.csv")) for s in ("train", "val", "test"))
        ytr, yva, yte = (d["label"].astype(int).to_numpy() for d in (tr, va, te))
        lens = tr["sequence"].str.len().to_numpy(float)
        r, pv = pointbiserialr(ytr, lens)
        entry = {"n_train": len(tr), "n_test": len(te),
                 "length_confound": {"point_biserial_r": float(r), "p_value": float(pv),
                                     "mean_len_pos": float(lens[ytr == 1].mean()), "mean_len_neg": float(lens[ytr == 0].mean())},
                 "baselines": {}}
        for mode in modes:
            Xtr, Xva, Xte = features(mode, tr["sequence"].tolist(), va["sequence"].tolist(), te["sequence"].tolist())
            s, C = fit_predict(mode, Xtr, ytr, Xva, yva, Xte)
            entry["baselines"][mode] = {"auroc": auroc(yte, s), "ci95": boot_ci(yte, s, rng), "C": C}
            print(f"{ds:15s} {mode:12s} {entry['baselines'][mode]['auroc']:.3f}")
        results[ds] = entry
    os.makedirs(a.output_dir, exist_ok=True)
    json.dump(results, open(os.path.join(a.output_dir, "shortcut_baselines.json"), "w"), indent=2)
    with open(os.path.join(a.output_dir, "shortcut_baselines.csv"), "w", newline="") as fh:
        w = csv.writer(fh)
        w.writerow(["dataset"] + modes + ["r_length_label", "mean_len_pos", "mean_len_neg"])
        for ds, e in results.items():
            w.writerow([ds] + [f"{e['baselines'][m]['auroc']:.4f}" for m in modes] +
                       [f"{e['length_confound']['point_biserial_r']:+.3f}", f"{e['length_confound']['mean_len_pos']:.0f}",
                        f"{e['length_confound']['mean_len_neg']:.0f}"])


if __name__ == "__main__":
    main()
