"""
Evaluate D1-trained MM probes (fine-tuned ESM-2, CLS pooling, VAL-selected layer, train-fit direction+threshold) on
the D5 ProteinMPNN stress test.

D5 is one-class, so 'detection rate' alone is uninterpretable.  Every number is reported next to its references,
all computed with the SAME model/layer/direction/threshold/extractor:
  * TPR on D1 test positives and FPR on D1 test negatives   (what the threshold does in-distribution)
  * detection rate on residue-shuffled D5 sequences          (composition-only control; should be ~FPR)
  * AUROC of D5 vs D1 test negatives                         (threshold-free; D5 as positives)
Uncertainty: 95% CI for the D5 detection rate by bootstrap over PARENT structures (designs from one backbone are
not independent; a per-sequence Wilson interval is also stored but is anti-conservative).

Run after 03_linear_probe.py --save-directions on fine-tuned D1 embeddings and 01_build_dataset5_proteinmpnn.py.
"""
import argparse
import json
import os

import numpy as np
import pandas as pd

from plm_common import MODELS, MODELS_WITH_3B, auroc, best_layer_by_val, check_embeddings_match, load_json, load_pkl
import d5_helpers as H


def parent_bootstrap_rate(detected, parents, n_boot, rng):
    """CI of mean(detected) resampling PARENTS with replacement (all designs of a drawn parent are kept)."""
    detected = np.asarray(detected, dtype=float)
    parents = np.asarray(parents)
    groups = [detected[parents == p] for p in np.unique(parents)]
    vals = []
    for _ in range(n_boot):
        pick = rng.integers(0, len(groups), len(groups))
        vals.append(np.concatenate([groups[i] for i in pick]).mean())
    return [float(np.percentile(vals, 2.5)), float(np.percentile(vals, 97.5))]


ID_BINS = [(0.0, 0.30), (0.30, 0.40), (0.40, 1.01)]


def summarise(s_d5, parents, s_pos, s_neg, s_shuf, thr, n_boot=2000, seed=0, identity=None):
    """Pure-numpy summary (unit-tested). All score arrays are projections on the same unit direction.
    identity (optional): max identity of each D5 design to any D1 sequence -> detection rate per identity bin."""
    rng = np.random.default_rng(seed)
    det = np.asarray(s_d5) > thr
    out = {
        "n_d5": int(len(det)), "n_parents": int(len(np.unique(parents))), "threshold": float(thr),
        "d5_detection_rate": float(det.mean()),
        "d5_detection_ci_parent_bootstrap": parent_bootstrap_rate(det, parents, n_boot, rng),
        "d5_detection_ci_wilson_per_sequence": H.wilson(int(det.sum()), len(det)),
        "d1_test_tpr": float((np.asarray(s_pos) > thr).mean()),
        "d1_test_fpr": float((np.asarray(s_neg) > thr).mean()),
        "shuffled_d5_detection_rate": float((np.asarray(s_shuf) > thr).mean()),
        "auroc_d5_vs_d1_test_neg": auroc(np.r_[np.ones(len(s_d5)), np.zeros(len(s_neg))], np.r_[s_d5, s_neg]),
        "auroc_shuffled_vs_d1_test_neg": auroc(np.r_[np.ones(len(s_shuf)), np.zeros(len(s_neg))], np.r_[s_shuf, s_neg]),
        "score_quartiles": [float(x) for x in np.percentile(s_d5, [25, 50, 75])],
    }
    per = {}
    for p in np.unique(parents):
        m = np.asarray(parents) == p
        per[str(p)] = {"n": int(m.sum()), "detection_rate": float(det[m].mean())}
    out["per_parent"] = per
    if identity is not None:
        ident, bins = np.asarray(identity, dtype=float), {}
        for lo, hi in ID_BINS:
            m = (ident >= lo) & (ident < hi)
            bins[f"{lo:.2f}-{min(hi, 1.0):.2f}"] = {"n": int(m.sum()),
                "detection_rate": float(det[m].mean()) if m.any() else None,
                "n_parents": int(len(np.unique(np.asarray(parents)[m]))) if m.any() else 0}
        out["by_identity_to_d1"] = bins
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--d5-csv", default="data/splits/dataset5/stress_test.csv")
    ap.add_argument("--data-dir", default="data/splits")
    ap.add_argument("--results-root", default="results")
    ap.add_argument("--output-dir", default="results/dataset5")
    ap.add_argument("--batch-size", type=int, default=8)
    ap.add_argument("--n-boot", type=int, default=2000)
    ap.add_argument("--seed", type=int, default=0)
    ap.add_argument("--include-3b", action="store_true")
    a = ap.parse_args()

    import torch
    from transformers import AutoTokenizer, EsmForSequenceClassification
    from embed_utils import extract_for_dataframe

    d5 = pd.read_csv(a.d5_csv)
    if d5["sequence"].str.contains("/").any() or not d5["label"].eq(1).all():
        raise ValueError("D5 csv is malformed (multi-chain '/' separators or non-positive labels): rebuild with "
                         "01_build_dataset5_proteinmpnn.py")
    rng = np.random.default_rng(a.seed)
    shuf = d5.copy()
    shuf["sequence"] = [H.shuffle_residues(s, rng) for s in d5["sequence"]]
    shuf["id"] = [f"{i}_shuf" for i in d5["id"]]
    d1_test = pd.read_csv(os.path.join(a.data_dir, "pft", "test.csv"))

    os.makedirs(a.output_dir, exist_ok=True)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    summary = {}
    for m in (MODELS_WITH_3B if a.include_3b else MODELS):
        mdir = os.path.join(a.results_root, m, "pft")
        pdir = os.path.join(a.results_root, "probes", "finetuned", m, "pft")
        if not (os.path.exists(os.path.join(pdir, "probe_results.json")) and os.path.isdir(mdir)):
            print(f"[SKIP] {m}: fine-tuned D1 model/probe not found")
            continue
        layer = best_layer_by_val(load_json(os.path.join(pdir, "probe_results.json"))["cls"], "mm")["layer"]
        d = np.asarray(load_json(os.path.join(pdir, "mm_directions_cls.json"))[str(layer)], dtype=np.float64)
        d /= np.linalg.norm(d)
        thr = float(load_json(os.path.join(pdir, "mm_thresholds_cls.json"))[str(layer)])

        tok = AutoTokenizer.from_pretrained(mdir)
        model = EsmForSequenceClassification.from_pretrained(mdir, torch_dtype=torch.float32).to(device).eval()
        e5 = extract_for_dataframe(model.esm, tok, d5, device, a.batch_size)
        es = extract_for_dataframe(model.esm, tok, shuf, device, a.batch_size)
        del model
        if torch.cuda.is_available():
            torch.cuda.empty_cache()
        e1 = load_pkl(os.path.join(mdir, "embeddings", "test_embeddings.pkl"))
        check_embeddings_match(e1, d1_test, f"{m}/pft/test")
        y1 = np.asarray(e1["labels"]).astype(int)
        s1 = e1["cls"][:, layer, :].astype(np.float64) @ d
        res = summarise(e5["cls"][:, layer, :].astype(np.float64) @ d, d5["parent_pdb"].to_numpy(),
                        s1[y1 == 1], s1[y1 == 0], es["cls"][:, layer, :].astype(np.float64) @ d,
                        thr, a.n_boot, a.seed,
                        identity=d5["max_identity_d1"].to_numpy() if "max_identity_d1" in d5 else None)
        res.update({"model": m, "layer": int(layer), "pooling": "cls"})
        summary[m] = res
        json.dump(res, open(os.path.join(a.output_dir, f"{m}_d5_results.json"), "w"), indent=2)
        print(f"{m} L{layer}: D5 det={res['d5_detection_rate']:.3f} {res['d5_detection_ci_parent_bootstrap']}  "
              f"D1 TPR={res['d1_test_tpr']:.3f} FPR={res['d1_test_fpr']:.3f}  shuf={res['shuffled_d5_detection_rate']:.3f}  "
              f"AUROC(D5 vs D1neg)={res['auroc_d5_vs_d1_test_neg']:.3f}")
    json.dump({m: {k: v for k, v in r.items() if k != "per_parent"} for m, r in summary.items()},
              open(os.path.join(a.output_dir, "detection_summary.json"), "w"), indent=2)


if __name__ == "__main__":
    main()
