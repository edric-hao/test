"""
Shared helpers used by every analysis script, so that probe definitions, layer selection and
data-consistency checks exist in exactly ONE place.

Conventions
-----------
* Embedding pickles have keys: cls, mean  (N, n_layers+1, D) float32;  labels, ids, seq_sha256, windowed.
* Layer selection is ALWAYS by validation AUROC (never test).
* 3B is excluded by default everywhere (pass --include-3b where offered).
"""
import hashlib
import json
import os
import pickle

import numpy as np
from scipy.special import expit
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import roc_auc_score
from sklearn.preprocessing import StandardScaler

DATASETS = ["pft", "virulence", "peptide_tox", "signal_peptide"]
HARM_DATASETS = ["pft", "virulence", "peptide_tox"]
CONTROL_DATASET = "signal_peptide"
MODELS = ["esm2_8m", "esm2_35m", "esm2_150m", "esm2_650m"]
MODELS_WITH_3B = MODELS + ["esm2_3b"]
HF_IDS = {
    "esm2_8m": "facebook/esm2_t6_8M_UR50D",
    "esm2_35m": "facebook/esm2_t12_35M_UR50D",
    "esm2_150m": "facebook/esm2_t30_150M_UR50D",
    "esm2_650m": "facebook/esm2_t33_650M_UR50D",
    "esm2_3b": "facebook/esm2_t36_3B_UR50D",
}
MAX_LEN = 1022
SPLITS = ["train", "val", "test"]


# ---------------------------------------------------------------------------
# small numerics
# ---------------------------------------------------------------------------
def unit(v):
    v = np.asarray(v, dtype=np.float64)
    n = np.linalg.norm(v)
    if not np.isfinite(n) or n < 1e-12:
        raise ValueError("cannot normalise a (near-)zero vector")
    return v / n


def project_out(X, d_hat):
    """Remove the component of every row of X along unit vector d_hat."""
    X = np.asarray(X, dtype=np.float64)
    return X - (X @ d_hat)[:, None] * d_hat[None, :]


def auroc(y, s):
    y = np.asarray(y)
    if len(np.unique(y)) < 2:
        raise ValueError("AUROC undefined: single-class labels")
    return float(roc_auc_score(y, s))


def mm_direction(X, y, allow_degenerate=False):
    """Unit mass-mean direction  mean(X[y==1]) - mean(X[y==0])  (float64).

    Degenerate case: at layer 0 the <cls> hidden state is the SAME vector for every sequence (it is the token
    embedding; no sequence information has been mixed in yet), so the class means coincide. With
    allow_degenerate=True a zero vector is returned (probe AUROC is then exactly 0.5 by ties); otherwise ValueError."""
    X = np.asarray(X, dtype=np.float64)
    y = np.asarray(y)
    diff = X[y == 1].mean(0) - X[y == 0].mean(0)
    if allow_degenerate and np.linalg.norm(diff) < 1e-6 * (1.0 + np.abs(X).mean()):
        return np.zeros_like(diff)
    return unit(diff)


# ---------------------------------------------------------------------------
# probes
# ---------------------------------------------------------------------------
class MMProbe:
    """Mass-mean probe (Marks & Tegmark 2023): score = <h, d_hat>, threshold = midpoint of class means."""

    def __init__(self):
        self.direction = None
        self.threshold = 0.0
        self.degenerate = False

    def fit(self, X, y):
        X = np.asarray(X, dtype=np.float64)
        y = np.asarray(y)
        self.direction = mm_direction(X, y, allow_degenerate=True)
        self.degenerate = not bool(np.any(self.direction))
        s = X @ self.direction
        self.threshold = float((s[y == 1].mean() + s[y == 0].mean()) / 2)
        return self

    def score(self, X):
        return np.asarray(X, dtype=np.float64) @ self.direction

    def predict_proba(self, X):
        return expit(self.score(X) - self.threshold)

    def predict(self, X):
        return (self.score(X) >= self.threshold).astype(int)


class LRProbe:
    """Standardised L2 logistic regression (C=1, no class weights; AUROC is the primary metric)."""

    def __init__(self, C=1.0, max_iter=1000):
        self.scaler = StandardScaler()
        self.lr = LogisticRegression(max_iter=max_iter, solver="lbfgs", C=C)

    def fit(self, X, y):
        self.lr.fit(self.scaler.fit_transform(np.asarray(X, dtype=np.float64)), y)
        return self

    def predict_proba(self, X):
        return self.lr.predict_proba(self.scaler.transform(np.asarray(X, dtype=np.float64)))[:, 1]

    def predict(self, X):
        return self.lr.predict(self.scaler.transform(np.asarray(X, dtype=np.float64)))


def best_layer_by_val(layer_records, probe="mm"):
    """Return the per-layer record with the highest VAL AUROC (ties -> lowest layer index).
    Raises if validation AUROC is absent: falling back to test would select layers on held-out data."""
    key = f"{probe}_val_auroc"
    if not layer_records:
        raise ValueError("no layer records")
    missing = [r.get("layer") for r in layer_records if key not in r]
    if missing:
        raise ValueError(f"{key} missing for layers {missing}; re-run 03_linear_probe.py")
    return max(sorted(layer_records, key=lambda r: r["layer"]), key=lambda r: r[key])


# ---------------------------------------------------------------------------
# IO + consistency
# ---------------------------------------------------------------------------
def load_pkl(path):
    with open(path, "rb") as f:
        return pickle.load(f)


def load_json(path):
    with open(path) as f:
        return json.load(f)


def sha256_file(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def seq_hash(seqs):
    return hashlib.sha256("\n".join(map(str, seqs)).encode()).hexdigest()


def splits_manifest(data_dir, datasets=DATASETS):
    out = {}
    for ds in datasets:
        for sp in SPLITS:
            p = os.path.join(data_dir, ds, f"{sp}.csv")
            if os.path.exists(p):
                out[f"{ds}/{sp}.csv"] = sha256_file(p)
    return out


def check_embeddings_match(emb, df, name=""):
    """Raise unless an embedding pickle was computed from exactly this dataframe (rows, order, labels)."""
    tag = f" [{name}]" if name else ""
    n = len(df)
    if len(emb["labels"]) != n or len(emb["ids"]) != n or emb["cls"].shape[0] != n:
        raise ValueError(f"embedding rows ({len(emb['labels'])}) != csv rows ({n}){tag}")
    if not np.array_equal(np.asarray(emb["labels"]).astype(int), df["label"].astype(int).to_numpy()):
        raise ValueError(f"embedding labels differ from csv{tag}")
    if [str(i) for i in emb["ids"]] != [str(i) for i in df["id"]]:
        raise ValueError(f"embedding ids differ from csv ids{tag}")
    if "seq_sha256" in emb and emb["seq_sha256"] != seq_hash(df["sequence"]):
        raise ValueError(f"embedding sequences differ from csv sequences{tag}")
    return True
