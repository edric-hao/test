"""
Post-run consistency check: every produced artefact must derive from the CURRENT frozen splits.

  * results/.data_manifest_sha256 equals the sha256 of data/MANIFEST.sha256
  * every probe_results.json / provenance.json carries split hashes equal to the current files
  * every embedding pickle matches its CSV (row count, order, ids, labels, sequence hash)
  * every fine-tuned run has test_results.json

Exit status 1 on any violation (stale or mixed-version results must not be reported).
"""
import argparse
import glob
import hashlib
import os
import sys

import pandas as pd

from plm_common import DATASETS, SPLITS, check_embeddings_match, load_json, load_pkl, splits_manifest


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--results-root", default="results")
    ap.add_argument("--data-dir", default="data/splits")
    ap.add_argument("--manifest", default="data/MANIFEST.sha256")
    a = ap.parse_args()
    R, errs, n_checked = a.results_root, [], 0
    cur = splits_manifest(a.data_dir)

    stamp = os.path.join(R, ".data_manifest_sha256")
    if os.path.exists(stamp) and os.path.exists(a.manifest):
        if open(stamp).read().strip() != hashlib.sha256(open(a.manifest, "rb").read()).hexdigest():
            errs.append("results were produced from a different data version (manifest stamp mismatch)")

    def cur_for(ds):
        return {k: v for k, v in cur.items() if k.startswith(ds + "/")}

    for p in glob.glob(os.path.join(R, "probes", "*", "*", "*", "probe_results.json")):
        ds = p.split(os.sep)[-2]
        sha = load_json(p).get("_meta", {}).get("split_sha256")
        n_checked += 1
        if sha != cur_for(ds):
            errs.append(f"stale probe results: {p}")
    for p in glob.glob(os.path.join(R, "*", "*", "provenance.json")):
        ds = p.split(os.sep)[-2]
        if ds not in DATASETS:
            continue
        sha = load_json(p).get("split_sha256")
        n_checked += 1
        if sha != cur_for(ds):
            errs.append(f"fine-tuned run trained/evaluated on different splits: {p}")
        if not os.path.exists(os.path.join(os.path.dirname(p), "test_results.json")):
            errs.append(f"missing test_results.json next to {p}")
    for p in glob.glob(os.path.join(R, "embeddings", "pretrained", "*", "*", "*_embeddings.pkl")) + \
             glob.glob(os.path.join(R, "*", "*", "embeddings", "*_embeddings.pkl")):
        parts = p.split(os.sep)
        sp = os.path.basename(p).replace("_embeddings.pkl", "")
        ds = parts[-2] if "pretrained" in parts else parts[-3]
        if ds not in DATASETS or sp not in SPLITS:
            continue
        n_checked += 1
        try:
            check_embeddings_match(load_pkl(p), pd.read_csv(os.path.join(a.data_dir, ds, f"{sp}.csv")), p)
        except Exception as e:  # noqa: BLE001
            errs.append(f"{p}: {e}")
    for e in errs:
        print("FAIL:", e)
    print(f"checked {n_checked} artefacts, {len(errs)} problem(s)")
    sys.exit(1 if errs else 0)


if __name__ == "__main__":
    main()
