"""
Re-derive, from an EXISTING fine-tuned checkpoint and the CURRENT split CSVs:
  * layer-wise embeddings for train/val/test  (<model-dir>/embeddings/*.pkl)
  * test_predictions.csv (id,label,prob)      (needed for classifier bootstrap CIs)
and CHECK that the classifier's recomputed test AUROC equals the stored test_results.json (tolerance 5e-3).
A mismatch means the checkpoint was evaluated on different data than the current splits (stale result) and the
run must be repeated; the script then exits non-zero.

    python scripts/extract_finetuned_embeddings.py --model-dir results/esm2_8m/pft --dataset pft
"""
import argparse
import json
import os
import pickle
import sys

import numpy as np
import pandas as pd
import torch
from transformers import AutoTokenizer, EsmForSequenceClassification

from embed_utils import extract_for_dataframe
from plm_common import MAX_LEN, SPLITS, auroc


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--model-dir", required=True)
    p.add_argument("--dataset", required=True)
    p.add_argument("--data-dir", default="data/splits")
    p.add_argument("--max-length", type=int, default=MAX_LEN)
    p.add_argument("--embed-batch-size", type=int, default=16)
    p.add_argument("--tolerance", type=float, default=5e-3)
    a = p.parse_args()

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    tok = AutoTokenizer.from_pretrained(a.model_dir)
    model = EsmForSequenceClassification.from_pretrained(a.model_dir, torch_dtype=torch.float32).to(device).eval()
    edir = os.path.join(a.model_dir, "embeddings")
    os.makedirs(edir, exist_ok=True)

    for sp in SPLITS:
        df = pd.read_csv(os.path.join(a.data_dir, a.dataset, f"{sp}.csv"))
        reps = extract_for_dataframe(model.esm, tok, df, device, a.embed_batch_size, a.max_length)
        with open(os.path.join(edir, f"{sp}_embeddings.pkl"), "wb") as f:
            pickle.dump(reps, f)
        if sp == "test":
            # classifier head applied to the final-layer CLS vector (exactly what the model does at inference)
            x = torch.tensor(reps["cls"][:, -1, :], dtype=torch.float32, device=device).unsqueeze(1)
            with torch.no_grad():
                probs = torch.softmax(model.classifier(x), -1)[:, 1].cpu().numpy()
            pd.DataFrame({"id": df["id"], "label": df["label"], "prob": probs}).to_csv(
                os.path.join(a.model_dir, "test_predictions.csv"), index=False)
            new = auroc(df["label"], probs)
            stored_path = os.path.join(a.model_dir, "test_results.json")
            if os.path.exists(stored_path):
                old = json.load(open(stored_path)).get("test_roc_auc")
                if old is not None and abs(old - new) > a.tolerance:
                    print(f"STALE: stored test AUROC {old:.4f} vs recomputed {new:.4f} on current test.csv")
                    sys.exit(2)
                print(f"OK: stored test AUROC {old} ~ recomputed {new:.4f}")
            else:
                print(f"recomputed test AUROC {new:.4f} (no stored test_results.json)")


if __name__ == "__main__":
    main()
