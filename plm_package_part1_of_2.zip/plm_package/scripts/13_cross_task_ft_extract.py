"""
Fine-tuned cross-task transfer needs ONE backbone applied to ALL tasks: for each fine-tuned model
results/<model>/<train_task>, extract test-set embeddings of every eval task with that same backbone.
Output: results/cross_task_ft/<model>/<train_task>/<eval_task>/test_embeddings.pkl

    python scripts/13_cross_task_ft_extract.py --model-short esm2_8m
"""
import argparse
import os
import pickle

import pandas as pd
import torch
from transformers import AutoTokenizer, EsmForSequenceClassification

from embed_utils import extract_for_dataframe
from plm_common import DATASETS, MAX_LEN


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--model-short", required=True)
    p.add_argument("--results-root", default="results")
    p.add_argument("--data-dir", default="data/splits")
    p.add_argument("--datasets", nargs="+", default=DATASETS)
    p.add_argument("--embed-batch-size", type=int, default=16)
    a = p.parse_args()
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    for train_task in a.datasets:
        mdir = os.path.join(a.results_root, a.model_short, train_task)
        tok = AutoTokenizer.from_pretrained(mdir)
        model = EsmForSequenceClassification.from_pretrained(mdir, torch_dtype=torch.float32).to(device).eval()
        for eval_task in a.datasets:
            out = os.path.join(a.results_root, "cross_task_ft", a.model_short, train_task, eval_task)
            os.makedirs(out, exist_ok=True)
            df = pd.read_csv(os.path.join(a.data_dir, eval_task, "test.csv"))
            reps = extract_for_dataframe(model.esm, tok, df, device, a.embed_batch_size, MAX_LEN)
            with open(os.path.join(out, "test_embeddings.pkl"), "wb") as f:
                pickle.dump(reps, f)
            print(f"{a.model_short}: model[{train_task}] on {eval_task} test: {reps['cls'].shape}")
        del model
        import gc; gc.collect(); torch.cuda.empty_cache()


if __name__ == "__main__":
    main()
