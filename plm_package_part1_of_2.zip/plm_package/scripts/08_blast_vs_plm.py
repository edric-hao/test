"""
PLM vs BLAST on the D3 (peptide_tox) test set, overall and per BLAST-identity bin.

BLAST score  = nearest-neighbour vote:  +qident if the best hit is toxic, -qident if non-toxic, 0 if no hit
               (both classes of hit carry information; the earlier "positive hits only" score handicapped BLAST).
PLM scores   = MM-probe score at the VAL-selected layer (fine-tuned and pretrained backbones) and the fine-tuned
               classifier probability (results/<model>/peptide_tox/test_predictions.csv).
95% CIs: stratified bootstrap over test sequences.

    python scripts/annotate_d3_blast.py && python scripts/08_blast_vs_plm.py --model-short esm2_8m
"""
import argparse
import json
import os

import numpy as np
import pandas as pd

from plm_common import auroc, best_layer_by_val, check_embeddings_match, load_json, load_pkl, unit

BINS = ["high_identity", "medium_identity", "low_identity"]


def blast_nn_score(df):
    sign = np.where(df["blast_hit_label"] == 1, 1.0, np.where(df["blast_hit_label"] == 0, -1.0, 0.0))
    return sign * df["blast_qident"].fillna(0.0).to_numpy()


def boot_ci(y, s, rng, n_boot=1000):
    pos, neg = np.where(y == 1)[0], np.where(y == 0)[0]
    vals = []
    for _ in range(n_boot):
        idx = np.concatenate([rng.choice(pos, len(pos)), rng.choice(neg, len(neg))])
        vals.append(auroc(y[idx], s[idx]))
    return [float(np.percentile(vals, 2.5)), float(np.percentile(vals, 97.5))]


def summarize(y, scores, mask, rng, min_n=20):
    ys = y[mask]
    out = {"n": int(mask.sum()), "n_pos": int(ys.sum())}
    for name, s in scores.items():
        if mask.sum() < min_n or len(np.unique(ys)) < 2:
            out[name] = None
        else:
            out[name] = {"auroc": auroc(ys, s[mask]), "ci95": boot_ci(ys, s[mask], rng)}
    return out


def mm_scores(root, stage, model, ds, pooling, test_df, emb_path):
    pr = load_json(os.path.join(root, "probes", stage, model, ds, "probe_results.json"))[pooling]
    layer = best_layer_by_val(pr, "mm")["layer"]
    d = unit(load_json(os.path.join(root, "probes", stage, model, ds, f"mm_directions_{pooling}.json"))[str(layer)])
    emb = load_pkl(emb_path)
    check_embeddings_match(emb, test_df, emb_path)
    return np.asarray(emb[pooling][:, layer, :], dtype=np.float64) @ d, layer


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--model-short", required=True)
    p.add_argument("--results-root", default="results")
    p.add_argument("--data-dir", default="data/splits")
    p.add_argument("--blast-csv", default="results/d3_blast/test_blast.csv")
    p.add_argument("--output-dir", default=None)
    p.add_argument("--pooling", default="cls", choices=["cls", "mean"])
    p.add_argument("--seed", type=int, default=0)
    a = p.parse_args()
    ds, R, m = "peptide_tox", a.results_root, a.model_short
    out_dir = a.output_dir or os.path.join(R, "blast_vs_plm", m)
    os.makedirs(out_dir, exist_ok=True)

    test = pd.read_csv(os.path.join(a.data_dir, ds, "test.csv"))
    bl = pd.read_csv(a.blast_csv)
    if len(bl) != len(test) or not (bl["id"].astype(str).to_numpy() == test["id"].astype(str).to_numpy()).all() \
            or not (bl["label"].to_numpy() == test["label"].to_numpy()).all():
        raise ValueError("BLAST annotation does not align with test.csv; re-run annotate_d3_blast.py")
    y = test["label"].astype(int).to_numpy()

    ft_s, ft_l = mm_scores(R, "finetuned", m, ds, a.pooling, test, os.path.join(R, m, ds, "embeddings", "test_embeddings.pkl"))
    pre_s, pre_l = mm_scores(R, "pretrained", m, ds, a.pooling, test, os.path.join(R, "embeddings", "pretrained", m, ds, "test_embeddings.pkl"))
    scores = {"blast_nn": blast_nn_score(bl), "ft_mm_probe": ft_s, "pre_mm_probe": pre_s}
    pp = os.path.join(R, m, ds, "test_predictions.csv")
    if os.path.exists(pp):
        pred = pd.read_csv(pp)
        if not (pred["id"].astype(str).to_numpy() == test["id"].astype(str).to_numpy()).all():
            raise ValueError("test_predictions.csv rows differ from test.csv")
        scores["ft_classifier"] = pred["prob"].to_numpy()

    rng = np.random.default_rng(a.seed)
    res = {"model": m, "pooling": a.pooling, "ft_probe_layer": ft_l, "pre_probe_layer": pre_l, "bins": {}}
    res["bins"]["overall"] = summarize(y, scores, np.ones(len(y), bool), rng)
    for b in BINS:
        res["bins"][b] = summarize(y, scores, (bl["identity_bin"] == b).to_numpy(), rng)
    if "in_test2" in test.columns:
        res["bins"]["in_test2"] = summarize(y, scores, test["in_test2"].fillna(False).astype(bool).to_numpy(), rng)
    json.dump(res, open(os.path.join(out_dir, f"blast_vs_plm_{a.pooling}.json"), "w"), indent=2)
    for k, v in res["bins"].items():
        print(k, v["n"], {n: (round(x["auroc"], 3) if x else None) for n, x in v.items() if n not in ("n", "n_pos")})


if __name__ == "__main__":
    main()
