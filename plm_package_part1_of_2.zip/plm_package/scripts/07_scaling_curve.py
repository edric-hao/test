"""
Aggregate AUROC across ESM-2 sizes for: fine-tuned classifier, fine-tuned MM probe, pretrained MM probe.
Probe layers are chosen by VAL AUROC. Fine-tuned-classifier error bars (SD over seeds) are drawn when
results_seed*/ directories from run_multiseed.sh exist.

Scaling statistics are DESCRIPTIVE: Spearman rho(log10 params, AUROC) with n = number of models. With n=4 the
smallest attainable two-sided p-value is 0.083, so no significance is claimed; compare differences to the
seed SD (14_seed_variance.py) instead.

    python scripts/07_scaling_curve.py --pooling cls     (and again with --pooling mean)
"""
import argparse
import glob
import json
import os

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import warnings

import numpy as np
from scipy.stats import spearmanr

from plm_common import CONTROL_DATASET, DATASETS, MODELS, MODELS_WITH_3B, best_layer_by_val, load_json

PARAMS = {"esm2_8m": 8e6, "esm2_35m": 35e6, "esm2_150m": 150e6, "esm2_650m": 650e6, "esm2_3b": 3000e6}
LABELS = {"esm2_8m": "8M", "esm2_35m": "35M", "esm2_150m": "150M", "esm2_650m": "650M", "esm2_3b": "3B"}
SERIES = {"FT classifier": ("ft_cls", "C0", "o"), "FT MM probe": ("ft_probe", "C1", "s"),
          "Pre-FT MM probe": ("pre_probe", "C2", "^")}


def ft_auroc(path):
    if not os.path.exists(path):
        return None
    return load_json(path).get("test_roc_auc")


def probe_auroc(root, stage, model, ds, pooling):
    path = os.path.join(root, "probes", stage, model, ds, "probe_results.json")
    if not os.path.exists(path):
        return None, None
    b = best_layer_by_val(load_json(path)[pooling], "mm")
    return b["mm_auroc"], b["layer"]


def seed_sd(root, model, ds):
    vals = []
    for d in [root] + sorted(glob.glob(root + "_seed*")):
        v = ft_auroc(os.path.join(d, model, ds, "test_results.json"))
        if v is not None:
            vals.append(v)
    return (float(np.std(vals, ddof=1)), len(vals)) if len(vals) >= 2 else (None, len(vals))


def collect(root, models, pooling):
    data = {}
    for m in models:
        data[m] = {}
        for ds in DATASETS:
            fp, fl = probe_auroc(root, "finetuned", m, ds, pooling)
            pp, pl = probe_auroc(root, "pretrained", m, ds, pooling)
            sd, ns = seed_sd(root, m, ds)
            data[m][ds] = {"ft_cls": ft_auroc(os.path.join(root, m, ds, "test_results.json")), "ft_probe": fp,
                           "pre_probe": pp, "ft_probe_layer": fl, "pre_probe_layer": pl,
                           "ft_cls_seed_sd": sd, "n_seeds": ns}
    return data


def stats(data, models):
    xs = np.log10([PARAMS[m] for m in models])
    out = {}
    for ds in DATASETS:
        out[ds] = {}
        for key in ("ft_cls", "ft_probe", "pre_probe"):
            pts = [(x, data[m][ds][key]) for x, m in zip(xs, models) if data[m][ds][key] is not None]
            if len(pts) >= 3:
                vx, vy = zip(*pts)
                with warnings.catch_warnings():
                    warnings.simplefilter("ignore")  # constant input (e.g. D4 = 1.000 everywhere) -> rho undefined
                    rho = float(spearmanr(vx, vy)[0])
                rho = None if np.isnan(rho) else rho   # strict JSON: no NaN literals
                out[ds][key] = {"spearman_rho": rho, "n_models": len(pts),
                                "delta_largest_minus_smallest": float(vy[-1] - vy[0])}
            else:
                out[ds][key] = {"spearman_rho": None, "n_models": len(pts), "delta_largest_minus_smallest": None}
    return out


def plot_all(data, models, pooling, out_dir):
    xs = np.log10([PARAMS[m] for m in models])
    fig, axes = plt.subplots(1, len(DATASETS), figsize=(4 * len(DATASETS), 4), sharey=True)
    for ax, ds in zip(axes, DATASETS):
        for label, (key, color, marker) in SERIES.items():
            pts = [(x, data[m][ds][key], data[m][ds]["ft_cls_seed_sd"] if key == "ft_cls" else None)
                   for x, m in zip(xs, models) if data[m][ds][key] is not None]
            if not pts:
                continue
            vx, vy, ve = zip(*pts)
            err = [e if e is not None else 0 for e in ve]
            ax.errorbar(vx, vy, yerr=err if any(err) else None, marker=marker, color=color, label=label,
                        linestyle="--" if ds == CONTROL_DATASET else "-", capsize=3)
        ax.axhline(0.5, color="gray", linestyle=":")
        ax.set_title(ds + (" (control)" if ds == CONTROL_DATASET else ""))
        ax.set_xticks(xs); ax.set_xticklabels([LABELS[m] for m in models])
    axes[0].set_ylabel("test AUROC"); axes[0].legend(fontsize=8)
    plt.suptitle(f"Scaling ({pooling} pooling); error bars = SD over seeds where available")
    plt.tight_layout(); plt.savefig(os.path.join(out_dir, f"scaling_all_{pooling}.png"), dpi=120); plt.close()


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--results-root", default="results")
    p.add_argument("--output-dir", default="results/scaling_curve")
    p.add_argument("--pooling", default="cls", choices=["cls", "mean"])
    p.add_argument("--include-3b", action="store_true")
    a = p.parse_args()
    os.makedirs(a.output_dir, exist_ok=True)
    models = MODELS_WITH_3B if a.include_3b else MODELS
    data = collect(a.results_root, models, a.pooling)
    st = stats(data, models)
    plot_all(data, models, a.pooling, a.output_dir)
    with open(os.path.join(a.output_dir, f"scaling_summary_{a.pooling}.json"), "w") as f:
        json.dump({f"{m}/{ds}": data[m][ds] for m in models for ds in DATASETS}, f, indent=2)
    with open(os.path.join(a.output_dir, f"scaling_stats_{a.pooling}.json"), "w") as f:
        json.dump(st, f, indent=2)
    for m in models:
        for ds in DATASETS:
            v = data[m][ds]
            print(f"{m:10s} {ds:15s} ft_cls={v['ft_cls']}  ft_probe={v['ft_probe']}  pre_probe={v['pre_probe']}")


if __name__ == "__main__":
    main()
