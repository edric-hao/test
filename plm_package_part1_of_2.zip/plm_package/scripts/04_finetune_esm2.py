"""
Full fine-tuning of ESM-2 for binary protein classification (single run = one model x one dataset x one seed).

* Early stopping / checkpoint selection on VAL AUROC only; the test split is evaluated exactly once, after training.
* Writes test_results.json, test_predictions.csv (id,label,prob), training_log.json, provenance.json and
  (with --extract-embeddings) layer-wise CLS/mean embeddings of the BEST checkpoint for all splits.
* --freeze-layers N freezes the embedding layer and the bottom N transformer layers. Gradient checkpointing is run
  with use_reentrant=False so gradients reach the unfrozen layers although the embeddings are frozen; a check
  after the first backward pass aborts the run if any unfrozen encoder/classifier parameter received no gradient.

    python scripts/04_finetune_esm2.py --model-id facebook/esm2_t6_8M_UR50D --dataset pft \
        --data-dir data/splits --output-dir results/esm2_8m/pft --extract-embeddings
"""
import argparse
import json
import math
import os
import pickle
import platform

import numpy as np
import pandas as pd
import torch
import transformers
from sklearn.metrics import accuracy_score, matthews_corrcoef, roc_auc_score
from torch.utils.data import Dataset
from transformers import (AutoTokenizer, DataCollatorWithPadding, EarlyStoppingCallback, EsmForSequenceClassification, Trainer,
                          TrainingArguments, set_seed)

from embed_utils import extract_for_dataframe
from plm_common import MAX_LEN, SPLITS, splits_manifest


def parse_args():
    p = argparse.ArgumentParser()
    p.add_argument("--model-id", default="facebook/esm2_t6_8M_UR50D")
    p.add_argument("--dataset", required=True)
    p.add_argument("--data-dir", default="data/splits")
    p.add_argument("--output-dir", required=True)
    p.add_argument("--max-length", type=int, default=MAX_LEN)
    p.add_argument("--epochs", type=int, default=10)
    p.add_argument("--batch-size", type=int, default=32)
    p.add_argument("--grad-accum", type=int, default=1)
    p.add_argument("--lr", type=float, default=1e-5)
    p.add_argument("--weight-decay", type=float, default=0.01)
    p.add_argument("--patience", type=int, default=3)
    p.add_argument("--seed", type=int, default=42)
    p.add_argument("--freeze-layers", type=int, default=0)
    p.add_argument("--no-gradient-checkpointing", action="store_true")
    p.add_argument("--extract-embeddings", action="store_true")
    p.add_argument("--embed-batch-size", type=int, default=16)
    p.add_argument("--num-workers", type=int, default=2)
    return p.parse_args()


class ProteinDataset(Dataset):
    def __init__(self, df, tokenizer, max_length):
        self.seqs = df["sequence"].tolist()
        self.labels = df["label"].astype(int).tolist()
        self.tok = tokenizer
        self.max_length = max_length + 2  # <cls>, <eos>

    def __len__(self):
        return len(self.seqs)

    def __getitem__(self, i):
        # no padding here: DataCollatorWithPadding pads each batch to its own longest sequence (masked, so the
        # result is identical to padding to 1024 but several times cheaper)
        enc = self.tok(self.seqs[i], truncation=True, max_length=self.max_length, padding=False)
        return {"input_ids": enc["input_ids"], "attention_mask": enc["attention_mask"], "labels": self.labels[i]}


def apply_freeze(model, n_freeze):
    if n_freeze == 0:
        return
    for prm in model.esm.embeddings.parameters():
        prm.requires_grad = False
    for i, layer in enumerate(model.esm.encoder.layer):
        if i < n_freeze:
            for prm in layer.parameters():
                prm.requires_grad = False
    tot = sum(p.numel() for p in model.parameters())
    trn = sum(p.numel() for p in model.parameters() if p.requires_grad)
    print(f"Froze embeddings + bottom {n_freeze} layers. Trainable {trn:,}/{tot:,} ({100*trn/tot:.1f}%)")


def metrics_from_logits(logits, labels):
    logits = np.asarray(logits, dtype=np.float64)
    z = logits - logits.max(1, keepdims=True)
    probs = (np.exp(z) / np.exp(z).sum(1, keepdims=True))[:, 1]
    preds = (probs >= 0.5).astype(int)
    return probs, {"roc_auc": float(roc_auc_score(labels, probs)), "mcc": float(matthews_corrcoef(labels, preds)),
                   "accuracy": float(accuracy_score(labels, preds))}


def compute_metrics(eval_pred):
    logits, labels = eval_pred
    if isinstance(logits, tuple):
        logits = logits[0]
    return metrics_from_logits(logits, labels)[1]


class CheckedTrainer(Trainer):
    """Aborts if, after the first backward pass, an unfrozen encoder/classifier parameter has no gradient."""

    _grad_checked = False

    def training_step(self, *args, **kwargs):
        loss = super().training_step(*args, **kwargs)
        if not self._grad_checked:
            bad = [n for n, p in self.model.named_parameters()
                   if p.requires_grad and (n.startswith("esm.encoder") or n.startswith("classifier")) and p.grad is None]
            if bad:
                raise RuntimeError(f"{len(bad)} trainable parameters received no gradient (e.g. {bad[:3]}); "
                                   "check freezing / gradient checkpointing")
            self._grad_checked = True
        return loss


def main():
    a = parse_args()
    set_seed(a.seed)
    os.makedirs(a.output_dir, exist_ok=True)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    dfs = {sp: pd.read_csv(os.path.join(a.data_dir, a.dataset, f"{sp}.csv")) for sp in SPLITS}
    print({sp: len(d) for sp, d in dfs.items()}, "train label dist:", dfs["train"]["label"].value_counts().to_dict())
    too_long = {sp: int((d["sequence"].str.len() > a.max_length).sum()) for sp, d in dfs.items()}
    if any(too_long.values()):
        raise ValueError(f"sequences longer than {a.max_length} found {too_long}: run 00_harmonize_length_policy.py")

    tok = AutoTokenizer.from_pretrained(a.model_id)
    model = EsmForSequenceClassification.from_pretrained(a.model_id, num_labels=2)
    apply_freeze(model, a.freeze_layers)
    ds = {sp: ProteinDataset(d, tok, a.max_length) for sp, d in dfs.items()}

    steps_per_epoch = math.ceil(len(ds["train"]) / (a.batch_size * a.grad_accum))
    args = TrainingArguments(
        output_dir=os.path.join(a.output_dir, "trainer_state"),
        num_train_epochs=a.epochs, per_device_train_batch_size=a.batch_size,
        per_device_eval_batch_size=a.batch_size * 2, gradient_accumulation_steps=a.grad_accum,
        learning_rate=a.lr, weight_decay=a.weight_decay, max_grad_norm=1.0,
        warmup_steps=max(1, int(0.1 * steps_per_epoch * a.epochs)), lr_scheduler_type="cosine",
        eval_strategy="epoch", save_strategy="epoch", load_best_model_at_end=True,
        metric_for_best_model="eval_roc_auc", greater_is_better=True,
        fp16=torch.cuda.is_available(),
        gradient_checkpointing=not a.no_gradient_checkpointing,
        gradient_checkpointing_kwargs={"use_reentrant": False},
        dataloader_num_workers=a.num_workers, seed=a.seed, data_seed=a.seed,
        report_to="none", logging_steps=20, save_total_limit=1, save_only_model=True,
    )
    trainer = CheckedTrainer(model=model, args=args, train_dataset=ds["train"], eval_dataset=ds["val"],
                             data_collator=DataCollatorWithPadding(tok),
                             compute_metrics=compute_metrics,
                             callbacks=[EarlyStoppingCallback(early_stopping_patience=a.patience)])
    trainer.train()
    best_val = trainer.state.best_metric
    print(f"best val AUROC {best_val:.4f}  ({trainer.state.best_model_checkpoint})")

    # test split: touched exactly once, after model selection
    pred = trainer.predict(ds["test"])
    logits = pred.predictions[0] if isinstance(pred.predictions, tuple) else pred.predictions
    probs, m = metrics_from_logits(logits, dfs["test"]["label"].astype(int).to_numpy())
    res = {"test_roc_auc": m["roc_auc"], "test_mcc": m["mcc"], "test_accuracy": m["accuracy"],
           "best_val_roc_auc": float(best_val), "n_test": len(dfs["test"])}
    print(json.dumps(res, indent=2))
    pd.DataFrame({"id": dfs["test"]["id"], "label": dfs["test"]["label"], "prob": probs}).to_csv(
        os.path.join(a.output_dir, "test_predictions.csv"), index=False)

    trainer.save_model(a.output_dir)
    tok.save_pretrained(a.output_dir)
    json.dump(res, open(os.path.join(a.output_dir, "test_results.json"), "w"), indent=2)
    json.dump(trainer.state.log_history, open(os.path.join(a.output_dir, "training_log.json"), "w"), indent=2)
    json.dump({"args": vars(a), "split_sha256": splits_manifest(a.data_dir, [a.dataset]),
               "torch": torch.__version__, "transformers": transformers.__version__,
               "python": platform.python_version(), "cuda": torch.cuda.is_available()},
              open(os.path.join(a.output_dir, "provenance.json"), "w"), indent=2)

    if a.extract_embeddings:
        model.eval().to(device)
        edir = os.path.join(a.output_dir, "embeddings")
        os.makedirs(edir, exist_ok=True)
        for sp in SPLITS:
            reps = extract_for_dataframe(model.esm, tok, dfs[sp], device, a.embed_batch_size, a.max_length)
            with open(os.path.join(edir, f"{sp}_embeddings.pkl"), "wb") as f:
                pickle.dump(reps, f)
            print(f"  [{sp}] embeddings {reps['cls'].shape}")


if __name__ == "__main__":
    main()
