"""
Single implementation of representation extraction, used for pretrained models (02), fine-tuned models
(04, extract_finetuned_embeddings, 13) and external sequences (eval_dataset5).  Using ONE function for all
of them guarantees that pretrained and fine-tuned representations are pooled identically.

Pooling definitions
-------------------
cls  : hidden state at token position 0 (<cls>), every layer (index 0 = embedding output).
mean : mean over residue tokens only (<cls>, <eos>, padding excluded), every layer.
Layer index L (= last) is the post final-LayerNorm hidden state (HF applies emb_layer_norm_after to it).
"""
import numpy as np

from plm_common import MAX_LEN, seq_hash


def residue_mask(attention_mask):
    """(B,T) 0/1 attention mask -> float32 mask that is 1 only on residue tokens (drops <cls>, <eos>, pad)."""
    m = np.asarray(attention_mask).astype(np.float32).copy()
    lengths = m.sum(1).astype(int)
    m[:, 0] = 0.0
    m[np.arange(m.shape[0]), np.maximum(lengths - 1, 0)] = 0.0
    return m


def window_starts(length, max_len=MAX_LEN, stride=511):
    """Start offsets of overlapping windows covering a sequence of `length`; last window anchored at the end."""
    if length <= max_len:
        return [0]
    starts, s = [], 0
    while True:
        starts.append(s)
        if s + max_len >= length:
            break
        nxt = s + stride
        if nxt + max_len > length:
            nxt = length - max_len
        s = nxt
    return starts


def _encode(backbone, tokenizer, seqs, device, max_len):
    import torch

    enc = tokenizer(list(seqs), return_tensors="pt", truncation=True, max_length=max_len + 2, padding=True)
    enc = {k: v.to(device) for k, v in enc.items()}
    with torch.no_grad():
        out = backbone(input_ids=enc["input_ids"], attention_mask=enc["attention_mask"], output_hidden_states=True)
        hs = torch.stack(out.hidden_states, dim=0).float()  # (L+1, B, T, D)
        cls = hs[:, :, 0, :]
        m = torch.from_numpy(residue_mask(enc["attention_mask"].cpu().numpy())).to(hs.device)
        cnt = m.sum(1).clamp(min=1.0)  # (B,)
        mean = (hs * m[None, :, :, None]).sum(2) / cnt[None, :, None]
    return cls.permute(1, 0, 2).cpu().numpy(), mean.permute(1, 0, 2).cpu().numpy()  # (B, L+1, D)


def extract_representations(backbone, tokenizer, seqs, device, batch_size=16, max_len=MAX_LEN, stride=511):
    """Return (cls, mean, windowed) for a list of sequences. Sequences longer than max_len are
    window-pooled (mean of per-window vectors); all others are encoded in batches. Order is preserved."""
    backbone.eval()
    seqs = [str(s).strip().upper() for s in seqs]
    for s in seqs:
        if "/" in s or len(s) == 0:
            raise ValueError("sequence contains a chain separator '/' or is empty")
    n = len(seqs)
    cls_out, mean_out = [None] * n, [None] * n
    windowed = [len(s) > max_len for s in seqs]
    short = [i for i, s in enumerate(seqs) if len(s) <= max_len]
    for b in range(0, len(short), batch_size):
        idx = short[b:b + batch_size]
        c, m = _encode(backbone, tokenizer, [seqs[i] for i in idx], device, max_len)
        for j, i in enumerate(idx):
            cls_out[i], mean_out[i] = c[j], m[j]
    for i in [i for i, w in enumerate(windowed) if w]:
        starts = window_starts(len(seqs[i]), max_len, stride)
        c, m = _encode(backbone, tokenizer, [seqs[i][s:s + max_len] for s in starts], device, max_len)
        cls_out[i], mean_out[i] = c.mean(0), m.mean(0)
    return np.stack(cls_out), np.stack(mean_out), windowed


def extract_for_dataframe(backbone, tokenizer, df, device, batch_size=16, max_len=MAX_LEN, stride=511):
    cls, mean, windowed = extract_representations(backbone, tokenizer, df["sequence"].tolist(), device,
                                                  batch_size, max_len, stride)
    return {
        "cls": cls.astype(np.float32),
        "mean": mean.astype(np.float32),
        "labels": df["label"].astype(int).tolist(),
        "ids": [str(i) for i in df["id"]],
        "seq_sha256": seq_hash(df["sequence"]),
        "windowed": windowed,
    }
