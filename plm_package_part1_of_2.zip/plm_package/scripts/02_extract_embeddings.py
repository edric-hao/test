"""
Extract layer-wise CLS and mean-pooled representations from a PRETRAINED (not fine-tuned) ESM-2 model.
Uses embed_utils.extract_for_dataframe, the same code path as the fine-tuned extraction.

    python scripts/02_extract_embeddings.py --model-id facebook/esm2_t6_8M_UR50D --dataset pft \
        --data-dir data/splits --output-dir results/embeddings/pretrained/esm2_8m/pft
"""
import argparse
import os
import pickle

import pandas as pd
import torch
from transformers import AutoTokenizer, EsmModel

from embed_utils import extract_for_dataframe
from plm_common import MAX_LEN, SPLITS


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--model-id", default="facebook/esm2_t6_8M_UR50D")
    p.add_argument("--dataset", required=True)
    p.add_argument("--data-dir", default="data/splits")
    p.add_argument("--output-dir", required=True)
    p.add_argument("--max-length", type=int, default=MAX_LEN)
    p.add_argument("--batch-size", type=int, default=32)
    p.add_argument("--stride", type=int, default=511)
    p.add_argument("--splits", nargs="+", default=SPLITS)
    a = p.parse_args()

    os.makedirs(a.output_dir, exist_ok=True)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    tok = AutoTokenizer.from_pretrained(a.model_id)
    model = EsmModel.from_pretrained(a.model_id, torch_dtype=torch.float32, add_pooling_layer=False).to(device)
    print(f"Model {a.model_id}: {sum(p.numel() for p in model.parameters()):,} params  device={device}")

    for sp in a.splits:
        csv = os.path.join(a.data_dir, a.dataset, f"{sp}.csv")
        if not os.path.exists(csv):
            raise FileNotFoundError(csv)
        df = pd.read_csv(csv)
        reps = extract_for_dataframe(model, tok, df, device, a.batch_size, a.max_length, a.stride)
        if any(reps["windowed"]):
            print(f"  [{sp}] {sum(reps['windowed'])} sequences were window-pooled")
        out = os.path.join(a.output_dir, f"{sp}_embeddings.pkl")
        with open(out, "wb") as f:
            pickle.dump(reps, f)
        print(f"  [{sp}] n={len(df)} cls={reps['cls'].shape} -> {out}")


if __name__ == "__main__":
    main()
