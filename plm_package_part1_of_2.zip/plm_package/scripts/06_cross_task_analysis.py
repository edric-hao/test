"""
Cross-task transfer of probe directions and direction geometry.

Transfer matrix M[i, j]: AUROC of task-i's MM direction (fit on task-i TRAIN, at task-i's val-selected layer)
scored on task-j TEST representations.  Rows/columns follow --datasets.

IMPORTANT - a direction is only meaningful inside the representation space it was fit in, so the evaluation
embeddings must come from the SAME backbone as the direction:
  --space pretrained : one shared pretrained backbone  (results/embeddings/pretrained/<model>/<task>)
  --space finetuned  : backbone fine-tuned on task i, applied to every task's test set
                       (results/cross_task_ft/<model>/<train_task>/<eval_task>, from 13_cross_task_ft_extract.py)
Cosine similarity / PCA between directions is only computed for --space pretrained (shared coordinates).

Leakage: if results/leakage/cross_pair_exclusions.json exists (from 12_cross_dataset_leakage.py), test sequences
of task j that are similar to task i's TRAIN set are excluded from M[i, j] (reported as n_excluded).
M_polarity_free = max(AUROC, 1-AUROC) because label polarity differs between tasks.
"""
import argparse
import json
import os

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

from plm_common import DATASETS, auroc, best_layer_by_val, check_embeddings_match, load_json, load_pkl, unit

LABELS = {"pft": "PFT", "virulence": "Virulence", "peptide_tox": "Pep-Tox", "signal_peptide": "Signal-P"}


def pair_key(i, j):
    return f"{i}->{j}"


def transfer_matrix(get_direction, get_test, datasets, exclusions=None):
    """get_direction(task)->(unit vec, layer); get_test(train_task, eval_task)->(X_layer_fn(layer)->(N,D), y).
    Returns (raw, polarity_free, n_eval, n_excluded) matrices."""
    n = len(datasets)
    raw, pol = np.full((n, n), np.nan), np.full((n, n), np.nan)
    n_eval, n_excl = np.zeros((n, n), int), np.zeros((n, n), int)
    for a, ti in enumerate(datasets):
        d, layer = get_direction(ti)
        for b, tj in enumerate(datasets):
            X_fn, y = get_test(ti, tj)
            X = X_fn(layer)
            keep = np.ones(len(y), bool)
            if exclusions and a != b:
                ex = np.asarray(exclusions.get(pair_key(ti, tj), []), dtype=int)
                keep[ex] = False
            n_excl[a, b] = int((~keep).sum())
            n_eval[a, b] = int(keep.sum())
            if len(np.unique(y[keep])) < 2:
                continue
            v = auroc(y[keep], X[keep] @ d)
            raw[a, b], pol[a, b] = v, max(v, 1 - v)
    return raw, pol, n_eval, n_excl


def heatmap(M, datasets, title, path, vmin=0.0, vmax=1.0):
    lab = [LABELS.get(d, d) for d in datasets]
    fig, ax = plt.subplots(figsize=(6, 5))
    im = ax.imshow(M, vmin=vmin, vmax=vmax, cmap="RdYlGn")
    ax.set_xticks(range(len(lab))); ax.set_xticklabels(lab, rotation=35, ha="right")
    ax.set_yticks(range(len(lab))); ax.set_yticklabels(lab)
    ax.set_xlabel("evaluated on (test)"); ax.set_ylabel("direction fit on (train)"); ax.set_title(title)
    for i in range(len(lab)):
        for j in range(len(lab)):
            if not np.isnan(M[i, j]):
                ax.text(j, i, f"{M[i, j]:.2f}", ha="center", va="center", fontsize=9)
    plt.colorbar(im, ax=ax)
    plt.tight_layout(); plt.savefig(path, dpi=120); plt.close()


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--results-root", default="results")
    p.add_argument("--data-dir", default="data/splits")
    p.add_argument("--model-short", required=True)
    p.add_argument("--space", default="pretrained", choices=["pretrained", "finetuned"])
    p.add_argument("--pooling", default="cls", choices=["cls", "mean"])
    p.add_argument("--datasets", nargs="+", default=DATASETS)
    p.add_argument("--output-dir", required=True)
    a = p.parse_args()
    os.makedirs(a.output_dir, exist_ok=True)
    R, m = a.results_root, a.model_short
    probe_root = os.path.join(R, "probes", a.space, m)

    dirs_cache, test_df = {}, {t: pd.read_csv(os.path.join(a.data_dir, t, "test.csv")) for t in a.datasets}

    def get_direction(task):
        if task not in dirs_cache:
            pr = load_json(os.path.join(probe_root, task, "probe_results.json"))[a.pooling]
            layer = best_layer_by_val(pr, "mm")["layer"]
            dirs = load_json(os.path.join(probe_root, task, f"mm_directions_{a.pooling}.json"))
            dirs_cache[task] = (unit(dirs[str(layer)]), layer)
        return dirs_cache[task]

    def get_test(ti, tj):
        if a.space == "pretrained":
            path = os.path.join(R, "embeddings", "pretrained", m, tj, "test_embeddings.pkl")
        else:
            path = os.path.join(R, "cross_task_ft", m, ti, tj, "test_embeddings.pkl")
        emb = load_pkl(path)
        check_embeddings_match(emb, test_df[tj], f"{path}")
        X = emb[a.pooling]
        return (lambda layer: np.asarray(X[:, layer, :], dtype=np.float64)), np.asarray(emb["labels"]).astype(int)

    ex_path = os.path.join(R, "leakage", "cross_pair_exclusions.json")
    exclusions = load_json(ex_path) if os.path.exists(ex_path) else None
    raw, pol, n_eval, n_excl = transfer_matrix(get_direction, get_test, a.datasets, exclusions)
    layers = {t: get_direction(t)[1] for t in a.datasets}
    for i, ti in enumerate(a.datasets):
        for j, tj in enumerate(a.datasets):
            print(f"{m} [{a.space}] dir({ti}, L{layers[ti]}) -> {tj}: AUROC {raw[i, j]:.3f} "
                  f"(n={n_eval[i, j]}, excluded {n_excl[i, j]})")
    heatmap(raw, a.datasets, f"{m} {a.space} {a.pooling}: raw AUROC", os.path.join(a.output_dir, f"transfer_raw_{a.pooling}.png"))
    heatmap(pol, a.datasets, f"{m} {a.space} {a.pooling}: polarity-free", os.path.join(a.output_dir, f"transfer_polfree_{a.pooling}.png"), 0.5, 1.0)

    out = {"model": m, "space": a.space, "pooling": a.pooling, "datasets": list(a.datasets),
           "direction_layer": layers, "auroc_raw": raw.tolist(), "auroc_polarity_free": pol.tolist(),
           "n_eval": n_eval.tolist(), "n_excluded_for_leakage": n_excl.tolist(),
           "leakage_exclusions_applied": exclusions is not None}

    if a.space == "pretrained":  # cosine geometry in shared coordinates, per layer, with chance level
        alld = {t: load_json(os.path.join(probe_root, t, f"mm_directions_{a.pooling}.json")) for t in a.datasets}
        n_layers = min(len(v) for v in alld.values())
        cos = {}
        for layer in range(n_layers):
            raw_d = [np.asarray(alld[t][str(layer)], dtype=np.float64) for t in a.datasets]
            if not all(np.any(v) for v in raw_d):  # degenerate layer-0 <cls>: direction undefined
                cos[str(layer)] = None
                continue
            D = np.stack([unit(v) for v in raw_d])
            cos[str(layer)] = (D @ D.T).tolist()
        dim = len(alld[a.datasets[0]]["0"])
        out["cosine_similarity_per_layer"] = cos
        out["cosine_chance_sd"] = float(1 / np.sqrt(dim))
        # same-layer cosine at each task's val-selected layer is NOT used: layers differ across tasks.
    with open(os.path.join(a.output_dir, f"cross_task_{a.space}_{a.pooling}.json"), "w") as f:
        json.dump(out, f, indent=2)


if __name__ == "__main__":
    main()
