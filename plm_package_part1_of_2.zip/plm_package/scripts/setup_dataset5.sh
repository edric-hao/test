#!/usr/bin/env bash
# Tools for the OPTIONAL D5 (ProteinMPNN stress test). Run from the project root. Needs network + a GPU for ESMFold.
set -euo pipefail
cd "$(dirname "$0")/.."
PY=${PY:-python}
[ -d ProteinMPNN ] || git clone https://github.com/dauparas/ProteinMPNN ProteinMPNN
$PY -m pip install fair-esm tmtools requests "biopython" --quiet
mkdir -p data/raw
if [ ! -s data/raw/uniprot_toxin_seqs.fasta ]; then
  curl -sSL "https://rest.uniprot.org/uniprotkb/stream?query=keyword%3AKW-0800+AND+reviewed%3Atrue&format=fasta" \
       -o data/raw/uniprot_toxin_seqs.fasta
fi
grep -c '^>' data/raw/uniprot_toxin_seqs.fasta | xargs echo "toxin FASTA records:"
cat <<'MSG'
Next (needs BLAST+, GPU):
  python scripts/01_build_dataset5_proteinmpnn.py            # all steps; resumable with --step N
  python scripts/eval_dataset5.py                            # after the main pipeline produced fine-tuned D1 models
Record the UniProt download date and the ProteinMPNN commit (git -C ProteinMPNN rev-parse HEAD) in the paper.
MSG
