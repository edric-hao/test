"""Pure-python helpers for the D5 builder (no Biopython needed, unit-tested in tests/)."""
import io
import itertools

import numpy as np

AA3 = {'ALA': 'A', 'ARG': 'R', 'ASN': 'N', 'ASP': 'D', 'CYS': 'C', 'GLN': 'Q', 'GLU': 'E', 'GLY': 'G', 'HIS': 'H',
       'ILE': 'I', 'LEU': 'L', 'LYS': 'K', 'MET': 'M', 'PHE': 'F', 'PRO': 'P', 'SER': 'S', 'THR': 'T', 'TRP': 'W',
       'TYR': 'Y', 'VAL': 'V'}
STANDARD = set("ACDEFGHIKLMNPQRSTVWY")


def parse_fasta(text):
    recs, head, seq = [], None, []
    for line in text.splitlines():
        line = line.strip()
        if line.startswith(">"):
            if head is not None:
                recs.append((head, "".join(seq)))
            head, seq = line[1:], []
        elif line:
            seq.append(line)
    if head is not None:
        recs.append((head, "".join(seq)))
    return recs


def parse_pmpnn_designed(text):
    """Designed sequences from a ProteinMPNN seqs/*.fa file.

    The FIRST record is the native/input sequence (header without 'sample='); it is never returned.
    Records containing the multi-chain separator '/' or non-standard residues are dropped."""
    out = []
    for head, seq in parse_fasta(text):
        if "sample=" not in head:
            continue
        seq = seq.upper()
        if "/" in seq or not seq or not set(seq) <= STANDARD:
            continue
        out.append(seq)
    return out


def pdb_chains(pdb_text):
    """{chain_id: (list of (resseq, aa), Nx3 CA coords)} for standard residues with a CA atom (first model only)."""
    chains, seen = {}, set()
    for line in pdb_text.splitlines():
        if line.startswith("ENDMDL"):
            break
        if not line.startswith("ATOM") or line[12:16].strip() != "CA":
            continue
        if line[16] not in (" ", "A"):  # alternate locations: keep first
            continue
        aa = AA3.get(line[17:20].strip())
        if aa is None:
            continue
        ch, resseq = line[21], (line[22:27])
        if (ch, resseq) in seen:
            continue
        seen.add((ch, resseq))
        xyz = [float(line[30:38]), float(line[38:46]), float(line[46:54])]
        chains.setdefault(ch, ([], []))
        chains[ch][0].append((resseq.strip(), aa))
        chains[ch][1].append(xyz)
    return {c: (v[0], np.asarray(v[1], dtype=np.float64)) for c, v in chains.items()}


def first_chain(pdb_text, min_len=30):
    """(chain_id, sequence, coords) of the first chain with >= min_len standard residues, else None."""
    for ch, (res, xyz) in pdb_chains(pdb_text).items():
        if len(res) >= min_len:
            return ch, "".join(a for _, a in res), xyz
    return None


def ss_class(pdb_text, chain):
    """'alpha' if HELIX residues > SHEET residues on `chain`, 'beta' if the reverse, 'unknown' if neither is annotated."""
    helix = strand = 0
    for line in pdb_text.splitlines():
        try:
            if line.startswith("HELIX ") and line[19] == chain:
                helix += int(line[33:37]) - int(line[21:25]) + 1
            elif line.startswith("SHEET ") and line[21] == chain:
                strand += int(line[33:37]) - int(line[22:26]) + 1
        except ValueError:
            continue
    if helix == 0 and strand == 0:
        return "unknown"
    return "alpha" if helix > strand else "beta"


def mean_bfactor_ca(pdb_text):
    vals = [float(l[60:66]) for l in pdb_text.splitlines() if l.startswith("ATOM") and l[12:16].strip() == "CA"]
    return float(np.mean(vals)) if vals else float("nan")


def rcsb_resolution(entry_json):
    """(resolution_angstrom or None, experimental method) from an RCSB core/entry JSON (works for X-ray and EM)."""
    info = entry_json.get("rcsb_entry_info") or {}
    res = (info.get("resolution_combined") or [None])[0]
    method = ((entry_json.get("exptl") or [{}])[0]).get("method", "")
    return (float(res) if res is not None else None), method


def passes_resolution(res, method, max_xray, max_em):
    if res is None:
        return False
    m = (method or "").upper()
    if "ELECTRON MICROSCOPY" in m:
        return res <= max_em
    if "X-RAY" in m:
        return res <= max_xray
    return False


def identity_nw(a, b, match=2, mismatch=-1, gap=-2):
    """Global alignment identity = identical columns / alignment length (Needleman-Wunsch, linear gaps)."""
    n, m = len(a), len(b)
    if n == 0 or m == 0:
        return 0.0
    score = np.zeros((n + 1, m + 1), dtype=np.int32)
    score[:, 0] = np.arange(n + 1) * gap
    score[0, :] = np.arange(m + 1) * gap
    ptr = np.zeros((n + 1, m + 1), dtype=np.int8)  # 0 diag, 1 up, 2 left
    ptr[:, 0], ptr[0, :] = 1, 2
    A = np.frombuffer(a.encode(), dtype=np.uint8)
    B = np.frombuffer(b.encode(), dtype=np.uint8)
    for i in range(1, n + 1):
        sub = np.where(B == A[i - 1], match, mismatch)
        diag = score[i - 1, :-1] + sub
        up = score[i - 1, 1:] + gap
        row = score[i]
        for j in range(1, m + 1):
            left = row[j - 1] + gap
            d, u = diag[j - 1], up[j - 1]
            if d >= u and d >= left:
                row[j], ptr[i, j] = d, 0
            elif u >= left:
                row[j], ptr[i, j] = u, 1
            else:
                row[j], ptr[i, j] = left, 2
    i, j, ident, cols = n, m, 0, 0
    while i > 0 or j > 0:
        p = ptr[i, j]
        if i > 0 and j > 0 and p == 0:
            ident += int(a[i - 1] == b[j - 1]); i -= 1; j -= 1
        elif i > 0 and (p == 1 or j == 0):
            i -= 1
        else:
            j -= 1
        cols += 1
    return ident / cols


def mean_pairwise_identity_aligned(seqs):
    """Mean position-wise identity between equal-length sequences designed on the SAME backbone."""
    vals = [sum(x == y for x, y in zip(s, t)) / len(s) for s, t in itertools.combinations(seqs, 2) if len(s) == len(t)]
    return float(np.mean(vals)) if vals else float("nan")


def choose_temperature(per_parent_by_temp, threshold=0.5):
    """per_parent_by_temp: {T: [list of designed seqs per parent]}. Pairwise identity is computed WITHIN each parent
    and averaged over parents. Returns lowest T with mean identity < threshold, else the T with the lowest identity."""
    summary = {}
    for T, parents in per_parent_by_temp.items():
        vals = [mean_pairwise_identity_aligned(p) for p in parents if len(p) >= 2]
        vals = [v for v in vals if not np.isnan(v)]
        summary[T] = float(np.mean(vals)) if vals else float("nan")
    ok = sorted(T for T, v in summary.items() if not np.isnan(v) and v < threshold)
    if ok:
        return ok[0], summary
    valid = {T: v for T, v in summary.items() if not np.isnan(v)}
    if not valid:
        raise ValueError("temperature pilot produced no usable sequences")
    return min(valid, key=valid.get), summary


def shuffle_residues(seq, rng):
    arr = list(seq)
    rng.shuffle(arr)
    return "".join(arr)


def wilson(k, n, z=1.96):
    if n == 0:
        return [float("nan"), float("nan")]
    p = k / n
    den = 1 + z * z / n
    c = (p + z * z / (2 * n)) / den
    h = z * np.sqrt(p * (1 - p) / n + z * z / (4 * n * n)) / den
    return [float(c - h), float(c + h)]
