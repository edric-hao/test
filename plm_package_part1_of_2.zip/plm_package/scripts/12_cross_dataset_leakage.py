"""
Homology audit of the (frozen) split files. Makes NO changes to any split file.

Reports
  * within-dataset leakage : train/val vs test sequences that are similar (should be none for D1,D2,D4; D3 uses the
                             official CAPTP split and is homologous by construction - reported, never modified)
  * cross-dataset overlap  : test sequences of task B that are similar to TRAIN sequences of task A.  This only
                             matters for cross-task transfer (06); the offending test rows are written to
                             results/leakage/cross_pair_exclusions.json  {"A->B": [row indices of B/test.csv]}
                             and 06 drops them from M[A, B].
  within-dataset flagged test rows are written to results/leakage/flagged_test_rows.json (consumed by
  13_leakage_sensitivity.py, which re-scores the probes without them; no split is ever edited).

Methods
  mmseqs : MMseqs2 easy-cluster at --identity (default 0.30, coverage 0.5 of the shorter sequence). Reference method.
  kmer   : shared k-mer fraction >= --kmer-frac (default k=5, 0.30) in either direction. Dependency-free fallback;
           it is NOT equivalent to 30% identity clustering - report which method produced the audit.

    python scripts/12_cross_dataset_leakage.py --method mmseqs [--fail-on-within-dataset]
"""
import argparse
import json
import os
import subprocess
import tempfile
from collections import defaultdict

import pandas as pd

from plm_common import DATASETS, SPLITS

OFFICIAL_SPLIT = {"peptide_tox"}


def load_rows(data_dir, datasets=DATASETS):
    rows = []
    for ds in datasets:
        for sp in SPLITS:
            df = pd.read_csv(os.path.join(data_dir, ds, f"{sp}.csv"))
            for i, s in enumerate(df["sequence"]):
                rows.append({"ds": ds, "split": sp, "idx": i, "seq": str(s)})
    return rows


def groups_from_kmers(rows, k=5, frac=0.30):
    """Pairs (as 2-member groups) of rows sharing >= frac of the k-mers of either member."""
    sets = [{r["seq"][i:i + k] for i in range(len(r["seq"]) - k + 1)} for r in rows]
    inv = defaultdict(list)
    for j, st in enumerate(sets):
        for x in st:
            inv[x].append(j)
    groups = []
    for i, st in enumerate(sets):
        if not st:
            continue
        cnt = defaultdict(int)
        for x in st:
            for j in inv[x]:
                if j > i:
                    cnt[j] += 1
        for j, c in cnt.items():
            if max(c / len(st), c / max(len(sets[j]), 1)) >= frac:
                groups.append([i, j])
    return groups


def parse_cluster_tsv(text):
    """MMseqs '<rep>\\t<member>' lines -> list of groups of row indices (ids are 'r<row>')."""
    clusters = defaultdict(list)
    for line in text.splitlines():
        parts = line.strip().split("\t")
        if len(parts) == 2:
            clusters[parts[0]].append(int(parts[1][1:]))
    return [sorted(set(g)) for g in clusters.values() if len(g) > 1]


def groups_from_mmseqs(rows, identity, threads):
    with tempfile.TemporaryDirectory() as tmp:
        fa, pre, wd = os.path.join(tmp, "all.fa"), os.path.join(tmp, "clu"), os.path.join(tmp, "wd")
        with open(fa, "w") as f:
            f.writelines(f">r{i}\n{r['seq']}\n" for i, r in enumerate(rows))
        subprocess.run(["mmseqs", "easy-cluster", fa, pre, wd, "--min-seq-id", str(identity), "-c", "0.5",
                        "--cov-mode", "1", "--threads", str(threads), "-v", "1"], check=True, capture_output=True)
        with open(pre + "_cluster.tsv") as f:
            return parse_cluster_tsv(f.read())


def _collect(rows, groups):
    within = defaultdict(set)   # ds -> set of test idx similar to a train/val row of the same dataset
    excl = defaultdict(set)     # "A->B" -> test idx of B similar to train of A
    for g in groups:
        for t in g:
            rt = rows[t]
            if rt["split"] != "test":
                continue
            for o in g:
                ro = rows[o]
                if ro["split"] not in ("train", "val") or o == t:
                    continue
                if ro["ds"] == rt["ds"]:
                    within[rt["ds"]].add(rt["idx"])
                elif ro["split"] == "train":
                    excl[f"{ro['ds']}->{rt['ds']}"].add(rt["idx"])
    return within, excl


def within_rows(rows, groups):
    """{dataset: sorted row indices of <dataset>/test.csv that are similar to a train/val row of the SAME dataset}.
    Used by 13_leakage_sensitivity.py; never used to edit a split."""
    within, _ = _collect(rows, groups)
    return {ds: sorted(within.get(ds, ())) for ds in DATASETS}


def analyse(rows, groups):
    """Return (report dict, exclusions dict)."""
    within, excl = _collect(rows, groups)
    n_test = {ds: sum(1 for r in rows if r["ds"] == ds and r["split"] == "test") for ds in DATASETS}
    report = {"within_dataset_test_rows_similar_to_train_or_val": {ds: len(v) for ds, v in within.items()},
              "within_dataset_fraction": {ds: len(within.get(ds, ())) / max(n_test[ds], 1) for ds in DATASETS},
              "cross_pair_excluded_test_rows": {k: len(v) for k, v in excl.items()}, "n_test": n_test}
    return report, {k: sorted(v) for k, v in excl.items()}


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--data-dir", default="data/splits")
    p.add_argument("--output-dir", default="results/leakage")
    p.add_argument("--method", default="mmseqs", choices=["mmseqs", "kmer"])
    p.add_argument("--identity", type=float, default=0.30)
    p.add_argument("--kmer", type=int, default=5)
    p.add_argument("--kmer-frac", type=float, default=0.30)
    p.add_argument("--threads", type=int, default=4)
    p.add_argument("--fail-on-within-dataset", action="store_true",
                   help="exit 1 if any non-official dataset has test sequences similar to its train/val")
    a = p.parse_args()
    rows = load_rows(a.data_dir)
    groups = (groups_from_mmseqs(rows, a.identity, a.threads) if a.method == "mmseqs"
              else groups_from_kmers(rows, a.kmer, a.kmer_frac))
    report, excl = analyse(rows, groups)
    report["method"] = a.method
    report["params"] = ({"identity": a.identity, "coverage": 0.5, "cov_mode": 1} if a.method == "mmseqs"
                        else {"k": a.kmer, "frac": a.kmer_frac})
    os.makedirs(a.output_dir, exist_ok=True)
    json.dump(report, open(os.path.join(a.output_dir, "leakage_report.json"), "w"), indent=2)
    json.dump(excl, open(os.path.join(a.output_dir, "cross_pair_exclusions.json"), "w"))
    json.dump({"method": report["method"], "params": report["params"], "rows": within_rows(rows, groups)},
              open(os.path.join(a.output_dir, "flagged_test_rows.json"), "w"))
    print(json.dumps(report, indent=2))
    bad = {d: n for d, n in report["within_dataset_test_rows_similar_to_train_or_val"].items()
           if d not in OFFICIAL_SPLIT and n > 0}
    if bad and a.fail_on_within_dataset:
        print("WITHIN-DATASET LEAKAGE:", bad)
        raise SystemExit(1)


if __name__ == "__main__":
    main()
