#!/usr/bin/env bash
# =============================================================================
# End-to-end pipeline on the FROZEN splits (data/splits, verified against data/MANIFEST.sha256).
# Dataset construction is NOT part of the pipeline (see data_construction/ and README): the splits are an input.
#
#   SKIP_3B=1 (default) excludes ESM-2 3B everywhere.   PY=python (override for conda run etc.)
#   MODELS="esm2_8m esm2_35m ..." restricts the model list.   BASE=<dir> results root (default: results)
#
# Resumable: every expensive step is skipped when its output exists. Outputs of a different data version are
# refused (results/.data_manifest_sha256), never silently mixed.
# Prerequisites: pip install -r requirements.txt ; bash scripts/install_biotools.sh (mmseqs2, blast+)
# =============================================================================
set -euo pipefail
cd "$(dirname "$0")/.."
PY=${PY:-python}
BASE=${BASE:-results}
SKIP_3B=${SKIP_3B:-1}
DATASETS=(pft virulence peptide_tox signal_peptide)
# short : HF id : extract-bs : finetune-bs : grad-accum : freeze-layers   (T4-16GB sized; effective FT batch = bs*accum)
declare -A HF=( [esm2_8m]=facebook/esm2_t6_8M_UR50D [esm2_35m]=facebook/esm2_t12_35M_UR50D
                [esm2_150m]=facebook/esm2_t30_150M_UR50D [esm2_650m]=facebook/esm2_t33_650M_UR50D [esm2_3b]=facebook/esm2_t36_3B_UR50D )
declare -A EBS=( [esm2_8m]=64 [esm2_35m]=64 [esm2_150m]=32 [esm2_650m]=8 [esm2_3b]=2 )
declare -A FBS=( [esm2_8m]=32 [esm2_35m]=32 [esm2_150m]=16 [esm2_650m]=4 [esm2_3b]=1 )
declare -A ACC=( [esm2_8m]=1 [esm2_35m]=1 [esm2_150m]=2 [esm2_650m]=8 [esm2_3b]=32 )
declare -A FRZ=( [esm2_8m]=0 [esm2_35m]=0 [esm2_150m]=0 [esm2_650m]=0 [esm2_3b]=30 )
MODELS=${MODELS:-"esm2_8m esm2_35m esm2_150m esm2_650m"}
[ "$SKIP_3B" = "0" ] && MODELS="$MODELS esm2_3b"
INC3B=""; [ "$SKIP_3B" = "0" ] && INC3B="--include-3b"
log() { echo; echo "=== [$(date '+%H:%M:%S')] $* ==="; }
mkdir -p "$BASE" logs

log "0. verify frozen data"
$PY scripts/verify_data.py
M_SHA=$(sha256sum data/MANIFEST.sha256 | cut -d' ' -f1)
if [ -f "$BASE/.data_manifest_sha256" ] && [ "$(cat "$BASE/.data_manifest_sha256")" != "$M_SHA" ]; then
  echo "ERROR: $BASE was produced from a different data version. Move/delete it before re-running." >&2; exit 1
fi
echo "$M_SHA" > "$BASE/.data_manifest_sha256"

log "1. homology audit + per-pair exclusions (needed by cross-task transfer)"
if command -v mmseqs >/dev/null; then METHOD=mmseqs; else METHOD=kmer; echo "WARNING: mmseqs not found -> k-mer fallback audit (state this in the paper)"; fi
[ -f "$BASE/leakage/leakage_report.json" ] || $PY scripts/12_cross_dataset_leakage.py --method $METHOD --output-dir "$BASE/leakage"

log "2. non-PLM shortcut baselines"
$PY scripts/11_shortcut_baselines.py --output-dir "$BASE"

for M in $MODELS; do
  for DS in "${DATASETS[@]}"; do
    log "$M / $DS : pretrained embeddings + probes"
    PE="$BASE/embeddings/pretrained/$M/$DS"
    [ -f "$PE/test_embeddings.pkl" ] || $PY scripts/02_extract_embeddings.py --model-id "${HF[$M]}" --dataset "$DS" \
        --output-dir "$PE" --batch-size "${EBS[$M]}"
    $PY scripts/03_linear_probe.py --embeddings-dir "$PE" --output-dir "$BASE/probes/pretrained/$M/$DS" --dataset "$DS" --save-directions

    log "$M / $DS : fine-tune (val-AUROC early stopping, test touched once) + fine-tuned probes"
    FT="$BASE/$M/$DS"
    if [ ! -f "$FT/test_results.json" ]; then
      $PY scripts/04_finetune_esm2.py --model-id "${HF[$M]}" --dataset "$DS" --output-dir "$FT" \
          --batch-size "${FBS[$M]}" --grad-accum "${ACC[$M]}" --freeze-layers "${FRZ[$M]}" --embed-batch-size "${EBS[$M]}" --extract-embeddings
      rm -rf "$FT"/checkpoint-*
    fi
    $PY scripts/03_linear_probe.py --embeddings-dir "$FT/embeddings" --output-dir "$BASE/probes/finetuned/$M/$DS" --dataset "$DS" --save-directions

    log "$M / $DS : ablation"
    $PY scripts/05_causal_ablation.py --model-dir "$FT" --embeddings-dir "$FT/embeddings" \
        --directions-file "$BASE/probes/finetuned/$M/$DS/mm_directions_cls.json" --output-dir "$BASE/ablation/$M/$DS" --pooling cls
  done

  log "$M : cross-task (shared backbone per direction) + steering"
  $PY scripts/13_cross_task_ft_extract.py --model-short "$M" --results-root "$BASE" --embed-batch-size "${EBS[$M]}"
  for SP in pretrained finetuned; do
    $PY scripts/06_cross_task_analysis.py --model-short "$M" --space $SP --results-root "$BASE" --output-dir "$BASE/cross_task/$SP/$M"
  done
  $PY scripts/09_activation_steering.py --model-id "${HF[$M]}" --model-short "$M" --results-root "$BASE" --batch-size "${EBS[$M]}"
done

log "3. D3 BLAST baseline vs PLMs"
$PY scripts/annotate_d3_blast.py --output "$BASE/d3_blast/test_blast.csv"
for M in $MODELS; do $PY scripts/08_blast_vs_plm.py --model-short "$M" --results-root "$BASE" --blast-csv "$BASE/d3_blast/test_blast.csv"; done

log "4. bootstrap CIs, scaling (descriptive), seed variance"
for P in cls mean; do
  $PY scripts/10_bootstrap_ci.py --pooling $P --results-root "$BASE" --output-dir "$BASE/bootstrap_ci" $INC3B
  $PY scripts/07_scaling_curve.py --pooling $P --results-root "$BASE" --output-dir "$BASE/scaling_curve" $INC3B
done
echo "Seed variance: bash scripts/run_multiseed.sh   (afterwards re-run 07 so error bars appear)"

log "5. consistency check of every produced result"
$PY scripts/verify_consistency.py --results-root "$BASE"
echo "Optional D5 stress test: bash scripts/setup_dataset5.sh ; python scripts/01_build_dataset5_proteinmpnn.py ; python scripts/eval_dataset5.py"
