#!/usr/bin/env python3
"""
Seed variance of fine-tuned test AUROC.  Seed 42 is the main run (results/); extra seeds come from
run_multiseed.sh (results_seed<S>/). Between-size differences must be compared against this SD before any
'scaling' statement is made.

Expects fine-tuning runs laid out as results_seed{S}/{model}/{dataset}/test_results.json (what
scripts/run_multiseed.sh produces); results/{model}/{dataset} is seed 42.

Usage:  python scripts/14_seed_variance.py --models esm2_8m esm2_35m
"""
import argparse, glob, json, os
import numpy as np

DATASETS = ["pft", "virulence", "peptide_tox", "signal_peptide"]


def read_auroc(path):
    if not os.path.exists(path):
        return None
    j = json.load(open(path))
    for k in ("test_roc_auc", "test_auroc", "auroc", "eval_auroc", "eval_roc_auc"):
        if k in j: return float(j[k])
        if "test" in j and isinstance(j["test"], dict) and k in j["test"]: return float(j["test"][k])
    return None


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--models", nargs="+", default=["esm2_8m", "esm2_35m"])
    ap.add_argument("--base", default="results")
    ap.add_argument("--output", default="results/seed_variance.json")
    a = ap.parse_args()
    seed_dirs = {42: a.base}
    for d in sorted(glob.glob(a.base + "_seed*")):
        seed_dirs[int(d.rsplit("seed", 1)[1])] = d
    out = {}
    for m in a.models:
        for ds in DATASETS:
            vals = {s: read_auroc(os.path.join(d, m, ds, "test_results.json")) for s, d in seed_dirs.items()}
            vals = {s: v for s, v in vals.items() if v is not None}
            if len(vals) >= 2:
                v = np.array(list(vals.values()))
                out[f"{m}/{ds}"] = {"seeds": vals, "mean": float(v.mean()), "std": float(v.std(ddof=1)),
                                    "range": float(v.max() - v.min())}
                print(f"{m:<10}{ds:<16} n={len(v)} mean={v.mean():.4f} sd={v.std(ddof=1):.4f} range={v.max() - v.min():.4f}")
    os.makedirs(os.path.dirname(a.output), exist_ok=True)
    json.dump(out, open(a.output, "w"), indent=2)


if __name__ == "__main__":
    main()
