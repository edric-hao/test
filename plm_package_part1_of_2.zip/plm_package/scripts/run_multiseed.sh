#!/bin/bash
# Seed-variance runs (seeds 1-4; seed 42 is the main run in results/).
# Works for 8M, 35M, 150M and 650M with the SAME per-size settings as run_full_pipeline.sh
# (effective batch 32 everywhere: 32x1, 32x1, 16x2, 4x8; all layers trainable).
# Output: results_seed{S}/{model}/{dataset}/test_results.json ; aggregated by scripts/14_seed_variance.py
# Usage:  bash scripts/run_multiseed.sh
#         MODELS="esm2_150m esm2_650m" SEEDS="1 2 3 4" bash scripts/run_multiseed.sh
# Resumable: a run whose test_results.json exists is skipped.
set -euo pipefail
cd "$(dirname "$0")/.."
PY=${PY:-python}
SEEDS=${SEEDS:-"1 2 3 4"}
MODELS=${MODELS:-"esm2_8m esm2_35m esm2_150m esm2_650m"}
declare -A HF=( [esm2_8m]=facebook/esm2_t6_8M_UR50D [esm2_35m]=facebook/esm2_t12_35M_UR50D
                [esm2_150m]=facebook/esm2_t30_150M_UR50D [esm2_650m]=facebook/esm2_t33_650M_UR50D )
declare -A FBS=( [esm2_8m]=32 [esm2_35m]=32 [esm2_150m]=16 [esm2_650m]=4 )
declare -A ACC=( [esm2_8m]=1 [esm2_35m]=1 [esm2_150m]=2 [esm2_650m]=8 )
for M in $MODELS; do
  [ -n "${HF[$M]:-}" ] || { echo "unknown model $M" >&2; exit 1; }
done
# seed 42 must come from the final pipeline (provenance.json present), otherwise the seed set mixes pipelines
for M in $MODELS; do
  for DS in pft virulence peptide_tox signal_peptide; do
    [ -f "results/${M}/${DS}/provenance.json" ] || { echo "ERROR: results/${M}/${DS}/provenance.json missing - run the seed-42 fine-tune with the final pipeline first (scripts/run_150m_650m_final.sh)" >&2; exit 1; }
  done
done
for S in $SEEDS; do
  for M in $MODELS; do
    for DS in pft virulence peptide_tox signal_peptide; do
      OUT="results_seed${S}/${M}/${DS}"
      if [ -f "${OUT}/test_results.json" ]; then echo "[SKIP] ${OUT}"; continue; fi
      $PY scripts/04_finetune_esm2.py --model-id "${HF[$M]}" --dataset "$DS" --data-dir data/splits \
        --output-dir "$OUT" --batch-size "${FBS[$M]}" --grad-accum "${ACC[$M]}" --freeze-layers 0 --seed "$S"
      find "$OUT" -maxdepth 1 -type d -name "checkpoint-?*" -exec rm -rf {} +
      rm -f "$OUT/model.safetensors" "$OUT/training_args.bin"   # weights are not used downstream; saves ~2.5 GB per 650M run
    done
  done
done
$PY scripts/14_seed_variance.py --models esm2_8m esm2_35m esm2_150m esm2_650m
