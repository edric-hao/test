"""Shared helpers for the round-2 scripts (no asterisk character anywhere in this package).

Round 2 reads round 1 outputs (projections, manifests, seed_analysis.json in rerun_out) and writes only to rerun_out2.
"""
import json
import os
from pathlib import Path

import numpy as np

import alignlib2 as al
import common as C
import engine as eg
from mathx import mul, sq


# ----------------------------------------------------------------------------
# configuration and paths
# ----------------------------------------------------------------------------
def load_cfg2(path=None):
    p = path or os.environ.get("RERUN2_CONFIG") or str(C.PKG_DIR / "config_rerun2.yaml")
    cfg = C.load_cfg(p)
    cfg["_out1"] = cfg["_root"] / cfg["paths"]["round1_out_dir"]
    return cfg


def results_dir(cfg):
    return cfg["_out"] / "results"


def report_dir(cfg):
    d = cfg["_out"] / "report"
    d.mkdir(parents=True, exist_ok=True)
    return d


def proj_file(cfg, arch, tag):
    """Projection file of one network, looking in rerun_out2 first and then in rerun_out (round 1)."""
    for d in (cfg["_out"], cfg["_out1"]):
        p = d / "proj" / (arch + "__" + tag + ".npz")
        if p.exists():
            return p
    return None


def have_proj(cfg, arch, tag):
    return proj_file(cfg, arch, tag) is not None


def load_Z(cfg, arch, tag):
    p = proj_file(cfg, arch, tag)
    if p is None:
        raise SystemExit("no projection for %s/%s (run r2_c0_project.py, or round 1 s4_project.py)" % (arch, tag))
    return np.load(p)["Z"]


def zmap_for(cfg, design):
    return {nm: load_Z(cfg, nm.split("/", 1)[0], nm.split("/", 1)[1]) for nm in design.nets()}


def read_json(path, default=None):
    path = Path(path)
    if not path.exists():
        if default is not None:
            return default
        raise SystemExit("missing file: %s" % path)
    return json.loads(path.read_text())


def round1_manifest(cfg):
    return read_json(cfg["_out1"] / "results" / "new_seed_manifest.json", default={})


def round1_failed(cfg):
    out = {}
    for key, rec in round1_manifest(cfg).items():
        if not rec.get("gate_pass", True):
            out.setdefault(rec["arch"], []).append(rec["tag"])
    return out


def manifest2(cfg, name):
    return read_json(results_dir(cfg) / name, default={})


def failed_in(man):
    out = {}
    for key, rec in man.items():
        if not rec.get("gate_pass", True):
            out.setdefault(rec["arch"], []).append(rec["tag"])
    return out


# ----------------------------------------------------------------------------
# designs
# ----------------------------------------------------------------------------
def floor_sets(cfg, which=("orig", "regen")):
    orig = {a: list(cfg["floors"]["orig_tags"]) for a in cfg["archs"]}
    out = {}
    for w in which:
        if w == "orig":
            out["orig"] = orig
        elif w == "regen":
            reg = dict(orig)
            reg["gnina"] = list(cfg["floors"]["regen_tags"])
            if all(have_proj(cfg, "gnina", t) for t in reg["gnina"]):
                out["regen"] = reg
    return out


def round1_trained(cfg, include_failed=False):
    failed = round1_failed(cfg)
    out = {}
    for arch in cfg["archs"]:
        tags = []
        for t in cfg["seeds"]["trained_tags"]:
            if not include_failed and t in failed.get(arch, []):
                continue
            if have_proj(cfg, arch, t):
                tags.append(t)
        out[arch] = tags
    return out


def make_design(cfg, trained, which=("orig",)):
    fs = floor_sets(cfg, which)
    if not fs:
        raise SystemExit("no floor set available")
    return eg.Design(cfg["arch_pairs"], trained, fs)


# ----------------------------------------------------------------------------
# running the engine
# ----------------------------------------------------------------------------
def run_engine(cfg, Zmap, cov, clusters, design, modes, n_boot, rows=None, gram_fn=None, keep_draws=False, seed=None):
    an = cfg["analysis"]
    return eg.run_seed_analysis(Zmap, cov, clusters, design, list(modes), int(n_boot),
                                int(an["boot_seed"] if seed is None else seed),
                                rows=rows, boot_kind=an["boot_kind"], chunk=int(an["chunk"]),
                                min_den=float(an["min_denominator"]), max_undef=float(an["max_undefined_fraction"]),
                                level=float(an["ci_level"]), keep_draws=keep_draws, gram_fn=gram_fn, log=C.log)


def pick(res, mode, key, fset="orig", est="seed_min"):
    """One estimator record, or None."""
    try:
        return res[mode][key][fset]["estimators"][est]
    except KeyError:
        return None


def pair_key(A, B):
    return A + "_x_" + B


def pkey(p):
    """pair_key of a two-element pair."""
    return pair_key(p[0], p[1])


def split_net(nm):
    """'arch/tag' to (arch, tag)."""
    a, t = nm.split("/", 1)
    return a, t


def fnum(x, nd=3):
    if x is None:
        return "undefined"
    try:
        if not np.isfinite(x):
            return "undefined"
    except TypeError:
        return str(x)
    return ("%." + str(nd) + "f") % x


def fci(ci, nd=2):
    if ci is None or ci[0] is None or ci[1] is None:
        return "n/a"
    return "(%s, %s)" % (fnum(ci[0], nd), fnum(ci[1], nd))


def md_table(headers, rows):
    lines = ["| " + " | ".join(headers) + " |", "|" + "|".join(["---" for _ in headers]) + "|"]
    for r in rows:
        lines.append("| " + " | ".join(str(x) for x in r) + " |")
    return "\n".join(lines)


def write_report(cfg, name, text):
    p = report_dir(cfg) / (name + ".md")
    p.write_text(text)
    C.log("wrote " + str(p))


def summarize_pairs(res, modes, fset="orig", ests=("seed_min", "orig")):
    """Rows (list of lists) summarizing every arch pair, mode and estimator in an engine result."""
    rows = []
    for mode in modes:
        if mode not in res:
            continue
        for key in res[mode]:
            for en in ests:
                e = pick(res, mode, key, fset, en)
                if e is None:
                    continue
                rows.append([mode, key, en, fnum(e.get("obs")), fnum(e.get("floor")), fnum(e.get("ceil")),
                             fnum(e.get("nab")), fci(e.get("ci_complex")), fci(e.get("ci_two_level"))])
    return rows


SUMMARY_HEADERS = ["mode", "pair", "estimator", "CKA", "floor", "ceiling", "n_AB", "CI (clusters)", "CI (two-level)"]


# ----------------------------------------------------------------------------
# misc numerics
# ----------------------------------------------------------------------------
def design_matrix(cols):
    """Intercept plus the given columns (each (n,) or (n, k))."""
    parts = [np.ones((len(np.asarray(cols[0])), 1))]
    for c in cols:
        c = np.asarray(c, dtype=np.float64)
        parts.append(c.reshape(len(c), -1))
    return np.concatenate(parts, axis=1)


def resid_on(Z, D):
    sol = np.linalg.lstsq(D, Z, rcond=None)
    return np.asarray(Z, dtype=np.float64) - D @ sol[0]


def zscore(x):
    x = np.asarray(x, dtype=np.float64)
    sd = x.std(axis=0)
    return np.divide(x - x.mean(axis=0), np.where(sd > 0, sd, 1.0))


def tertile_labels(x, n=3):
    edges = np.quantile(x, np.linspace(0, 1, n + 1))
    edges[-1] = edges[-1] + 1.0
    lab = np.searchsorted(edges, x, side="right") - 1
    return np.clip(lab, 0, n - 1)


def within_stratum_permutation(strata, rng):
    """Permutation of row indices that only moves rows inside their own stratum."""
    perm = np.arange(len(strata))
    order = np.argsort(strata, kind="stable")
    s_sorted = np.asarray(strata)[order]
    bounds = np.flatnonzero(np.diff(s_sorted)) + 1
    for blk in np.split(order, bounds):
        if len(blk) > 1:
            perm[blk] = blk[rng.permutation(len(blk))]
    return perm


def spearman(a, b):
    from scipy.stats import spearmanr
    a = np.asarray(a, dtype=np.float64)
    b = np.asarray(b, dtype=np.float64)
    if len(a) < 3 or np.std(a) == 0 or np.std(b) == 0:
        return None
    return float(spearmanr(a, b)[0])


def pearson(a, b):
    a = np.asarray(a, dtype=np.float64)
    b = np.asarray(b, dtype=np.float64)
    if len(a) < 3 or np.std(a) == 0 or np.std(b) == 0:
        return None
    return float(np.corrcoef(a, b)[0, 1])


def load_vectors(cfg, fname, core, name_prefix=""):
    """Load an npz written by the GPU scripts: arrays keyed by name plus an ids array. Rows reordered to core order."""
    d = np.load(fname, allow_pickle=False)
    ids = [str(x) for x in d["ids"]]
    out = {}
    for k in d.files:
        if k == "ids":
            continue
        out[k] = C.strict_subset(np.asarray(d[k], dtype=np.float64), ids, core, name=name_prefix + k)
    return out
