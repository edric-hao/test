#!/usr/bin/env python
"""r2_c5_prediction_agreement.py  --  CPU box. How much of the CKA is agreement between the predicted scalars?

Needs results/predictions.npz from r2_g3_layers_preds.py (test-set predictions of every network, in the id order of the network).

A. For every cross-architecture pair of trained seeds: CKA (raw and size-residualized), squared Pearson correlation of the two
   predictions, and the same after removing size from the predictions. Summarized per architecture pair with the correlation
   across seed pairs between CKA and squared prediction correlation.
B. Alignment after residualizing each network's embedding on its OWN prediction (and its square), optionally together with the size
   covariates. Floors use the untrained networks residualized on their own (untrained) predictions. This is the seed-aware analysis
   on those transformed embeddings.

Output: results/prediction_agreement.json, report/prediction_agreement.md
"""
import argparse

import numpy as np

import common as C
import r2lib as R


def get_pred(preds, arch, tag):
    k = "%s|%s" % (arch, tag)
    if k not in preds:
        raise SystemExit("no predictions for %s (run r2_g3_layers_preds.py for all trained and untrained tags)" % k)
    return preds[k]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--n_boot", type=int, default=None, help="override draws (smoke tests only)")
    a = ap.parse_args()
    cfg = R.load_cfg2()
    C.ensure_dirs(cfg)
    C.verify_lock(cfg)
    an = cfg["analysis"]
    pa = cfg["prediction_agreement"]
    n_boot = int(a.n_boot if a.n_boot is not None else pa["n_boot"])
    core = C.core_ids(cfg)
    cov = C.load_covariates(cfg, core)
    clusters = C.load_clusters(cfg, core)
    pf = cfg["_out"] / "results" / "predictions.npz"
    if not pf.exists():
        raise SystemExit("missing %s (run r2_g3_layers_preds.py on the GPU box and copy the file here)" % pf)
    preds = R.load_vectors(cfg, pf, core, "pred:")
    trained = R.round1_trained(cfg)
    design = R.make_design(cfg, trained, which=("orig",))
    Zmap = R.zmap_for(cfg, design)
    D_size = R.design_matrix([cov])

    # ---------------- A. agreement of predictions versus CKA
    res_pt = R.run_engine(cfg, Zmap, cov, clusters, design, ["raw", "resid_linear"], 0)
    A = {}
    for (X, Y) in cfg["arch_pairs"]:
        key = R.pair_key(X, Y)
        rec_raw = res_pt["raw"][key]["orig"]
        rec_res = res_pt["resid_linear"][key]["orig"]
        cross_raw = np.array(rec_raw["cross"], dtype=np.float64)
        cross_res = np.array(rec_res["cross"], dtype=np.float64)
        rows = []
        for i, tx in enumerate(trained[X]):
            for j, ty in enumerate(trained[Y]):
                px, py = get_pred(preds, X, tx), get_pred(preds, Y, ty)
                r = float(np.corrcoef(px, py)[0, 1])
                rx, ry = R.resid_on(px[:, None], D_size)[:, 0], R.resid_on(py[:, None], D_size)[:, 0]
                rp = float(np.corrcoef(rx, ry)[0, 1])
                rows.append(dict(x=tx, y=ty, cka_raw=float(cross_raw[i, j]), cka_resid=float(cross_res[i, j]),
                                 pred_r=r, pred_r2=float(np.multiply(r, r)), pred_partial_r=rp, pred_partial_r2=float(np.multiply(rp, rp))))
        c_raw = [q["cka_raw"] for q in rows]
        c_res = [q["cka_resid"] for q in rows]
        r2 = [q["pred_r2"] for q in rows]
        pr2 = [q["pred_partial_r2"] for q in rows]
        A[key] = dict(rows=rows, mean_cka_raw=float(np.mean(c_raw)), mean_cka_resid=float(np.mean(c_res)),
                      mean_pred_r2=float(np.mean(r2)), mean_pred_partial_r2=float(np.mean(pr2)),
                      mean_cka_minus_r2=float(np.mean(np.array(c_raw) - np.array(r2))),
                      pearson_cka_raw_vs_r2=R.pearson(c_raw, r2), spearman_cka_raw_vs_r2=R.spearman(c_raw, r2),
                      pearson_cka_resid_vs_partial_r2=R.pearson(c_res, pr2), spearman_cka_resid_vs_partial_r2=R.spearman(c_res, pr2))
    nets_size = {}
    for arch in cfg["archs"]:
        for t in trained[arch]:
            p = get_pred(preds, arch, t)
            r = R.resid_on(p[:, None], D_size)[:, 0]
            nets_size["%s/%s" % (arch, t)] = 1.0 - float(np.sum(np.square(r - r.mean()))) / float(np.sum(np.square(p - p.mean())))

    # ---------------- B. alignment after removing the predicted scalar
    B = {}
    for vname, cols in pa["variants"].items():
        Zt = {}
        for nm in design.nets():
            arch, tag = nm.split("/", 1)
            p = R.zscore(get_pred(preds, arch, tag))
            parts = []
            for c in cols:
                if c == "pred":
                    parts.append(p)
                elif c == "pred2":
                    parts.append(np.square(p))
                elif c == "c1":
                    parts.append(cov[:, 0])
                elif c == "c2":
                    parts.append(cov[:, 1])
                else:
                    raise SystemExit("unknown column in prediction_agreement.variants: " + str(c))
            D = R.design_matrix(parts)
            Zt[nm] = R.resid_on(Zmap[nm], D)
        res = R.run_engine(cfg, Zt, cov, clusters, design, ["raw"], n_boot)
        B[vname] = res
    out = dict(stamp=C.stamp(), label="added_after_review_round2", n_boot=n_boot, trained=trained,
               agreement=A, prediction_size_r2=nets_size, after_removing_prediction=B)
    C.json_dump(out, cfg["_out"] / "results" / "prediction_agreement.json")

    lines = ["# Agreement of predicted scalars versus CKA (added after review, round 2)", ""]
    rows = []
    for key, s in A.items():
        rows.append([key, R.fnum(s["mean_cka_raw"]), R.fnum(s["mean_pred_r2"]), R.fnum(s["mean_cka_minus_r2"]),
                     R.fnum(s["pearson_cka_raw_vs_r2"]), R.fnum(s["mean_cka_resid"]), R.fnum(s["mean_pred_partial_r2"]),
                     R.fnum(s["pearson_cka_resid_vs_partial_r2"])])
    lines.append("## A. Seed-pair means (raw CKA against squared prediction correlation, then after size)")
    lines.append(R.md_table(["pair", "mean raw CKA", "mean r2 of predictions", "mean CKA minus r2", "corr over seed pairs",
                             "mean residualized CKA", "mean partial r2 of predictions", "corr over seed pairs (residualized)"], rows))
    lines.append("")
    lines.append("R2 of each network's prediction on the size covariates: " + ", ".join("%s %s" % (k, R.fnum(v, 2)) for k, v in nets_size.items()))
    lines.append("")
    for vname, res in B.items():
        lines.append("## B. After residualizing each embedding on: " + ", ".join(pa["variants"][vname]) + "  (variant " + vname + ")")
        lines.append(R.md_table(R.SUMMARY_HEADERS, R.summarize_pairs(res, ["raw"], "orig", ("seed_min", "orig"))))
        lines.append("")
    R.write_report(cfg, "prediction_agreement", "\n".join(lines) + "\n")


if __name__ == "__main__":
    main()
