#!/usr/bin/env bash
# run_all_round2.sh  --  run the round-2 experiments (added after the OpenReview reviews) in order.
#
#   bash run_all_round2.sh gpu      GPU box: lock, GNINA stream audit, decoupled GNINA seeds, size-corrected networks, layers and predictions, input features
#   bash run_all_round2.sh cpu      CPU box: lock, projections, then all analyses and the report
#   bash run_all_round2.sh all      both, one after the other, on one machine that has a GPU
#
# Needed environment variables
#   PROJECT_ROOT   project folder from round 1 (holds config, data, rerun_out)
#   PDBBIND_DIR    folder with the PDBbind_2020 complexes (GPU stages only)
# Optional
#   PYTHON         python executable (default python)
# Every stage is resumable: rerun the same command and finished networks are skipped.
# Round 1 outputs in rerun_out are only read. Round 2 writes to rerun_out2.
set -euo pipefail

HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$HERE"
PY="${PYTHON:-python}"
: "${PROJECT_ROOT:?set PROJECT_ROOT to the project folder}"
LOGDIR="$PROJECT_ROOT/rerun_out2/logs"
mkdir -p "$LOGDIR"

run() {
  local name="$1"; shift
  echo "=== $name : $(date -u +%H:%M:%S) UTC"
  "$@" 2>&1 | tee -a "$LOGDIR/$name.log"
  echo "=== $name finished"
}

stage="${1:-}"
if [ "$stage" != "gpu" ] && [ "$stage" != "cpu" ] && [ "$stage" != "all" ]; then
  echo "usage: bash run_all_round2.sh gpu|cpu|all"
  exit 2
fi

if [ "$stage" = "gpu" ] || [ "$stage" = "all" ]; then
  : "${PDBBIND_DIR:?set PDBBIND_DIR to the PDBbind_2020 folder}"
  run r2_s0_gpu "$PY" r2_s0_lock_and_checks.py --mode gpu
  run r2_g0_audit "$PY" r2_g0_audit_gnina_streams.py
  run r2_g4_input_features "$PY" r2_g4_input_features.py
  run r2_g1_gnina_decoupled "$PY" r2_g1_gnina_decoupled.py
  run r2_g2_sizecorr_train "$PY" r2_g2_sizecorr_train.py
  run r2_g3_layers_preds "$PY" r2_g3_layers_preds.py
fi

if [ "$stage" = "cpu" ] || [ "$stage" = "all" ]; then
  run r2_s0_cpu "$PY" r2_s0_lock_and_checks.py --mode cpu
  run r2_c0_project "$PY" r2_c0_project.py
  run r2_c1_decoupled "$PY" r2_c1_decoupled_gnina.py
  run r2_c2_sizecorr "$PY" r2_c2_sizecorr_analysis.py
  run r2_c3_size_content "$PY" r2_c3_seed_size_content.py
  run r2_c4_controls "$PY" r2_c4_residual_controls.py
  run r2_c5_prediction "$PY" r2_c5_prediction_agreement.py
  run r2_c6_input_deconf "$PY" r2_c6_input_deconfound.py
  run r2_c7_layers "$PY" r2_c7_layers_analysis.py
  run r2_c8_size_balanced "$PY" r2_c8_size_balanced.py
  run r2_c9_report "$PY" r2_c9_report.py
fi
echo "done"
