#!/usr/bin/env bash
# run_all_aws.sh  --  run the added-after-review reruns in order.
#
#   bash run_all_aws.sh gpu      GPU box:  s0 (checks and lock), s1 (EGNN and Distance-GNN seeds), s2 (GNINA seeds), s3 (GNINA untrained references)
#   bash run_all_aws.sh cpu      CPU box:  s0, s4 (projections and regression gate), s5, s6, s7, s8, s9
#   bash run_all_aws.sh all      both, one after the other, on one machine that has a GPU
#
# Needed environment variables
#   PROJECT_ROOT   folder that holds data, config, src, logs (the project folder from the earlier runs)
#   PDBBIND_DIR    folder with the PDBbind_2020 complexes (GPU stages only)
# Optional
#   WORKERS        parallel workers for the positive control (default 4)
#   THREADS        BLAS threads per worker (default 2)
#   GATE_FLAG      set to --gate_warn_only to continue even if the regression gate fails (not recommended)
set -euo pipefail

HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$HERE"
PY="${PYTHON:-python}"
: "${PROJECT_ROOT:?set PROJECT_ROOT to the project folder}"
WORKERS="${WORKERS:-4}"
THREADS="${THREADS:-2}"
GATE_FLAG="${GATE_FLAG:-}"
LOGDIR="$PROJECT_ROOT/rerun_out/logs"
mkdir -p "$LOGDIR"

run() {
  local name="$1"; shift
  echo "=== $name : $(date -u +%H:%M:%S) UTC"
  "$@" 2>&1 | tee -a "$LOGDIR/$name.log"
  echo "=== $name finished"
}

stage="${1:-}"
if [ "$stage" != "gpu" ] && [ "$stage" != "cpu" ] && [ "$stage" != "all" ]; then
  echo "usage: bash run_all_aws.sh gpu|cpu|all"
  exit 2
fi

if [ "$stage" = "gpu" ] || [ "$stage" = "all" ]; then
  : "${PDBBIND_DIR:?set PDBBIND_DIR to the PDBbind_2020 folder}"
  run s0_gpu "$PY" s0_lock_and_checks.py --mode gpu
  run s1_gnn_seeds "$PY" s1_train_gnn_seeds.py
  run s2_gnina_seeds "$PY" s2_train_gnina_seeds.py
  run s3_gnina_floor "$PY" s3_gnina_floor.py
fi

if [ "$stage" = "cpu" ] || [ "$stage" = "all" ]; then
  run s0_cpu "$PY" s0_lock_and_checks.py --mode cpu
  run s4_project "$PY" s4_project.py $GATE_FLAG
  run s5_seed_analysis "$PY" s5_seed_analysis.py
  run s6_positive_control "$PY" s6_positive_control.py --workers "$WORKERS" --threads "$THREADS"
  run s7_pc_rsa_cca "$PY" s7_pc_removal_rsa_cca.py
  run s8_size_stratified "$PY" s8_size_stratified.py
  run s9_report "$PY" s9_report.py
fi
echo "done"
