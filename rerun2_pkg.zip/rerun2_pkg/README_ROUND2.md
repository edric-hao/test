# Round 2: experiments added after the OpenReview reviews

Everything here is labeled "added after review, round 2". Round 1 (rerun_out) is read, never changed. Round 2 writes only to
PROJECT_ROOT/rerun_out2. The registered plan is config_rerun2.yaml. The first command (r2_s0) hashes it and writes
rerun_out2/PREREG_RERUN_LOCK.json, and every later stage refuses to run if the file changed. Do not edit it after r2_s0.
No file in this package contains the asterisk character, so everything can be pasted through chat apps.

## What each reviewer request maps to

| Request | Stage | What it does |
|---|---|---|
| GNINA seed independence | r2_g0 (audit), r2_g1 (train), r2_c1 (analysis) | Round 1 seeded epoch e with seed+e, so nearby seeds share data streams. g0 quantifies the overlap. g1 trains five GNINA seeds (dc1 to dc5) with an independent stream per (seed, epoch). c1 recomputes ceilings and n_AB with them. |
| Size-corrected target (ligand efficiency style) | r2_g2 (train), r2_c2 (analysis) | Target y minus a train-only polynomial fit on the two size covariates, plus the train mean. Five EGNN, five Distance-GNN, three GNINA. Gate on the corrected target is val r at least 0.15 and 0.10 above untrained (my choice, registered before any run). |
| Seed ceilings after size residualization | r2_c3 | Size content per network, relation to cross and within CKA, ceilings per residualization mode from round 1. |
| Permuted or random covariate and own-PC1 controls | r2_c4 | A: rows of the covariate matrix permuted, 100 times. B: residualized null, embeddings permuted within protein cluster x size tertile, 100 times. |
| CKA versus squared prediction correlation | r2_g3 (predictions), r2_c5 | r2 of predictions against CKA per seed pair, then CKA after residualizing each embedding on its own prediction (and its square, and size). |
| Cui et al. input-similarity deconfounding | r2_g4 (41 input features per complex), r2_c6 | Linear residualization on input features and kernel conditioning R K R with R = eps (K_Z + eps I)^-1, eps in 0.1, 1, 10. |
| Earlier layer | r2_g3, r2_c7 | Graph models: L0 to L3 plus L3 pooled over ligand and over pocket nodes. GNINA: spatial mean of the first three Conv3d outputs. Exploratory. |
| Size-balanced evaluation | r2_c8 | 3 x 3 (size tertile x affinity tertile) equal-cell subsamples, 10 draws. Exploratory. |

## Setup

    export PROJECT_ROOT=/home/ec2-user/SageMaker/pdbbind_data      # the round 1 project folder (holds data, config, rerun_out)
    export PDBBIND_DIR=/path/to/PDBbind_2020                       # GPU stages only

Unzip this package anywhere. It is self contained (it carries the round 1 libraries it imports). Use the same environment that made
the round 1 embeddings on the GPU box (torch, rdkit, molgrid, gninatorch, numpy below 2). The CPU box needs requirements_rerun.txt.
Round 1 must be finished: rerun_out must hold results/new_seed_manifest.json, results/seed_analysis.json and proj/.

Tests (CPU, about 30 seconds in total):

    python tests/test_round2_units.py
    bash tests/smoke_test_round2.sh

## Run order

    bash run_all_round2.sh gpu     # GPU box
    bash run_all_round2.sh cpu     # CPU box

If the GPU and CPU boxes differ, copy these from the GPU box to the same places in PROJECT_ROOT on the CPU box before the cpu stage:
data/embeddings (the new dc and sc files), rerun_out2/results (manifests, layers, predictions.npz, input_features.tsv,
sizecorr_target.tsv, audit json), rerun_out2/PREREG_RERUN_LOCK.json. Then run the cpu stage. Everything is resumable: rerun the same
command and finished networks are skipped.

Order inside the gpu stage: r2_s0 (checks, lock), r2_g0 (stream audit; needs round 1 checkpoints), r2_g4 (input features, fast),
r2_g1 (5 GNINA trainings), r2_g2 (10 graph and 3 GNINA trainings), r2_g3 (one forward pass per network, 35 networks).
Cost scales like round 1: each GNINA training costs what one round 1 GNINA seed cost, each graph training what one round 1 graph seed
cost. GNINA is by far the dominant item (8 trainings), so to shorten the run first reduce dc1 to dc5 (pass --tags dc1 dc2 dc3 to
r2_g1) and sc tags with --tags on r2_g2. Changing the config tag lists after the lock needs --relock, so prefer the command-line flag.

## Outputs

rerun_out2/report/report_round2.md collects all sections, in the order of the table above. Per-stage reports and json files are in
rerun_out2/report and rerun_out2/results. Failed gate networks are listed, never retrained, and the analysis is repeated with them.

## Things to know

1. GPU stages could not be run in the environment where this package was written (no GPU, torch, molgrid). They reuse the round 1
   training and extraction code, which already ran on your data, and add small pieces: the epoch seed rule, a predict method, forward
   hooks, a corrected-target types file. r2_g1 and r2_g2 run the round 1 selftest first (use --skip_selftest to skip it). r2_g3 checks that
   its L3 vector equals the saved primary embedding and aborts if not, and logs a test-r comparison for GNINA. Read the first minute of
   each GPU log before leaving it running.
2. All CPU stages were run end to end on a synthetic project (tests/smoke_test_round2.sh). Numbers there are random and meaningless.
3. The GNINA ceiling reported in round 1 comes from seeds that share data streams, so it is probably too high. r2_g0 shows how much the
   streams overlap and r2_c1 shows what the ceiling and n_AB become when seeds are independent.
4. The pre-registration lock covers config_rerun2.yaml. Code hashes are stored in each output.
