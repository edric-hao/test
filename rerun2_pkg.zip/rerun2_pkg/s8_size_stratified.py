#!/usr/bin/env python
"""s8_size_stratified.py  --  CPU box. Item 6 (optional, exploratory): CKA within ligand-size strata.

Core complexes are split into strata by raw ligand heavy-atom count (config stratified.n_strata quantile bins). Inside each
stratum the full seed-aware analysis is rerun (centering and residualization fitted within the stratum, cluster bootstrap
over the protein clusters present in the stratum). The number of protein clusters and complexes per stratum is reported,
with a warning below stratified.min_clusters_warn clusters.

Output: results/size_stratified.json
"""
import argparse

import numpy as np

import common as C
import engine as eg
from s4_project import load_proj, proj_path
from s5_seed_analysis import build_design


def strata_rows(size, n_strata):
    edges = np.quantile(size, np.linspace(0, 1, n_strata + 1))
    edges[-1] = edges[-1] + 1.0
    lab = np.searchsorted(edges, size, side="right") - 1
    lab = np.clip(lab, 0, n_strata - 1)
    return lab, edges


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--n_boot", type=int, default=None, help="override draws (smoke tests only)")
    ap.add_argument("--floor_set", default=None)
    a = ap.parse_args()
    cfg = C.load_cfg()
    C.ensure_dirs(cfg)
    C.verify_lock(cfg)
    st = cfg["stratified"]
    an = cfg["analysis"]
    core = C.core_ids(cfg)
    cov = C.load_covariates(cfg, core)
    clusters = C.load_clusters(cfg, core)
    size = C.ligand_size(cfg, core)
    failed = C.failed_seed_tags(cfg)
    floor_set = a.floor_set or an["headline_floor_set"]
    have_regen = all(proj_path(cfg, "gnina", t).exists() for t in cfg["floors"]["regen_tags"])
    design = build_design(cfg, failed, False, have_regen, only_set=floor_set)
    Zmap = {nm: load_proj(cfg, nm.split("/", 1)[0], nm.split("/", 1)[1]) for nm in design.nets()}
    nb = int(a.n_boot if a.n_boot is not None else st["n_boot"])
    lab, edges = strata_rows(size, int(st["n_strata"]))
    out = dict(stamp=C.stamp(), exploratory=True, by=st["by"], edges=edges.tolist(), floor_set=floor_set, n_boot=nb,
               trained=design.trained, strata={})
    for s in range(int(st["n_strata"])):
        rows = np.where(lab == s)[0]
        ncl = int(len(np.unique(clusters[rows])))
        info = dict(n_complexes=int(len(rows)), n_clusters=ncl,
                    size_min=float(size[rows].min()), size_max=float(size[rows].max()))
        if ncl < int(st["min_clusters_warn"]):
            info["warning"] = "fewer than %d protein clusters; intervals are unreliable" % int(st["min_clusters_warn"])
            C.log("WARNING stratum %d: %s" % (s, info["warning"]))
        C.log("stratum %d: %d complexes, %d clusters, size %s to %s" % (s, len(rows), ncl, info["size_min"], info["size_max"]))
        info["results"] = eg.run_seed_analysis(Zmap, cov, clusters, design, list(st["modes"]), nb, int(an["boot_seed"]),
                                               rows=rows, boot_kind=an["boot_kind"], chunk=int(an["chunk"]),
                                               min_den=float(an["min_denominator"]),
                                               max_undef=float(an["max_undefined_fraction"]),
                                               level=float(an["ci_level"]), log=C.log)
        out["strata"][str(s)] = info
    C.json_dump(out, cfg["_out"] / "results" / "size_stratified.json")
    C.log("wrote results/size_stratified.json")


if __name__ == "__main__":
    main()
