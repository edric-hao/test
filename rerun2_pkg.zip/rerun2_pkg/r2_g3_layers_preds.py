#!/usr/bin/env python
"""r2_g3_layers_preds.py  --  GPU box. One forward pass per network on the TEST set that records
  - the prediction of the network (float64, evaluation mode),
  - earlier-layer vectors (config layers):
      graph models  L0 mean of the atom-type embedding over nodes, L1 L2 L3 mean over nodes of the node features after message-passing
                    layer 1 to 3, L3_lig and L3_poc the same for layer 3 restricted to ligand nodes and to pocket nodes.
                    L3 equals the published embedding (input of readout.0), which is checked against the saved embeddings first.
      GNINA         conv1 to convK, spatial mean of the output of the first K Conv3d modules in registration order.
Networks: every tag listed in config layers.tags whose checkpoint exists (trained seeds, decoupled GNINA seeds, untrained references).
Outputs: results/layers/ARCH__TAG.npz (specs, pred, ids) and results/predictions.npz (key ARCH|TAG, plus ids).

Usage
  python r2_g3_layers_preds.py                       everything
  python r2_g3_layers_preds.py --archs egnn distance_gnn
  python r2_g3_layers_preds.py --archs gnina --tags primary dc1
  python r2_g3_layers_preds.py --force
"""
import argparse
import time

import numpy as np

import common as C
import r2lib as R
from mathx import mul


def layers_dir(cfg):
    d = cfg["_out"] / "results" / "layers"
    d.mkdir(parents=True, exist_ok=True)
    return d


def ckpt_exists(cfg, arch, tag):
    return (C.ckpt_dir(cfg) / ("%s_%s.pt" % (arch, tag))).exists()


class LayerCapture:
    """Forward hooks that store node features after every message-passing layer of a graph model."""

    def __init__(self, model, arch, hidden):
        self.h = {}
        self.handles = []
        if not hasattr(model, "embed"):
            raise SystemExit("model has no attribute embed; children: %s" % [n for n, _ in model.named_children()])
        self.handles.append(model.embed.register_forward_hook(self._embed_hook))
        if arch == "egnn":
            if not hasattr(model, "layers"):
                raise SystemExit("EGNN has no attribute layers; children: %s" % [n for n, _ in model.named_children()])
            for l, layer in enumerate(model.layers):
                self.handles.append(layer.register_forward_hook(self._egnn_hook(l + 1)))
        else:
            if not hasattr(model, "upd"):
                raise SystemExit("Distance-GNN has no attribute upd; children: %s" % [n for n, _ in model.named_children()])
            for l, upd in enumerate(model.upd):
                self.handles.append(upd.register_forward_hook(self._dgnn_hook(l + 1, hidden)))

    def _embed_hook(self, mod, inp, out):
        self.h[0] = out.detach()

    def _egnn_hook(self, l):
        def hook(mod, inp, out):
            self.h[l] = out[0].detach()
        return hook

    def _dgnn_hook(self, l, hidden):
        def hook(mod, inp, out):
            self.h[l] = (inp[0][:, :hidden] + out).detach()
        return hook

    def close(self):
        for h in self.handles:
            h.remove()


def graph_part(cfg, archs, tags_by_arch, only_tags, force):
    import torch
    import gnn_lib as G
    ctx = G.GnnContext(cfg)
    specs = list(cfg["layers"]["graph_specs"])
    ids = ctx.ids["test"]
    loader = ctx.loader(ids, 1, False)
    for arch in archs:
        hp = ctx.specs[arch]["hp"]
        hidden = int(hp["hidden"])
        n_layers = int(hp["n_layers"])
        tags = [t for t in tags_by_arch[arch] if (only_tags is None or t in only_tags)]
        for tag in tags:
            out = layers_dir(cfg) / ("%s__%s.npz" % (arch, tag))
            if out.exists() and not force:
                C.log("[%s/%s] already done" % (arch, tag))
                continue
            if not ckpt_exists(cfg, arch, tag):
                C.log("[%s/%s] checkpoint not found; skipped" % (arch, tag))
                continue
            model, _ = ctx.load_checkpoint_model(arch, tag)
            m64 = ctx.new_model(arch).double()
            m64.load_state_dict({k: v.detach().cpu().double() for k, v in model.state_dict().items()})
            m64.eval()
            cap = LayerCapture(m64, arch, hidden)
            rows = {s: [] for s in specs}
            preds = []
            t0 = time.time()
            with torch.no_grad():
                for pids, z, x, ei, b, ng, _ in loader:
                    x = x.double()
                    pred = m64(z, x, ei, b, ng)
                    preds.append(float(pred.reshape(-1)[0]))
                    lig = (z % 2) == 1
                    poc = ~lig
                    for s in specs:
                        if s == "L0":
                            v = cap.h[0].mean(dim=0)
                        elif s in ("L1", "L2", "L3"):
                            v = cap.h[int(s[1])].mean(dim=0)
                        elif s == "L3_lig":
                            v = cap.h[n_layers][lig].mean(dim=0)
                        elif s == "L3_poc":
                            v = cap.h[n_layers][poc].mean(dim=0)
                        else:
                            raise SystemExit("unknown graph layer spec " + s)
                        rows[s].append(v.cpu().numpy().astype(np.float64))
            cap.close()
            arrays = {s: np.stack(rows[s]) for s in specs}
            if "L3" in arrays and tag == "primary":
                npy, idsf = C.emb_paths(cfg, arch, tag, "test")
                if npy.exists():
                    S = np.load(npy, mmap_mode="r")
                    sid = C.read_ids(idsf)
                    pos = {p: i for i, p in enumerate(sid)}
                    n_chk = min(12, len(ids))
                    ref = np.asarray(S[[pos[p] for p in ids[:n_chk]]], dtype=np.float64)
                    rel = float(np.abs(arrays["L3"][:n_chk] - ref).max() / max(np.abs(ref).max(), 1e-12))
                    if rel > 1e-6:
                        raise SystemExit("[%s/%s] L3 differs from the saved embedding (rel %.3g); hooks do not match the model" % (arch, tag, rel))
                    C.log("[%s/%s] check passed: L3 equals the saved embedding (rel diff %.2e)" % (arch, tag, rel))
            arrays["pred"] = np.asarray(preds, dtype=np.float64)
            arrays["ids"] = np.array(ids)
            C.save_npz(out, arrays)
            C.log("[%s/%s] layers and predictions written (%d complexes, %.0fs)" % (arch, tag, len(ids), time.time() - t0))


def gnina_part(cfg, tags_gnina, only_tags, force, extract_device):
    import torch
    import gnina_lib as GL
    ctx = GL.GninaContext(cfg, extract_device=extract_device)
    k = int(cfg["layers"]["gnina_conv"])
    ids = ctx.ids["test"]
    n = len(ids)
    labels = np.array([float(ctx.split.loc[p, ctx.aff]) for p in ids])
    r1 = R.round1_manifest(cfg)
    dcm = R.manifest2(cfg, "decoupled_gnina_manifest.json")
    for tag in [t for t in tags_gnina if (only_tags is None or t in only_tags)]:
        out = layers_dir(cfg) / ("gnina__%s.npz" % tag)
        if out.exists() and not force:
            C.log("[gnina/%s] already done" % tag)
            continue
        if not ckpt_exists(cfg, "gnina", tag):
            C.log("[gnina/%s] checkpoint not found; skipped" % tag)
            continue
        model = ctx.load_extraction_model(tag)
        convs = [(nm, m) for nm, m in model.named_modules() if isinstance(m, torch.nn.Conv3d)][:k]
        if len(convs) < k:
            raise SystemExit("GNINA model has only %d Conv3d modules, config asks for %d" % (len(convs), k))
        C.log("[gnina/%s] Conv3d modules used: %s" % (tag, [(nm, m.out_channels) for nm, m in convs]))
        store = {}

        def make(i):
            def hook(mod, inp, out_):
                store[i] = out_.detach().mean(dim=(2, 3, 4))[0]
            return hook
        handles = [m.register_forward_hook(make(i + 1)) for i, (_, m) in enumerate(convs)]
        provider = ctx.make_provider(ctx.types["test"], 1, False)
        rows = {"conv%d" % (i + 1): [] for i in range(k)}
        preds = []
        t0 = time.time()
        with torch.no_grad():
            for i in range(n):
                grid = ctx._grid_double(provider, 1)
                o = ctx.pick_affinity(model(grid))
                preds.append(float(o.reshape(-1)[0]))
                for j in range(k):
                    rows["conv%d" % (j + 1)].append(store[j + 1].cpu().numpy().astype(np.float64))
                if i == 19:
                    rate = (time.time() - t0) / 20
                    C.log("  first 20 complexes: %.2f s/complex -> about %.1f min for %d" % (rate, mul(rate, n) / 60, n))
        for h in handles:
            h.remove()
        preds = np.asarray(preds, dtype=np.float64)
        r_test = float(np.corrcoef(preds, labels)[0, 1])
        rec = r1.get("gnina/%s" % tag) or dcm.get("gnina/%s" % tag)
        if rec is not None and rec.get("test_pearson_r") is not None:
            d = abs(r_test - float(rec["test_pearson_r"]))
            C.log("[gnina/%s] test r from this pass %.4f, recorded %.4f%s" % (tag, r_test, rec["test_pearson_r"], "  WARNING: differs" if d > 2e-3 else ""))
        else:
            C.log("[gnina/%s] test r from this pass %.4f (no recorded value to compare)" % (tag, r_test))
        arrays = {kk: np.stack(v) for kk, v in rows.items()}
        arrays["pred"] = preds
        arrays["ids"] = np.array(ids)
        C.save_npz(out, arrays)
        C.log("[gnina/%s] layers and predictions written (%.0fs)" % (tag, time.time() - t0))


def assemble_predictions(cfg):
    ld = layers_dir(cfg)
    arrays = {}
    ids = None
    for f in sorted(ld.iterdir()):
        if f.suffix != ".npz" or "__" not in f.name:
            continue
        arch, tag = f.stem.split("__", 1)
        d = np.load(f, allow_pickle=False)
        if "pred" not in d.files:
            continue
        this_ids = [str(x) for x in d["ids"]]
        if ids is None:
            ids = this_ids
        if this_ids != ids:
            raise SystemExit("%s has a different id order from the other networks" % f.name)
        arrays["%s|%s" % (arch, tag)] = np.asarray(d["pred"], dtype=np.float64)
    if ids is None:
        return
    arrays["ids"] = np.array(ids)
    C.save_npz(cfg["_out"] / "results" / "predictions.npz", arrays)
    C.log("wrote results/predictions.npz with %d networks" % (len(arrays) - 1))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--archs", nargs="+", default=None)
    ap.add_argument("--tags", nargs="+", default=None)
    ap.add_argument("--extract_device", default=None)
    ap.add_argument("--force", action="store_true")
    a = ap.parse_args()
    cfg = R.load_cfg2()
    C.ensure_dirs(cfg)
    C.verify_lock(cfg)
    tags = cfg["layers"]["tags"]
    archs = a.archs or ["egnn", "distance_gnn", "gnina"]
    ga = [x for x in archs if x in ("egnn", "distance_gnn")]
    if ga:
        graph_part(cfg, ga, tags, a.tags, a.force)
    if "gnina" in archs:
        gnina_part(cfg, tags["gnina"], a.tags, a.force, a.extract_device)
    assemble_predictions(cfg)


if __name__ == "__main__":
    main()
