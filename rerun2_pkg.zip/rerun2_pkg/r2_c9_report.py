#!/usr/bin/env python
"""r2_c9_report.py  --  CPU box. Concatenates the per-stage reports into report/report_round2.md and lists which stages are present."""
import common as C
import r2lib as R

ORDER = [
    ("gnina_stream_audit", "r2_g0_audit_gnina_streams.py", "Independence of GNINA seeds"),
    ("decoupled_gnina", "r2_c1_decoupled_gnina.py", "GNINA with decoupled data streams"),
    ("sizecorr_alignment", "r2_c2_sizecorr_analysis.py", "Networks trained on a size-corrected target"),
    ("seed_size_content", "r2_c3_seed_size_content.py", "Size content per seed and residualized ceilings"),
    ("residual_controls", "r2_c4_residual_controls.py", "Permuted-covariate and residualized-null controls"),
    ("prediction_agreement", "r2_c5_prediction_agreement.py", "Agreement of predicted scalars versus CKA"),
    ("input_deconfound", "r2_c6_input_deconfound.py", "Deconfounding on input similarity"),
    ("layers_analysis", "r2_c7_layers_analysis.py", "Earlier-layer alignment"),
    ("size_balanced", "r2_c8_size_balanced.py", "Size-balanced evaluation"),
]


def main():
    cfg = R.load_cfg2()
    C.ensure_dirs(cfg)
    rd = R.report_dir(cfg)
    parts = ["# Round 2 report (added after review)", "",
             "Written %s. Round 1 results are unchanged. Every number below is labeled added after review." % C.utc_now(), ""]
    status = []
    for name, script, title in ORDER:
        f = rd / (name + ".md")
        if f.exists():
            status.append([title, "present"])
            parts.append(f.read_text())
            parts.append("")
        else:
            status.append([title, "NOT RUN (%s)" % script])
    parts.insert(3, R.md_table(["analysis", "status"], status))
    parts.insert(4, "")
    (rd / "report_round2.md").write_text("\n".join(parts))
    C.log("wrote %s" % (rd / "report_round2.md"))
    for t, s in status:
        C.log("%-60s %s" % (t, s))


if __name__ == "__main__":
    main()
