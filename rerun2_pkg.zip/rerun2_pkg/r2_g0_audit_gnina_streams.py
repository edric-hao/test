#!/usr/bin/env python
"""r2_g0_audit_gnina_streams.py  --  audit of independence between GNINA seeds. Cheap; run it first. torch is optional.

The GNINA training code sets the random stream of epoch e to (seed + e). Two runs whose seed values differ by d therefore use
identical shuffles and augmentations, shifted by d epochs, for every epoch they both reach. This script
  1. lists the set of per-epoch seeds each GNINA run used (epochs run = best epoch + patience + 1),
  2. computes the overlap between every pair of runs,
  3. relates the overlap to the within-architecture CKA of the pair (round 1 analysis),
  4. verifies that the decoupled seeding of round 2 produces no shared per-epoch seeds,
  5. if torch is available, compares first-convolution weights across runs (shared initialization would show as a high cosine).

Epochs run for the primary and anchor seeds come from the training history inside their checkpoints when torch is available.
Without torch pass them explicitly:  --epochs primary=60 anchor=58

Output: results/gnina_stream_audit.json, report/gnina_stream_audit.md
"""
import argparse
import itertools

import numpy as np

import common as C
import r2lib as R

PATIENCE = 20


def epoch_set(seed, n_epochs):
    return set(range(int(seed), int(seed) + int(n_epochs)))


def decoupled_set(seed, n_epochs):
    return set(int(np.random.SeedSequence([int(seed), int(e)]).generate_state(1)[0] % 2147483647) for e in range(int(n_epochs)))


def overlap(a, b):
    return len(a & b), (len(a & b) / float(min(len(a), len(b))) if min(len(a), len(b)) else 0.0)


def history_len(cfg, tag):
    try:
        import torch
    except ImportError:
        return None, None
    p = C.ckpt_dir(cfg) / ("gnina_%s.pt" % tag)
    if not p.exists():
        return None, None
    try:
        st = torch.load(p, map_location="cpu", weights_only=False)
    except TypeError:
        st = torch.load(p, map_location="cpu")
    h = st.get("history", [])
    return (len(h) if h else None), st


def first_conv_vector(state):
    sd = state["model"]
    for k, v in sd.items():
        if k.endswith("weight") and getattr(v, "dim", lambda: 0)() == 5:
            return k, v.detach().cpu().numpy().astype(np.float64).ravel()
    return None, None


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--epochs", nargs="+", default=[], help="tag=number of epochs run, for tags without a readable checkpoint")
    ap.add_argument("--no_weights", action="store_true")
    a = ap.parse_args()
    cfg = R.load_cfg2()
    C.ensure_dirs(cfg)
    C.verify_lock(cfg)
    manual = {}
    for item in a.epochs:
        k, v = item.split("=")
        manual[k] = int(v)
    man = R.round1_manifest(cfg)
    runs = {}
    seeds = dict(cfg["seeds"]["existing_seed_values"])
    seeds.update(cfg["seeds"]["new_seed_values"])
    states = {}
    for tag in cfg["seeds"]["trained_tags"]:
        rec = man.get("gnina/%s" % tag)
        n_ep, st = history_len(cfg, tag)
        if rec is not None and rec.get("best_epoch") is not None:
            n_ep = int(rec["best_epoch"]) + PATIENCE + 1
        if tag in manual:
            n_ep = manual[tag]
        if n_ep is None:
            C.log("WARNING: epochs run for gnina/%s unknown; pass --epochs %s=NUMBER" % (tag, tag))
            continue
        runs[tag] = dict(seed=int(seeds[tag]), epochs=int(n_ep))
        if st is not None:
            states[tag] = st
    legacy = {t: epoch_set(r["seed"], r["epochs"]) for t, r in runs.items()}
    tags = list(runs)
    pairs = []
    for x, y in itertools.combinations(tags, 2):
        n, f = overlap(legacy[x], legacy[y])
        pairs.append(dict(a=x, b=y, shared_epoch_seeds=n, shared_fraction=f, seed_difference=abs(runs[x]["seed"] - runs[y]["seed"])))

    # within-architecture GNINA CKA from round 1
    r1j = R.read_json(cfg["_out1"] / "results" / "seed_analysis.json", default={})
    cka = {}
    try:
        for mode in ("raw", "resid_linear"):
            rec = r1j["results"][mode]["egnn_x_gnina"]["orig"]
            w = np.array(rec["within_B"], dtype=np.float64)
            tg = rec["tags_B"]
            cka[mode] = {(tg[i], tg[j]): float(w[i, j]) for i in range(len(tg)) for j in range(i + 1, len(tg))}
    except (KeyError, TypeError):
        pass
    for p in pairs:
        for mode in cka:
            k = (p["a"], p["b"]) if (p["a"], p["b"]) in cka[mode] else (p["b"], p["a"])
            p["cka_" + mode] = cka[mode].get(k)
    corr = {}
    for mode in cka:
        xs = [p["shared_fraction"] for p in pairs if p.get("cka_" + mode) is not None]
        ys = [p["cka_" + mode] for p in pairs if p.get("cka_" + mode) is not None]
        corr[mode] = dict(spearman=R.spearman(xs, ys), pearson=R.pearson(xs, ys), n_pairs=len(xs))

    # decoupled seeding check
    dc = cfg["decoupled_gnina"]
    dc_sets = {t: decoupled_set(s, 200) for t, s in dc["seed_values"].items()}
    dc_collisions = []
    for x, y in itertools.combinations(dc_sets, 2):
        n, _ = overlap(dc_sets[x], dc_sets[y])
        if n:
            dc_collisions.append((x, y, n))
    for t, s in dc_sets.items():
        for lt, ls in legacy.items():
            n, _ = overlap(s, ls)
            if n:
                dc_collisions.append((t, lt, n))

    # weights
    weights = None
    if not a.no_weights and states:
        vecs = {}
        for t, st in states.items():
            k, v = first_conv_vector(st)
            if v is not None:
                vecs[t] = v
        if vecs:
            weights = {}
            for x, y in itertools.combinations(vecs, 2):
                vx, vy = vecs[x], vecs[y]
                weights["%s|%s" % (x, y)] = float(np.dot(vx, vy) / np.multiply(np.linalg.norm(vx), np.linalg.norm(vy)))
    out = dict(stamp=C.stamp(), label="added_after_review_round2", runs=runs, pairs=pairs, relation=corr,
               decoupled_collisions=dc_collisions, first_conv_cosine=weights)
    C.json_dump(out, cfg["_out"] / "results" / "gnina_stream_audit.json")

    lines = ["# GNINA seed independence audit (added after review, round 2)", "",
             "Per-epoch seeds are seed plus epoch in the round 1 training code. Runs: " +
             ", ".join("%s (seed %d, %d epochs)" % (t, r["seed"], r["epochs"]) for t, r in runs.items()), ""]
    rows = []
    for p in pairs:
        rows.append([p["a"], p["b"], p["seed_difference"], p["shared_epoch_seeds"], R.fnum(p["shared_fraction"], 2),
                     R.fnum(p.get("cka_raw")), R.fnum(p.get("cka_resid_linear"))])
    lines.append(R.md_table(["run A", "run B", "seed difference", "shared per-epoch seeds", "shared fraction", "CKA (raw)", "CKA (size-residualized)"], rows))
    lines.append("")
    for mode, c in corr.items():
        lines.append("Shared fraction versus CKA (%s): Spearman %s, Pearson %s over %d pairs." %
                     (mode, R.fnum(c["spearman"]), R.fnum(c["pearson"]), c["n_pairs"]))
    lines.append("")
    lines.append("Decoupled seeding collisions (should be none): %s" % (dc_collisions if dc_collisions else "none"))
    if weights:
        lines += ["", "Cosine similarity of the first convolution weights between trained runs:",
                  R.md_table(["pair", "cosine"], [[k, R.fnum(v)] for k, v in weights.items()])]
    R.write_report(cfg, "gnina_stream_audit", "\n".join(lines) + "\n")


if __name__ == "__main__":
    main()
