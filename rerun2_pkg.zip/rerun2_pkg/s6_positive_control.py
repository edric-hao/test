#!/usr/bin/env python
"""s6_positive_control.py  --  CPU box. Item 4: positive control with analytic truth.

Synthetic networks (simlib.py) with a planted cross-architecture signal rho, run through the SAME engine, the same
estimators, the same residualization modes and the same cluster bootstrap as the real analysis, on the real covariates
and the real protein clusters. Conditions: no shared signal, size-independent shared signal, size-associated shared signal
(linear and nonlinear). Repeated simulations per cell. Reports bias, RMSE, coverage of both intervals, how often an interval
contains zero, and the recovered-versus-planted relation.

Optional second part (config positive_control.real_spike_in): a planted shared signal is added to the REAL egnn and
distance_gnn projections to show how the estimators respond. There is no analytic truth there; the check is monotone response.

Cells are saved one file each under results/pc_cells, so the script can be stopped and resumed.

Usage
  python s6_positive_control.py --workers 8 --threads 4
  python s6_positive_control.py --quick            (3 reps, 2 rho levels, 50 draws; for a smoke test, not for the paper)
  python s6_positive_control.py --aggregate_only
"""
import argparse
import json
import multiprocessing as mp
import os
import time

import numpy as np

import common as C
from mathx import mul

TRAINED = ["primary", "anchor", "seed3", "seed4", "seed5"]
UNTR = ["untrained", "untrained_init2", "untrained_init3", "untrained_init4", "untrained_init5"]
_CTX = {}


def cell_dir(cfg):
    d = cfg["_out"] / "results" / ("pc_cells_QUICK" if cfg.get("_quick") else "pc_cells")
    d.mkdir(parents=True, exist_ok=True)
    return d


def cell_name(cond, rho, rep):
    return "%s__rho%.2f__rep%03d.json" % (cond, rho, rep)


def get_ctx(cfg):
    if "cov" not in _CTX:
        core = C.core_ids(cfg)
        _CTX["cov"] = C.load_covariates(cfg, core)
        _CTX["clusters"] = C.load_clusters(cfg, core)
    return _CTX["cov"], _CTX["clusters"]


def run_cell(task):
    cfg, cond, rho, rep, n_boot, cell_index = task
    import engine as eg
    import simlib as S
    path = cell_dir(cfg) / cell_name(cond, rho, rep)
    if path.exists():
        return str(path), "cached"
    t0 = time.time()
    cov, clusters = get_ctx(cfg)
    pc = cfg["positive_control"]
    an = cfg["analysis"]
    rng = np.random.default_rng([int(pc["seed"]), int(cell_index), int(rep)])
    Z = S.build_world(cond, rho, cov, TRAINED, UNTR, rng)
    design = eg.Design([("a1", "a2")], {"a1": TRAINED, "a2": TRAINED}, {"orig": {"a1": UNTR, "a2": UNTR}})
    res = eg.run_seed_analysis(Z, cov, clusters, design, list(an["modes"]), n_boot, int(pc["seed"]) + int(rep),
                               boot_kind=an["boot_kind"], chunk=min(int(an["chunk"]), max(n_boot, 1)),
                               min_den=float(an["min_denominator"]), max_undef=float(an["max_undefined_fraction"]),
                               level=float(an["ci_level"]), log=lambda m: None)
    rec = dict(cond=cond, rho=rho, rep=rep, n_boot=n_boot, modes={})
    for mode in an["modes"]:
        est = res[mode]["a1_x_a2"]["orig"]["estimators"]
        t_mode = S.truth(cond, rho, mode, TRAINED, UNTR)
        t_sig = S.truth(cond, rho, mode, TRAINED, UNTR, signal_only=True)
        rec["modes"][mode] = dict(truth_min=t_mode["nab_min"], truth_geo=t_mode["nab_geo"],
                                  truth_signal_min=t_sig["nab_min"], truth_signal_geo=t_sig["nab_geo"],
                                  truth_parts=t_mode, estimators=est)
    rec["seconds"] = round(time.time() - t0, 1)
    C.json_dump(rec, path)
    return str(path), "done"


def aggregate(cfg):
    recs = []
    for f in sorted(p for p in cell_dir(cfg).iterdir() if p.suffix == ".json"):
        recs.append(json.loads(f.read_text()))
    if not recs:
        raise SystemExit("no positive-control cells found")
    groups = {}
    for r in recs:
        for mode, m in r["modes"].items():
            for en, e in m["estimators"].items():
                tk = "truth_geo" if en == "seed_geo" else "truth_min"
                sk = "truth_signal_geo" if en == "seed_geo" else "truth_signal_min"
                groups.setdefault((r["cond"], r["rho"], mode, en), []).append(
                    (m[tk], m[sk], e.get("nab"), e.get("ci_complex"), e.get("ci_two_level")))
    rows = []
    for (cond, rho, mode, en), v in sorted(groups.items()):
        tr = np.array([x[0] for x in v], dtype=float)
        ts = np.array([x[1] for x in v], dtype=float)
        est = np.array([np.nan if x[2] is None else x[2] for x in v], dtype=float)
        ok = np.isfinite(est) & np.isfinite(tr)

        def cover(idx, truth):
            hits, cnt, zero = 0, 0, 0
            for x, t in zip(v, truth):
                ci = x[idx]
                if ci is None or ci[0] is None or not np.isfinite(t):
                    continue
                cnt += 1
                hits += int(ci[0] <= t <= ci[1])
                zero += int(ci[0] <= 0.0 <= ci[1])
            return (hits / cnt if cnt else None), (zero / cnt if cnt else None), cnt
        cov_c, zero_c, n_c = cover(3, tr)
        cov_t, zero_t, n_t = cover(4, tr)
        cov_cs, _, _ = cover(3, ts)
        cov_ts, _, _ = cover(4, ts)
        rows.append(dict(
            cond=cond, rho=rho, mode=mode, estimator=en, n_reps=len(v), n_defined=int(ok.sum()),
            truth_mode=float(np.nanmean(tr)), truth_signal=float(np.nanmean(ts)),
            mean_estimate=float(np.nanmean(est)) if ok.any() else None,
            sd_estimate=float(np.nanstd(est)) if ok.any() else None,
            bias_vs_truth_mode=float(np.nanmean(est - tr)) if ok.any() else None,
            bias_vs_truth_signal=float(np.nanmean(est - ts)) if ok.any() else None,
            rmse_vs_truth_mode=float(np.sqrt(np.nanmean(np.square(est - tr)))) if ok.any() else None,
            coverage_complex_truth_mode=cov_c, coverage_two_level_truth_mode=cov_t,
            coverage_complex_truth_signal=cov_cs, coverage_two_level_truth_signal=cov_ts,
            frac_ci_complex_contains_zero=zero_c, frac_ci_two_level_contains_zero=zero_t,
            n_ci_complex=n_c, n_ci_two_level=n_t))
    return rows


def spike_in(cfg, quick):
    """Planted shared signal added to the real egnn and distance_gnn projections."""
    import engine as eg
    from s4_project import load_proj, proj_path
    sp = cfg["positive_control"]["real_spike_in"]
    if not sp.get("enabled", False):
        return []
    core = C.core_ids(cfg)
    cov, clusters = C.load_covariates(cfg, core), C.load_clusters(cfg, core)
    A, B = "egnn", "distance_gnn"
    failed = C.failed_seed_tags(cfg)
    tags = {}
    for arch in (A, B):
        tags[arch] = [t for t in C.trained_tags(cfg) if proj_path(cfg, arch, t).exists()
                      and t not in failed.get(arch, [])]
    base = {}
    for arch in (A, B):
        for t in tags[arch] + list(cfg["floors"]["orig_tags"]):
            base[arch + "/" + t] = load_proj(cfg, arch, t)
    design = eg.Design([(A, B)], tags, {"orig": {A: list(cfg["floors"]["orig_tags"]), B: list(cfg["floors"]["orig_tags"])}})
    an = cfg["analysis"]
    n_boot = 50 if quick else int(cfg["positive_control"]["n_boot"])
    out = []
    levels = [float(x) for x in sp["lambda_levels"]]
    if quick:
        levels = levels[:2] + levels[-1:]
    for lam in levels:
        reps = 1 if lam == 0.0 else (1 if quick else int(sp["n_reps"]))
        for rep in range(reps):
            rng = np.random.default_rng([int(sp["seed"]), int(round(mul(lam, 100))), rep])
            F = rng.normal(size=(len(core), 6))
            Z = {}
            for nm, z in base.items():
                if nm.split("/", 1)[1] in tags[nm.split("/", 1)[0]]:
                    U, _ = np.linalg.qr(rng.normal(size=(z.shape[1], 6)))
                    scale = float(np.sqrt(np.mean(np.var(z, axis=0))))
                    Z[nm] = z + mul(mul(lam, scale), F @ U.T)
                else:
                    Z[nm] = z
            res = eg.run_seed_analysis(Z, cov, clusters, design, list(an["modes"]), n_boot, int(sp["seed"]) + rep,
                                       boot_kind=an["boot_kind"], chunk=min(int(an["chunk"]), max(n_boot, 1)),
                                       min_den=float(an["min_denominator"]), log=lambda m: None)
            for mode in an["modes"]:
                est = res[mode][A + "_x_" + B]["orig"]["estimators"]
                out.append(dict(lam=lam, rep=rep, mode=mode, estimators=est))
        C.log("spike-in lambda %.2f done" % lam)
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--workers", type=int, default=1)
    ap.add_argument("--threads", type=int, default=0, help="BLAS threads per worker (0 leaves the default)")
    ap.add_argument("--quick", action="store_true")
    ap.add_argument("--aggregate_only", action="store_true")
    ap.add_argument("--skip_spike", action="store_true")
    a = ap.parse_args()
    cfg = C.load_cfg()
    C.ensure_dirs(cfg)
    C.verify_lock(cfg)
    cfg["_quick"] = bool(a.quick)
    pc = cfg["positive_control"]
    n_reps = 3 if a.quick else int(pc["n_reps"])
    n_boot = 50 if a.quick else int(pc["n_boot"])
    rhos = [float(x) for x in pc["rho_levels"]]
    if a.quick:
        rhos = [rhos[0], rhos[-1]]
    if a.quick:
        C.log("QUICK mode: not for the paper")
    if not a.aggregate_only:
        tasks = []
        for ci, cond in enumerate(pc["conditions"]):
            levels = [0.0] if cond == "null_shared" else rhos
            for rho in levels:
                for rep in range(n_reps):
                    tasks.append((cfg, cond, rho, rep, n_boot, ci))
        todo = [t for t in tasks if not (cell_dir(cfg) / cell_name(t[1], t[2], t[3])).exists()]
        C.log("%d cells in total, %d to run, %d workers" % (len(tasks), len(todo), a.workers))
        if a.threads > 0:
            for k in ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS"):
                os.environ[k] = str(a.threads)
        if a.workers > 1:
            ctx = mp.get_context("spawn")
            with ctx.Pool(a.workers) as pool:
                for i, (p, st) in enumerate(pool.imap_unordered(run_cell, todo)):
                    C.log("[%d/%d] %s %s" % (i + 1, len(todo), os.path.basename(p), st))
        else:
            for i, t in enumerate(todo):
                p, st = run_cell(t)
                C.log("[%d/%d] %s %s" % (i + 1, len(todo), os.path.basename(p), st))
    rows = aggregate(cfg)
    spike = [] if (a.skip_spike or a.aggregate_only) else spike_in(cfg, a.quick)
    C.json_dump(dict(stamp=C.stamp(), quick=bool(a.quick), n_reps=n_reps, n_boot=n_boot, rho_levels=rhos,
                     conditions=list(pc["conditions"]), summary=rows, real_spike_in=spike,
                     sim_params=__import__("simlib").PARAMS),
                cfg["_out"] / "results" / ("positive_control_QUICK.json" if a.quick else "positive_control.json"))
    C.log("wrote positive-control results")


if __name__ == "__main__":
    main()
