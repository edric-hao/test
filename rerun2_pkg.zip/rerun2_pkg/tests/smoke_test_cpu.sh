#!/usr/bin/env bash
# Runs every CPU stage (s0, s4 to s9) on a small synthetic project. Takes about a minute. Not for the paper:
# the numbers come from random data, and the regression gate is expected to disagree with the published values.
#   bash tests/smoke_test_cpu.sh
set -euo pipefail
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$HERE"
FIX="${FIX:-/tmp/rerun_fixture}"
rm -rf "$FIX"
python tests/make_fixture.py "$FIX"
export PROJECT_ROOT="$FIX"
export RERUN_CONFIG="$FIX/config_rerun_fixture.yaml"
python s0_lock_and_checks.py --mode cpu
python s4_project.py --gate_warn_only
python tests/test_gate.py
python s5_seed_analysis.py
python s6_positive_control.py --quick --workers 2 --threads 1
python s7_pc_removal_rsa_cca.py
python s8_size_stratified.py
python s9_report.py
echo "SMOKE TEST PASSED. Report: $FIX/rerun_out/report/report_rerun.md"
