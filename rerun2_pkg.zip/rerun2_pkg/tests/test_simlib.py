"""Check that the analytic truth in simlib matches the debiased CKA measured on simulated networks. Run: python tests/test_simlib.py"""
import os
import sys

import numpy as np

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
import alignlib2 as al  # noqa: E402
import simlib as S  # noqa: E402


def main():
    rng = np.random.default_rng(11)
    n = 2171
    cov = np.column_stack([rng.gamma(3, 1, n), rng.normal(size=n) + np.multiply(0.5, rng.gamma(3, 1, n))])
    cov = (cov - cov.mean(0)) / cov.std(0)
    tr = ["primary", "anchor", "seed3"]
    un = ["untrained", "u2"]
    pairs = [("a1/primary", "a2/primary"), ("a1/primary", "a1/anchor"), ("a2/primary", "a2/anchor"),
             ("a1/untrained", "a2/untrained")]
    worst = 0.0
    for cond, rho in [("null_shared", 0.0), ("size_independent", 0.5), ("size_linear", 0.5), ("size_nonlinear", 1.0),
                      ("size_linear", 0.0), ("size_nonlinear", 0.0)]:
        for mode in ("raw", "resid_linear", "resid_poly2"):
            vals = []
            for _ in range(4):
                Z = S.build_world(cond, rho, cov, tr, un, rng)
                grams = {k: al.gram_zero_diag(al.residualize(v, cov, mode)) for k, v in Z.items()}
                vals.append(al.GramBank(grams).cka_point(pairs))
            got = np.mean(vals, axis=0)
            T = S.truth(cond, rho, mode, tr, un)
            want = np.array([T["cross"], T["ceil_a1"], T["ceil_a2"], T["floor"]])
            d = float(np.abs(got - want).max())
            worst = max(worst, d)
            assert d < 0.02, (cond, rho, mode, got, want)
    # residualized truth must not depend on the size factors it removes
    a = S.truth("size_linear", 0.5, "resid_poly2", tr, un)["nab_min"]
    b = S.truth("size_independent", 0.5, "resid_poly2", tr, un)["nab_min"]
    assert abs(a - b) < 1e-12
    # null has zero truth
    assert S.truth("null_shared", 0.7, "raw", tr, un)["nab_min"] == 0.0
    print("simlib analytic truth matches simulation; worst abs difference %.4f" % worst)
    print("ALL SIMLIB TESTS PASSED")


if __name__ == "__main__":
    main()
