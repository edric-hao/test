"""Unit tests of the new round-2 helper logic (CPU, seconds). Run: python tests/test_round2_units.py"""
import importlib
import os
import sys

import numpy as np

PKG = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..")
sys.path.insert(0, PKG)
import r2lib as R  # noqa: E402

ok = []


def check(name, cond):
    ok.append(bool(cond))
    print(("PASS " if cond else "FAIL ") + name)


rng = np.random.default_rng(0)

# within_stratum_permutation: valid permutation, never crosses strata, singletons fixed
strata = rng.integers(0, 12, size=500)
perm = R.within_stratum_permutation(strata, rng)
check("perm is a permutation", sorted(perm.tolist()) == list(range(500)))
check("perm stays in stratum", np.array_equal(strata[perm], strata))
check("perm actually moves rows", np.mean(perm != np.arange(500)) > 0.5)
s2 = np.array([0, 1, 1, 2])
p2 = R.within_stratum_permutation(s2, rng)
check("singleton strata fixed", p2[0] == 0 and p2[3] == 3)

# tertile_labels: three near-equal groups
x = rng.normal(size=900)
lab = R.tertile_labels(x, 3)
check("tertiles balanced", sorted(np.bincount(lab).tolist()) == [300, 300, 300])

# resid_on: residuals orthogonal to design
D = R.design_matrix([rng.normal(size=(200, 2))])
Z = rng.normal(size=(200, 5)) + D[:, 1:2]
Rz = R.resid_on(Z, D)
check("residuals orthogonal to design", np.abs(D.T @ Rz).max() < 1e-8)

# rbf conditioner
c6 = importlib.import_module("r2_c6_input_deconfound")
F = rng.normal(size=(120, 6))
Rb, med = c6.rbf_conditioner(F, 1.0)
check("R symmetric", np.allclose(Rb, Rb.T))
Rbig, _ = c6.rbf_conditioner(F, 1e6)
check("large eps gives near identity", np.abs(Rbig - np.eye(120)).max() < 1e-3)
Rsm, _ = c6.rbf_conditioner(F, 1e-6)
check("small eps removes most kernel-explained signal", np.linalg.norm(Rsm @ F[:, :1]) < np.linalg.norm(F[:, :1]))
check("median bandwidth positive", med > 0)

# balanced_rows: equal cells
c8 = importlib.import_module("r2_c8_size_balanced")
sl = rng.integers(0, 3, size=1000)
yl = rng.integers(0, 3, size=1000)
rows, m = c8.balanced_rows(sl, yl, 3, rng)
cnt = np.zeros((3, 3), int)
for r in rows:
    cnt[sl[r], yl[r]] += 1
check("balanced cells equal", (cnt == m).all() and len(rows) == int(np.multiply(9, m)) and len(set(rows.tolist())) == len(rows))

# GNINA stream audit
g0 = importlib.import_module("r2_g0_audit_gnina_streams")
a, b = g0.epoch_set(20260919, 60), g0.epoch_set(20260923, 60)
check("coupled seeds overlap", g0.overlap(a, b)[1] > 0.8)
d1, d2 = g0.decoupled_set(20270101, 60), g0.decoupled_set(20270202, 60)
check("decoupled seeds do not overlap", g0.overlap(d1, d2)[0] == 0)
check("decoupled within one seed distinct", len(set(d1)) == len(d1))

# epoch_seed rule in GninaContext without building it
# gnina_lib needs torch, so take the epoch_seed method out of the source and test it alone
import ast  # noqa: E402
import textwrap  # noqa: E402
src = open(os.path.join(PKG, "gnina_lib.py")).read()
fn = [n for n in ast.walk(ast.parse(src)) if isinstance(n, ast.FunctionDef) and n.name == "epoch_seed"][0]
ns = {"np": np}
exec(textwrap.dedent(ast.get_source_segment(src, fn)).replace("@staticmethod\n", ""), ns)


class _Ctx:
    epoch_seeding = "legacy"
    epoch_seed = ns["epoch_seed"]


ctx = _Ctx()
ctx.epoch_seeding = "legacy"
check("legacy seed+epoch", ctx.epoch_seed(10, 3) == 13)
ctx.epoch_seeding = "decoupled"
vals = {ctx.epoch_seed(s, e) for s in (20270101, 20270202) for e in range(100)}
check("decoupled unique and in range", len(vals) == 200 and max(vals) < 2147483647)
check("decoupled deterministic", ctx.epoch_seed(5, 7) == ctx.epoch_seed(5, 7))

# pearson/spearman guards
check("pearson constant is None", R.pearson([1, 1, 1, 1], [1, 2, 3, 4]) is None)
check("spearman monotone is 1", abs(R.spearman([1, 2, 3, 4], [1, 4, 9, 16]) - 1) < 1e-12)

print("%d of %d passed" % (sum(ok), len(ok)))
sys.exit(0 if all(ok) else 1)
