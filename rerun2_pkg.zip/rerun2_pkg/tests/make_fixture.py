"""Build a small synthetic project folder so every CPU stage can be smoke-tested without the real data.

Usage: python tests/make_fixture.py FIXTURE_DIR
Then:  PROJECT_ROOT=FIXTURE_DIR RERUN_CONFIG=FIXTURE_DIR/config_rerun_fixture.yaml python s0_lock_and_checks.py --mode cpu
"""
import hashlib
import json
import os
import sys

import numpy as np
import pandas as pd
import yaml

PKG = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..")

N_TEST, N_TRAIN, N_VAL, CL = 400, 600, 100, 10
DIMS = {"egnn": 64, "distance_gnn": 64, "gnina": 300}
TRAINED = ["primary", "anchor", "seed3", "seed4", "seed5"]
UNTR = ["untrained", "untrained_init2", "untrained_init3", "untrained_init4", "untrained_init5"]
REGEN = ["untrained_regen1", "untrained_regen2", "untrained_regen3", "untrained_regen4", "untrained_regen5"]


def main(root):
    rng = np.random.default_rng(7)
    os.makedirs(root + "/config", exist_ok=True)
    os.makedirs(root + "/data/embeddings", exist_ok=True)
    os.makedirs(root + "/data/splits", exist_ok=True)
    n_all = N_TEST + N_TRAIN + N_VAL
    ids = ["%04d" % (1000 + i) for i in range(n_all)]
    split = np.repeat(["test", "train", "val"], [N_TEST, N_TRAIN, N_VAL]).tolist()
    lig = np.round(rng.gamma(6, 3, n_all) + 5).astype(int)
    atoms = np.round(np.multiply(lig, 9) + rng.normal(0, 30, n_all)).astype(int)
    pd.DataFrame({"split": split, "ligand_heavy_atom_count": lig, "complex_atom_count": atoms,
                  "value": rng.normal(6, 1.5, n_all)}, index=ids).to_csv(root + "/data/splits/split_v1.tsv", sep="\t")
    pd.DataFrame({"complex_atom_count": atoms, "ligand_heavy_atom_count": lig}, index=ids).to_csv(
        root + "/data/covariates.tsv", sep="\t")
    clus = np.arange(n_all) // CL
    pd.DataFrame({"cluster_id": clus}, index=ids).to_csv(root + "/data/clusters.tsv", sep="\t")

    orig = {"embeddings": {"models": {a: {"dim": d, "layer": "x"} for a, d in DIMS.items()}},
            "split": {"file": "data/splits/split_v1.tsv", "affinity_column": "value"},
            "paths": {"pdbbind_dir": ""}}
    cpath = root + "/config/config.yaml"
    open(cpath, "w").write(yaml.safe_dump(orig))
    h = hashlib.sha256(open(cpath, "rb").read()).hexdigest()
    json.dump({"config_sha256": h}, open(root + "/config/config.lock.json", "w"))

    # latent world: shared signal (strength differs by arch), size, private
    shared = rng.normal(size=(n_all, 4))
    def z(x):
        return (x - x.mean(0)) / x.std(0)
    size = z(np.column_stack([lig, atoms]).astype(float))
    for arch, d in DIMS.items():
        for tag in TRAINED + UNTR + (REGEN if arch == "gnina" else []):
            trained = tag in TRAINED
            lat = [rng.normal(size=(n_all, 6))]
            lat.append(size)
            if trained:
                lat.append(shared)
            L = np.column_stack(lat)
            W = rng.normal(size=(L.shape[1], d))
            E = L @ W + np.multiply(0.3, rng.normal(size=(n_all, d)))
            for sp, lo, hi in (("test", 0, N_TEST), ("train", N_TEST, N_TEST + N_TRAIN),
                               ("val", N_TEST + N_TRAIN, n_all)):
                sub = np.arange(lo, hi)
                perm = rng.permutation(sub) if sp == "test" else sub
                np.save("%s/data/embeddings/%s_%s_%s.npy" % (root, arch, tag, sp), E[perm])
                open("%s/data/embeddings/%s_%s_%s_ids.txt" % (root, arch, tag, sp), "w").write(
                    "\n".join(ids[i] for i in perm))
    # fixture rerun config
    cfg = yaml.safe_load(open(PKG + "/config_rerun.yaml"))
    cfg["data"]["n_core_expected"] = N_TEST
    cfg["analysis"]["n_boot"] = 60
    cfg["analysis"]["chunk"] = 32
    cfg["positive_control"]["n_reps"] = 2
    cfg["positive_control"]["n_boot"] = 30
    cfg["positive_control"]["real_spike_in"]["n_reps"] = 1
    cfg["pc_removal"]["n_boot"] = 30
    cfg["pc_removal"]["rsa_cca_n_boot"] = 6
    cfg["stratified"]["n_boot"] = 30
    cfg["stratified"]["min_clusters_warn"] = 5
    cfg["paths"]["project_root"] = root
    cfg["paths"]["out_dir"] = "rerun_out"
    open(root + "/config_rerun_fixture.yaml", "w").write(yaml.safe_dump(cfg))
    # a manifest with one failed seed
    os.makedirs(root + "/rerun_out/results", exist_ok=True)
    man = {}
    for arch in ("egnn", "distance_gnn", "gnina"):
        for tag in ("seed3", "seed4", "seed5"):
            man["%s/%s" % (arch, tag)] = dict(arch=arch, tag=tag, gate_pass=not (arch == "egnn" and tag == "seed5"))
    json.dump(man, open(root + "/rerun_out/results/new_seed_manifest.json", "w"))
    print("fixture written to", root)


if __name__ == "__main__":
    main(sys.argv[1])
