"""Check the seed-aware engine against slow independent computations. Run: python tests/test_engine.py

Set ORIG_SRC_DIR to the folder holding the published alignlib.py to also check larger problems.
"""
import os
import sys

import numpy as np

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
import alignlib2 as al  # noqa: E402
import engine as eg  # noqa: E402
from mathx import mul  # noqa: E402

TRAINED5 = ["primary", "anchor", "seed3", "seed4", "seed5"]
UNTR5 = ["untrained", "untrained_init2", "untrained_init3", "untrained_init4", "untrained_init5"]
REGEN5 = ["untrained_regen1", "untrained_regen2", "untrained_regen3", "untrained_regen4", "untrained_regen5"]


def make_data(n, K, d, cluster_size, seed):
    rng = np.random.default_rng(seed)
    shared = rng.normal(size=(n, 3))
    cov = rng.normal(size=(n, 2))
    clusters = np.repeat(np.arange(n // cluster_size), cluster_size)
    archs = ["a1", "a2", "a3"]
    trained = TRAINED5[:K]
    untr = UNTR5[:K]
    regen = REGEN5[:K]
    Z = {}
    for a in archs:
        own = rng.normal(size=(n, 2))
        for t in trained:
            lat = np.concatenate([shared, own, cov, rng.normal(size=(n, 2))], axis=1)
            Z[eg.net_name(a, t)] = lat @ rng.normal(size=(lat.shape[1], d))
        for t in untr + regen:
            lat = np.concatenate([mul(0.3, shared), cov, rng.normal(size=(n, 3))], axis=1)
            Z[eg.net_name(a, t)] = lat @ rng.normal(size=(lat.shape[1], d))
    design = eg.Design(
        arch_pairs=[("a1", "a2"), ("a1", "a3"), ("a2", "a3")],
        trained={a: trained for a in archs},
        floor_sets={"orig": {a: untr for a in archs},
                    "regen": {"a1": untr, "a2": untr, "a3": regen}})
    return Z, cov, clusters, design


def feat(Z, cov, mode, name):
    return al.residualize(Z[name], cov, mode)


def point_reference(Z, cov, design, mode, cka_w, A, B):
    n = next(iter(Z.values())).shape[0]
    one = np.ones(n)
    ta, tb = design.trained[A], design.trained[B]

    def c(x, y):
        return cka_w(feat(Z, cov, mode, x), feat(Z, cov, mode, y), one)
    K = len(ta)
    obs = np.mean([[c(A + "/" + x, B + "/" + y) for y in tb] for x in ta])
    cA = np.mean([c(A + "/" + ta[i], A + "/" + ta[j]) for i in range(K) for j in range(i + 1, K)])
    cB = np.mean([c(B + "/" + tb[i], B + "/" + tb[j]) for i in range(K) for j in range(i + 1, K)])
    fl = np.mean([c(A + "/" + u, B + "/" + v)
                  for u, v in zip(design.floor_sets["orig"][A], design.floor_sets["orig"][B])])
    return obs, cA, cB, fl, c


def run_point_test(n, K, cka_w, tol, label, modes):
    Z, cov, cl, design = make_data(n, K, d=4 if n < 50 else 8, cluster_size=2 if n < 50 else 4, seed=0)
    for mode in modes:
        res = eg.run_seed_analysis(Z, cov, cl, design, [mode], n_boot=0, boot_seed=5, log=lambda s: None)
        for (A, B) in [("a1", "a2"), ("a2", "a3")]:
            rec = res[mode][A + "_x_" + B]["orig"]
            obs, cA, cB, fl, c = point_reference(Z, cov, design, mode, cka_w, A, B)
            e = rec["estimators"]["seed_min"]
            assert abs(e["obs"] - obs) < tol and abs(e["floor"] - fl) < tol, (label, mode, e, obs, fl)
            assert abs(e["ceil"] - min(cA, cB)) < tol
            assert abs(e["nab"] - (obs - fl) / (min(cA, cB) - fl)) < mul(10.0, tol)
            g = rec["estimators"]["seed_geo"]
            assert abs(g["ceil"] - np.sqrt(mul(cA, cB))) < tol
            o = rec["estimators"]["orig"]
            p = c(A + "/primary", B + "/primary")
            ca = c(A + "/primary", A + "/anchor")
            cb = c(B + "/primary", B + "/anchor")
            assert abs(o["obs"] - p) < tol and abs(o["ceil"] - min(ca, cb)) < tol
        r3 = res[mode]["a1_x_a3"]["regen"]["floors"]
        ref3 = [c(("a1/" + u), ("a3/" + v)) for u, v in zip(design.floor_sets["regen"]["a1"], design.floor_sets["regen"]["a3"])]
        assert np.allclose(r3, ref3, atol=tol)
        assert np.allclose(res[mode]["a1_x_a2"]["orig"]["floors"], res[mode]["a1_x_a2"]["regen"]["floors"])
    print("point estimates (%s, n=%d, K=%d): ok" % (label, n, K))


def run_draw_test(n, K, cka_w, tol, label, mode, B, bs, which):
    Z, cov, cl, design = make_data(n, K, d=4 if n < 50 else 8, cluster_size=2 if n < 50 else 4, seed=1)
    res = eg.run_seed_analysis(Z, cov, cl, design, [mode], n_boot=B, boot_seed=bs, chunk=16,
                               keep_draws=True, log=lambda s: None)
    nab_eng = res["_draws"][mode + "|a1_x_a3|regen|seed_min_nab_two_level"]
    inv, G = al.cluster_inverse(cl)
    Ms = np.concatenate([M for _, M in al.iter_weights("cluster", inv, G, B, 16, bs)], axis=1)
    rng = np.random.default_rng([bs, 99991])
    sidx = {a: rng.integers(0, K, size=(B, K)) for a in design.trained}
    kidx = rng.integers(0, K, size=(B, K))
    tags = design.trained["a1"]
    f1 = design.floor_sets["regen"]["a1"]
    f3 = design.floor_sets["regen"]["a3"]
    for b in which:
        w = Ms[:, b]

        def cka(x, y):
            return cka_w(feat(Z, cov, mode, x), feat(Z, cov, mode, y), w)
        sa, sb = sidx["a1"][b], sidx["a3"][b]
        obs = np.mean([[cka("a1/" + tags[i], "a3/" + tags[j]) for j in sb] for i in sa])

        def ceil_of(arch, s):
            vals = [cka(arch + "/" + tags[s[i]], arch + "/" + tags[s[j]])
                    for i in range(K) for j in range(K) if s[i] != s[j]]
            return np.mean(vals) if vals else np.nan
        cA, cB = ceil_of("a1", sa), ceil_of("a3", sb)
        fl = np.mean([cka("a1/" + f1[k], "a3/" + f3[k]) for k in kidx[b]])
        c = min(cA, cB)
        ref = (obs - fl) / (c - fl) if (c - fl) >= 0.05 else np.nan
        e = nab_eng[b]
        both_nan = np.isnan(ref) and np.isnan(e)
        assert both_nan or abs(ref - e) < tol, (label, b, ref, e)
    print("two-level draws (%s, n=%d, K=%d) match manual computation: ok" % (label, n, K))


def test_undefined_handling():
    obs = np.array([0.5, 0.5])
    floor = np.array([0.1, 0.9])
    ceil = np.array([0.8, 0.7])
    v = eg.nab_value(obs, floor, ceil, 0.05)
    assert np.isclose(v[0], (0.5 - 0.1) / 0.7) and np.isnan(v[1])
    lo, hi, fr = eg.interval(np.array([np.nan] + [0.5 for _ in range(9)]), 0.95, 0.05)
    assert lo is None and abs(fr - 0.1) < 1e-12
    print("undefined handling: ok")


def brute_cka(Za, Zb, w):
    return al.brute_force_cka_weighted(Za, Zb, w)


if __name__ == "__main__":
    test_undefined_handling()
    # tiny problems against enumeration over distinct tuples (exact definition)
    run_point_test(12, 3, brute_cka, 1e-8, "enumeration", ["raw", "resid_linear"])
    run_draw_test(12, 3, brute_cka, 1e-7, "enumeration", "resid_linear", B=6, bs=11, which=[0, 3])
    orig = os.environ.get("ORIG_SRC_DIR")
    if orig:
        sys.path.insert(0, orig)
        import alignlib as oal
        run_point_test(160, 5, lambda a, b, w: oal.cka_feature_w(a, b, w), 1e-8, "original alignlib",
                       ["raw", "resid_linear", "resid_poly2"])
        run_draw_test(160, 5, lambda a, b, w: oal.cka_feature_w(a, b, w), 5e-4, "original alignlib",
                      "resid_poly2", B=40, bs=11, which=[0, 7, 23, 39])
    else:
        print("original alignlib comparison skipped (set ORIG_SRC_DIR)")
    print("ALL ENGINE TESTS PASSED")
