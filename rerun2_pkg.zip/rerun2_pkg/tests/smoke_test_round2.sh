#!/usr/bin/env bash
# Runs every CPU stage of round 2 on a small synthetic project (round 1 fixture plus round 2 fixture). About 2 minutes.
# The numbers are random and never to be used. The GPU stages (r2_g1 to r2_g4) have no synthetic test.
#   bash tests/smoke_test_round2.sh
set -euo pipefail
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$HERE"
FIX="${FIX:-/tmp/rerun2_fixture}"
rm -rf "$FIX"
python tests/make_fixture.py "$FIX"
export PROJECT_ROOT="$FIX"
# round 1 prerequisites on the fixture: lock, projections, seed analysis (writes rerun_out/)
export RERUN_CONFIG="$FIX/config_rerun_fixture.yaml"
python s0_lock_and_checks.py --mode cpu
python s4_project.py --gate_warn_only
python s5_seed_analysis.py
unset RERUN_CONFIG
python tests/make_fixture_round2.py "$FIX"
export RERUN2_CONFIG="$FIX/config_rerun2_fixture.yaml"
python r2_s0_lock_and_checks.py --mode cpu
python r2_c0_project.py
python r2_g0_audit_gnina_streams.py --epochs primary=60 anchor=58 --no_weights
python r2_c1_decoupled_gnina.py
python r2_c2_sizecorr_analysis.py
python r2_c3_seed_size_content.py
python r2_c4_residual_controls.py
python r2_c5_prediction_agreement.py
python r2_c6_input_deconfound.py
python r2_c7_layers_analysis.py
python r2_c8_size_balanced.py
python r2_c9_report.py
echo "ROUND 2 SMOKE TEST PASSED. Report: $FIX/rerun_out2/report/report_round2.md"
