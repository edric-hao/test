"""Adds round-2 synthetic inputs to the project built by tests/make_fixture.py.

Usage: python tests/make_fixture_round2.py FIXTURE_DIR
Creates: embeddings for decoupled GNINA seeds (dc1 to dc5) and size-corrected networks (sc tags), predictions.npz, layers files,
input_features.tsv, manifests, and config_rerun2_fixture.yaml. Numbers are random and never to be used.
"""
import json
import os
import sys

import numpy as np
import pandas as pd
import yaml

PKG = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..")
sys.path.insert(0, PKG)
import common as C  # noqa: E402
N_TEST, N_TRAIN, N_VAL = 400, 600, 100
DIMS = {"egnn": 64, "distance_gnn": 64, "gnina": 300}


def z(x):
    return (x - x.mean(0)) / x.std(0)


def main(root):
    rng = np.random.default_rng(11)
    n_all = N_TEST + N_TRAIN + N_VAL
    split = pd.read_csv(root + "/data/splits/split_v1.tsv", sep="\t", index_col=0)
    ids = ["%04d" % (1000 + i) for i in range(n_all)]
    lig = split["ligand_heavy_atom_count"].to_numpy(float)
    atoms = split["complex_atom_count"].to_numpy(float)
    size = z(np.column_stack([lig, atoms]))
    shared = rng.normal(size=(n_all, 4))
    tags = {"gnina": ["dc1", "dc2", "dc3", "dc4", "dc5", "sc1", "sc2", "sc3"],
            "egnn": ["sc1", "sc2", "sc3", "sc4", "sc5"], "distance_gnn": ["sc1", "sc2", "sc3", "sc4", "sc5"]}
    for arch, tl in tags.items():
        d = DIMS[arch]
        for tag in tl:
            lat = [rng.normal(size=(n_all, 6)), shared, np.multiply(0.5 if tag.startswith("sc") else 1.0, size)]
            L = np.column_stack(lat)
            E = L @ rng.normal(size=(L.shape[1], d)) + np.multiply(0.3, rng.normal(size=(n_all, d)))
            for sp, lo, hi in (("test", 0, N_TEST), ("train", N_TEST, N_TEST + N_TRAIN), ("val", N_TEST + N_TRAIN, n_all)):
                sub = np.arange(lo, hi)
                perm = rng.permutation(sub) if sp == "test" else sub
                np.save("%s/data/embeddings/%s_%s_%s.npy" % (root, arch, tag, sp), E[perm])
                open("%s/data/embeddings/%s_%s_%s_ids.txt" % (root, arch, tag, sp), "w").write("\n".join(ids[i] for i in perm))
    # test ids in the id order of the saved embeddings (egnn primary)
    test_ids = open(root + "/data/embeddings/egnn_primary_test_ids.txt").read().split()
    pos = {p: i for i, p in enumerate(ids)}
    sh_test = shared[[pos[p] for p in test_ids]]
    sz_test = size[[pos[p] for p in test_ids]]
    out = os.path.join(root, "rerun_out2")
    os.makedirs(out + "/results/layers", exist_ok=True)
    allnets = {}
    for arch in DIMS:
        trained = ["primary", "anchor", "seed3", "seed4", "seed5"] + (["dc1", "dc2", "dc3", "dc4", "dc5"] if arch == "gnina" else [])
        untr = ["untrained", "untrained_init2", "untrained_init3", "untrained_init4", "untrained_init5"]
        allnets[arch] = trained + untr
    preds = {}
    for arch, tl in allnets.items():
        for tag in tl:
            trained = not tag.startswith("untrained")
            p = np.zeros(N_TEST)
            if trained:
                p = sh_test @ np.array([1.0, 0.5, 0.0, 0.0]) + np.multiply(0.6, sz_test[:, 0]) + np.multiply(0.4, rng.normal(size=N_TEST))
            else:
                p = np.multiply(0.5, sz_test[:, 0]) + rng.normal(size=N_TEST)
            preds["%s|%s" % (arch, tag)] = p
            arrays = {"pred": p, "ids": np.array(test_ids)}
            specs = ["L0", "L1", "L2", "L3", "L3_lig", "L3_poc"] if arch != "gnina" else ["conv1", "conv2", "conv3"]
            for s in specs:
                dim = 64 if arch != "gnina" else {"conv1": 32, "conv2": 64, "conv3": 128}[s]
                lat = np.column_stack([rng.normal(size=(N_TEST, 5)), sz_test] + ([sh_test] if trained else []))
                arrays[s] = lat @ rng.normal(size=(lat.shape[1], dim)) + np.multiply(0.3, rng.normal(size=(N_TEST, dim)))
            C.save_npz("%s/results/layers/%s__%s.npz" % (out, arch, tag), arrays)
    preds["ids"] = np.array(test_ids)
    C.save_npz(out + "/results/predictions.npz", preds)
    # input features
    feat = pd.DataFrame(index=test_ids)
    zz = np.column_stack([sz_test, rng.normal(size=(N_TEST, 6))])
    for j in range(zz.shape[1]):
        feat["f%d" % j] = zz[:, j] + np.multiply(0.1, rng.normal(size=N_TEST))
    feat["zero_var"] = 3.0
    feat.index.name = "pdb_id"
    feat.to_csv(out + "/results/input_features.tsv", sep="\t")
    # manifests
    man = {}
    for t in ["dc1", "dc2", "dc3", "dc4", "dc5"]:
        man["gnina/" + t] = dict(arch="gnina", tag=t, gate_pass=(t != "dc5"), seed=1, test_pearson_r=0.5)
    json.dump(man, open(out + "/results/decoupled_gnina_manifest.json", "w"))
    man = {}
    for arch, tl in (("egnn", 5), ("distance_gnn", 5), ("gnina", 3)):
        for i in range(tl):
            t = "sc%d" % (i + 1)
            man["%s/%s" % (arch, t)] = dict(arch=arch, tag=t, gate_pass=True, seed=2, val_pearson_r_corrected=0.2,
                                            test_pearson_r_corrected=0.2, test_pearson_r_raw=0.55, size_only_test_r_raw=0.52)
    json.dump(man, open(out + "/results/sizecorr_manifest.json", "w"))
    # config
    cfg = yaml.safe_load(open(PKG + "/config_rerun2.yaml"))
    cfg["paths"]["project_root"] = root
    cfg["data"]["n_core_expected"] = N_TEST
    cfg["analysis"]["n_boot"] = 40
    cfg["analysis"]["chunk"] = 20
    cfg["controls"]["n_perm_covariates"] = 3
    cfg["controls"]["n_perm_null"] = 4
    cfg["prediction_agreement"]["n_boot"] = 20
    cfg["input_deconf"]["n_boot"] = 20
    cfg["input_deconf"]["rbf_eps"] = [1.0]
    cfg["layers"]["analysis"]["n_boot"] = 20
    cfg["size_balanced"]["n_draws"] = 3
    cfg["size_balanced"]["n_boot"] = 20
    open(root + "/config_rerun2_fixture.yaml", "w").write(yaml.safe_dump(cfg))
    print("round-2 fixture written to", root)


if __name__ == "__main__":
    main(sys.argv[1])
