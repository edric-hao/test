"""Check the regression-gate logic of s4_project.py with a self-consistent fake reference.

Needs the synthetic fixture. Run:
  python tests/make_fixture.py FIX
  PROJECT_ROOT=FIX RERUN_CONFIG=FIX/config_rerun_fixture.yaml python tests/test_gate.py
(after s0_lock_and_checks.py and s4_project.py have been run on the fixture)
"""
import json
import os
import sys
import tempfile
from pathlib import Path

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
import common as C  # noqa: E402
import s4_project as P  # noqa: E402


def main():
    cfg = C.load_cfg()
    core = C.core_ids(cfg)
    cov = C.load_covariates(cfg, core)
    rows, worst = P.regression_gate(cfg, core, cov, 0.003)
    assert any(not r["ok"] for r in rows), "the real reference should NOT match the synthetic fixture"
    # build a reference in the published schema from the recomputed values
    raw, lin, poly = {}, {}, {}
    for r in rows:
        tgt = {"raw": raw, "resid_linear": lin, "resid_poly2": poly}[r["mode"]].setdefault(r["pair"], {})
        tgt[r["quantity"]] = r["recomputed"]
    ref_raw = {k: dict(cka=v["obs"], floor=v["floor"], ceiling=v["ceil"], n_AB=v["nab"]) for k, v in raw.items()}

    def cl(v):
        return {"cluster": dict(obs_point=v["obs"], floor_point=v["floor"], ceiling_point=v["ceil"], n_ab_point=v["nab"])}
    ref_res = {"linear": {k: cl(v) for k, v in lin.items()}, "poly2": {k: cl(v) for k, v in poly.items()}}
    with tempfile.TemporaryDirectory() as td:
        (Path(td) / "reference").mkdir()
        json.dump(ref_raw, open(Path(td) / "reference" / "h1_results_published.json", "w"))
        json.dump(ref_res, open(Path(td) / "reference" / "h1_size_resid_published.json", "w"))
        old = C.PKG_DIR
        C.PKG_DIR = Path(td)
        try:
            rows2, worst2 = P.regression_gate(cfg, core, cov, 0.003)
            assert all(r["ok"] for r in rows2) and worst2 == 0.0, worst2
            # a perturbed reference must be caught
            ref_raw["egnn_x_gnina"]["cka"] += 0.01
            json.dump(ref_raw, open(Path(td) / "reference" / "h1_results_published.json", "w"))
            rows3, _ = P.regression_gate(cfg, core, cov, 0.003)
            assert any(not r["ok"] for r in rows3)
        finally:
            C.PKG_DIR = old
    print("regression gate logic: ok (%d checks)" % len(rows))
    print("GATE TEST PASSED")


if __name__ == "__main__":
    main()
