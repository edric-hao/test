"""Unit tests for alignlib2. Run: python tests/test_alignlib2.py"""
import os
import sys

import numpy as np

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
import alignlib2 as al  # noqa: E402
from mathx import mul  # noqa: E402


def test_weighted_equals_bruteforce():
    rng = np.random.default_rng(0)
    n, d = 8, 4
    A = rng.normal(size=(n, d))
    B = mul(0.5, A) + rng.normal(size=(n, d))
    bank = al.GramBank({"a": al.gram_zero_diag(A), "b": al.gram_zero_diag(B)})
    for trial in range(6):
        w = rng.integers(0, 4, size=n).astype(float)
        if (w > 0).sum() < 5:
            w[:5] = 1.0
        got = bank.cka_table([("a", "b")], w[:, None])[0, 0]
        ref = al.brute_force_cka_weighted(A, B, w)
        assert abs(got - ref) < 1e-9, (got, ref, w)
    full = bank.cka_point([("a", "b")])[0]
    assert abs(full - al.brute_force_cka_weighted(A, B, np.ones(n))) < 1e-9
    print("weighted estimator == enumeration over distinct tuples: ok")


def test_matches_original_pipeline_if_available():
    """The original estimator centers each bootstrap draw by its weighted mean; this package centers once
    on the full sample. Point estimates must agree exactly, draws closely."""
    orig = os.environ.get("ORIG_SRC_DIR")
    if not orig:
        print("original alignlib comparison: skipped (set ORIG_SRC_DIR to the folder that contains alignlib.py)")
        return
    sys.path.insert(0, orig)
    import importlib
    oal = importlib.import_module("alignlib")
    rng = np.random.default_rng(10)
    n, d = 900, 12
    A = rng.normal(size=(n, d))
    B = mul(0.4, A) + rng.normal(size=(n, d))
    groups = np.repeat(np.arange(n // 5), 5)
    bank = al.GramBank({"a": al.gram_zero_diag(A), "b": al.gram_zero_diag(B)})
    assert abs(bank.cka_point([("a", "b")])[0] - oal.cka_feature(A, B)) < 1e-9
    worst = 0.0
    for t in range(8):
        w = oal.boot_weights(n, rng, groups)
        got = bank.cka_table([("a", "b")], w[:, None])[0, 0]
        ref = oal.cka_feature_w(A, B, w)
        worst = max(worst, abs(got - ref))
    assert worst < 2e-3, worst
    print("matches the original alignlib: point estimate exact, bootstrap draws max abs diff %.2e: ok" % worst)


def test_centering_invariance_unit_weights():
    rng = np.random.default_rng(5)
    n = 50
    A = rng.normal(size=(n, 5)) + 3.0
    B = rng.normal(size=(n, 5)) - 2.0

    def raw_gram(X):
        K = X @ X.T
        np.fill_diagonal(K, 0.0)
        return K
    b1 = al.GramBank({"a": raw_gram(A), "b": raw_gram(B)})
    b2 = al.GramBank({"a": al.gram_zero_diag(A), "b": al.gram_zero_diag(B)})
    x = b1.cka_point([("a", "b")])[0]
    y = b2.cka_point([("a", "b")])[0]
    assert abs(x - y) < 1e-9, (x, y)
    print("with unit weights, centering does not matter: ok")


def test_cka_symmetry_and_selfsim():
    rng = np.random.default_rng(1)
    A = rng.normal(size=(60, 5))
    B = rng.normal(size=(60, 5))
    bank = al.GramBank({"a": al.gram_zero_diag(A), "b": al.gram_zero_diag(B)})
    ab, ba, aa = bank.cka_point([("a", "b"), ("b", "a"), ("a", "a")])
    assert abs(ab - ba) < 1e-12
    assert abs(aa - 1.0) < 1e-10
    print("symmetry and self similarity: ok")


def test_debiased_null_is_zero_and_rotation_invariant():
    rng = np.random.default_rng(2)
    n, d = 300, 64
    vals = []
    for _ in range(30):
        A = rng.normal(size=(n, d))
        B = rng.normal(size=(n, d))
        bank = al.GramBank({"a": al.gram_zero_diag(A), "b": al.gram_zero_diag(B)})
        vals.append(bank.cka_point([("a", "b")])[0])
    assert abs(np.mean(vals)) < 0.01, np.mean(vals)
    A = rng.normal(size=(n, 10))
    B = A + rng.normal(size=(n, 10))
    Q, _ = np.linalg.qr(rng.normal(size=(10, 10)))
    bank = al.GramBank({"a": al.gram_zero_diag(A), "b": al.gram_zero_diag(B),
                        "br": al.gram_zero_diag(B @ Q)})
    x, y = bank.cka_point([("a", "b"), ("a", "br")])
    assert abs(x - y) < 1e-10
    print("null mean about 0 and rotation invariance: ok")


def test_pca_paths_agree():
    rng = np.random.default_rng(3)
    n, d, k = 80, 200, 10
    X = mul(rng.normal(size=(n, 12)), 1.0) @ rng.normal(size=(12, d)) + mul(0.1, rng.normal(size=(n, d)))
    fit_gram = al.pca_fit(X, k, chunk_cols=37)  # d > n -> gram path
    Xt = X[:, :]
    # reference by SVD
    Xc = Xt - Xt.mean(0, keepdims=True)
    U, S, Vt = np.linalg.svd(Xc, full_matrices=False)
    ref_eig = np.divide(np.square(S[:k]), n - 1.0)
    assert np.allclose(fit_gram["eigvals"], ref_eig, rtol=1e-8)
    P1 = al.pca_project(X, fit_gram, chunk_cols=41)
    P2 = Xc @ Vt[:k].T
    # sign agnostic comparison through gram of projections
    assert np.allclose(P1 @ P1.T, P2 @ P2.T, atol=1e-6)
    # covariance path
    X2 = X[:, :40]
    fit_cov = al.pca_fit(X2, 5)
    Xc2 = X2 - X2.mean(0, keepdims=True)
    U2, S2, Vt2 = np.linalg.svd(Xc2, full_matrices=False)
    assert np.allclose(fit_cov["eigvals"], np.divide(np.square(S2[:5]), n - 1.0), rtol=1e-8)
    assert abs(fit_cov["evr"].sum() - np.divide(np.square(S2[:5]).sum(), np.square(S2).sum())) < 1e-10
    print("pca covariance and gram paths: ok")


def test_residualize_removes_covariates():
    rng = np.random.default_rng(4)
    n = 500
    cov = rng.normal(size=(n, 2))
    Z = rng.normal(size=(n, 6)) + mul(2.0, cov[:, :1]) + mul(1.0, cov[:, 1:2])
    R = al.residualize(Z, cov, "resid_linear")
    D = al.covariate_design(cov, "resid_linear")
    assert np.abs(D.T @ R).max() < 1e-8
    R2 = al.residualize(Z, cov, "resid_poly2")
    D2 = al.covariate_design(cov, "resid_poly2")
    assert D2.shape[1] == 5 and np.abs(D2.T @ R2).max() < 1e-8
    R3 = al.residualize(Z, cov, "resid_poly2x")
    D3 = al.covariate_design(cov, "resid_poly2x")
    assert D3.shape[1] == 6 and np.abs(D3.T @ R3).max() < 1e-8
    print("residualization: ok")


def test_bootstrap_weights():
    labels = np.array([0, 0, 1, 1, 1, 2, 3, 3, 3, 3])
    inv, G = al.cluster_inverse(labels)
    assert G == 4
    seen = []
    for b0, M in al.iter_weights("cluster", inv, G, 600, 256, 7):
        seen.append(M)
        # every complex of a cluster has an identical weight
        for g in range(G):
            cols = M[inv == g]
            assert np.all(cols == cols[0:1, :])
    M = np.concatenate(seen, axis=1)
    assert M.shape == (10, 600)
    # reproducible
    M2 = np.concatenate([x for _, x in al.iter_weights("cluster", inv, G, 600, 256, 7)], axis=1)
    assert np.array_equal(M, M2)
    # expected weight is one for each complex
    assert abs(M.mean() - 1.0) < 0.1
    Mc = np.concatenate([x for _, x in al.iter_weights("complex", inv, G, 300, 256, 7)], axis=1)
    assert np.all(Mc.sum(axis=0) == 10)
    print("bootstrap weights: ok")


if __name__ == "__main__":
    test_weighted_equals_bruteforce()
    test_matches_original_pipeline_if_available()
    test_centering_invariance_unit_weights()
    test_cka_symmetry_and_selfsim()
    test_debiased_null_is_zero_and_rotation_invariant()
    test_pca_paths_agree()
    test_residualize_removes_covariates()
    test_bootstrap_weights()
    print("ALL ALIGNLIB2 TESTS PASSED")
