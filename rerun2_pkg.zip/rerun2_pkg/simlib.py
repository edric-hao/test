"""Synthetic networks with analytic alignment truth (positive control).

World. Factors G, H, P are independent standard normal draws. Size factors are exact standardized functions of the real
covariates (so they live inside the residualization span). Population linear CKA is then
  CKA(X, Y) = sum over shared factors k of (l_Xk l_Yk)^2  /  sqrt( sum_k l_Xk^4 x sum_k l_Yk^4 ),
where l are the factor loadings of the two networks. Each network is a random orthonormal rotation of its loaded factors into 64 dimensions.

Factor families
  G        shared by every TRAINED network of both architectures, loading sqrt(rho) x g_load. This is the planted cross-architecture signal.
  H_arch   shared by the trained seeds of one architecture only (what makes the within-architecture ceiling).
  P_net    private to a single network (trained or untrained).
  S_lin    a size factor, linear in the covariates.   S_nl  a size factor, quadratic and orthogonal to the linear covariate span.
Size factors load on EVERY network, trained and untrained, in the size conditions.

Conditions
  null_shared       no G anywhere (rho forced to 0), no size.   True alignment 0.
  size_independent  planted G, no size factor.
  size_linear       planted G plus the linear size factor in all networks.
  size_nonlinear    planted G plus the quadratic size factor in all networks.

Truth for a mode keeps the size factors that the mode does not remove: raw keeps all, resid_linear removes S_lin only,
resid_poly2 and resid_poly2x remove both. truth_signal always excludes size (the planted protein-level alignment).
"""
import numpy as np

import alignlib2 as al
from mathx import mul

CONDITIONS = ("null_shared", "size_independent", "size_linear", "size_nonlinear")

PARAMS = dict(kG=6, kH=6, kP=40, g_load=1.0, h_load=1.0, size_load=1.0, u_size_load=0.8,
              p_load={"a1": 0.3, "a2": 0.5}, u_p_load={"a1": 0.6, "a2": 0.6}, dim=64)


def size_factor_names(cond):
    return {"size_linear": ["S_lin"], "size_nonlinear": ["S_nl"]}.get(cond, [])


def kept_size_factors(cond, mode):
    names = size_factor_names(cond)
    if mode == "raw":
        return names
    if mode == "resid_linear":
        return [s for s in names if s == "S_nl"]
    return []


def loadings(arch, tag, trained, cond, rho, include_size, P=PARAMS):
    """Dict factor -> loading for one network. include_size is the list of size factors to keep."""
    d = {}
    if trained:
        if cond != "null_shared":
            for i in range(P["kG"]):
                d["G_%d" % i] = mul(float(np.sqrt(rho)), P["g_load"])
        for i in range(P["kH"]):
            d["H_%s_%d" % (arch, i)] = P["h_load"]
    pl = P["p_load"][arch] if trained else P["u_p_load"][arch]
    for i in range(P["kP"]):
        d["P_%s_%s_%d" % (arch, tag, i)] = pl
    sl = P["size_load"] if trained else P["u_size_load"]
    for s in include_size:
        d[s] = sl
    return d


def pop_cka(la, lb):
    num = 0.0
    for k, v in la.items():
        if k in lb:
            num += float(np.square(mul(v, lb[k])))
    sa = sum(float(np.power(v, 4)) for v in la.values())
    sb = sum(float(np.power(v, 4)) for v in lb.values())
    return num / np.sqrt(mul(sa, sb))


def truth(cond, rho, mode, trained_tags, untrained_tags, signal_only=False, P=PARAMS):
    """Analytic cross, ceilings, floor and n_AB for archs a1 and a2."""
    inc = [] if signal_only else kept_size_factors(cond, mode)
    r = 0.0 if cond == "null_shared" else rho

    def L(arch, tag, tr):
        return loadings(arch, tag, tr, cond, r, inc, P)
    cross = pop_cka(L("a1", trained_tags[0], True), L("a2", trained_tags[0], True))
    c1 = pop_cka(L("a1", trained_tags[0], True), L("a1", trained_tags[1], True))
    c2 = pop_cka(L("a2", trained_tags[0], True), L("a2", trained_tags[1], True))
    floor = pop_cka(L("a1", untrained_tags[0], False), L("a2", untrained_tags[0], False))
    out = dict(cross=cross, ceil_a1=c1, ceil_a2=c2, floor=floor)
    for nm, ceil in (("min", min(c1, c2)), ("geo", float(np.sqrt(mul(c1, c2))))):
        den = ceil - floor
        out["nab_" + nm] = float((cross - floor) / den) if den > 1e-12 else float("nan")
    return out


def _size_columns(cov, size_names):
    """Exact standardized size factors as functions of the covariates (columns of unit sample variance)."""
    D = al.covariate_design(cov, "resid_poly2x")
    Ql, _ = np.linalg.qr(al.covariate_design(cov, "resid_linear"))
    out = {}
    c1 = D[:, 1:2]
    v = c1 - Ql[:, :1] @ (Ql[:, :1].T @ c1)
    out["S_lin"] = v[:, 0]
    c1sq = D[:, 3:4]
    w = c1sq - Ql @ (Ql.T @ c1sq)
    out["S_nl"] = w[:, 0]
    return {k: np.divide(v_ - v_.mean(), v_.std()) for k, v_ in out.items() if k in size_names}


def build_world(cond, rho, cov, trained_tags, untrained_tags, rng, P=PARAMS):
    """Zmap (net name -> (n, 64)) for archs a1 and a2, with all trained and untrained tags."""
    n = cov.shape[0]
    r = 0.0 if cond == "null_shared" else rho
    size_names = size_factor_names(cond)
    nets = [(a, t, True) for a in ("a1", "a2") for t in trained_tags] + \
           [(a, t, False) for a in ("a1", "a2") for t in untrained_tags]
    fam = {}
    for a, t, tr in nets:
        for k in loadings(a, t, tr, cond, r, size_names, P):
            fam[k] = True
    rand_names = [k for k in fam if k not in size_names]
    col = _size_columns(cov, size_names)
    for nm in rand_names:
        col[nm] = rng.normal(size=n)
    Zmap = {}
    for a, t, tr in nets:
        ld = loadings(a, t, tr, cond, r, size_names, P)
        names = list(ld.keys())
        F = np.column_stack([mul(ld[k], col[k]) for k in names])
        M = rng.normal(size=(P["dim"], len(names)))
        U, _ = np.linalg.qr(M)                       # (dim, k) orthonormal columns
        Zmap["%s/%s" % (a, t)] = F @ U.T
    return Zmap
