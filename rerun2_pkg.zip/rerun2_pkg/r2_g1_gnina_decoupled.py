#!/usr/bin/env python
"""r2_g1_gnina_decoupled.py  --  GPU box. Train GNINA seeds whose data streams are decoupled (tags dc1 to dc5), gate them, extract embeddings.

Identical to round 1 s2_train_gnina_seeds.py (same architecture, optimizer, early stopping, augmentation, float64 extraction of the pose
output layer input) with one change: the random stream of epoch e is drawn from numpy SeedSequence([seed, e]) instead of seed + e, so no
two runs share a shuffle or an augmentation. Gate: validation r at least 0.4 and at least 0.10 above the untrained network. A failed seed
is recorded and never retrained.

Usage
  python r2_g1_gnina_decoupled.py
  python r2_g1_gnina_decoupled.py --tags dc1 dc2 dc3
  python r2_g1_gnina_decoupled.py --extract_device cpu      (slower, the device the original extraction used)
"""
import argparse

import numpy as np

import common as C
import r2lib as R


def finite_and_varied(npy, n_check=2000):
    E = np.load(npy, mmap_mode="r")
    sub = np.asarray(E[:n_check], dtype=np.float64)
    return bool(np.isfinite(sub).all()), bool((sub.std(axis=0) > 0).any())


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--tags", nargs="+", default=None)
    ap.add_argument("--extract_device", default=None)
    ap.add_argument("--skip_selftest", action="store_true")
    a = ap.parse_args()
    cfg = R.load_cfg2()
    C.ensure_dirs(cfg)
    C.verify_lock(cfg)
    dc = cfg["decoupled_gnina"]
    import gnina_lib as GL
    ctx = GL.GninaContext(cfg, extract_device=a.extract_device, epoch_seeding=dc["epoch_seeding"])
    C.log("train device %s, extraction device %s, epoch seeding %s" % (ctx.device, ctx.extract_device, ctx.epoch_seeding))
    if not a.skip_selftest:
        C.json_dump(ctx.selftest(), cfg["_out"] / "results" / "gnina_selftest_round2.json")
    tags = a.tags or list(dc["tags"])
    manifest = R.manifest2(cfg, "decoupled_gnina_manifest.json")
    man_path = cfg["_out"] / "results" / "decoupled_gnina_manifest.json"
    mu = ctx.load_saved_untrained("untrained")
    vm_u = ctx.evaluate(mu, "val")
    del mu
    C.log("[gnina] untrained validation r = %.3f" % vm_u["pearson_r"])
    for tag in tags:
        key = "gnina/%s" % tag
        have_all = all(C.emb_paths(cfg, "gnina", tag, sp)[0].exists() for sp in ("train", "val", "test"))
        if key in manifest and have_all:
            C.log("[%s] already trained and extracted; skipping" % key)
            continue
        seed = int(dc["seed_values"][tag])
        C.log("[%s] training with seed %d (decoupled streams)" % (key, seed))
        model, info = ctx.train_gnina(seed, tag)
        model = model.to(ctx.device)
        vm = ctx.evaluate(model, "val")
        tm = ctx.evaluate(model, "test")
        ok = bool(vm["pearson_r"] >= float(cfg["gate"]["min_val_pearson"])
                  and (vm["pearson_r"] - vm_u["pearson_r"]) >= float(cfg["gate"]["min_margin_over_untrained"]))
        hist = info.get("history", [])
        best_epoch = int(min(hist, key=lambda h: h["val_loss"])["epoch"]) if hist else None
        C.log("[%s] val r=%.3f (untrained %.3f) test r=%.3f  GATE %s"
              % (key, vm["pearson_r"], vm_u["pearson_r"], tm["pearson_r"], "PASS" if ok else "FAIL"))
        del model
        outs = ctx.extract_tag(tag)
        health = {}
        for sp, npy in outs.items():
            fin, var = finite_and_varied(npy)
            health[sp] = dict(finite=fin, varied=var)
            if not (fin and var):
                C.log("WARNING: %s/%s embeddings are non-finite or constant" % (key, sp))
        manifest[key] = dict(arch="gnina", tag=tag, seed=seed, epoch_seeding=ctx.epoch_seeding, best_epoch=best_epoch,
                             n_epochs_run=len(hist), val_pearson_r=vm["pearson_r"], val_rmse=vm["rmse"], val_loss=vm["val_loss"],
                             test_pearson_r=tm["pearson_r"], test_rmse=tm["rmse"], untrained_val_pearson_r=vm_u["pearson_r"],
                             gate_pass=ok, health=health)
        C.json_dump(manifest, man_path)
    C.json_dump(manifest, man_path)
    fails = [k for k, v in manifest.items() if not v["gate_pass"]]
    C.log("done. gate failures (reported, not retrained): %s" % (fails if fails else "none"))


if __name__ == "__main__":
    main()
