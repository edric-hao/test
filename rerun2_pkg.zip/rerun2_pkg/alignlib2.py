"""Core alignment metrics for the rerun package.

Contents
  pca_fit_project   exact top-k PCA fitted on train embeddings (chunked, handles 27648-d)
  residualize       OLS residualization on standardized covariates (linear or quadratic)
  gram_zero_diag    mean-centered linear Gram matrix with zeroed diagonal
  hsic_value        unbiased HSIC from the five sufficient terms (Song et al. 2012)
  GramBank          debiased linear CKA for many network pairs under many multiplicity
                    weight vectors (exact weighted estimator with masked self pairs)
  iter_weights      cluster or complex bootstrap multiplicity weights, reproducible per chunk
  brute_force_cka   slow reference implementation used only by the tests

No source file in this package uses the asterisk character. Use mathx.mul and mathx.sq.
"""
import numpy as np
from scipy import linalg as sla

from mathx import mul, sq


# ----------------------------------------------------------------------------
# PCA
# ----------------------------------------------------------------------------
def _col_chunks(d, chunk):
    for c0 in range(0, d, chunk):
        yield c0, min(d, c0 + chunk)


def pca_fit(X_train, k, chunk_cols=2048):
    """Exact top-k PCA of X_train (n, d). X_train may be a np.memmap.

    Returns dict with mean (d,), V (d, k) orthonormal columns ordered by
    decreasing variance, evr (k,) explained variance ratio of the TOTAL train
    variance, total_var, eigvals (k,).
    """
    n, d = X_train.shape
    k = int(min(k, d, n - 1))
    mean = np.zeros(d, dtype=np.float64)
    for c0, c1 in _col_chunks(d, chunk_cols):
        mean[c0:c1] = np.asarray(X_train[:, c0:c1], dtype=np.float64).mean(axis=0)
    denom = float(n - 1)
    if d <= n:
        Xc = np.asarray(X_train, dtype=np.float64) - mean[None, :]
        C = np.divide(Xc.T @ Xc, denom)
        C = np.multiply(0.5, C + C.T)
        lam, U = sla.eigh(C, subset_by_index=[d - k, d - 1])
        order = np.argsort(lam)[::-1]
        lam = lam[order]
        V = U[:, order]
        total_var = float(np.trace(C))
        eig_k = lam
    else:
        G = np.zeros((n, n), dtype=np.float64)
        for c0, c1 in _col_chunks(d, chunk_cols):
            blk = np.asarray(X_train[:, c0:c1], dtype=np.float64) - mean[None, c0:c1]
            G += blk @ blk.T
        G = np.multiply(0.5, G + G.T)
        total_var = float(np.divide(np.trace(G), denom))
        lam_g, U = sla.eigh(G, subset_by_index=[n - k, n - 1])
        order = np.argsort(lam_g)[::-1]
        lam_g = lam_g[order]
        U = U[:, order]
        V = np.zeros((d, k), dtype=np.float64)
        scale = np.sqrt(np.maximum(lam_g, 1e-300))
        for c0, c1 in _col_chunks(d, chunk_cols):
            blk = np.asarray(X_train[:, c0:c1], dtype=np.float64) - mean[None, c0:c1]
            V[c0:c1, :] = np.divide(blk.T @ U, scale[None, :])
        eig_k = np.divide(lam_g, denom)
    # deterministic sign: largest absolute loading positive
    for j in range(V.shape[1]):
        i = int(np.argmax(np.abs(V[:, j])))
        if V[i, j] < 0:
            V[:, j] = -V[:, j]
    evr = np.divide(eig_k, total_var)
    return {"mean": mean, "V": V, "evr": evr, "total_var": total_var, "eigvals": eig_k}


def pca_project(X, fit, chunk_cols=2048):
    """Project X (m, d) with a fit returned by pca_fit -> (m, k)."""
    m, d = X.shape
    k = fit["V"].shape[1]
    out = np.zeros((m, k), dtype=np.float64)
    for c0, c1 in _col_chunks(d, chunk_cols):
        blk = np.asarray(X[:, c0:c1], dtype=np.float64) - fit["mean"][None, c0:c1]
        out += blk @ fit["V"][c0:c1, :]
    return out


def pca_fit_project_sklearn(E_train, E_test, k=64):
    """Exactly what the published pipeline did: sklearn PCA(n_components=k, random_state=0)
    fitted on mean-centered train embeddings, test projected with the same mean.
    For 27648-d inputs sklearn's auto solver is randomized, so this reproduces that choice.
    Returns (Z_test (m, k), evr (k,)).
    """
    from sklearn.decomposition import PCA
    E_train = np.asarray(E_train, dtype=np.float64)
    kk = int(min(k, E_train.shape[0] - 1, E_train.shape[1]))
    mu = E_train.mean(axis=0)
    pca = PCA(n_components=kk, random_state=0).fit(E_train - mu)
    Z = pca.transform(np.asarray(E_test, dtype=np.float64) - mu)
    return Z, np.asarray(pca.explained_variance_ratio_)


# ----------------------------------------------------------------------------
# Covariate residualization
# ----------------------------------------------------------------------------
RESID_MODES = ("raw", "resid_linear", "resid_poly2", "resid_poly2x")


def covariate_design(cov, mode):
    """Design matrix with intercept. cov (n, p) is z-scored on the rows given.

    resid_linear  [1, c1, c2]
    resid_poly2   [1, c1, c2, c1^2, c2^2]          (what the published code ran)
    resid_poly2x  [1, c1, c2, c1^2, c2^2, c1 c2]   (what the appendix text describes)
    """
    cov = np.asarray(cov, dtype=np.float64)
    mu = cov.mean(axis=0, keepdims=True)
    sd = cov.std(axis=0, keepdims=True)
    sd = np.where(sd > 0, sd, 1.0)
    c = np.divide(cov - mu, sd)
    cols = [np.ones((c.shape[0], 1))]
    for j in range(c.shape[1]):
        cols.append(c[:, j:j + 1])
    if mode in ("resid_poly2", "resid_poly2x"):
        for j in range(c.shape[1]):
            cols.append(np.square(c[:, j:j + 1]))
    if mode == "resid_poly2x":
        for j in range(c.shape[1]):
            for l in range(j + 1, c.shape[1]):
                cols.append(mul(c[:, j:j + 1], c[:, l:l + 1]))
    return np.concatenate(cols, axis=1)


def residualize(Z, cov, mode):
    """Residuals of each column of Z after OLS on the covariate design (fit on these rows)."""
    if mode == "raw":
        return np.asarray(Z, dtype=np.float64)
    if mode not in RESID_MODES:
        raise ValueError("unknown residualization mode: " + str(mode))
    D = covariate_design(cov, mode)
    sol = np.linalg.lstsq(D, Z, rcond=None)
    return np.asarray(Z, dtype=np.float64) - D @ sol[0]


# ----------------------------------------------------------------------------
# Gram matrices and the debiased CKA
# ----------------------------------------------------------------------------
def gram_zero_diag(Z):
    """Mean-center columns, scale to unit mean squared row norm, linear Gram, zero diagonal.

    The scale is irrelevant for CKA and only protects against tiny numbers after
    principal components have been removed.
    """
    Zc = np.asarray(Z, dtype=np.float64)
    Zc = Zc - Zc.mean(axis=0, keepdims=True)
    msq = float(np.mean(np.sum(sq(Zc), axis=1)))
    if msq > 0:
        Zc = np.divide(Zc, np.sqrt(msq))
    K = Zc @ Zc.T
    K = np.multiply(0.5, K + K.T)
    np.fill_diagonal(K, 0.0)
    return K


def _weight_moments(W):
    """Per-column moments of multiplicity weights. W is (n, b)."""
    W2 = np.square(W)
    n_ = W.sum(axis=0)
    S2 = W2.sum(axis=0)
    S3 = np.multiply(W2, W).sum(axis=0)
    S4 = np.square(W2).sum(axis=0)
    P2 = np.square(n_) - S2
    P3 = np.power(n_, 3) - mul(3.0, np.multiply(n_, S2)) + mul(2.0, S3)
    P4 = (np.power(n_, 4) - mul(6.0, np.multiply(np.square(n_), S2)) + mul(3.0, np.square(S2))
          + mul(8.0, np.multiply(n_, S3)) - mul(6.0, S4))
    return W2, P2, P3, P4


def hsic_weighted_terms(N2, B12, B22, SA, SB, cw2, cw1, P2, P3, P4):
    """Exact debiased HSIC of a multiset (copies of one complex never pair with each other).

    HSIC = N2 / P2 + N4 / P4 - 2 N3 / P3 with
      N2 = sum_{i!=j} w_i w_j K_ij L_ij
      N3 = sum_{i,j,q distinct} w_i w_j w_q K_ij L_iq        = cw1 - B12
      N4 = sum_{i,j,q,r distinct} w_i w_j w_q w_r K_ij L_qr  = SA SB - 4 cw2 + 2 B22
    where SA = w'K w, SB = w'L w, cw2 = sum_i w_i^2 (K w)_i (L w)_i,
    cw1 = sum_i w_i (K w)_i (L w)_i, B12 = sum_{i!=j} w_i w_j^2 K_ij L_ij,
    B22 = sum_{i!=j} w_i^2 w_j^2 K_ij L_ij.  With all weights one this equals the
    Song et al. (2012) unbiased estimator, which is also what the published pipeline uses.
    """
    N3 = cw1 - B12
    N4 = np.multiply(SA, SB) - mul(4.0, cw2) + mul(2.0, B22)
    return np.divide(N2, P2) + np.divide(N4, P4) - np.divide(mul(2.0, N3), P3)


class GramBank:
    """Holds zero-diagonal Gram matrices and computes weighted debiased CKA.

    This uses the same exact weighted estimator as the published pipeline
    (alignlib.cka_feature_w): sums run over distinct complexes, every term is
    normalised by the weighted count of distinct pairs, triples and quadruples.
    Centering is not needed because the unbiased estimator ignores additive
    row and column terms (checked in tests).
    """

    def __init__(self, grams):
        self.g = grams
        first = next(iter(grams.values()))
        self.n = first.shape[0]
        self._buf = np.zeros((self.n, self.n), dtype=np.float64)

    def names(self):
        return list(self.g.keys())

    def _pair_terms(self, Ka, Kb, W, W2):
        np.multiply(Ka, Kb, out=self._buf)
        KLW = self._buf @ W
        KLW2 = self._buf @ W2
        N2 = np.einsum("ib,ib->b", W, KLW)
        B12 = np.einsum("ib,ib->b", W2, KLW)
        B22 = np.einsum("ib,ib->b", W2, KLW2)
        return N2, B12, B22

    def cka_table(self, pairs, M, chunk=256):
        """CKA for each pair under each weight column. M is (n, B). Returns (B, n_pairs)."""
        n, B = M.shape
        if n != self.n:
            raise ValueError("weight matrix has wrong number of rows")
        used = sorted(set([x for p in pairs for x in p]))
        out = np.full((B, len(pairs)), np.nan, dtype=np.float64)
        for c0 in range(0, B, chunk):
            W = np.ascontiguousarray(M[:, c0:c0 + chunk])
            nb = W.shape[1]
            W2, P2, P3, P4 = _weight_moments(W)
            bad = (np.minimum(np.minimum(P2, P3), P4) <= 1e-9)
            KW, SW, H = {}, {}, {}
            for a in used:
                Ka = self.g[a]
                sA = Ka @ W
                SA = np.einsum("ib,ib->b", W, sA)
                N2, B12, B22 = self._pair_terms(Ka, Ka, W, W2)
                cw2 = np.einsum("ib,ib,ib->b", W2, sA, sA)
                cw1 = np.einsum("ib,ib,ib->b", W, sA, sA)
                KW[a], SW[a] = sA, SA
                H[a] = hsic_weighted_terms(N2, B12, B22, SA, SA, cw2, cw1, P2, P3, P4)
            for j, (a, b) in enumerate(pairs):
                N2, B12, B22 = self._pair_terms(self.g[a], self.g[b], W, W2)
                cw2 = np.einsum("ib,ib,ib->b", W2, KW[a], KW[b])
                cw1 = np.einsum("ib,ib,ib->b", W, KW[a], KW[b])
                hab = hsic_weighted_terms(N2, B12, B22, SW[a], SW[b], cw2, cw1, P2, P3, P4)
                prod_self = np.multiply(H[a], H[b])
                ok = (prod_self > 0) & (~bad)
                den = np.sqrt(np.where(ok, prod_self, 1.0))
                out[c0:c0 + nb, j] = np.where(ok, np.divide(hab, den), np.nan)
        return out

    def cka_point(self, pairs):
        """CKA for each pair on the full sample (all weights one). Returns (n_pairs,)."""
        M = np.ones((self.n, 1), dtype=np.float64)
        return self.cka_table(pairs, M, chunk=1)[0]


# ----------------------------------------------------------------------------
# Bootstrap weights
# ----------------------------------------------------------------------------
def cluster_inverse(labels):
    """Map arbitrary cluster labels to 0..G-1. Returns (inverse index, G)."""
    uniq, inv = np.unique(np.asarray(labels), return_inverse=True)
    return inv.astype(np.int64), int(len(uniq))


def iter_weights(kind, inv, G, B, chunk, seed):
    """Yield (b0, M) with M (n, nb) multiplicity weights. Reproducible per chunk.

    kind = cluster: resample whole clusters with replacement (each complex of a
    drawn cluster is included once per draw of that cluster).
    kind = complex: resample complexes with replacement.
    """
    n = len(inv)
    for b0 in range(0, B, chunk):
        nb = min(chunk, B - b0)
        rng = np.random.default_rng([int(seed), int(b0)])
        M = np.zeros((n, nb), dtype=np.float64)
        for j in range(nb):
            if kind == "cluster":
                draw = rng.integers(0, G, size=G)
                counts = np.bincount(draw, minlength=G).astype(np.float64)
                M[:, j] = counts[inv]
            elif kind == "complex":
                draw = rng.integers(0, n, size=n)
                M[:, j] = np.bincount(draw, minlength=n).astype(np.float64)
            else:
                raise ValueError("kind must be cluster or complex")
        yield b0, M


# ----------------------------------------------------------------------------
# Reference implementations for tests only (slow, direct from the definition)
# ----------------------------------------------------------------------------
def brute_force_hsic_weighted(K, L, w):
    """Direct enumeration over DISTINCT index tuples with weights. Tiny n only."""
    import itertools
    n = K.shape[0]
    K0 = np.array(K, dtype=np.float64)
    L0 = np.array(L, dtype=np.float64)
    np.fill_diagonal(K0, 0.0)
    np.fill_diagonal(L0, 0.0)
    idx = [i for i in range(n) if w[i] > 0]
    N2 = P2 = N3 = P3 = N4 = P4 = 0.0
    for i, j in itertools.permutations(idx, 2):
        wt = mul(w[i], w[j])
        N2 += mul(wt, mul(K0[i, j], L0[i, j]))
        P2 += wt
    for i, j, q in itertools.permutations(idx, 3):
        wt = mul(mul(w[i], w[j]), w[q])
        N3 += mul(wt, mul(K0[i, j], L0[i, q]))
        P3 += wt
    for i, j, q, r in itertools.permutations(idx, 4):
        wt = mul(mul(w[i], w[j]), mul(w[q], w[r]))
        N4 += mul(wt, mul(K0[i, j], L0[q, r]))
        P4 += wt
    return N2 / P2 + N4 / P4 - mul(2.0, N3 / P3)


def brute_force_cka_weighted(Za, Zb, w):
    """Weighted debiased CKA from the definition, features -> centered Grams."""
    Ka = gram_zero_diag(Za)
    Kb = gram_zero_diag(Zb)
    hab = brute_force_hsic_weighted(Ka, Kb, w)
    haa = brute_force_hsic_weighted(Ka, Ka, w)
    hbb = brute_force_hsic_weighted(Kb, Kb, w)
    return hab / np.sqrt(mul(haa, hbb))
