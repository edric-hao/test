#!/usr/bin/env python
"""r2_c2_sizecorr_analysis.py  --  CPU box. Alignment of networks trained on the size-corrected target (tags sc1 and up).

Design: trained = the sc networks of every architecture (ceilings from sc seeds), floors = the untrained references (they do not
depend on the target). The analysis is the round 1 seed-aware analysis (raw, linear and quadratic residualization, cluster and
two-level bootstrap). It also reports mean CKA between regimes (original target versus size-corrected target).

Output: results/sizecorr_alignment.json, report/sizecorr_alignment.md
"""
import argparse

import numpy as np

import alignlib2 as al
import common as C
import engine as eg
import r2lib as R


def regime_cka(cfg, orig_tags, sc_tags, Zmap, cov, modes):
    names = {}
    for arch in cfg["archs"]:
        names[(arch, "orig")] = ["%s/%s" % (arch, t) for t in orig_tags[arch]]
        names[(arch, "sc")] = ["%s/%s" % (arch, t) for t in sc_tags.get(arch, [])]
    allnets = sorted(set(n for v in names.values() for n in v))
    out = {}
    for mode in modes:
        grams = {nm: al.gram_zero_diag(al.residualize(Zmap[nm], cov, mode)) for nm in allnets}
        bank = al.GramBank(grams)

        def mean_between(g1, g2, same):
            pairs = []
            for i, x in enumerate(names[g1]):
                for j, y in enumerate(names[g2]):
                    if x == y or (same and j <= i):
                        continue
                    pairs.append(eg.canon(x, y))
            pairs = list(dict.fromkeys(pairs))
            if not pairs:
                return None
            return float(np.mean(bank.cka_point(pairs)))
        rec = {}
        for arch in cfg["archs"]:
            rec["%s within orig" % arch] = mean_between((arch, "orig"), (arch, "orig"), True)
            rec["%s within sc" % arch] = mean_between((arch, "sc"), (arch, "sc"), True)
            rec["%s orig vs sc" % arch] = mean_between((arch, "orig"), (arch, "sc"), False)
        for (A, B) in cfg["arch_pairs"]:
            rec["%s x %s orig" % (A, B)] = mean_between((A, "orig"), (B, "orig"), False)
            rec["%s x %s sc" % (A, B)] = mean_between((A, "sc"), (B, "sc"), False)
            rec["%s x %s orig vs sc" % (A, B)] = mean_between((A, "orig"), (B, "sc"), False)
        out[mode] = rec
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--n_boot", type=int, default=None, help="override draws (smoke tests only)")
    a = ap.parse_args()
    cfg = R.load_cfg2()
    C.ensure_dirs(cfg)
    C.verify_lock(cfg)
    an = cfg["analysis"]
    n_boot = int(a.n_boot if a.n_boot is not None else an["n_boot"])
    core = C.core_ids(cfg)
    cov = C.load_covariates(cfg, core)
    clusters = C.load_clusters(cfg, core)
    man = R.manifest2(cfg, "sizecorr_manifest.json")
    failed = R.failed_in(man)
    sc_tags = {}
    for arch, tags in cfg["sizecorr"]["tags"].items():
        sc_tags[arch] = [t for t in tags if R.have_proj(cfg, arch, t)]
    short = [arch for arch, t in sc_tags.items() if len(t) < 2]
    if short:
        raise SystemExit("need at least two size-corrected networks with projections for %s. Run r2_g2 and r2_c0 first." % short)
    out = dict(stamp=C.stamp(), n_boot=n_boot, failed=failed, label="added_after_review_round2")

    def run(include_failed):
        trained = {arch: [t for t in tags if include_failed or t not in failed.get(arch, [])]
                   for arch, tags in sc_tags.items()}
        design = R.make_design(cfg, trained, which=tuple(an["floor_sets"]))
        Zmap = R.zmap_for(cfg, design)
        return trained, R.run_engine(cfg, Zmap, cov, clusters, design, an["modes"], n_boot)

    trained, res = run(False)
    out["trained"] = trained
    out["results"] = res
    if any(failed.values()):
        t2, r2 = run(True)
        out["with_failed"] = dict(trained=t2, results=r2)
    r1 = R.round1_trained(cfg)
    allZ = {}
    for arch in cfg["archs"]:
        for t in r1[arch]:
            allZ["%s/%s" % (arch, t)] = R.load_Z(cfg, arch, t)
        for t in sc_tags[arch]:
            allZ["%s/%s" % (arch, t)] = R.load_Z(cfg, arch, t)
    out["regime_cka"] = regime_cka(cfg, r1, sc_tags, allZ, cov, ["raw", "resid_linear"])
    C.json_dump(out, cfg["_out"] / "results" / "sizecorr_alignment.json")

    lines = ["# Size-corrected target (added after review, round 2)", "",
             "Networks are trained on y minus a size function fitted on the training split only. Trained networks: " + str(trained),
             "Gate failures (reported, not retrained): " + str(failed if failed else "none"), ""]
    perf = []
    for key, rec in sorted(man.items()):
        perf.append([key, rec.get("seed"), R.fnum(rec.get("val_pearson_r_corrected")), R.fnum(rec.get("test_pearson_r_corrected")),
                     R.fnum(rec.get("test_pearson_r_raw")), R.fnum(rec.get("size_only_test_r_raw")),
                     "pass" if rec.get("gate_pass") else "FAIL"])
    if perf:
        lines.append("## Accuracy")
        lines.append(R.md_table(["network", "seed", "val r (corrected)", "test r (corrected)", "test r (raw, size added back)",
                                 "size-only test r (raw)", "gate"], perf))
        lines.append("")
    lines.append("## Normalized alignment of size-corrected networks (floor set orig)")
    lines.append(R.md_table(R.SUMMARY_HEADERS, R.summarize_pairs(res, an["modes"], "orig", ("seed_min", "seed_geo"))))
    lines.append("")
    rows = []
    for mode, rec in out["regime_cka"].items():
        for k, v in rec.items():
            rows.append([mode, k, R.fnum(v)])
    lines.append("## Mean CKA between regimes")
    lines.append(R.md_table(["mode", "comparison", "mean CKA"], rows))
    R.write_report(cfg, "sizecorr_alignment", "\n".join(lines) + "\n")


if __name__ == "__main__":
    main()
