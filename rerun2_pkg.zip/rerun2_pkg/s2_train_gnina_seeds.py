#!/usr/bin/env python
"""s2_train_gnina_seeds.py  --  GPU box. Train extra GNINA seeds (random init), gate them, extract embeddings.

Same logic as s1 for the graph models. Extraction is float64 on the layer input of the pose output (dim 27648).
A failed validation gate is recorded and the seed is never retrained.

Usage
  python s2_train_gnina_seeds.py
  python s2_train_gnina_seeds.py --tags seed3
  python s2_train_gnina_seeds.py --extract_device cpu        (the device the original extraction used; much slower)
  python s2_train_gnina_seeds.py --skip_selftest             (not recommended)
"""
import argparse
import hashlib

import numpy as np

import common as C


def finite_and_varied(npy, n_check=2000):
    E = np.load(npy, mmap_mode="r")
    sub = np.asarray(E[:n_check], dtype=np.float64)
    return bool(np.isfinite(sub).all()), bool((sub.std(axis=0) > 0).any())


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--tags", nargs="+", default=None)
    ap.add_argument("--extract_device", default=None)
    ap.add_argument("--skip_selftest", action="store_true")
    a = ap.parse_args()

    cfg = C.load_cfg()
    C.ensure_dirs(cfg)
    C.verify_lock(cfg)
    import gnina_lib as GL
    ctx = GL.GninaContext(cfg, extract_device=a.extract_device)
    C.log("train device %s, extraction device %s" % (ctx.device, ctx.extract_device))
    selftest = {}
    if not a.skip_selftest:
        selftest = ctx.selftest()
        C.json_dump(selftest, cfg["_out"] / "results" / "gnina_selftest_seeds.json")

    tags = a.tags or [t for t in C.trained_tags(cfg) if t not in ("primary", "anchor")]
    seeds = cfg["seeds"]["new_seed_values"]
    manifest = C.read_new_seed_manifest(cfg)
    sha_path = cfg["_out"] / "results" / "embeddings_manifest_rerun.json"
    sha_manifest = C.json.loads(sha_path.read_text()) if sha_path.exists() else {}

    mu = ctx.load_saved_untrained("untrained")
    vm_u = ctx.evaluate(mu, "val")
    del mu
    C.log("[gnina] untrained validation r = %.3f" % vm_u["pearson_r"])

    for tag in tags:
        key = "gnina/%s" % tag
        have_all = all(C.emb_paths(cfg, "gnina", tag, sp)[0].exists() for sp in ("train", "val", "test"))
        if key in manifest and have_all:
            C.log("[%s] already trained and extracted; skipping" % key)
            continue
        seed = int(seeds[tag])
        C.log("[%s] training with seed %d" % (key, seed))
        model, info = ctx.train_gnina(seed, tag)
        model = model.to(ctx.device)
        vm = ctx.evaluate(model, "val")
        tm = ctx.evaluate(model, "test")
        ok = bool(vm["pearson_r"] >= float(cfg["gate"]["min_val_pearson"])
                  and (vm["pearson_r"] - vm_u["pearson_r"]) >= float(cfg["gate"]["min_margin_over_untrained"]))
        hist = info.get("history", [])
        best_epoch = int(min(hist, key=lambda h: h["val_loss"])["epoch"]) if hist else None
        C.log("[%s] val r=%.3f (untrained %.3f) test r=%.3f  GATE %s"
              % (key, vm["pearson_r"], vm_u["pearson_r"], tm["pearson_r"], "PASS" if ok else "FAIL"))
        del model
        outs = ctx.extract_tag(tag)
        health = {}
        for sp, npy in outs.items():
            fin, var = finite_and_varied(npy)
            E = np.load(npy, mmap_mode="r")
            sha_manifest["%s/%s" % (key, sp)] = dict(
                shape=list(E.shape), sha256=C.sha256_file(npy), npy=str(npy.relative_to(cfg["_root"])),
                extract_device=str(ctx.extract_device))
            health[sp] = dict(finite=fin, varied=var)
            if not (fin and var):
                C.log("WARNING: %s/%s embeddings are non-finite or constant" % (key, sp))
        manifest[key] = dict(arch="gnina", tag=tag, seed=seed, best_epoch=best_epoch,
                             val_pearson_r=vm["pearson_r"], val_rmse=vm["rmse"], val_loss=vm["val_loss"],
                             test_pearson_r=tm["pearson_r"], test_rmse=tm["rmse"],
                             untrained_val_pearson_r=vm_u["pearson_r"], gate_pass=ok, health=health)
        C.json_dump(manifest, C.new_seed_manifest_path(cfg))
        C.json_dump(sha_manifest, sha_path)
    C.json_dump(manifest, C.new_seed_manifest_path(cfg))
    fails = [k for k, v in manifest.items() if not v["gate_pass"]]
    C.log("done. gate failures (reported, not retrained): %s" % (fails if fails else "none"))


if __name__ == "__main__":
    main()
