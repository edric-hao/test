#!/usr/bin/env python
"""s1_train_gnn_seeds.py  --  GPU box. Train extra EGNN and Distance-GNN seeds, gate them, extract embeddings.

What it does for each architecture and each new seed tag in config_rerun.yaml (seed3, seed4, seed5):
  1. trains with the project's own loop (same model class, hyperparameters, early stopping on validation loss),
  2. applies the validation gate (r >= 0.4 and r exceeds the untrained network by at least 0.10),
  3. extracts float64 embeddings for train, val, test exactly as run_t3_anchors.py did,
  4. writes results/new_seed_manifest.json (gate result, seed, best epoch, validation and test metrics).
A failed gate is recorded and the seed is NEVER retrained.

Before anything is trained a self test proves that this code reproduces your saved untrained and primary models.

Usage
  python s1_train_gnn_seeds.py
  python s1_train_gnn_seeds.py --archs egnn --tags seed3 seed4 seed5
  python s1_train_gnn_seeds.py --skip_selftest        (not recommended)
"""
import argparse
import hashlib
import json

import numpy as np

import common as C


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--archs", nargs="+", default=["egnn", "distance_gnn"])
    ap.add_argument("--tags", nargs="+", default=None)
    ap.add_argument("--skip_selftest", action="store_true")
    a = ap.parse_args()

    cfg = C.load_cfg()
    C.ensure_dirs(cfg)
    C.verify_lock(cfg)
    import gnn_lib as G
    ctx = G.GnnContext(cfg)
    C.log("device: %s" % ctx.device)
    if not a.skip_selftest:
        ctx.selftest(a.archs)
    tags = a.tags or [t for t in C.trained_tags(cfg) if t not in ("primary", "anchor")]
    seeds = cfg["seeds"]["new_seed_values"]
    manifest = C.read_new_seed_manifest(cfg)
    emb = C.emb_dir(cfg)
    emb.mkdir(parents=True, exist_ok=True)
    sha_manifest_path = cfg["_out"] / "results" / "embeddings_manifest_rerun.json"
    sha_manifest = json.loads(sha_manifest_path.read_text()) if sha_manifest_path.exists() else {}
    val_loader = ctx.loader(ctx.ids["val"], 32, False)
    test_loader = ctx.loader(ctx.ids["test"], 32, False)

    for arch in a.archs:
        mu, _ = ctx.load_checkpoint_model(arch, "untrained")
        vm_u = ctx.evaluate(mu, val_loader)
        C.log("[%s] untrained validation r = %.3f" % (arch, vm_u["pearson_r"]))
        for tag in tags:
            key = "%s/%s" % (arch, tag)
            have_all = all(C.emb_paths(cfg, arch, tag, sp)[0].exists() for sp in ("train", "val", "test"))
            if key in manifest and have_all:
                C.log("[%s] already trained and extracted; skipping" % key)
                continue
            seed = int(seeds[tag])
            C.log("[%s] training with seed %d" % (key, seed))
            model, info = ctx.train_one(arch, seed, tag)
            model = model.to(ctx.device)
            vm = ctx.evaluate(model, val_loader)
            tm = ctx.evaluate(model, test_loader)
            ok = ctx.gate(arch, vm["pearson_r"], vm_u["pearson_r"])
            hist = info.get("history", [])
            best_epoch = int(min(hist, key=lambda h: h["val_loss"])["epoch"]) if hist else None
            C.log("[%s] val r=%.3f (untrained %.3f) test r=%.3f  GATE %s"
                  % (key, vm["pearson_r"], vm_u["pearson_r"], tm["pearson_r"], "PASS" if ok else "FAIL"))
            health = {}
            for sp in ("train", "val", "test"):
                E, ids_order = ctx.extract_ids(arch, model, ctx.ids[sp])
                if ids_order != ctx.ids[sp]:
                    raise SystemExit("%s/%s: extracted id order differs from the original id order" % (key, sp))
                npy, idsf = C.emb_paths(cfg, arch, tag, sp)
                np.save(npy, E)
                idsf.write_text("\n".join(ids_order))
                sha_manifest["%s/%s" % (key, sp)] = dict(
                    shape=list(E.shape), sha256=hashlib.sha256(E.tobytes()).hexdigest(),
                    npy=str(npy.relative_to(cfg["_root"])), extract_device="cpu_float64")
                if sp == "test":
                    cov_cols = list(cfg["data"]["covariate_cols"])
                    Zc = ctx.split.loc[ids_order, cov_cols].to_numpy()
                    health = ctx.eu.embedding_sanity(E, Zc)
                C.log("  %s/%s extracted %s" % (key, sp, E.shape))
            manifest[key] = dict(arch=arch, tag=tag, seed=seed, best_epoch=best_epoch,
                                 val_pearson_r=vm["pearson_r"], val_rmse=vm["rmse"], val_loss=vm["val_loss"],
                                 test_pearson_r=tm["pearson_r"], test_rmse=tm["rmse"],
                                 untrained_val_pearson_r=vm_u["pearson_r"], gate_pass=ok,
                                 health_test=health)
            C.json_dump(manifest, C.new_seed_manifest_path(cfg))
            C.json_dump(sha_manifest, sha_manifest_path)
    C.json_dump(manifest, C.new_seed_manifest_path(cfg))
    fails = [k for k, v in manifest.items() if not v["gate_pass"]]
    C.log("done. gate failures (reported, not retrained): %s" % (fails if fails else "none"))


if __name__ == "__main__":
    main()
