"""Shared I/O helpers for the rerun package. No asterisks anywhere in this package."""
import datetime as dt
import hashlib
import json
import os
import sys
from pathlib import Path

import numpy as np
import pandas as pd
import yaml

from mathx import mul

PKG_DIR = Path(__file__).resolve().parent
if str(PKG_DIR) not in sys.path:
    sys.path.insert(0, str(PKG_DIR))


# ----------------------------------------------------------------------------
# configuration
# ----------------------------------------------------------------------------
def load_cfg(path=None):
    """Load config_rerun.yaml and resolve the project root and output directory."""
    if not path and os.environ.get("RERUN_CONFIG"):
        path = os.environ["RERUN_CONFIG"]      # used only by the synthetic smoke tests
    path = Path(path) if path else PKG_DIR / "config_rerun.yaml"
    cfg = yaml.safe_load(path.read_text())
    root = Path(os.environ.get("PROJECT_ROOT", cfg["paths"]["project_root"])).resolve()
    cfg["_root"] = root
    cfg["_cfg_path"] = path
    out = root / cfg["paths"]["out_dir"]
    cfg["_out"] = out
    pdb = os.environ.get("PDBBIND_DIR", cfg["paths"].get("pdbbind_dir", ""))
    cfg["_pdbbind_dir"] = Path(pdb) if pdb else None
    return cfg


def ensure_dirs(cfg):
    for sub in ("", "proj", "results", "figures", "logs", "checkpoints", "types"):
        (cfg["_out"] / sub).mkdir(parents=True, exist_ok=True)


def emb_dir(cfg):
    return cfg["_root"] / "data" / "embeddings"


def ckpt_dir(cfg):
    return cfg["_root"] / "data" / "checkpoints"


def load_original_cfg(cfg):
    return yaml.safe_load((cfg["_root"] / cfg["paths"]["original_config"]).read_text())


def sha256_file(path, block=1 << 20):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(block), b""):
            h.update(chunk)
    return h.hexdigest()


def utc_now():
    return dt.datetime.now(dt.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


# ----------------------------------------------------------------------------
# pre-registration lock for the rerun
# ----------------------------------------------------------------------------
def lock_path(cfg):
    return cfg["_out"] / "PREREG_RERUN_LOCK.json"


def verify_lock(cfg, allow_missing=False):
    """Abort if config_rerun.yaml changed after it was locked."""
    lp = lock_path(cfg)
    if not lp.exists():
        if allow_missing:
            return None
        raise SystemExit("No rerun lock found. Run s0_lock_and_checks.py first (it hashes config_rerun.yaml).")
    lock = json.loads(lp.read_text())
    now = sha256_file(cfg["_cfg_path"])
    if now != lock["config_rerun_sha256"]:
        raise SystemExit("config_rerun.yaml changed after the lock (%s vs %s). "
                         "Revert it, or relock deliberately with s0_lock_and_checks.py --relock 'reason'."
                         % (now[:12], lock["config_rerun_sha256"][:12]))
    return lock


def code_hashes():
    out = {}
    for p in sorted(PKG_DIR.iterdir()):
        if p.suffix in (".py", ".sh", ".yaml", ".txt"):
            out[p.name] = sha256_file(p)
    return out


# ----------------------------------------------------------------------------
# json
# ----------------------------------------------------------------------------
def _default(o):
    if isinstance(o, np.generic):
        return o.item()
    if isinstance(o, np.ndarray):
        return o.tolist()
    if isinstance(o, Path):
        return str(o)
    raise TypeError("not serializable: " + str(type(o)))


def json_dump(obj, path):
    path = Path(path)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(obj, indent=2, default=_default, allow_nan=True))
    os.replace(tmp, path)


def save_npz(path, arrays):
    """Write a dict of arrays as a compressed .npz without keyword unpacking."""
    import io
    import zipfile
    path = Path(path)
    tmp = path.with_suffix(".tmp")
    with zipfile.ZipFile(tmp, "w", zipfile.ZIP_DEFLATED) as zf:
        for k, v in arrays.items():
            buf = io.BytesIO()
            np.lib.format.write_array(buf, np.asarray(v), allow_pickle=False)
            zf.writestr(str(k) + ".npy", buf.getvalue())
    os.replace(tmp, path)


def stamp(extra=None):
    d = {"label": "added_after_review", "written_utc": utc_now(), "code_sha256": code_hashes()}
    if extra:
        d.update(extra)
    return d


# ----------------------------------------------------------------------------
# data access
# ----------------------------------------------------------------------------
def read_ids(path):
    ids = []
    for line in Path(path).read_text().splitlines():
        line = line.strip()
        if not line:
            continue
        ids.append(line.split("\t")[0])
    return ids


def emb_paths(cfg, arch, tag, split):
    d = emb_dir(cfg)
    return d / (arch + "_" + tag + "_" + split + ".npy"), d / (arch + "_" + tag + "_" + split + "_ids.txt")


def have_embeddings(cfg, arch, tag, splits=("train", "test")):
    for sp in splits:
        npy, ids = emb_paths(cfg, arch, tag, sp)
        if not (npy.exists() and ids.exists()):
            return False
    return True


def core_ids(cfg):
    """Sorted test ids, exactly as the published pipeline built its core set."""
    npy, idsf = emb_paths(cfg, "egnn", "primary", "test")
    ids = sorted(read_ids(idsf))
    n_exp = int(cfg["data"]["n_core_expected"])
    if len(ids) != n_exp:
        raise SystemExit("core set has %d complexes, expected %d" % (len(ids), n_exp))
    return ids


def strict_subset(E, ids, core, name=""):
    """Rows of E in core order. Fails loudly on any id problem."""
    ids = list(ids)
    if len(ids) != E.shape[0]:
        raise SystemExit("%s: %d ids vs %d rows" % (name, len(ids), E.shape[0]))
    if len(set(ids)) != len(ids):
        raise SystemExit("%s: duplicate ids" % name)
    rev = {p: i for i, p in enumerate(ids)}
    missing = [p for p in core if p not in rev]
    if missing:
        raise SystemExit("%s: %d core ids missing, e.g. %s" % (name, len(missing), missing[:3]))
    return E[[rev[p] for p in core]]


def load_covariates(cfg, core):
    df = pd.read_csv(cfg["_root"] / "data" / "covariates.tsv", sep="\t", index_col=0)
    df.index = df.index.astype(str).str.lower()
    cols = list(cfg["data"]["covariate_cols"])
    for c in cols:
        if c not in df.columns:
            raise SystemExit("covariate column missing: " + c)
    miss = [p for p in core if p not in df.index]
    if miss:
        raise SystemExit("%d core complexes lack covariates, e.g. %s" % (len(miss), miss[:3]))
    cov = df.loc[[p.lower() for p in core], cols].to_numpy(dtype=np.float64)
    if not np.isfinite(cov).all():
        raise SystemExit("non-finite covariates among core complexes")
    sd = cov.std(axis=0)
    cov = np.divide(cov - cov.mean(axis=0), np.where(sd > 0, sd, 1.0))
    return cov


def load_clusters(cfg, core):
    """Cluster label per core complex; unclustered complexes become singleton clusters."""
    df = pd.read_csv(cfg["_root"] / "data" / "clusters.tsv", sep="\t", index_col=0)
    col = cfg["data"]["cluster_col"]
    if col not in df.columns:
        raise SystemExit("cluster column %s not in clusters.tsv (columns: %s)" % (col, list(df.columns)))
    lab = {str(k).lower(): int(v) for k, v in df[col].items()}
    g = np.array([lab.get(str(p).lower(), -1) for p in core], dtype=np.int64)
    neg = g < 0
    n_unc = int(neg.sum())
    if n_unc > mul(0.02, len(core)):
        raise SystemExit("%d core complexes have no cluster label (more than 2 percent)" % n_unc)
    if neg.any():
        start = int(g.max()) + 1
        g[neg] = start + np.arange(int(neg.sum()))
    return g


def split_table(cfg):
    orig = load_original_cfg(cfg)
    df = pd.read_csv(cfg["_root"] / orig["split"]["file"], sep="\t", index_col=0)
    df.index = df.index.astype(str).str.lower()
    return df, orig


def ligand_size(cfg, core):
    """Raw ligand heavy atom count per core complex, from the frozen split table."""
    df, _ = split_table(cfg)
    return df.loc[[p.lower() for p in core], "ligand_heavy_atom_count"].to_numpy(dtype=np.float64)


# ----------------------------------------------------------------------------
# network bookkeeping
# ----------------------------------------------------------------------------
def trained_tags(cfg):
    return list(cfg["seeds"]["trained_tags"])


def floor_tags(cfg, arch, which):
    if which == "orig" or arch != "gnina":
        return list(cfg["floors"]["orig_tags"])
    return list(cfg["floors"]["regen_tags"])


def new_seed_manifest_path(cfg):
    return cfg["_out"] / "results" / "new_seed_manifest.json"


def read_new_seed_manifest(cfg):
    p = new_seed_manifest_path(cfg)
    return json.loads(p.read_text()) if p.exists() else {}


def failed_seed_tags(cfg):
    """Dict arch -> list of new seed tags that failed the validation gate."""
    man = read_new_seed_manifest(cfg)
    out = {}
    for key, rec in man.items():
        if not rec.get("gate_pass", True):
            out.setdefault(rec["arch"], []).append(rec["tag"])
    return out


def log(msg):
    print(dt.datetime.now().strftime("%H:%M:%S") + "  " + str(msg), flush=True)
