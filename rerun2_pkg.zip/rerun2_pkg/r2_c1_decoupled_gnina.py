#!/usr/bin/env python
"""r2_c1_decoupled_gnina.py  --  CPU box. Seed-aware alignment with GNINA seeds whose data streams are decoupled (tags dc1 to dc5).

The EGNN and Distance-GNN networks are the round 1 trained seeds. The GNINA ceiling and the GNINA side of every cross-architecture
CKA come from the decoupled seeds. Everything else (floors, modes, bootstrap, estimators) is the round 1 analysis.
Round 1 numbers are not changed; this is a separate, labeled sensitivity analysis.

Output: results/decoupled_gnina.json, report/decoupled_gnina.md
"""
import argparse

import numpy as np

import common as C
import r2lib as R


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--n_boot", type=int, default=None, help="override draws (smoke tests only)")
    a = ap.parse_args()
    cfg = R.load_cfg2()
    C.ensure_dirs(cfg)
    C.verify_lock(cfg)
    an = cfg["analysis"]
    n_boot = int(a.n_boot if a.n_boot is not None else an["n_boot"])
    core = C.core_ids(cfg)
    cov = C.load_covariates(cfg, core)
    clusters = C.load_clusters(cfg, core)
    man = R.manifest2(cfg, "decoupled_gnina_manifest.json")
    failed = R.failed_in(man)
    have = [t for t in cfg["decoupled_gnina"]["tags"] if R.have_proj(cfg, "gnina", t)]
    if len(have) < 2:
        raise SystemExit("need at least two decoupled GNINA seeds with projections (found %s). Run r2_g1 and r2_c0 first." % have)
    r1 = R.round1_trained(cfg)
    out = dict(stamp=C.stamp(), n_boot=n_boot, failed=failed, label="added_after_review_round2")

    def run(include_failed):
        dc = [t for t in have if include_failed or t not in failed.get("gnina", [])]
        trained = {"egnn": r1["egnn"], "distance_gnn": r1["distance_gnn"], "gnina": dc}
        design = R.make_design(cfg, trained, which=tuple(an["floor_sets"]))
        Zmap = R.zmap_for(cfg, design)
        res = R.run_engine(cfg, Zmap, cov, clusters, design, an["modes"], n_boot)
        return trained, res

    trained, res = run(False)
    out["trained"] = trained
    out["results"] = res
    if any(failed.values()):
        t2, r2 = run(True)
        out["with_failed"] = dict(trained=t2, results=r2)
    C.json_dump(out, cfg["_out"] / "results" / "decoupled_gnina.json")

    # report: decoupled versus coupled (round 1) within-GNINA CKA and normalized alignment
    r1j = R.read_json(cfg["_out1"] / "results" / "seed_analysis.json", default={})
    lines = ["# Decoupled GNINA seeds (added after review, round 2)", "",
             "GNINA seeds dc1 to dc5 use an independent data stream for every (seed, epoch). Round 1 used seed plus epoch.", ""]
    lines.append("Trained networks: " + str(trained) + "  Failed gate: " + str(failed if failed else "none"))
    lines.append("")
    rows = []
    for mode in an["modes"]:
        key = "gnina_x_distance_gnn"
        rec = res[mode][key]["orig"]
        wa = np.array(rec["within_A"], dtype=np.float64)
        iu = np.triu_indices(wa.shape[0], 1)
        d_mean = float(np.nanmean(wa[iu])) if wa.shape[0] > 1 else None
        d_rng = (float(np.nanmin(wa[iu])), float(np.nanmax(wa[iu]))) if wa.shape[0] > 1 else (None, None)
        c_mean = c_rng = None
        try:
            cw = np.array(r1j["results"][mode][key]["orig"]["within_A"], dtype=np.float64)
            ci = np.triu_indices(cw.shape[0], 1)
            c_mean = float(np.nanmean(cw[ci]))
            c_rng = (float(np.nanmin(cw[ci])), float(np.nanmax(cw[ci])))
        except (KeyError, TypeError):
            pass
        rows.append([mode, R.fnum(c_mean), "%s to %s" % (R.fnum(c_rng[0] if c_rng else None), R.fnum(c_rng[1] if c_rng else None)),
                     R.fnum(d_mean), "%s to %s" % (R.fnum(d_rng[0]), R.fnum(d_rng[1]))])
    lines.append("## Same-architecture GNINA CKA (the GNINA ceiling)")
    lines.append(R.md_table(["mode", "coupled mean (round 1)", "coupled range", "decoupled mean", "decoupled range"], rows))
    lines.append("")
    lines.append("## Normalized alignment with decoupled GNINA seeds (floor set orig)")
    lines.append(R.md_table(R.SUMMARY_HEADERS, R.summarize_pairs(res, an["modes"], "orig", ("seed_min", "seed_geo"))))
    lines.append("")
    lines.append("## Same table, floor set regen (rebuilt GNINA floors)")
    rr = R.summarize_pairs(res, an["modes"], "regen", ("seed_min",))
    lines.append(R.md_table(R.SUMMARY_HEADERS, rr) if rr else "regenerated floors not available")
    R.write_report(cfg, "decoupled_gnina", "\n".join(lines) + "\n")


if __name__ == "__main__":
    main()
