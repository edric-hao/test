#!/usr/bin/env python
"""r2_c6_input_deconfound.py  --  CPU box. Deconfounding on input similarity (in the spirit of Cui et al. 2022).

Input similarity of a complex is summarized by features computed from its input graph by r2_g4_input_features.py: node counts, atom-type
counts, radius-graph edge counts and edge-distance histograms (all edges and ligand-pocket edges). Variants of the seed-aware analysis:
  raw          no adjustment
  size_linear  linear residualization on the two size covariates (round 1 analysis)
  input_linear linear residualization on all input features
  input_rbf    kernel conditioning: each Gram matrix K is replaced by R K R with R = eps (K_Z + eps I)^-1, K_Z a centered RBF kernel
               of the standardized input features (median bandwidth), for each eps in config input_deconf.rbf_eps
The question is whether the high CKA between untrained networks (the floor, 0.906 for the two graph models) is explained by input similarity.

Output: results/input_deconfound.json, report/input_deconfound.md
"""
import argparse

import numpy as np
import pandas as pd

import alignlib2 as al
import common as C
import r2lib as R
from mathx import mul


def rbf_conditioner(F, eps):
    n = F.shape[0]
    sq = np.sum(np.square(F), axis=1)
    d2 = np.maximum(sq[:, None] + sq[None, :] - mul(2.0, F @ F.T), 0.0)
    iu = np.triu_indices(n, 1)
    med = float(np.median(np.sqrt(d2[iu])))
    sig2 = mul(med, med) if med > 0 else 1.0
    K = np.exp(-np.divide(d2, mul(2.0, sig2)))
    H = np.eye(n) - np.divide(np.ones((n, n)), n)
    Kc = H @ K @ H
    Rm = np.linalg.solve(Kc + mul(eps, np.eye(n)), mul(eps, np.eye(n)))
    Rm = np.multiply(0.5, Rm + Rm.T)
    return Rm, med


def make_gram_fn(Rm):
    def f(Z):
        Zc = np.asarray(Z, dtype=np.float64)
        Zc = Zc - Zc.mean(axis=0, keepdims=True)
        msq = float(np.mean(np.sum(np.square(Zc), axis=1)))
        if msq > 0:
            Zc = np.divide(Zc, np.sqrt(msq))
        K = Zc @ Zc.T
        K = np.multiply(0.5, K + K.T)
        Kt = Rm @ K @ Rm
        Kt = np.multiply(0.5, Kt + Kt.T)
        np.fill_diagonal(Kt, 0.0)
        return Kt
    return f


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--n_boot", type=int, default=None, help="override draws (smoke tests only)")
    a = ap.parse_args()
    cfg = R.load_cfg2()
    C.ensure_dirs(cfg)
    C.verify_lock(cfg)
    idc = cfg["input_deconf"]
    n_boot = int(a.n_boot if a.n_boot is not None else idc["n_boot"])
    core = C.core_ids(cfg)
    cov = C.load_covariates(cfg, core)
    clusters = C.load_clusters(cfg, core)
    f = cfg["_out"] / "results" / "input_features.tsv"
    if not f.exists():
        raise SystemExit("missing %s (run r2_g4_input_features.py and copy the file here)" % f)
    df = pd.read_csv(f, sep="\t", index_col=0)
    df.index = df.index.astype(str).str.lower()
    miss = [p for p in core if p.lower() not in df.index]
    if miss:
        raise SystemExit("%d core complexes lack input features, e.g. %s" % (len(miss), miss[:3]))
    F = df.loc[[p.lower() for p in core]].to_numpy(dtype=np.float64)
    keep = F.std(axis=0) > 0
    F = R.zscore(F[:, keep])
    cols = [c for c, k in zip(df.columns, keep) if k]
    C.log("input features: %d columns kept of %d" % (F.shape[1], len(keep)))
    trained = R.round1_trained(cfg)
    design = R.make_design(cfg, trained, which=("orig",))
    Zmap = R.zmap_for(cfg, design)

    variants = {}
    variants["raw"] = R.run_engine(cfg, Zmap, cov, clusters, design, ["raw"], n_boot)["raw"]
    variants["size_linear"] = R.run_engine(cfg, Zmap, cov, clusters, design, ["resid_linear"], n_boot)["resid_linear"]
    variants["input_linear"] = R.run_engine(cfg, Zmap, F, clusters, design, ["resid_linear"], n_boot)["resid_linear"]
    meds = {}
    for eps in idc["rbf_eps"]:
        Rm, med = rbf_conditioner(F, float(eps))
        meds[str(eps)] = med
        variants["input_rbf_eps%s" % eps] = R.run_engine(cfg, Zmap, cov, clusters, design, ["raw"], n_boot,
                                                         gram_fn=make_gram_fn(Rm))["raw"]
        C.log("kernel conditioning eps %s done (median distance %.3f)" % (eps, med))

    # how much of each embedding the input features explain linearly
    D_in = R.design_matrix([F])
    share = {}
    for nm in design.nets():
        Z = Zmap[nm]
        Zc = Z - Z.mean(axis=0, keepdims=True)
        share[nm] = 1.0 - float(np.sum(np.square(R.resid_on(Zc, D_in)))) / float(np.sum(np.square(Zc)))
    out = dict(stamp=C.stamp(), label="added_after_review_round2", n_boot=n_boot, n_features=int(F.shape[1]),
               feature_names=cols, rbf_median_distance=meds, variants=variants, input_linear_variance_share=share,
               headline_eps=idc["headline_eps"])
    C.json_dump(out, cfg["_out"] / "results" / "input_deconfound.json")

    lines = ["# Deconfounding on input similarity (added after review, round 2)", "",
             "%d input features (%s)." % (F.shape[1], ", ".join(cols[:6]) + ", ..."), ""]
    rows = []
    for vn, res in variants.items():
        for key in res:
            rec = res[key]["orig"]
            e = rec["estimators"]["seed_min"]
            fl = rec["floors"]
            rows.append([vn, key, R.fnum(float(np.mean(fl))), R.fnum(e.get("obs")), R.fnum(e.get("ceil")), R.fnum(e.get("nab")),
                         R.fci(e.get("ci_complex")), R.fci(e.get("ci_two_level"))])
    lines.append("## Floor (mean untrained CKA), trained CKA, ceiling and n_AB per variant (seed-aware estimator)")
    lines.append(R.md_table(["variant", "pair", "floor", "CKA", "ceiling", "n_AB", "CI (clusters)", "CI (two-level)"], rows))
    lines.append("")
    rows = []
    for arch in cfg["archs"]:
        tr = [share["%s/%s" % (arch, t)] for t in trained[arch]]
        un = [share["%s/%s" % (arch, t)] for t in cfg["floors"]["orig_tags"]]
        rows.append([arch, R.fnum(float(np.mean(tr))), R.fnum(float(np.mean(un)))])
    lines.append("## Variance share of the embedding explained linearly by the input features")
    lines.append(R.md_table(["architecture", "trained (mean)", "untrained (mean)"], rows))
    R.write_report(cfg, "input_deconfound", "\n".join(lines) + "\n")


if __name__ == "__main__":
    main()
