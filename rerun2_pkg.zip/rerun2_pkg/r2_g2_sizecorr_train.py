#!/usr/bin/env python
"""r2_g2_sizecorr_train.py  --  GPU box. Train networks on a size-corrected target, gate them, extract embeddings.

Target. y_corr = y - f(c) + mean(y_train), where f is an ordinary least squares fit on the TRAIN complexes of y on
[1, c1, c2, c1^2, c2^2] (c1, c2 the two size covariates, standardized with train statistics). The same coefficients are applied to the
validation and test complexes. Nothing else changes: architectures, optimizers, early stopping on validation loss and embedding layers are the
project's. GNINA uses decoupled per-epoch data streams.

Gate (config sizecorr.gate): validation Pearson r with the corrected target at least 0.15 and at least 0.10 above the untrained network
evaluated on the same corrected labels. A failed network is recorded and never retrained.

For every network the manifest holds validation and test r with the corrected target, test r with the raw target after adding f(c) back, and
the test r of f(c) alone (the size-only baseline).

Usage
  python r2_g2_sizecorr_train.py                         (all architectures and tags in the config)
  python r2_g2_sizecorr_train.py --archs egnn distance_gnn
  python r2_g2_sizecorr_train.py --archs gnina --tags sc1
Output: results/sizecorr_target.tsv, results/sizecorr_target_fit.json, results/sizecorr_manifest.json, embeddings data/embeddings/ARCH_scN_SPLIT.npy
"""
import argparse

import numpy as np
import pandas as pd

import common as C
import r2lib as R


def build_target(cfg):
    split, orig = C.split_table(cfg)
    aff = orig["split"]["affinity_column"]
    cov = pd.read_csv(cfg["_root"] / "data" / "covariates.tsv", sep="\t", index_col=0)
    cov.index = cov.index.astype(str).str.lower()
    cols = list(cfg["data"]["covariate_cols"])
    ids = [p for p in split.index if p in cov.index]
    sp = split.loc[ids, "split"].to_numpy()
    y = split.loc[ids, aff].to_numpy(dtype=np.float64)
    c = cov.loc[ids, cols].to_numpy(dtype=np.float64)
    tr = sp == "train"
    mu, sd = c[tr].mean(axis=0), c[tr].std(axis=0)
    cz = np.divide(c - mu, np.where(sd > 0, sd, 1.0))

    def design(cz_):
        return np.concatenate([np.ones((len(cz_), 1)), cz_, np.square(cz_)], axis=1)
    D = design(cz)
    beta = np.linalg.lstsq(D[tr], y[tr], rcond=None)[0]
    fit = D @ beta
    corr = y - fit + y[tr].mean()
    res = y[tr] - fit[tr]
    r2 = 1.0 - float(np.sum(np.square(res - res.mean()))) / float(np.sum(np.square(y[tr] - y[tr].mean())))
    rho = float(np.corrcoef(corr[tr], cz[tr, 0])[0, 1]), float(np.corrcoef(corr[tr], cz[tr, 1])[0, 1])
    info = dict(coef=beta.tolist(), train_r2_size=r2, train_corr_target_with_c1_c2=list(rho), n_train=int(tr.sum()),
                train_mean_y=float(y[tr].mean()), cov_mean=mu.tolist(), cov_sd=sd.tolist(), design="[1, c1, c2, c1^2, c2^2]")
    table = pd.DataFrame({"split": sp, "y_raw": y, "y_fit": fit, "y_corr": corr}, index=ids)
    return table, info


def metrics_for(preds, ids, table, split_name):
    t = table.loc[ids]
    pc = np.asarray(preds, dtype=np.float64)
    r_corr = float(np.corrcoef(pc, t["y_corr"].to_numpy())[0, 1])
    raw_pred = pc + t["y_fit"].to_numpy() - float(table.loc[table["split"] == "train", "y_raw"].mean())
    r_raw = float(np.corrcoef(raw_pred, t["y_raw"].to_numpy())[0, 1])
    r_size = float(np.corrcoef(t["y_fit"].to_numpy(), t["y_raw"].to_numpy())[0, 1])
    return r_corr, r_raw, r_size


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--archs", nargs="+", default=None)
    ap.add_argument("--tags", nargs="+", default=None)
    ap.add_argument("--extract_device", default=None)
    ap.add_argument("--skip_selftest", action="store_true")
    a = ap.parse_args()
    cfg = R.load_cfg2()
    C.ensure_dirs(cfg)
    C.verify_lock(cfg)
    sc = cfg["sizecorr"]
    table, info = build_target(cfg)
    table.to_csv(cfg["_out"] / "results" / "sizecorr_target.tsv", sep="\t")
    C.json_dump(info, cfg["_out"] / "results" / "sizecorr_target_fit.json")
    C.log("size fit on train: R2 %.3f; corrected target correlation with c1, c2 on train: %s" %
          (info["train_r2_size"], np.round(info["train_corr_target_with_c1_c2"], 4).tolist()))
    target = {p: float(v) for p, v in table["y_corr"].items()}
    archs = a.archs or list(sc["tags"].keys())
    manifest = R.manifest2(cfg, "sizecorr_manifest.json")
    man_path = cfg["_out"] / "results" / "sizecorr_manifest.json"

    def record(arch, tag, seed, best_epoch, n_ep, vm, vm_u, rc, rr, rs, ok, extra=None):
        rec = dict(arch=arch, tag=tag, seed=seed, best_epoch=best_epoch, n_epochs_run=n_ep,
                   val_pearson_r_corrected=vm["pearson_r"], untrained_val_pearson_r_corrected=vm_u["pearson_r"],
                   test_pearson_r_corrected=rc, test_pearson_r_raw=rr, size_only_test_r_raw=rs, gate_pass=ok)
        if extra:
            rec.update(extra)
        manifest["%s/%s" % (arch, tag)] = rec
        C.json_dump(manifest, man_path)

    gate_cfg = sc["gate"]

    def passes(vr, ur):
        return bool(vr >= float(gate_cfg["min_val_pearson"]) and (vr - ur) >= float(gate_cfg["min_margin_over_untrained"]))

    graph_archs = [x for x in archs if x in ("egnn", "distance_gnn")]
    if graph_archs:
        import gnn_lib as G

        class SizeCorrGnn(G.GnnContext):
            def __init__(self, cfg_, target_):
                self.target = target_
                super().__init__(cfg_)

            def get_graph(self, pid):
                z, x, y = super().get_graph(pid)
                return z, x, float(self.target[pid])
        ctx = SizeCorrGnn(cfg, target)
        C.log("device: %s" % ctx.device)
        val_loader = ctx.loader(ctx.ids["val"], 32, False)
        test_loader = ctx.loader(ctx.ids["test"], 32, False)
        for arch in graph_archs:
            mu, _ = ctx.load_checkpoint_model(arch, "untrained")
            vm_u = ctx.evaluate(mu, val_loader)
            C.log("[%s] untrained validation r with the corrected target = %.3f" % (arch, vm_u["pearson_r"]))
            for tag in (a.tags or sc["tags"][arch]):
                key = "%s/%s" % (arch, tag)
                have_all = all(C.emb_paths(cfg, arch, tag, s)[0].exists() for s in ("train", "val", "test"))
                if key in manifest and have_all:
                    C.log("[%s] already trained and extracted; skipping" % key)
                    continue
                seed = int(sc["seed_values"][tag])
                C.log("[%s] training on the corrected target with seed %d" % (key, seed))
                model, tinfo = ctx.train_one(arch, seed, tag)
                model = model.to(ctx.device)
                vm = ctx.evaluate(model, val_loader)
                preds, pid = ctx.predict(model, test_loader)
                rc, rr, rs = metrics_for(preds, pid, table, "test")
                ok = passes(vm["pearson_r"], vm_u["pearson_r"])
                hist = tinfo.get("history", [])
                best_epoch = int(min(hist, key=lambda h: h["val_loss"])["epoch"]) if hist else None
                C.log("[%s] val r (corrected)=%.3f (untrained %.3f) test r corrected=%.3f raw=%.3f size-only=%.3f GATE %s"
                      % (key, vm["pearson_r"], vm_u["pearson_r"], rc, rr, rs, "PASS" if ok else "FAIL"))
                for sp in ("train", "val", "test"):
                    E, ids_order = ctx.extract_ids(arch, model, ctx.ids[sp])
                    if ids_order != ctx.ids[sp]:
                        raise SystemExit("%s/%s: extracted id order differs from the original id order" % (key, sp))
                    npy, idsf = C.emb_paths(cfg, arch, tag, sp)
                    np.save(npy, E)
                    idsf.write_text("\n".join(ids_order))
                    C.log("  %s/%s extracted %s" % (key, sp, E.shape))
                record(arch, tag, seed, best_epoch, len(hist), vm, vm_u, rc, rr, rs, ok)
        del ctx

    if "gnina" in archs:
        import gnina_lib as GL

        class SizeCorrGnina(GL.GninaContext):
            def __init__(self, cfg_, target_, extract_device, epoch_seeding):
                self.target = target_
                super().__init__(cfg_, extract_device=extract_device, epoch_seeding=epoch_seeding)

            def _write_types_files(self):
                idx = self._pdb_index()
                out = {}
                tdir = self.cfg["_out"] / "types_sc"
                tdir.mkdir(parents=True, exist_ok=True)
                for sp in ("train", "val", "test"):
                    lines = []
                    for pid in self.ids[sp]:
                        d = idx.get(pid)
                        if d is None:
                            raise SystemExit("no PDBbind directory for %s" % pid)
                        pocket = d / (pid + "_pocket.pdb")
                        lig = d / (pid + "_ligand.sdf")
                        if not lig.exists():
                            lig = d / (pid + "_ligand.mol2")
                        if not pocket.exists() or not lig.exists():
                            raise SystemExit("missing pocket or ligand file for %s" % pid)
                        lines.append("%s %s %s" % (self.target[pid], pocket, lig))
                    path = tdir / (sp + ".types")
                    path.write_text("\n".join(lines) + "\n")
                    out[sp] = path
                    C.log("corrected-target types file %s: %d complexes" % (sp, len(lines)))
                return out
        ctx = SizeCorrGnina(cfg, target, a.extract_device, sc["gnina_epoch_seeding"])
        C.log("train device %s, extraction device %s, epoch seeding %s" % (ctx.device, ctx.extract_device, ctx.epoch_seeding))
        if not a.skip_selftest:
            C.json_dump(ctx.selftest(), cfg["_out"] / "results" / "gnina_selftest_sizecorr.json")
        mu = ctx.load_saved_untrained("untrained")
        vm_u = ctx.evaluate(mu, "val")
        del mu
        C.log("[gnina] untrained validation r with the corrected target = %.3f" % vm_u["pearson_r"])
        for tag in (a.tags or sc["tags"]["gnina"]):
            key = "gnina/%s" % tag
            have_all = all(C.emb_paths(cfg, "gnina", tag, s)[0].exists() for s in ("train", "val", "test"))
            if key in manifest and have_all:
                C.log("[%s] already trained and extracted; skipping" % key)
                continue
            seed = int(sc["seed_values"][tag])
            C.log("[%s] training on the corrected target with seed %d" % (key, seed))
            model, tinfo = ctx.train_gnina(seed, tag)
            model = model.to(ctx.device)
            vm = ctx.evaluate(model, "val")
            preds = ctx.predict(model, "test")
            rc, rr, rs = metrics_for(preds, ctx.ids["test"], table, "test")
            ok = passes(vm["pearson_r"], vm_u["pearson_r"])
            hist = tinfo.get("history", [])
            best_epoch = int(min(hist, key=lambda h: h["val_loss"])["epoch"]) if hist else None
            C.log("[%s] val r (corrected)=%.3f (untrained %.3f) test r corrected=%.3f raw=%.3f size-only=%.3f GATE %s"
                  % (key, vm["pearson_r"], vm_u["pearson_r"], rc, rr, rs, "PASS" if ok else "FAIL"))
            del model
            ctx.extract_tag(tag)
            record("gnina", tag, seed, best_epoch, len(hist), vm, vm_u, rc, rr, rs, ok, extra=dict(epoch_seeding=ctx.epoch_seeding))
    fails = [k for k, v in manifest.items() if not v["gate_pass"]]
    C.log("done. gate failures (reported, not retrained): %s" % (fails if fails else "none"))


if __name__ == "__main__":
    main()
