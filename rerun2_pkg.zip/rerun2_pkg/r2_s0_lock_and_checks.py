#!/usr/bin/env python
"""r2_s0_lock_and_checks.py  --  run this FIRST for round 2, on both the GPU box and the CPU box.

1. Confirms the original locked config.yaml is untouched.
2. Writes the pre-registration lock for config_rerun2.yaml (rerun_out2/PREREG_RERUN_LOCK.json).
3. Checks that the round 1 outputs and the inputs the round-2 stages need are present.

Usage
  python r2_s0_lock_and_checks.py --mode cpu
  python r2_s0_lock_and_checks.py --mode gpu
  python r2_s0_lock_and_checks.py --relock "reason"      deliberate change of config_rerun2.yaml after the lock
"""
import argparse
import importlib
import json
import sys

import common as C
import r2lib as R


def pkg_version(name):
    try:
        m = importlib.import_module(name)
        return getattr(m, "__version__", "importable")
    except Exception as e:  # noqa: BLE001
        return "MISSING (%s)" % type(e).__name__


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--mode", choices=["cpu", "gpu"], default="cpu")
    ap.add_argument("--relock", default=None)
    ap.add_argument("--ignore_orig_lock", action="store_true")
    a = ap.parse_args()
    cfg = R.load_cfg2()
    C.ensure_dirs(cfg)
    root = cfg["_root"]
    errors, warns = [], []
    C.log("project root: %s" % root)

    lockf = root / cfg["paths"]["original_lock"]
    conf = root / cfg["paths"]["original_config"]
    if lockf.exists() and conf.exists():
        want = json.loads(lockf.read_text())["config_sha256"]
        have = C.sha256_file(conf)
        if want == have:
            C.log("original config.yaml matches its lock (%s)" % have[:12])
        else:
            (warns if a.ignore_orig_lock else errors).append(
                "original config.yaml (%s) differs from config.lock.json (%s)" % (have[:12], want[:12]))
    else:
        errors.append("original config or lock not found under %s" % root)

    lp = C.lock_path(cfg)
    now = C.sha256_file(cfg["_cfg_path"])
    if lp.exists():
        lock = json.loads(lp.read_text())
        if lock["config_rerun_sha256"] == now:
            C.log("round-2 lock present and unchanged (locked %s)" % lock["locked_utc"])
        elif a.relock:
            lock.setdefault("history", []).append({"config_rerun_sha256": lock["config_rerun_sha256"],
                                                   "superseded_utc": C.utc_now(), "reason": a.relock})
            lock["config_rerun_sha256"] = now
            lock["locked_utc"] = C.utc_now()
            C.json_dump(lock, lp)
            C.log("RELOCKED with reason: %s  (a deviation; list it in the paper)" % a.relock)
        else:
            errors.append("config_rerun2.yaml changed after the lock; revert it or use --relock 'reason'")
    else:
        lock = {"label": "added_after_review_round2", "locked_utc": C.utc_now(), "config_rerun_sha256": now,
                "decision_rules": C.yaml.safe_load(cfg["_cfg_path"].read_text())["decision_rules"], "history": []}
        C.json_dump(lock, lp)
        C.log("WROTE round-2 lock %s  (config_rerun2.yaml sha256 %s)" % (lp, now[:12]))

    r1lock = cfg["_out1"] / "PREREG_RERUN_LOCK.json"
    if r1lock.exists():
        C.log("round 1 lock found (%s)" % r1lock)
    else:
        warns.append("round 1 lock not found at %s (round 1 outputs are expected in %s)" % (r1lock, cfg["_out1"]))

    if a.mode == "cpu":
        for need in ("results/seed_analysis.json", "results/new_seed_manifest.json"):
            if not (cfg["_out1"] / need).exists():
                errors.append("round 1 output missing: %s" % (cfg["_out1"] / need))
        missing = []
        for arch in cfg["archs"]:
            for t in list(cfg["seeds"]["trained_tags"]) + list(cfg["floors"]["orig_tags"]):
                if not R.have_proj(cfg, arch, t):
                    missing.append("%s/%s" % (arch, t))
        if missing:
            errors.append("round 1 projections missing (copy rerun_out/proj or run round 1 s4): %s" % missing[:8])
        for need in ("data/covariates.tsv", "data/clusters.tsv"):
            if not (root / need).exists():
                errors.append("missing " + need)
        try:
            C.core_ids(cfg)
        except SystemExit as e:
            errors.append("core ids: %s" % e)
    else:
        for mod in ("torch", "numpy", "pandas", "yaml", "scipy"):
            if pkg_version(mod).startswith("MISSING"):
                errors.append("missing python package: " + mod)
        try:
            import torch
            if not torch.cuda.is_available():
                warns.append("torch cannot see a CUDA device; GNINA training will be extremely slow")
        except Exception:  # noqa: BLE001
            pass
        for mod in ("molgrid", "gninatorch"):
            if pkg_version(mod).startswith("MISSING"):
                warns.append("%s not importable (needed for the GNINA stages only; numpy below 2 is required for molgrid)" % mod)
        for need in ("src/embed_utils.py", "src/seeds.py", "data/graph_cache", "data/checkpoints/egnn_primary.pt",
                     "data/checkpoints/gnina_primary.pt", "data/covariates.tsv"):
            if not (root / need).exists():
                (errors if need.startswith("src/") else warns).append("missing " + need)
        if cfg["_pdbbind_dir"] is None:
            warns.append("PDBBIND_DIR is not set (needed for GNINA stages and for graph cache rebuilds)")

    env = {m: pkg_version(m) for m in ("numpy", "scipy", "pandas", "sklearn", "torch", "molgrid", "gninatorch", "yaml")}
    env["python"] = sys.version
    C.json_dump(C.stamp({"mode": a.mode, "env": env}), cfg["_out"] / "logs" / ("environment_%s.json" % a.mode))
    for w in warns:
        C.log("WARNING: " + w)
    for e in errors:
        C.log("ERROR: " + e)
    if errors:
        raise SystemExit("r2_s0 found %d blocking problem(s)" % len(errors))
    C.log("r2_s0 OK (%s mode)" % a.mode)


if __name__ == "__main__":
    main()
