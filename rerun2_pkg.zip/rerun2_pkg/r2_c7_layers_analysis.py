#!/usr/bin/env python
"""r2_c7_layers_analysis.py  --  CPU box. Seed-aware alignment at earlier, pre-specified layers (exploratory).

Needs results/layers/ARCH__TAG.npz from r2_g3_layers_preds.py. For every layer pair in config layers.analysis.pairs the analysis uses
the vectors of that layer for both architectures (no PCA, the vectors are at most 128 dimensional), the same trained seeds as round 1,
and the untrained initializations as floors.

Output: results/layers_analysis.json, report/layers_analysis.md
"""
import argparse

import numpy as np

import common as C
import engine as eg
import r2lib as R


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--n_boot", type=int, default=None, help="override draws (smoke tests only)")
    a = ap.parse_args()
    cfg = R.load_cfg2()
    C.ensure_dirs(cfg)
    C.verify_lock(cfg)
    la = cfg["layers"]["analysis"]
    n_boot = int(a.n_boot if a.n_boot is not None else la["n_boot"])
    core = C.core_ids(cfg)
    cov = C.load_covariates(cfg, core)
    clusters = C.load_clusters(cfg, core)
    ldir = cfg["_out"] / "results" / "layers"
    failed = R.round1_failed(cfg)
    cache = {}

    def vecs(arch, tag):
        k = (arch, tag)
        if k not in cache:
            f = ldir / ("%s__%s.npz" % (arch, tag))
            cache[k] = R.load_vectors(cfg, f, core, "%s/%s:" % (arch, tag)) if f.exists() else None
        return cache[k]
    results, skipped = {}, []
    for (A, sa, B, sb) in la["pairs"]:
        label = "%s:%s x %s:%s" % (A, sa, B, sb)
        trained, floors, Zmap = {}, {}, {}
        ok = True
        for arch, spec in ((A, sa), (B, sb)):
            pseudo = "%s@%s" % (arch, spec)
            tr = [t for t in cfg["seeds"]["trained_tags"] if t not in failed.get(arch, [])]
            fl = list(cfg["floors"]["orig_tags"])
            for t in tr + fl:
                v = vecs(arch, t)
                if v is None or spec not in v:
                    ok = False
                    break
                Zmap["%s/%s" % (pseudo, t)] = v[spec]
            if not ok:
                break
            trained[pseudo] = tr
            floors[pseudo] = fl
        if not ok:
            skipped.append(label)
            C.log("skipped %s (layer files missing)" % label)
            continue
        pa, pb = "%s@%s" % (A, sa), "%s@%s" % (B, sb)
        design = eg.Design([(pa, pb)], trained, {"orig": floors})
        res = R.run_engine(cfg, Zmap, cov, clusters, design, la["modes"], n_boot)
        results[label] = {m: res[m][R.pair_key(pa, pb)]["orig"] for m in la["modes"]}
        del Zmap, res
    out = dict(stamp=C.stamp(), label="added_after_review_round2", exploratory=True, n_boot=n_boot, skipped=skipped, results=results)
    C.json_dump(out, cfg["_out"] / "results" / "layers_analysis.json")
    rows = []
    for label, per in results.items():
        for mode, rec in per.items():
            e = rec["estimators"]["seed_min"]
            rows.append([label, mode, R.fnum(e.get("obs")), R.fnum(e.get("floor")), R.fnum(e.get("ceil")), R.fnum(e.get("nab")),
                         R.fci(e.get("ci_complex")), R.fci(e.get("ci_two_level"))])
    lines = ["# Earlier-layer alignment (exploratory, added after review, round 2)", "",
             "Layers L1 to L3 are mean-pooled node features after message-passing layer 1 to 3, L0 is the atom-type embedding, "
             "L3_lig and L3_poc pool the ligand and pocket nodes of layer 3, conv1 to conv3 are spatial means of GNINA convolutions.", ""]
    lines.append(R.md_table(["layers", "mode", "CKA", "floor", "ceiling", "n_AB", "CI (clusters)", "CI (two-level)"], rows))
    if skipped:
        lines += ["", "Skipped (files missing): " + "; ".join(skipped)]
    R.write_report(cfg, "layers_analysis", "\n".join(lines) + "\n")


if __name__ == "__main__":
    main()
