#!/usr/bin/env python
"""s0_lock_and_checks.py  --  run this FIRST, on both the GPU box and the CPU box.

1. Confirms the original locked config.yaml is untouched.
2. Writes the pre-registration lock for config_rerun.yaml (runs "added after review").
3. Checks that the inputs the reruns depend on exist and line up, and records package versions.

Usage
  python s0_lock_and_checks.py --mode cpu            # analysis box
  python s0_lock_and_checks.py --mode gpu            # training box
  python s0_lock_and_checks.py --mode cpu --verify_hashes   # also compare embedding files with provenance/embeddings_sha256.txt (slow)
  python s0_lock_and_checks.py --relock "reason"     # deliberate change of config_rerun.yaml after the lock
"""
import argparse
import importlib
import json
import sys
from pathlib import Path

import numpy as np

import common as C


def pkg_version(name):
    try:
        m = importlib.import_module(name)
        return getattr(m, "__version__", "importable")
    except Exception as e:  # noqa: BLE001
        return "MISSING (%s)" % type(e).__name__


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--mode", choices=["cpu", "gpu"], default="cpu")
    ap.add_argument("--verify_hashes", action="store_true")
    ap.add_argument("--relock", default=None, help="reason string; allows config_rerun.yaml to change after the lock")
    ap.add_argument("--ignore_orig_lock", action="store_true")
    a = ap.parse_args()

    cfg = C.load_cfg()
    C.ensure_dirs(cfg)
    root = cfg["_root"]
    errors, warns = [], []
    C.log("project root: %s" % root)

    # 1. original lock
    lockf = root / cfg["paths"]["original_lock"]
    conf = root / cfg["paths"]["original_config"]
    if lockf.exists() and conf.exists():
        want = json.loads(lockf.read_text())["config_sha256"]
        have = C.sha256_file(conf)
        if want == have:
            C.log("original config.yaml matches its lock (%s)" % have[:12])
        else:
            msg = "original config.yaml (%s) differs from config.lock.json (%s)" % (have[:12], want[:12])
            (warns if a.ignore_orig_lock else errors).append(msg)
    else:
        errors.append("original config or lock not found under %s" % root)

    # 2. rerun lock
    lp = C.lock_path(cfg)
    now = C.sha256_file(cfg["_cfg_path"])
    if lp.exists():
        lock = json.loads(lp.read_text())
        if lock["config_rerun_sha256"] == now:
            C.log("rerun lock present and unchanged (locked %s)" % lock["locked_utc"])
        elif a.relock:
            lock.setdefault("history", []).append({"config_rerun_sha256": lock["config_rerun_sha256"],
                                                   "superseded_utc": C.utc_now(), "reason": a.relock})
            lock["config_rerun_sha256"] = now
            lock["locked_utc"] = C.utc_now()
            C.json_dump(lock, lp)
            C.log("RELOCKED with reason: %s  (this is a deviation; list it in the paper)" % a.relock)
        else:
            errors.append("config_rerun.yaml changed after the lock; revert it or use --relock 'reason'")
    else:
        lock = {"label": "added_after_review", "locked_utc": C.utc_now(), "config_rerun_sha256": now,
                "decision_rules": C.yaml.safe_load(cfg["_cfg_path"].read_text())["decision_rules"], "history": []}
        C.json_dump(lock, lp)
        C.log("WROTE rerun lock %s  (config_rerun.yaml sha256 %s)" % (lp, now[:12]))

    # 3. inputs
    arch_dims = {"egnn": 64, "distance_gnn": 64, "gnina": 27648}
    try:
        om = C.load_original_cfg(cfg)["embeddings"]["models"]
        arch_dims = {a: int(om[a]["dim"]) for a in arch_dims}
    except Exception:  # noqa: BLE001
        warns.append("could not read embedding dimensions from the original config; using 64, 64, 27648")
    n_exp = int(cfg["data"]["n_core_expected"])
    existing = ["primary", "anchor"] + list(cfg["floors"]["orig_tags"])
    core = None
    try:
        core = C.core_ids(cfg)
    except SystemExit as e:
        errors.append("core ids: %s" % e)
    if a.mode == "cpu":
        for arch in cfg["archs"]:
            for tag in existing:
                if not C.have_embeddings(cfg, arch, tag, ("train", "test")):
                    errors.append("missing train/test embeddings: %s/%s" % (arch, tag))
                    continue
                npy, idsf = C.emb_paths(cfg, arch, tag, "test")
                E = np.load(npy, mmap_mode="r")
                ids = C.read_ids(idsf)
                if E.shape != (n_exp, arch_dims[arch]):
                    errors.append("%s/%s test shape %s, expected %s" % (arch, tag, E.shape, (n_exp, arch_dims[arch])))
                if core is not None and set(ids) != set(core):
                    errors.append("%s/%s test ids differ from the core set" % (arch, tag))
                npy_tr, _ = C.emb_paths(cfg, arch, tag, "train")
                Etr = np.load(npy_tr, mmap_mode="r")
                if Etr.shape[1] != arch_dims[arch]:
                    errors.append("%s/%s train dim %d, expected %d" % (arch, tag, Etr.shape[1], arch_dims[arch]))
        for need in ("data/covariates.tsv", "data/clusters.tsv"):
            if not (root / need).exists():
                errors.append("missing " + need)
        # which new tags are already present
        for arch in cfg["archs"]:
            new = [t for t in C.trained_tags(cfg) if t not in ("primary", "anchor")]
            have_new = [t for t in new if C.have_embeddings(cfg, arch, t)]
            C.log("%s: new seed embeddings present: %s of %s" % (arch, have_new, new))
        have_regen = [t for t in cfg["floors"]["regen_tags"] if C.have_embeddings(cfg, "gnina", t)]
        C.log("gnina: regenerated floor embeddings present: %s" % have_regen)
        if a.verify_hashes:
            prov = root / "provenance" / "embeddings_sha256.txt"
            if not prov.exists():
                warns.append("provenance/embeddings_sha256.txt not found; skipping hash check")
            else:
                bad = 0
                for line in prov.read_text().splitlines():
                    parts = line.split()
                    if len(parts) != 2:
                        continue
                    h, rel = parts
                    f = root / rel
                    if f.exists() and f.suffix == ".npy":
                        if C.sha256_file(f) != h:
                            bad += 1
                            errors.append("hash mismatch: " + rel)
                C.log("hash check done, mismatches: %d" % bad)
    else:
        for mod in ("torch", "numpy", "pandas", "yaml", "scipy"):
            if pkg_version(mod).startswith("MISSING"):
                errors.append("missing python package: " + mod)
        try:
            import torch
            if not torch.cuda.is_available():
                warns.append("torch cannot see a CUDA device; GNINA training will be extremely slow")
        except Exception:  # noqa: BLE001
            pass
        for mod in ("molgrid", "gninatorch"):
            if pkg_version(mod).startswith("MISSING"):
                warns.append("%s not importable here (needed for the GNINA stages only; numpy below 2 is required for molgrid)" % mod)
        for need in ("src/embed_utils.py", "src/seeds.py", "data/graph_cache", "data/checkpoints/egnn_primary.pt",
                     "data/checkpoints/egnn_untrained.pt", "data/checkpoints/distance_gnn_primary.pt",
                     "data/checkpoints/distance_gnn_untrained.pt", "data/checkpoints/gnina_primary.pt",
                     "data/checkpoints/gnina_untrained.pt"):
            if not (root / need).exists():
                (errors if need.startswith("src/") else warns).append("missing " + need)

    env = {m: pkg_version(m) for m in ("numpy", "scipy", "pandas", "sklearn", "torch", "molgrid", "gninatorch", "yaml", "matplotlib")}
    env["python"] = sys.version
    C.json_dump(C.stamp({"mode": a.mode, "env": env}), cfg["_out"] / "logs" / ("environment_%s.json" % a.mode))
    for w in warns:
        C.log("WARNING: " + w)
    for e in errors:
        C.log("ERROR: " + e)
    if errors:
        raise SystemExit("s0 found %d blocking problem(s)" % len(errors))
    C.log("s0 OK (%s mode)" % a.mode)


if __name__ == "__main__":
    main()
