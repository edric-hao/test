#!/usr/bin/env python
"""r2_c0_project.py  --  CPU box. PCA-64 projections for the networks trained in round 2 (decoupled GNINA seeds, size-corrected
targets). Same procedure as round 1 s4_project.py: PCA fitted on the network's own TRAIN embeddings, test rows in core order.
Projections go to rerun_out2/proj. Networks whose embeddings are not present are skipped.

Usage: python r2_c0_project.py [--force]
"""
import argparse

import numpy as np

import common as C
import r2lib as R
from s4_project import project_one, source_signature, proj_path


def wanted(cfg):
    out = []
    for t in cfg["decoupled_gnina"]["tags"]:
        out.append(("gnina", t))
    for arch, tags in cfg["sizecorr"]["tags"].items():
        for t in tags:
            out.append((arch, t))
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--force", action="store_true")
    a = ap.parse_args()
    cfg = R.load_cfg2()
    C.ensure_dirs(cfg)
    C.verify_lock(cfg)
    core = C.core_ids(cfg)
    method = cfg["data"]["pca_method"]
    k = int(cfg["data"]["pca_dim"])
    n_done = 0
    for arch, tag in wanted(cfg):
        out = proj_path(cfg, arch, tag)
        if not C.have_embeddings(cfg, arch, tag, ("train", "test")):
            C.log("[%s/%s] embeddings not present; skipped" % (arch, tag))
            continue
        if out.exists() and not a.force:
            old = np.load(out, allow_pickle=False)
            if (str(old["method"]) == method and int(old["dim"]) == k and "source_sig" in old.files
                    and str(old["source_sig"]) == source_signature(cfg, arch, tag)):
                C.log("[%s/%s] cached" % (arch, tag))
                continue
        Z, evr, shp = project_one(cfg, arch, tag, core, method, k)
        np.savez(out, Z=Z, evr=evr, ids=np.array(core), method=np.array(method), dim=np.array(k),
                 train_shape=np.array(shp), source_sig=np.array(source_signature(cfg, arch, tag)))
        n_done += 1
        C.log("[%s/%s] projected %s, top-3 variance share %s" % (arch, tag, Z.shape, np.round(evr[:3], 3).tolist()))
    C.log("projected %d network(s)" % n_done)


if __name__ == "__main__":
    main()
