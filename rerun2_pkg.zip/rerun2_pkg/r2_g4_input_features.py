#!/usr/bin/env python
"""r2_g4_input_features.py  --  GPU box (needs torch to read the graph cache). Input-similarity features of the test complexes.

For every core (test) complex, from the cached input graph (atom types, coordinates):
  n_nodes, n_lig, n_poc              node counts (ligand nodes are the odd node types)
  type_0 to type_15                  counts of each node type
  n_edges, n_edges_lp                pairs within the 5 A radius, all and ligand-pocket only
  dist_all_0 to dist_all_9           histogram of those pair distances (10 bins from 0 to 5 A)
  dist_lp_0 to dist_lp_9             the same for ligand-pocket pairs
These are what both graph models see at the input (and the node composition that every model sees), so they summarize input similarity.

Output: results/input_features.tsv (index = complex id)
"""
import numpy as np
import pandas as pd

import common as C
import r2lib as R


def features(z, x, cutoff=5.0, nb=10):
    z = np.asarray(z, dtype=np.int64)
    x = np.asarray(x, dtype=np.float64)
    n = len(z)
    lig = (z % 2) == 1
    d = np.sqrt(np.maximum(np.sum(np.square(x[:, None, :] - x[None, :, :]), axis=2), 0.0))
    iu = np.triu_indices(n, 1)
    dd = d[iu]
    within = dd < cutoff
    lp = (lig[iu[0]] != lig[iu[1]])
    bins = np.linspace(0.0, cutoff, nb + 1)
    h_all = np.histogram(dd[within], bins=bins)[0]
    h_lp = np.histogram(dd[within & lp], bins=bins)[0]
    row = {"n_nodes": n, "n_lig": int(lig.sum()), "n_poc": int((~lig).sum())}
    tc = np.bincount(z, minlength=16)[:16]
    for i in range(16):
        row["type_%d" % i] = int(tc[i])
    row["n_edges"] = int(within.sum())
    row["n_edges_lp"] = int((within & lp).sum())
    for i in range(nb):
        row["dist_all_%d" % i] = int(h_all[i])
    for i in range(nb):
        row["dist_lp_%d" % i] = int(h_lp[i])
    return row


def main():
    cfg = R.load_cfg2()
    C.ensure_dirs(cfg)
    C.verify_lock(cfg)
    import gnn_lib as G
    ctx = G.GnnContext(cfg)
    ids = ctx.ids["test"]
    rows = {}
    for i, pid in enumerate(ids):
        z, x, _ = ctx.get_graph(pid)
        rows[pid] = features(z.numpy(), x.numpy())
        if (i + 1) % 500 == 0:
            C.log("%d of %d complexes" % (i + 1, len(ids)))
    df = pd.DataFrame.from_dict(rows, orient="index")
    df.index.name = "pdb_id"
    out = cfg["_out"] / "results" / "input_features.tsv"
    df.to_csv(out, sep="\t")
    C.log("wrote %s (%d complexes, %d features)" % (out, df.shape[0], df.shape[1]))


if __name__ == "__main__":
    main()
