#!/usr/bin/env python
"""s3_gnina_floor.py  --  GPU box. Rebuild all five GNINA untrained references with ONE procedure.

For each seed in floors.regen_seed_values: setup_gnina_model, reinit_weights on the training device,
save as gnina_untrained_regenK.pt, extract float64 train/val/test embeddings.
Validation per initialization: finite, non-constant, shape (n, 27648). Validation r is recorded for disclosure.
Also reports how close regenerated initialization 1 is to the originally saved untrained embeddings.
If any initialization fails validation the JSON is written and the script exits with an error.

Usage
  python s3_gnina_floor.py
  python s3_gnina_floor.py --extract_device cpu
"""
import argparse

import numpy as np

import common as C


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--extract_device", default=None)
    ap.add_argument("--skip_selftest", action="store_true")
    a = ap.parse_args()

    cfg = C.load_cfg()
    C.ensure_dirs(cfg)
    C.verify_lock(cfg)
    import gnina_lib as GL
    ctx = GL.GninaContext(cfg, extract_device=a.extract_device)
    C.log("train device %s, extraction device %s" % (ctx.device, ctx.extract_device))
    selftest = {} if a.skip_selftest else ctx.selftest()

    tags = list(cfg["floors"]["regen_tags"])
    seeds = [int(s) for s in cfg["floors"]["regen_seed_values"]]
    if len(tags) != len(seeds):
        raise SystemExit("regen_tags and regen_seed_values differ in length")
    out_path = cfg["_out"] / "results" / "gnina_floor_regen.json"
    rec = C.json.loads(out_path.read_text()) if out_path.exists() else {}
    n_exp = int(cfg["data"]["n_core_expected"])

    for tag, seed in zip(tags, seeds):
        done = all(C.emb_paths(cfg, "gnina", tag, sp)[0].exists() for sp in ("train", "val", "test"))
        if tag in rec and done:
            C.log("[%s] already built; skipping" % tag)
            continue
        C.log("[%s] building random initialization with seed %d" % (tag, seed))
        model = ctx.make_random_init(seed)
        ctx.save_untrained(model, seed, tag)
        vm = ctx.evaluate(model, "val")
        del model
        outs = ctx.extract_tag(tag)
        checks = {}
        valid = True
        for sp, npy in outs.items():
            E = np.load(npy, mmap_mode="r")
            sub = np.asarray(E[:2000], dtype=np.float64)
            fin = bool(np.isfinite(sub).all())
            var = bool((sub.std(axis=0) > 0).any())
            shape_ok = (E.shape[0] == len(ctx.ids[sp])) and (E.shape[1] == ctx.expected_dim)
            checks[sp] = dict(shape=list(E.shape), finite=fin, varied=var, shape_ok=shape_ok)
            valid = valid and fin and var and shape_ok
        rec[tag] = dict(seed=seed, valid=bool(valid), val_pearson_r=vm["pearson_r"], val_rmse=vm["rmse"],
                        checks=checks, extract_device=str(ctx.extract_device))
        C.log("[%s] valid=%s, validation r of the untrained network = %.3f" % (tag, valid, vm["pearson_r"]))
        C.json_dump(rec, out_path)

    # how close is regenerated init 1 to the originally saved untrained embeddings
    try:
        npy_new, _ = C.emb_paths(cfg, "gnina", tags[0], "test")
        npy_old, ids_old = C.emb_paths(cfg, "gnina", "untrained", "test")
        new = np.asarray(np.load(npy_new, mmap_mode="r")[:50], dtype=np.float64)
        old = np.asarray(np.load(npy_old, mmap_mode="r")[:50], dtype=np.float64)
        rel = float(np.abs(new - old).max() / max(np.abs(old).max(), 1e-12))
        rec["_init1_vs_saved_untrained"] = dict(max_rel_diff_first50_test_rows=rel,
                                                note="Disclosed, not a failure condition.")
        C.log("regenerated init 1 vs saved untrained: max rel diff %.3g" % rel)
    except Exception as e:  # noqa: BLE001
        rec["_init1_vs_saved_untrained"] = dict(error=str(e))
    rec["_selftest"] = selftest
    C.json_dump(rec, out_path)
    bad = [t for t in tags if not rec[t]["valid"]]
    if bad:
        raise SystemExit("GNINA initializations failed validation: %s. See %s. Do not continue to analysis." % (bad, out_path))
    C.log("all five GNINA untrained references are valid")


if __name__ == "__main__":
    main()
