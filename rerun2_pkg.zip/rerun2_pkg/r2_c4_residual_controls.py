#!/usr/bin/env python
"""r2_c4_residual_controls.py  --  CPU box. Two controls on the size residualization.

A. Permuted covariates. The rows of the two-column covariate matrix are permuted jointly (same marginal distribution, same variance,
   same joint distribution, no relation to the embeddings) and the full seed-aware analysis is rerun with the permuted covariates in
   the linear and the quadratic residualization. This gives the reduction in CKA that residualizing on two arbitrary covariates
   produces in this sample, and answers whether the real reduction exceeds it.
B. Residualized null. Embeddings are residualized on the real covariates, and the rows of the second network are then permuted
   within protein cluster x ligand-size tertile. The resulting null for the residualized CKA says how much alignment the
   residualized embeddings keep when only cluster and coarse size structure is preserved, which is the comparison made for the
   unresidualized CKA in round 1.

Estimator: seed-aware, mean over all trained seed pairs across architectures (seed_min). Floors are the original untrained references.
Output: results/residual_controls.json, report/residual_controls.md
"""
import argparse
import time

import numpy as np

import alignlib2 as al
import common as C
import engine as eg
import r2lib as R


def collect(res, mode, pairs):
    out = {}
    for A, B in pairs:
        e = R.pick(res, mode, R.pair_key(A, B), "orig", "seed_min")
        out[R.pair_key(A, B)] = {k: e.get(k) for k in ("obs", "floor", "ceil", "nab")}
    return out


def pctl(x, q):
    x = np.asarray([v for v in x if v is not None and np.isfinite(v)], dtype=np.float64)
    return float(np.percentile(x, q)) if len(x) else None


def part_a(cfg, Zmap, cov, clusters, design, n_perm, rng):
    modes = list(cfg["controls"]["modes"])
    pairs = [tuple(p) for p in cfg["arch_pairs"]]
    real = R.run_engine(cfg, Zmap, cov, clusters, design, ["raw"] + modes, 0)
    out = {"real": {m: collect(real, m, pairs) for m in ["raw"] + modes}, "perm": {m: {R.pkey(p): [] for p in pairs} for m in modes}}
    t0 = time.time()
    n = cov.shape[0]
    for r in range(n_perm):
        perm = rng.permutation(n)
        res = R.run_engine(cfg, Zmap, cov[perm], clusters, design, modes, 0)
        for m in modes:
            for p in pairs:
                out["perm"][m][R.pkey(p)].append(collect(res, m, [p])[R.pkey(p)])
        if (r + 1) % 5 == 0 or r + 1 == n_perm:
            C.log("  permuted covariates: %d of %d (%.0fs)" % (r + 1, n_perm, time.time() - t0))
    summ = {}
    for m in modes:
        summ[m] = {}
        for p in pairs:
            key = R.pkey(p)
            recs = out["perm"][m][key]
            obs = [q["obs"] for q in recs]
            nab = [q["nab"] for q in recs]
            real_obs = out["real"][m][key]["obs"]
            raw_obs = out["real"]["raw"][key]["obs"]
            fin = np.array([v for v in obs if v is not None and np.isfinite(v)])
            summ[m][key] = dict(
                raw_obs=raw_obs, real_obs=real_obs,
                perm_obs_mean=float(fin.mean()) if len(fin) else None, perm_obs_p05=pctl(obs, 5), perm_obs_p95=pctl(obs, 95),
                perm_obs_min=float(fin.min()) if len(fin) else None,
                reduction_real=(raw_obs - real_obs) if (raw_obs is not None and real_obs is not None) else None,
                reduction_perm_mean=(raw_obs - float(fin.mean())) if (raw_obs is not None and len(fin)) else None,
                p_perm_le_real=float((1 + np.sum(fin <= real_obs)) / (1 + len(fin))) if (len(fin) and real_obs is not None) else None,
                real_nab=out["real"][m][key]["nab"], perm_nab_mean=pctl(nab, 50), perm_nab_p05=pctl(nab, 5), perm_nab_p95=pctl(nab, 95),
                perm_nab_undefined=int(sum(1 for v in nab if v is None or not np.isfinite(v))), n_perm=len(recs))
    out["summary"] = summ
    return out


def part_b(cfg, Zmap, cov, clusters, design, size, n_perm, rng):
    pairs = [tuple(p) for p in cfg["arch_pairs"]]
    modes = ["raw"] + list(cfg["controls"]["modes"])
    n = cov.shape[0]
    tert = R.tertile_labels(size, 3)
    _, strata = np.unique(np.stack([clusters, tert], axis=1), axis=0, return_inverse=True)
    strata = np.asarray(strata).reshape(-1)
    n_str = int(len(np.unique(strata)))
    sizes = np.bincount(strata)
    permutable = float(np.sum(sizes[sizes > 1])) / n
    out = dict(n_strata=n_str, permutable_fraction=permutable, modes={})
    t0 = time.time()
    for mode in modes:
        grams = {}
        for arch in cfg["archs"]:
            for t in design.trained[arch]:
                nm = "%s/%s" % (arch, t)
                grams[nm] = al.gram_zero_diag(al.residualize(Zmap[nm], cov, mode))
        out["modes"][mode] = {}
        for (A, B) in pairs:
            na = ["%s/%s" % (A, t) for t in design.trained[A]]
            nb = ["%s/%s" % (B, t) for t in design.trained[B]]
            prs = [(x, y) for x in na for y in nb]
            bank = al.GramBank({k: grams[k] for k in na + nb})
            obs = float(np.mean(bank.cka_point(prs)))
            null = []
            for r in range(n_perm):
                p = R.within_stratum_permutation(strata, rng)
                g = {x: grams[x] for x in na}
                for y in nb:
                    g["perm/" + y] = grams[y][np.ix_(p, p)]
                bk = al.GramBank(g)
                null.append(float(np.mean(bk.cka_point([(x, "perm/" + y) for x in na for y in nb]))))
            null = np.array(null)
            out["modes"][mode][R.pair_key(A, B)] = dict(
                observed=obs, null_mean=float(null.mean()), null_p99=float(np.percentile(null, 99)),
                excess_over_null_mean=obs - float(null.mean()), excess_over_p99=obs - float(np.percentile(null, 99)),
                p_value=float((1 + np.sum(null >= obs)) / (1 + len(null))), n_perm=int(n_perm),
                retained_fraction=(float(null.mean()) / obs) if obs > 0 else None)
            C.log("  residualized null %s %s: observed %.3f, null mean %.3f (%.0fs)" % (mode, R.pair_key(A, B), obs, null.mean(), time.time() - t0))
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--n_perm_cov", type=int, default=None)
    ap.add_argument("--n_perm_null", type=int, default=None)
    ap.add_argument("--skip_a", action="store_true")
    ap.add_argument("--skip_b", action="store_true")
    a = ap.parse_args()
    cfg = R.load_cfg2()
    C.ensure_dirs(cfg)
    C.verify_lock(cfg)
    ct = cfg["controls"]
    n_a = int(a.n_perm_cov if a.n_perm_cov is not None else ct["n_perm_covariates"])
    n_b = int(a.n_perm_null if a.n_perm_null is not None else ct["n_perm_null"])
    if a.n_perm_cov is not None or a.n_perm_null is not None:
        C.log("WARNING: permutation counts overridden; do not use these numbers in the paper")
    core = C.core_ids(cfg)
    cov = C.load_covariates(cfg, core)
    clusters = C.load_clusters(cfg, core)
    size = C.ligand_size(cfg, core)
    trained = R.round1_trained(cfg)
    design = R.make_design(cfg, trained, which=("orig",))
    Zmap = R.zmap_for(cfg, design)
    rng = np.random.default_rng([int(ct["seed"]), 17])
    out = dict(stamp=C.stamp(), label="added_after_review_round2", trained=trained)
    if not a.skip_a:
        out["permuted_covariates"] = part_a(cfg, Zmap, cov, clusters, design, n_a, rng)
    if not a.skip_b:
        out["residualized_null"] = part_b(cfg, Zmap, cov, clusters, design, size, n_b, rng)
    C.json_dump(out, cfg["_out"] / "results" / "residual_controls.json")

    lines = ["# Residualization controls (added after review, round 2)", "", "Trained networks: " + str(trained), ""]
    if "permuted_covariates" in out:
        rows = []
        for m, per in out["permuted_covariates"]["summary"].items():
            for key, s in per.items():
                rows.append([m, key, R.fnum(s["raw_obs"]), R.fnum(s["real_obs"]), R.fnum(s["perm_obs_mean"]),
                             "%s to %s" % (R.fnum(s["perm_obs_p05"]), R.fnum(s["perm_obs_p95"])), R.fnum(s["p_perm_le_real"], 3),
                             R.fnum(s["real_nab"]), R.fnum(s["perm_nab_mean"]), s["n_perm"]])
        lines.append("## A. Permuted covariates (seed-mean CKA)")
        lines.append(R.md_table(["mode", "pair", "raw CKA", "CKA after real covariates", "CKA after permuted covariates (mean)",
                                 "permuted 5th to 95th", "p (permuted <= real)", "n_AB real", "n_AB permuted (median)", "n perm"], rows))
        lines.append("")
    if "residualized_null" in out:
        rows = []
        for m, per in out["residualized_null"]["modes"].items():
            for key, s in per.items():
                rows.append([m, key, R.fnum(s["observed"]), R.fnum(s["null_mean"]), R.fnum(s["null_p99"]),
                             R.fnum(s["excess_over_null_mean"]), R.fnum(s["excess_over_p99"]), R.fnum(s["p_value"], 3)])
        lines.append("## B. Residualized null (cluster x size-tertile permutation of residualized embeddings; strata %d, permutable fraction %s)"
                     % (out["residualized_null"]["n_strata"], R.fnum(out["residualized_null"]["permutable_fraction"])))
        lines.append(R.md_table(["mode", "pair", "observed seed-mean CKA", "null mean", "null 99th percentile",
                                 "excess over null mean", "excess over 99th", "p"], rows))
    R.write_report(cfg, "residual_controls", "\n".join(lines) + "\n")


if __name__ == "__main__":
    main()
