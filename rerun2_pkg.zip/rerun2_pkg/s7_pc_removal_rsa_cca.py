#!/usr/bin/env python
"""s7_pc_removal_rsa_cca.py  --  CPU box. Item 5.

A. PC removal: drop the first 0, 1, 3 principal coordinates of every network (config pc_removal.drop) and rerun the full
   seed-aware analysis (raw and linearly residualized). Also reports how much variance the dropped coordinates carry and how
   strongly the first coordinate tracks the size covariates.
B. RSA (Spearman correlation of Euclidean dissimilarity matrices) and CCA (mean of the first k canonical correlations) as
   secondary similarity measures, with the same floor and ceiling logic and a cluster bootstrap (rows of the drawn clusters,
   each used once). These are diagnostics; neither is read as independent confirmation.

Output: results/pc_removal.json, results/rsa_cca.json
Usage: python s7_pc_removal_rsa_cca.py [--skip_rsa_cca] [--skip_pc]
"""
import argparse
import time

import numpy as np
from scipy.spatial.distance import pdist
from scipy.stats import rankdata

import alignlib2 as al
import common as C
import engine as eg
from mathx import mul
from s4_project import load_proj, proj_path
from s5_seed_analysis import build_design


# ---------------------------------------------------------------- A. PC removal
def pc_removal(cfg, core, cov, clusters, design, Zmap, floor_set, n_boot_override=None):
    pr = cfg["pc_removal"]
    an = cfg["analysis"]
    n_boot = int(n_boot_override if n_boot_override is not None else pr["n_boot"])
    out = dict(drops={}, floor_set=floor_set, n_boot=n_boot)
    for d in pr["drop"]:
        res = eg.run_seed_analysis(Zmap, cov, clusters, design, list(pr["modes"]), n_boot, int(an["boot_seed"]),
                                   pc_drop=int(d), boot_kind=an["boot_kind"], chunk=int(an["chunk"]),
                                   min_den=float(an["min_denominator"]), max_undef=float(an["max_undefined_fraction"]),
                                   level=float(an["ci_level"]), log=C.log)
        out["drops"][str(d)] = res
    diag = {}
    for nm in design.nets():
        arch, tag = nm.split("/", 1)
        d = np.load(proj_path(cfg, arch, tag))
        Z = d["Z"]
        evr = d["evr"]
        r = [abs(float(np.corrcoef(Z[:, 0], cov[:, j])[0, 1])) for j in range(cov.shape[1])]
        diag[nm] = dict(variance_share_pc1=float(evr[0]), variance_share_first3=float(np.sum(evr[:3])),
                        abs_corr_pc1_with_covariates=r)
    out["pc_diagnostics"] = diag
    return out


# ---------------------------------------------------------------- B. RSA and CCA
def prep_rsa(Z):
    d = pdist(Z)
    r = rankdata(d).astype(np.float32)
    r -= r.mean()
    r /= np.linalg.norm(r)
    return r


def prep_cca(Z):
    Zc = Z - Z.mean(axis=0, keepdims=True)
    U, s, _ = np.linalg.svd(Zc, full_matrices=False)
    keep = s > mul(1e-8, s[0])
    return U[:, keep]


def sim_rsa(a, b):
    return float(np.dot(a, b))


def make_sim_cca(k):
    def sim(Qa, Qb):
        sv = np.linalg.svd(Qa.T @ Qb, compute_uv=False)
        kk = int(min(k, len(sv)))
        return float(np.mean(np.clip(sv[:kk], 0.0, 1.0)))
    return sim


def pair_table(Zres, rows, pairs, prep, sim):
    P = {nm: prep(Zres[nm][rows]) for nm in Zres}
    return np.array([sim(P[a], P[b]) for a, b in pairs], dtype=np.float64)


def estimators_for(T, design, pmap, min_den):
    """T (B, n_pairs) -> per arch pair, per estimator dict of (B,) arrays."""
    out = {}
    fs = next(iter(design.floor_sets.values()))
    for (A, B) in design.arch_pairs:
        ta, tb = design.trained[A], design.trained[B]
        ip, ia = ta.index("primary"), ta.index("anchor")
        jp, ja = tb.index("primary"), tb.index("anchor")
        c = eg.cross_matrix(T, pmap, A, ta, B, tb)
        wa = eg.within_matrix(T, pmap, A, ta)
        wb = eg.within_matrix(T, pmap, B, tb)
        f = eg.floor_matrix(T, pmap, A, fs[A], B, fs[B])
        out[A + "_x_" + B] = eg.estimators_from_arrays(c, wa, wb, f, ip, jp, ia, ja, None, None, None, min_den)
    return out


def secondary_measure(cfg, name, prep, sim, design, Zmap, cov, clusters, modes, n_boot):
    an = cfg["analysis"]
    pairs = design.pairs()
    pmap = {p: i for i, p in enumerate(pairs)}
    inv, G = al.cluster_inverse(clusters)
    n = len(clusters)
    members = [np.where(inv == g)[0] for g in range(G)]
    res = {}
    for mode in modes:
        t0 = time.time()
        Zres = {nm: al.residualize(Zmap[nm], cov, mode) for nm in design.nets()}
        T0 = pair_table(Zres, np.arange(n), pairs, prep, sim)[None, :]
        pt = estimators_for(T0, design, pmap, float(an["min_denominator"]))
        rng = np.random.default_rng([int(an["boot_seed"]), 4242])
        Tb = np.zeros((n_boot, len(pairs)))
        for b in range(n_boot):
            draw = rng.integers(0, G, size=G)
            rows = np.unique(np.concatenate([members[g] for g in np.unique(draw)]))
            Tb[b] = pair_table(Zres, rows, pairs, prep, sim)
            if (b + 1) % 25 == 0:
                C.log("  %s/%s: %d of %d draws (%.0fs)" % (name, mode, b + 1, n_boot, time.time() - t0))
        bt = estimators_for(Tb, design, pmap, float(an["min_denominator"]))
        res[mode] = {}
        for key, ests in pt.items():
            rec = {}
            for en, d in ests.items():
                lo, hi, fr = eg.interval(bt[key][en]["nab"], float(an["ci_level"]), float(an["max_undefined_fraction"]))
                rec[en] = {q: (float(v[0]) if np.isfinite(v[0]) else None) for q, v in d.items()}
                rec[en]["ci_complex"] = [lo, hi]
                rec[en]["frac_undef"] = fr
            res[mode][key] = rec
        C.log("  %s/%s done in %.0fs" % (name, mode, time.time() - t0))
    return res


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--skip_pc", action="store_true")
    ap.add_argument("--skip_rsa_cca", action="store_true")
    ap.add_argument("--n_boot", type=int, default=None, help="override draws (smoke tests only)")
    ap.add_argument("--floor_set", default=None)
    a = ap.parse_args()
    cfg = C.load_cfg()
    C.ensure_dirs(cfg)
    C.verify_lock(cfg)
    core = C.core_ids(cfg)
    cov = C.load_covariates(cfg, core)
    clusters = C.load_clusters(cfg, core)
    failed = C.failed_seed_tags(cfg)
    floor_set = a.floor_set or cfg["analysis"]["headline_floor_set"]
    have_regen = all(proj_path(cfg, "gnina", t).exists() for t in cfg["floors"]["regen_tags"])
    design = build_design(cfg, failed, False, have_regen, only_set=floor_set)
    Zmap = {nm: load_proj(cfg, nm.split("/", 1)[0], nm.split("/", 1)[1]) for nm in design.nets()}
    C.log("trained networks: %s; floor set: %s" % (design.trained, floor_set))
    if a.n_boot is not None:
        C.log("WARNING: draws overridden to %d; smoke test only" % a.n_boot)

    if not a.skip_pc:
        out = pc_removal(cfg, core, cov, clusters, design, Zmap, floor_set, a.n_boot)
        out["stamp"] = C.stamp()
        out["failed_seeds"] = failed
        C.json_dump(out, cfg["_out"] / "results" / "pc_removal.json")
        C.log("wrote results/pc_removal.json")
    if not a.skip_rsa_cca:
        pr = cfg["pc_removal"]
        nb = int(a.n_boot if a.n_boot is not None else pr["rsa_cca_n_boot"])
        modes = list(pr["modes"])
        res = dict(stamp=C.stamp(), floor_set=floor_set, n_boot=nb, failed_seeds=failed, trained=design.trained,
                   note="Secondary measures. Bootstrap draws use the rows of the drawn clusters, each row once.")
        res["rsa_spearman"] = secondary_measure(cfg, "rsa", prep_rsa, sim_rsa, design, Zmap, cov, clusters, modes, nb)
        res["cca_top_k"] = secondary_measure(cfg, "cca", prep_cca, make_sim_cca(int(pr["cca_top_k"])), design, Zmap,
                                             cov, clusters, modes, nb)
        res["cca_k"] = int(pr["cca_top_k"])
        C.json_dump(res, cfg["_out"] / "results" / "rsa_cca.json")
        C.log("wrote results/rsa_cca.json")


if __name__ == "__main__":
    main()
