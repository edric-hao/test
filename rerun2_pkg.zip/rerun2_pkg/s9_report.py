#!/usr/bin/env python
"""s9_report.py  --  CPU box. Turn the JSON results into tables (CSV and one Markdown file) and figures (PNG).

Every table and figure is labeled "added after review". Sections whose result file is missing are skipped with a note.
Reading rule used in the tables (pre-registered): an interval that contains zero is called "uninformative"; an interval that
is None is "undefined" (too many bootstrap draws had ceiling minus floor below the minimum denominator).

Output: rerun_out/report/report_rerun.md plus the tables folder (csv files) and the figures folder (png files)
"""
import json

import numpy as np
import pandas as pd

import common as C
from mathx import mul

LABEL = "Added after review"


def rd(cfg, name):
    p = cfg["_out"] / "results" / name
    return json.loads(p.read_text()) if p.exists() else None


def fmt(x, nd=3):
    if x is None or (isinstance(x, float) and not np.isfinite(x)):
        return "NA"
    return ("%." + str(nd) + "f") % x


def ci_str(ci):
    if ci is None or ci[0] is None:
        return "undefined"
    return "[%s, %s]" % (fmt(ci[0]), fmt(ci[1]))


def reading(ci):
    if ci is None or ci[0] is None:
        return "undefined"
    if ci[0] <= 0.0 <= ci[1]:
        return "uninformative (CI includes zero)"
    return "CI excludes zero"


def md_table(df):
    cols = list(df.columns)
    lines = ["| " + " | ".join(cols) + " |", "|" + "|".join(["---" for _ in cols]) + "|"]
    for _, r in df.iterrows():
        lines.append("| " + " | ".join("" if (isinstance(v, float) and not np.isfinite(v)) else str(v) for v in r.values) + " |")
    return "\n".join(lines)


def save_table(cfg, name, df, md, title, note=None):
    d = cfg["_out"] / "report" / "tables"
    d.mkdir(parents=True, exist_ok=True)
    df.to_csv(d / (name + ".csv"), index=False)
    md.append("\n### %s  (%s)\n" % (title, LABEL))
    if note:
        md.append(note + "\n")
    md.append(md_table(df))


def table_gate(cfg, md):
    man = C.read_new_seed_manifest(cfg)
    if not man:
        md.append("\n(no new_seed_manifest.json: seed training not run)\n")
        return
    rows = []
    for k, v in sorted(man.items()):
        rows.append(dict(arch=v["arch"], tag=v["tag"], seed=v.get("seed"), val_r=fmt(v.get("val_pearson_r")),
                         untrained_val_r=fmt(v.get("untrained_val_pearson_r")), test_r=fmt(v.get("test_pearson_r")),
                         best_epoch=v.get("best_epoch"), gate="PASS" if v.get("gate_pass") else "FAIL"))
    save_table(cfg, "seed_gate", pd.DataFrame(rows), md, "Table A1. Validation gate for the added seeds",
               "Gate: validation r >= 0.4 and at least 0.10 above the untrained network. Failures are reported, never retrained.")


def table_main(cfg, sa, md):
    rows = []
    for mode, byp in sa["results"].items():
        for pk, bys in byp.items():
            for sname, rec in bys.items():
                for en, e in rec["estimators"].items():
                    rows.append(dict(mode=mode, pair=pk, floor_set=sname, estimator=en,
                                     role="primary" if en == sa["primary_estimator"] else "sensitivity",
                                     observed=fmt(e.get("obs")), floor=fmt(e.get("floor")), ceiling=fmt(e.get("ceil")),
                                     nAB=fmt(e.get("nab")), ci_complex=ci_str(e.get("ci_complex")),
                                     reading_complex=reading(e.get("ci_complex")),
                                     ci_two_level=ci_str(e.get("ci_two_level")) if "ci_two_level" in e else "",
                                     reading_two_level=reading(e.get("ci_two_level")) if "ci_two_level" in e else ""))
    df = pd.DataFrame(rows)
    save_table(cfg, "seed_aware_main", df, md, "Table A2. Alignment with five seeds per architecture",
               "Primary estimator: the published rule (primary x primary, ceiling from the primary x anchor pair). Seed-aware estimators "
               "are sensitivity analyses. ci_complex resamples protein clusters; ci_two_level also resamples networks and untrained "
               "initializations. Failed seeds excluded: %s." % (sa["failed_seeds"] or "none"))
    if "with_failed" in sa:
        rows2 = []
        for mode, byp in sa["with_failed"]["results"].items():
            for pk, bys in byp.items():
                for sname, rec in bys.items():
                    e = rec["estimators"]["seed_min"]
                    rows2.append(dict(mode=mode, pair=pk, floor_set=sname, nAB_seed_min=fmt(e.get("nab")),
                                      ci_two_level=ci_str(e.get("ci_two_level"))))
        save_table(cfg, "seed_aware_with_failed", pd.DataFrame(rows2), md, "Table A2b. Same analysis with failed seeds included")
    return df


def table_seed_pairs(cfg, sa, md):
    rows = []
    mode = "raw"
    for pk, bys in sa["results"][mode].items():
        rec = next(iter(bys.values()))
        ta, tb = rec["tags_A"], rec["tags_B"]
        for i, x in enumerate(ta):
            for j, y in enumerate(tb):
                rows.append(dict(pair=pk, seed_A=x, seed_B=y, raw_cka=fmt(rec["cross"][i][j]),
                                 nAB_given_seed_min_floor_ceiling=fmt(rec["nab_by_combo_seed_min"][i][j])))
    save_table(cfg, "seed_pair_values", pd.DataFrame(rows), md, "Table A3. Every seed pair (raw CKA and n_AB)",
               "n_AB here uses the seed-averaged floor and ceiling (seed_min), so pairs are comparable.")


def table_floor(cfg, sa, md):
    rows = []
    mode = "raw"
    for pk, bys in sa["results"][mode].items():
        for sname, rec in bys.items():
            f = np.array(rec["floors"], dtype=float)
            rows.append(dict(pair=pk, floor_set=sname, floor_tags_A=",".join(rec["floor_tags_A"]),
                             floor_tags_B=",".join(rec["floor_tags_B"]),
                             values=" ".join(fmt(x) for x in f), mean=fmt(f.mean()), sd=fmt(f.std(ddof=1)),
                             min=fmt(f.min()), max=fmt(f.max())))
    save_table(cfg, "floors_individual", pd.DataFrame(rows), md, "Table A4. Matched untrained floors, individual values and spread (raw)")
    reg = rd(cfg, "gnina_floor_regen.json")
    if reg:
        rr = []
        for tag, v in reg.items():
            if tag.startswith("_"):
                continue
            rr.append(dict(tag=tag, seed=v["seed"], valid=v["valid"], val_r_untrained=fmt(v["val_pearson_r"]),
                           extract_device=v["extract_device"]))
        save_table(cfg, "gnina_regen_validation", pd.DataFrame(rr), md, "Table A5. Regenerated GNINA untrained references: validation",
                   "Init 1 versus the originally saved untrained embeddings: %s" % reg.get("_init1_vs_saved_untrained"))
    rep = sa.get("gnina_floor_report", {})
    if rep.get("old_init_k_vs_regen_init_k"):
        rr = [dict(old_vs_regen=k, raw_cka=fmt(v)) for k, v in rep["old_init_k_vs_regen_init_k"].items()]
        save_table(cfg, "gnina_old_vs_regen", pd.DataFrame(rr), md, "Table A6. CKA between each original and regenerated GNINA untrained initialization")


def table_pc(cfg, md):
    pc = rd(cfg, "positive_control.json")
    if pc is None:
        pc = rd(cfg, "positive_control_QUICK.json")
        if pc is not None:
            md.append("\nWARNING: positive-control numbers below come from the QUICK smoke run, not the registered run.\n")
    if pc is None:
        md.append("\n(positive control not run)\n")
        return None
    rows = []
    for r in pc["summary"]:
        if r["estimator"] not in ("orig", "seed_min"):
            continue
        rows.append(dict(condition=r["cond"], rho=r["rho"], mode=r["mode"], estimator=r["estimator"], n_reps=r["n_reps"],
                         truth_in_mode=fmt(r["truth_mode"]), truth_signal_only=fmt(r["truth_signal"]),
                         mean_estimate=fmt(r["mean_estimate"]), bias_vs_signal=fmt(r["bias_vs_truth_signal"]),
                         rmse=fmt(r["rmse_vs_truth_mode"]),
                         coverage_complex=fmt(r["coverage_complex_truth_mode"], 2),
                         coverage_two_level=fmt(r["coverage_two_level_truth_mode"], 2),
                         ci_contains_zero_complex=fmt(r["frac_ci_complex_contains_zero"], 2)))
    save_table(cfg, "positive_control", pd.DataFrame(rows), md, "Table A7. Positive control: recovered versus planted n_AB",
               "truth_in_mode keeps the size factors the mode does not remove; truth_signal_only is the planted protein-level alignment. "
               "Coverage is the share of repeated simulations whose 95 percent interval contains truth_in_mode.")
    if pc.get("real_spike_in"):
        rows = []
        for r in pc["real_spike_in"]:
            e = r["estimators"]["orig"]
            rows.append(dict(lam=r["lam"], rep=r["rep"], mode=r["mode"], nAB=fmt(e.get("nab")), ci=ci_str(e.get("ci_complex"))))
        df = pd.DataFrame(rows)
        save_table(cfg, "spike_in", df, md, "Table A8. Planted signal added to the real egnn and distance_gnn embeddings (no analytic truth)")
    return pc


def fig_pc(cfg, pc, md):
    if pc is None:
        return
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    modes = [m for m in ("raw", "resid_linear", "resid_poly2") if any(r["mode"] == m for r in pc["summary"])]
    conds = pc["conditions"]
    fig, axes = plt.subplots(1, len(modes), figsize=(mul(4.2, len(modes)), 4.2), sharex=True, sharey=True, squeeze=False)
    colors = dict(zip(conds, ["#555555", "#1b9e77", "#d95f02", "#7570b3"]))
    for ax, mode in zip(axes[0], modes):
        for cond in conds:
            pts = [r for r in pc["summary"] if r["mode"] == mode and r["cond"] == cond and r["estimator"] == "seed_min"
                   and r["mean_estimate"] is not None]
            if not pts:
                continue
            ax.errorbar([r["truth_signal"] for r in pts], [r["mean_estimate"] for r in pts],
                        yerr=[r["sd_estimate"] for r in pts], fmt="o", ms=4, capsize=2, color=colors[cond], label=cond)
        ax.plot([0, 1], [0, 1], color="black", lw=0.8, ls="--")
        ax.set_title(mode)
        ax.set_xlabel("planted n_AB (signal only)")
    axes[0][0].set_ylabel("recovered n_AB (seed_min), mean and sd over simulations")
    axes[0][0].legend(fontsize=7, loc="upper left")
    fig.suptitle("Positive control, " + LABEL.lower(), fontsize=9)
    fig.tight_layout()
    d = cfg["_out"] / "report" / "figures"
    d.mkdir(parents=True, exist_ok=True)
    fig.savefig(d / "positive_control_recovered_vs_planted.png", dpi=200)
    plt.close(fig)
    md.append("\n![recovered vs planted](figures/positive_control_recovered_vs_planted.png)\n")


def fig_forest(cfg, df, md):
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    sub = df[(df["floor_set"] == "orig") & (df["estimator"].isin(["orig", "seed_min"]))]
    if sub.empty:
        return
    fig, ax = plt.subplots(figsize=(7, mul(0.32, len(sub)) + 1.5))
    labels = []
    for i, (_, r) in enumerate(sub.iterrows()):
        ci = r["ci_two_level"] if r["estimator"] == "seed_min" else r["ci_complex"]
        labels.append("%s | %s | %s" % (r["pair"], r["mode"], r["estimator"]))
        try:
            lo, hi = [float(x) for x in ci.strip("[]").split(",")]
        except ValueError:
            lo = hi = np.nan
        y = len(sub) - i
        ax.plot([lo, hi], [y, y], color="black", lw=1)
        if r["nAB"] != "NA":
            ax.plot([float(r["nAB"])], [y], "o", color="C0")
    ax.axvline(0, color="grey", lw=0.8)
    ax.axvline(1, color="grey", lw=0.8, ls=":")
    ax.set_yticks(range(len(sub), 0, -1))
    ax.set_yticklabels(labels, fontsize=6)
    ax.set_xlabel("n_AB with 95 percent interval (orig: cluster; seed_min: two-level)")
    ax.set_title("Alignment estimates, " + LABEL.lower(), fontsize=9)
    fig.tight_layout()
    d = cfg["_out"] / "report" / "figures"
    d.mkdir(parents=True, exist_ok=True)
    fig.savefig(d / "nab_forest.png", dpi=200)
    plt.close(fig)
    md.append("\n![n_AB estimates](figures/nab_forest.png)\n")


def table_pc_removal(cfg, md):
    pr = rd(cfg, "pc_removal.json")
    if pr is None:
        md.append("\n(PC removal not run)\n")
        return
    rows = []
    for drop, byd in pr["drops"].items():
        for mode, byp in byd.items():
            for pk, bys in byp.items():
                for sname, rec in bys.items():
                    for en in ("orig", "seed_min"):
                        e = rec["estimators"][en]
                        rows.append(dict(pcs_removed=drop, mode=mode, pair=pk, estimator=en, observed=fmt(e.get("obs")),
                                         floor=fmt(e.get("floor")), ceiling=fmt(e.get("ceil")), nAB=fmt(e.get("nab")),
                                         ci_complex=ci_str(e.get("ci_complex")), reading=reading(e.get("ci_complex"))))
    save_table(cfg, "pc_removal", pd.DataFrame(rows), md, "Table A9. n_AB after removing leading principal coordinates",
               "Diagnostic. Floor set: %s." % pr.get("floor_set"))
    rows = [dict(network=k, pc1_variance_share=fmt(v["variance_share_pc1"]), first3_variance_share=fmt(v["variance_share_first3"]),
                 abs_corr_pc1_covariates=" ".join(fmt(x, 2) for x in v["abs_corr_pc1_with_covariates"]))
            for k, v in pr["pc_diagnostics"].items()]
    save_table(cfg, "pc_diagnostics", pd.DataFrame(rows), md, "Table A10. Leading coordinates: variance share and association with size")


def table_rsa_cca(cfg, md):
    rc = rd(cfg, "rsa_cca.json")
    if rc is None:
        md.append("\n(RSA and CCA not run)\n")
        return
    rows = []
    for meas in ("rsa_spearman", "cca_top_k"):
        for mode, byp in rc[meas].items():
            for pk, ests in byp.items():
                for en in ("orig", "seed_min"):
                    e = ests[en]
                    rows.append(dict(measure=meas, mode=mode, pair=pk, estimator=en, observed=fmt(e.get("obs")),
                                     floor=fmt(e.get("floor")), ceiling=fmt(e.get("ceil")), nAB=fmt(e.get("nab")),
                                     ci_complex=ci_str(e.get("ci_complex")), reading=reading(e.get("ci_complex"))))
    save_table(cfg, "rsa_cca", pd.DataFrame(rows), md, "Table A11. RSA and CCA as secondary measures",
               "Diagnostics, not independent confirmation. %d bootstrap draws. CCA = mean of the first %s canonical correlations." % (rc["n_boot"], rc.get("cca_k")))


def table_strat(cfg, md):
    st = rd(cfg, "size_stratified.json")
    if st is None:
        md.append("\n(size-stratified analysis not run)\n")
        return
    rows = []
    for s, info in st["strata"].items():
        for mode, byp in info["results"].items():
            for pk, bys in byp.items():
                for sname, rec in bys.items():
                    for en in ("orig", "seed_min"):
                        e = rec["estimators"][en]
                        rows.append(dict(stratum=s, ligand_size_range="%g to %g" % (info["size_min"], info["size_max"]),
                                         n_complexes=info["n_complexes"], n_clusters=info["n_clusters"], mode=mode, pair=pk,
                                         estimator=en, observed=fmt(e.get("obs")), nAB=fmt(e.get("nab")),
                                         ci_complex=ci_str(e.get("ci_complex")), reading=reading(e.get("ci_complex")),
                                         warning=info.get("warning", "")))
    save_table(cfg, "size_stratified", pd.DataFrame(rows), md, "Table A12. Alignment within ligand-size strata (exploratory)",
               "The number of protein clusters per stratum is shown; intervals with few clusters are unreliable.")


def main():
    cfg = C.load_cfg()
    C.ensure_dirs(cfg)
    (cfg["_out"] / "report").mkdir(parents=True, exist_ok=True)
    md = ["# Runs added after review", "",
          "All numbers below come from runs added after review under the pre-registered file config_rerun.yaml "
          "(lock: PREREG_RERUN_LOCK.json). The published estimator is the primary analysis; seed-aware estimators, "
          "RSA, CCA, PC removal and size strata are sensitivity or diagnostic analyses."]
    lock = C.lock_path(cfg)
    if lock.exists():
        md.append("\nLock written %s; config_rerun.yaml sha256 %s." % (json.loads(lock.read_text())["locked_utc"],
                                                                  json.loads(lock.read_text())["config_rerun_sha256"][:16]))
    rg = rd(cfg, "regression_gate.json")
    if rg:
        md.append("\nRegression gate (recomputing the published two-seed numbers): %d checks, %d outside tolerance %.4f, worst difference %s."
                  % (rg["n_checks"], rg["n_failed"], rg["tolerance"], fmt(rg["worst_abs_diff"], 5)))
    table_gate(cfg, md)
    sa = rd(cfg, "seed_analysis.json")
    if sa:
        df = table_main(cfg, sa, md)
        table_seed_pairs(cfg, sa, md)
        table_floor(cfg, sa, md)
        fig_forest(cfg, df, md)
    else:
        md.append("\n(seed-aware analysis not run)\n")
    pc = table_pc(cfg, md)
    fig_pc(cfg, pc, md)
    table_pc_removal(cfg, md)
    table_rsa_cca(cfg, md)
    table_strat(cfg, md)
    out = cfg["_out"] / "report" / "report_rerun.md"
    out.write_text("\n".join(md) + "\n")
    C.log("wrote %s" % out)


if __name__ == "__main__":
    main()
