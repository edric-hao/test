"""Arithmetic helpers.

The whole package avoids the asterisk character on purpose, because asterisks
get eaten when code is copy-pasted through chat apps. Use these helpers for
multiplication and powers instead of the usual operators.
"""
import operator

import numpy as np


def mul(a, b):
    """Elementwise or scalar product."""
    return operator.mul(a, b)


def sq(x):
    """Square of a scalar or an array."""
    return np.square(x)


def prod(values):
    """Product of an iterable of numbers."""
    out = 1.0
    for v in values:
        out = operator.mul(out, v)
    return out
