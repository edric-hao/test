#!/usr/bin/env python
"""r2_c3_seed_size_content.py  --  CPU box. Does a network's size content explain its alignment? Also tabulates the
size-residualized ceilings across the five seeds of each architecture (from the round 1 analysis).

For every trained and untrained network of round 1 it measures
  - the share of embedding variance explained by the size covariates (linear and quadratic design),
  - R squared of the first principal coordinate on the size covariates,
  - the debiased linear CKA between the embedding and the size covariates themselves.
Then, per architecture, it relates each trained seed's size content to the mean CKA of that seed with the other architectures
and with its own architecture's other seeds (Spearman over seeds, descriptive).

Output: results/seed_size_content.json, report/seed_size_content.md
"""
import numpy as np

import alignlib2 as al
import common as C
import engine as eg
import r2lib as R


def main():
    cfg = R.load_cfg2()
    C.ensure_dirs(cfg)
    C.verify_lock(cfg)
    core = C.core_ids(cfg)
    cov = C.load_covariates(cfg, core)
    trained = R.round1_trained(cfg)
    floors = {a: list(cfg["floors"]["orig_tags"]) for a in cfg["archs"]}
    nets = []
    for arch in cfg["archs"]:
        nets += ["%s/%s" % (arch, t) for t in trained[arch] + floors[arch]]
    Zmap = {nm: R.load_Z(cfg, R.split_net(nm)[0], R.split_net(nm)[1]) for nm in nets}
    D_lin = al.covariate_design(cov, "resid_linear")
    D_pol = al.covariate_design(cov, "resid_poly2")
    grams = {nm: al.gram_zero_diag(Zmap[nm]) for nm in nets}
    grams["__size__"] = al.gram_zero_diag(cov)
    bank = al.GramBank(grams)
    content = {}
    for nm in nets:
        Z = Zmap[nm]
        Zc = Z - Z.mean(axis=0, keepdims=True)
        tot = float(np.sum(np.square(Zc)))
        rl = R.resid_on(Zc, D_lin)
        rp = R.resid_on(Zc, D_pol)
        pc1 = Zc[:, 0:1]
        r1 = R.resid_on(pc1, D_lin)
        content[nm] = dict(
            share_linear=1.0 - float(np.sum(np.square(rl))) / tot,
            share_poly2=1.0 - float(np.sum(np.square(rp))) / tot,
            pc1_r2_linear=1.0 - float(np.sum(np.square(r1))) / float(np.sum(np.square(pc1))),
            cka_with_size=float(bank.cka_point([(nm, "__size__")] if nm < "__size__" else [("__size__", nm)])[0]))
    # CKA of every trained network with every other trained network (raw)
    tr_names = {a: ["%s/%s" % (a, t) for t in trained[a]] for a in cfg["archs"]}
    pairs = []
    for a in cfg["archs"]:
        for b in cfg["archs"]:
            for x in tr_names[a]:
                for y in tr_names[b]:
                    if x != y:
                        pairs.append(eg.canon(x, y))
    pairs = list(dict.fromkeys(pairs))
    vals = dict(zip(pairs, bank.cka_point(pairs)))

    def cka(x, y):
        return float(vals[eg.canon(x, y)])
    rel = {}
    for a in cfg["archs"]:
        rows = []
        for x in tr_names[a]:
            same = [cka(x, y) for y in tr_names[a] if y != x]
            cross = [cka(x, y) for b in cfg["archs"] if b != a for y in tr_names[b]]
            rows.append(dict(net=x, size_content=content[x]["share_linear"], cka_with_size=content[x]["cka_with_size"],
                             mean_within=float(np.mean(same)), mean_cross=float(np.mean(cross))))
        sc = [r["size_content"] for r in rows]
        rel[a] = dict(rows=rows,
                      spearman_size_vs_within=R.spearman(sc, [r["mean_within"] for r in rows]),
                      spearman_size_vs_cross=R.spearman(sc, [r["mean_cross"] for r in rows]),
                      pearson_size_vs_within=R.pearson(sc, [r["mean_within"] for r in rows]),
                      pearson_size_vs_cross=R.pearson(sc, [r["mean_cross"] for r in rows]))
    # ceilings across seeds in every mode, from the round 1 analysis
    r1j = R.read_json(cfg["_out1"] / "results" / "seed_analysis.json")
    ceil = {}
    for mode, per_pair in r1j["results"].items():
        ceil[mode] = {}
        for arch, key, which in (("egnn", "egnn_x_gnina", "within_A"), ("gnina", "egnn_x_gnina", "within_B"),
                                 ("distance_gnn", "egnn_x_distance_gnn", "within_B")):
            rec = per_pair[key]["orig"]
            w = np.array(rec[which], dtype=np.float64)
            tags = rec["tags_A"] if which == "within_A" else rec["tags_B"]
            iu = np.triu_indices(w.shape[0], 1)
            ceil[mode][arch] = dict(mean=float(np.nanmean(w[iu])), min=float(np.nanmin(w[iu])), max=float(np.nanmax(w[iu])),
                                    tags=tags, matrix=w.tolist())
    out = dict(stamp=C.stamp(), label="added_after_review_round2", content=content, relation=rel, ceilings_by_mode=ceil)
    C.json_dump(out, cfg["_out"] / "results" / "seed_size_content.json")

    lines = ["# Size content of each network and size-residualized ceilings (added after review, round 2)", ""]
    rows = []
    for nm in nets:
        c = content[nm]
        rows.append([nm, R.fnum(c["share_linear"]), R.fnum(c["share_poly2"]), R.fnum(c["pc1_r2_linear"]), R.fnum(c["cka_with_size"])])
    lines.append("## Size content per network (PCA-64 test projections)")
    lines.append(R.md_table(["network", "variance share (linear size)", "variance share (quadratic size)", "R2 of PC1 on size", "CKA with size covariates"], rows))
    lines.append("")
    rows = []
    for a, r in rel.items():
        for q in r["rows"]:
            rows.append([a, q["net"], R.fnum(q["size_content"]), R.fnum(q["mean_within"]), R.fnum(q["mean_cross"])])
        rows.append([a, "Spearman over seeds (size vs within, size vs cross)", R.fnum(r["spearman_size_vs_within"]),
                     R.fnum(r["spearman_size_vs_cross"]), ""])
    lines.append("## Seed size content versus alignment")
    lines.append(R.md_table(["architecture", "network", "size content", "mean within-architecture CKA", "mean cross-architecture CKA"], rows))
    lines.append("")
    rows = []
    for mode, per in ceil.items():
        for arch, rec in per.items():
            rows.append([mode, arch, R.fnum(rec["mean"]), R.fnum(rec["min"]), R.fnum(rec["max"])])
    lines.append("## Seed ceilings (mean within-architecture CKA over the seed pairs) by residualization mode")
    lines.append(R.md_table(["mode", "architecture", "mean", "min", "max"], rows))
    R.write_report(cfg, "seed_size_content", "\n".join(lines) + "\n")


if __name__ == "__main__":
    main()
