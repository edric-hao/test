"""Seed-aware n_AB engine.

Given PCA-64 test projections for every network, this builds Gram matrices for each
transform (raw, linear residualized, quadratic residualized), computes debiased CKA
for every pair that any estimator needs, under (a) the full sample and (b) cluster
bootstrap weights, then derives three estimators.

Estimators (all use floor = mean over matched untrained pairs k with k)
  orig       primary x primary observed CKA, ceiling = min over the two
             same-architecture primary x anchor CKAs. This is the published rule.
  seed_min   observed = mean over all trained seed pairs across architectures,
             ceiling_A = mean over all distinct same-architecture seed pairs,
             ceiling = min(ceiling_A, ceiling_B)
  seed_geo   same observed and ceiling_A, ceiling = sqrt(ceiling_A x ceiling_B)

n_AB = (observed - floor) / (ceiling - floor), undefined when ceiling - floor < min_den.

Intervals
  ci_complex   resamples protein clusters only (networks held fixed)
  ci_two_level resamples protein clusters AND networks: trained networks are redrawn
               with replacement within each architecture (pairs of the same network
               are dropped from the ceiling), and untrained initializations are redrawn
               with replacement. This respects the dependence between seed pairs that
               reuse the same network.
An interval is reported only if at most max_undef_frac of draws are undefined.
"""
import time

import numpy as np

import alignlib2 as al
from mathx import mul


def net_name(arch, tag):
    return str(arch) + "/" + str(tag)


def canon(a, b):
    return (a, b) if a <= b else (b, a)


class Design:
    """Which networks exist.

    trained    dict arch -> list of tags (put primary and anchor in the list if present)
    floor_sets dict set_name -> dict arch -> list of untrained tags (same length for all archs)
    arch_pairs list of (archA, archB)
    """

    def __init__(self, arch_pairs, trained, floor_sets):
        self.arch_pairs = [tuple(p) for p in arch_pairs]
        self.trained = {a: list(t) for a, t in trained.items()}
        self.floor_sets = {s: {a: list(t) for a, t in d.items()} for s, d in floor_sets.items()}
        for s, d in self.floor_sets.items():
            lens = set(len(v) for v in d.values())
            if len(lens) != 1:
                raise ValueError("floor set " + s + " has unequal numbers of inits across architectures")

    def nets(self):
        out = []
        for a, tags in self.trained.items():
            out += [net_name(a, t) for t in tags]
        for s, d in self.floor_sets.items():
            for a, tags in d.items():
                out += [net_name(a, t) for t in tags]
        seen, uniq = set(), []
        for n in out:
            if n not in seen:
                seen.add(n)
                uniq.append(n)
        return uniq

    def pairs(self):
        ps = []
        for (A, B) in self.arch_pairs:
            for ta in self.trained[A]:
                for tb in self.trained[B]:
                    ps.append(canon(net_name(A, ta), net_name(B, tb)))
            for X in (A, B):
                tags = self.trained[X]
                for i in range(len(tags)):
                    for j in range(i + 1, len(tags)):
                        ps.append(canon(net_name(X, tags[i]), net_name(X, tags[j])))
            for s, d in self.floor_sets.items():
                for ua, ub in zip(d[A], d[B]):
                    ps.append(canon(net_name(A, ua), net_name(B, ub)))
        seen, uniq = set(), []
        for p in ps:
            if p not in seen:
                seen.add(p)
                uniq.append(p)
        return uniq


# ----------------------------------------------------------------------------
# helpers on the pair table
# ----------------------------------------------------------------------------
def _col(T, pmap, x, y):
    return T[:, pmap[canon(x, y)]]


def cross_matrix(T, pmap, A, tags_a, B, tags_b):
    out = np.zeros((T.shape[0], len(tags_a), len(tags_b)))
    for i, ta in enumerate(tags_a):
        for j, tb in enumerate(tags_b):
            out[:, i, j] = _col(T, pmap, net_name(A, ta), net_name(B, tb))
    return out


def within_matrix(T, pmap, A, tags):
    K = len(tags)
    out = np.full((T.shape[0], K, K), np.nan)
    for i in range(K):
        for j in range(i + 1, K):
            v = _col(T, pmap, net_name(A, tags[i]), net_name(A, tags[j]))
            out[:, i, j] = v
            out[:, j, i] = v
    return out


def floor_matrix(T, pmap, A, tags_a, B, tags_b):
    out = np.zeros((T.shape[0], len(tags_a)))
    for k, (ua, ub) in enumerate(zip(tags_a, tags_b)):
        out[:, k] = _col(T, pmap, net_name(A, ua), net_name(B, ub))
    return out


def _gather_cross(cross, sA, sB):
    ar = np.arange(cross.shape[0])[:, None, None]
    return cross[ar, sA[:, :, None], sB[:, None, :]]


def _gather_within(w, s):
    ar = np.arange(w.shape[0])[:, None, None]
    return w[ar, s[:, :, None], s[:, None, :]]


def _nanmean_axes12(x):
    tot = np.nansum(x, axis=(1, 2))
    cnt = np.sum(np.isfinite(x), axis=(1, 2))
    return np.where(cnt > 0, np.divide(tot, np.maximum(cnt, 1)), np.nan)


def nab_value(obs, floor, ceil, min_den):
    den = ceil - floor
    ok = np.isfinite(den) & np.isfinite(obs) & np.isfinite(floor) & (den >= min_den)
    return np.where(ok, np.divide(obs - floor, np.where(ok, den, 1.0)), np.nan)


def estimators_from_arrays(cross, wA, wB, fl, ip, jp, ia, ja, sA, sB, kidx, min_den):
    """All inputs carry a leading batch dimension B.

    cross (B,KA,KB), wA (B,KA,KA) NaN diagonal, wB (B,KB,KB), fl (B,F).
    ip, jp  index of primary in A and B lists (or None); ia, ja index of anchor.
    sA, sB (B,K) integer network resamples or None; kidx (B,F) init resamples or None.
    Returns dict estimator -> dict(obs, floor, ceil, nab) of (B,) arrays.
    """
    B = cross.shape[0]
    KA, KB = cross.shape[1], cross.shape[2]
    F = fl.shape[1]
    out = {}
    if ip is not None and ia is not None and jp is not None and ja is not None and sA is None:
        obs = cross[:, ip, jp]
        cA = wA[:, ip, ia]
        cB = wB[:, jp, ja]
        floor = fl.mean(axis=1)
        ceil = np.minimum(cA, cB)
        out["orig"] = {"obs": obs, "floor": floor, "ceil": ceil,
                       "nab": nab_value(obs, floor, ceil, min_den)}
    if sA is None:
        sA = np.tile(np.arange(KA), (B, 1))
        sB = np.tile(np.arange(KB), (B, 1))
    if kidx is None:
        kidx = np.tile(np.arange(F), (B, 1))
    crs = _gather_cross(cross, sA, sB)
    obs = crs.mean(axis=(1, 2))
    cA = _nanmean_axes12(_gather_within(wA, sA))
    cB = _nanmean_axes12(_gather_within(wB, sB))
    floor = np.take_along_axis(fl, kidx, axis=1).mean(axis=1)
    ceil_min = np.minimum(cA, cB)
    prod_c = mul(cA, cB)
    ceil_geo = np.sqrt(np.where(prod_c > 0, prod_c, np.nan))
    out["seed_min"] = {"obs": obs, "floor": floor, "ceil": ceil_min,
                       "nab": nab_value(obs, floor, ceil_min, min_den), "cA": cA, "cB": cB}
    out["seed_geo"] = {"obs": obs, "floor": floor, "ceil": ceil_geo,
                       "nab": nab_value(obs, floor, ceil_geo, min_den), "cA": cA, "cB": cB}
    return out


def interval(draws, level, max_undef):
    """Percentile interval over finite draws. Returns (lo, hi, frac_undefined)."""
    x = np.asarray(draws, dtype=np.float64)
    fin = np.isfinite(x)
    frac = float(1.0 - fin.mean()) if x.size else 1.0
    if frac > max_undef or fin.sum() < 20:
        return None, None, frac
    a = (1.0 - level) / 2.0
    lo, hi = np.percentile(x[fin], [mul(100.0, a), mul(100.0, 1.0 - a)])
    return float(lo), float(hi), frac


def _tolist(x):
    return np.asarray(x).tolist()


# ----------------------------------------------------------------------------
# main entry point
# ----------------------------------------------------------------------------
def run_seed_analysis(Zmap, cov, clusters, design, modes, n_boot, boot_seed,
                      rows=None, pc_drop=0, boot_kind="cluster", chunk=256,
                      min_den=0.05, max_undef=0.05, level=0.95, keep_draws=False, log=print,
                      gram_fn=None):
    """Run the full seed-aware analysis.

    Zmap      dict net_name -> (n, d) PCA-64 test projection, rows in core order
    cov       (n, p) covariates, clusters (n,) protein-cluster labels
    rows      optional row subset (strata); statistics, centering and residualization
              are all computed within the subset
    pc_drop   remove the first pc_drop principal coordinates from every network
    gram_fn   optional function Z -> zero-diagonal Gram matrix that replaces the default linear Gram
              (used for kernel-conditioned CKA; None keeps the published behavior)
    """
    n_all = next(iter(Zmap.values())).shape[0]
    rows = np.arange(n_all) if rows is None else np.asarray(rows)
    cov_r = np.asarray(cov)[rows]
    cl_r = np.asarray(clusters)[rows]
    inv, G = al.cluster_inverse(cl_r)
    pairs = design.pairs()
    pmap = {p: i for i, p in enumerate(pairs)}
    nets = design.nets()
    missing = [x for x in nets if x not in Zmap]
    if missing:
        raise KeyError("missing projections for: " + ", ".join(missing))
    rng = np.random.default_rng([int(boot_seed), 99991])
    seed_idx = {a: rng.integers(0, len(t), size=(max(n_boot, 1), len(t)))
                for a, t in design.trained.items()}
    first_set = next(iter(design.floor_sets.values()))
    Fn = len(next(iter(first_set.values())))
    kidx_all = rng.integers(0, Fn, size=(max(n_boot, 1), Fn))

    results = {}
    draws_store = {}
    for mode in modes:
        t0 = time.time()
        grams = {}
        for nm in nets:
            Z = np.asarray(Zmap[nm])[rows][:, pc_drop:]
            Z = al.residualize(Z, cov_r, mode)
            grams[nm] = al.gram_zero_diag(Z) if gram_fn is None else gram_fn(Z)
        bank = al.GramBank(grams)
        T0 = bank.cka_point(pairs)[None, :]
        Tb = None
        if n_boot > 0:
            Tb = np.zeros((n_boot, len(pairs)))
            for b0, M in al.iter_weights(boot_kind, inv, G, n_boot, chunk, boot_seed):
                Tb[b0:b0 + M.shape[1], :] = bank.cka_table(pairs, M, chunk=chunk)
        log("  [%s] tables done in %.1fs (n=%d, pairs=%d, boots=%d)"
            % (mode, time.time() - t0, len(rows), len(pairs), n_boot))
        del bank, grams
        results[mode] = {}
        for (A, B) in design.arch_pairs:
            ta, tb = design.trained[A], design.trained[B]
            ip = ta.index("primary") if ("primary" in ta and "anchor" in ta) else None
            ia = ta.index("anchor") if ip is not None else None
            jp = tb.index("primary") if ("primary" in tb and "anchor" in tb) else None
            ja = tb.index("anchor") if jp is not None else None
            key = A + "_x_" + B
            results[mode][key] = {}
            for sname, fs in design.floor_sets.items():
                fa, fb = fs[A], fs[B]

                def mats(T):
                    return (cross_matrix(T, pmap, A, ta, B, tb),
                            within_matrix(T, pmap, A, ta),
                            within_matrix(T, pmap, B, tb),
                            floor_matrix(T, pmap, A, fa, B, fb))
                c0, wa0, wb0, f0 = mats(T0)
                pt = estimators_from_arrays(c0, wa0, wb0, f0, ip, jp, ia, ja, None, None, None, min_den)
                rec = {"n_rows": int(len(rows)), "n_clusters": int(G), "pc_drop": int(pc_drop),
                       "tags_A": ta, "tags_B": tb, "floor_tags_A": fa, "floor_tags_B": fb,
                       "cross": _tolist(c0[0]), "within_A": _tolist(wa0[0]), "within_B": _tolist(wb0[0]),
                       "floors": _tolist(f0[0]), "estimators": {}}
                for en, d in pt.items():
                    rec["estimators"][en] = {k: (float(v[0]) if np.isfinite(v[0]) else None)
                                             for k, v in d.items()}
                # per seed-combination n_AB using the seed-averaged min ceiling
                cm = pt["seed_min"]
                rec["nab_by_combo_seed_min"] = _tolist(nab_value(
                    c0[0], np.full(c0[0].shape, cm["floor"][0]), np.full(c0[0].shape, cm["ceil"][0]), min_den))
                if n_boot > 0:
                    cb, wab, wbb, fb_ = mats(Tb)
                    bc = estimators_from_arrays(cb, wab, wbb, fb_, ip, jp, ia, ja, None, None, None, min_den)
                    bt = estimators_from_arrays(cb, wab, wbb, fb_, None, None, None, None,
                                                seed_idx[A][:n_boot], seed_idx[B][:n_boot],
                                                kidx_all[:n_boot], min_den)
                    for en in rec["estimators"]:
                        lo, hi, fr = interval(bc[en]["nab"], level, max_undef)
                        rec["estimators"][en]["ci_complex"] = [lo, hi]
                        rec["estimators"][en]["frac_undef_complex"] = fr
                        rec["estimators"][en]["obs_ci_complex"] = list(interval(bc[en]["obs"], level, 1.0)[:2])
                        if en in bt:
                            lo, hi, fr = interval(bt[en]["nab"], level, max_undef)
                            rec["estimators"][en]["ci_two_level"] = [lo, hi]
                            rec["estimators"][en]["frac_undef_two_level"] = fr
                            rec["estimators"][en]["obs_ci_two_level"] = list(interval(bt[en]["obs"], level, 1.0)[:2])
                    if keep_draws:
                        draws_store[mode + "|" + key + "|" + sname + "|seed_min_nab_two_level"] = bt["seed_min"]["nab"]
                        draws_store[mode + "|" + key + "|" + sname + "|seed_min_obs_two_level"] = bt["seed_min"]["obs"]
                        draws_store[mode + "|" + key + "|" + sname + "|seed_min_ceil_two_level"] = bt["seed_min"]["ceil"]
                        draws_store[mode + "|" + key + "|" + sname + "|seed_min_floor_two_level"] = bt["seed_min"]["floor"]
                results[mode][key][sname] = rec
    if keep_draws:
        results["_draws"] = draws_store
    return results
