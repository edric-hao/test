# Pre-registration of the runs added after review

Written before any of these runs were launched. The machine-readable version is config_rerun.yaml; its sha256 is written to
rerun_out/PREREG_RERUN_LOCK.json by s0_lock_and_checks.py before the first run, and every later stage refuses to run if the file
changed. Everything the original locked config.yaml fixed (data split, losses, optimizers, early stopping, embedding layers,
the 2171 core complexes, the 178 protein clusters) is unchanged.

All results from these runs are labeled "added after review" in the paper.

## Runs

1. Extra seeds. Five trained seeds per architecture (EGNN, Distance-GNN, GNINA): the existing primary and anchor plus seed3, seed4,
   seed5 (seed values 20261001, 20261002, 20261003). Same models, hyperparameters, early stopping and extraction as the original runs.
2. Seed-aware analysis on all seed pairs: raw CKA, residualized CKA, and n_AB, in three modes (raw, linear residualization on the two size
   covariates, quadratic residualization without a cross term, as in the published code).
3. Regenerated GNINA untrained references: five initializations (seeds 20260919, 20260924 to 20260927) built by one procedure.
   Individual values and their spread are reported.
4. Positive control on synthetic networks with analytic truth: four conditions (no shared signal, size-independent shared signal,
   size-associated shared signal with linear size, with nonlinear size), five planted levels, 20 repeated simulations per cell,
   300 bootstrap draws. A second check adds a planted signal to the real egnn and distance_gnn embeddings.
5. Diagnostics: removal of the first 0, 1, 3 principal coordinates; RSA (Spearman on Euclidean dissimilarities) and CCA (mean of the
   first 10 canonical correlations) as secondary measures.
6. Optional, exploratory: CKA within three ligand-size strata, with the number of protein clusters per stratum.

## Metrics

- Debiased linear CKA on per-network PCA-64 projections of the test embeddings (PCA fitted on that network's training embeddings).
- n_AB = (observed minus floor) / (ceiling minus floor). Floor: mean over five matched untrained pairs. Ceiling: same-architecture seed similarity.
- Estimators. orig (primary, the published rule): primary x primary observed, ceiling = minimum over the two architectures of the
  primary x anchor similarity. seed_min and seed_geo (sensitivity): observed = mean over all trained seed pairs across architectures,
  ceiling from the mean over all distinct same-architecture seed pairs, combined by the minimum or the geometric mean.
- n_AB is undefined when ceiling minus floor is below 0.05.
- Intervals: percentile, 95 percent, 10000 protein-cluster bootstrap draws (seed 20260920). The two-level interval also redraws trained
  networks (within architecture) and untrained initializations with replacement, which respects the dependence between seed pairs
  that reuse a network. An interval is reported only if at most 5 percent of draws are undefined.

## Exclusions and decision rules

- A new seed passes the gate if validation Pearson r is at least 0.4 and at least 0.10 above the untrained network. A failing seed is
  reported, never retrained, left out of the primary seed-aware analysis, and the analysis is repeated with it included.
- The published estimator is the primary analysis. Seed-aware estimators are sensitivity analyses.
- The two original seeds must reproduce the published numbers within 0.003 (regression gate). If not, the discrepancy is resolved before anything else is reported.
- A GNINA untrained initialization with non-finite or constant embeddings fails validation; the run stops and the failure is reported.
  A mismatch with the originally saved initialization 1 is disclosed, not treated as a failure.
- The positive control validates the measurement procedure on synthetic data. It says nothing about convergence in the real models.
- PC removal, RSA and CCA are diagnostics. Neither is read as independent confirmation. Size-stratified results are exploratory.
- An interval that contains zero is called uninformative. All results are reported whatever they show.

## Writing changes that still apply

- Claims are scoped to calibration in a low-performance regime.
- H3b and pose recovery move to the appendix.
- "Shared objective and stopping rule" replaces "training held fixed".
