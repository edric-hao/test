"""GNINA (Default2018Affinity, random initialization): training, untrained references, extraction.

This is notebooks/notebook_2b_gnina_training_aws_v2.py and notebook_2c_gnina_extraction_aws_v2.py turned
into functions, with the same procedure: setup_gnina_model, reinit_weights on the training device, molgrid
canonical grid, per-epoch seeding, early stopping on validation loss, float64 extraction of the pose-output
layer input. Hyperparameters come from the project's locked config/config.yaml.

Only the GPU box needs this module (torch, molgrid with numpy below 2, gninatorch).
"""
import os
import sys
import time
from pathlib import Path

import numpy as np
import torch
from scipy.stats import pearsonr

import common as C
from mathx import mul


def torch_load(path, map_location="cpu"):
    try:
        return torch.load(path, map_location=map_location, weights_only=False)
    except TypeError:
        return torch.load(path, map_location=map_location)


class GninaContext:
    def __init__(self, cfg, extract_device=None, epoch_seeding="legacy"):
        import molgrid
        from gninatorch.gnina import setup_gnina_model
        self.molgrid = molgrid
        self.setup_gnina_model = setup_gnina_model
        self.cfg = cfg
        if epoch_seeding not in ("legacy", "decoupled"):
            raise SystemExit("epoch_seeding must be legacy or decoupled")
        self.epoch_seeding = epoch_seeding
        self.root = cfg["_root"]
        for p in (str(self.root), str(self.root / "src")):
            if p not in sys.path:
                sys.path.insert(0, p)
        import embed_utils as eu
        self.eu = eu
        self.orig = C.load_original_cfg(cfg)
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        want = extract_device or ("cuda" if torch.cuda.is_available() else "cpu")
        self.extract_device = torch.device(want if (want == "cpu" or torch.cuda.is_available()) else "cpu")
        mc = self.orig["embeddings"]["models"]["gnina"]
        self.cnn = mc["cnn"]
        self.res = mc["grid_resolution_A"]
        self.dim_a = mc["grid_dimension_A"]
        self.expected_dim = mc["dim"]
        self.frozen_layer = mc["layer"]
        if mc.get("orientation") != "fixed_canonical":
            raise SystemExit("config says gnina orientation is not fixed_canonical; this script only implements the canonical path")
        self.hp = self.orig["training"]["gnina"]
        self.aug_translate_a = 2.0
        self.receptor_typer = molgrid.defaultGninaReceptorTyper
        self.ligand_typer = molgrid.defaultGninaLigandTyper
        self.gmaker = molgrid.GridMaker(resolution=self.res, dimension=self.dim_a)
        self.split, _ = C.split_table(cfg)
        self.aff = self.orig["split"]["affinity_column"]
        self.ids = {}
        for sp in ("train", "val", "test"):
            f = C.emb_dir(cfg) / ("gnina_primary_%s_ids.txt" % sp)
            if not f.exists():
                raise SystemExit("missing %s (the original GNINA primary embeddings define the id order)" % f)
            self.ids[sp] = C.read_ids(f)
            want = sorted(self.split.index[self.split["split"] == sp].tolist())
            if set(want) != set(self.ids[sp]):
                C.log("WARNING: %s ids in %s differ from the split table (%d vs %d complexes); "
                      "the saved embeddings define the set used here" % (sp, f.name, len(self.ids[sp]), len(want)))
            elif want != self.ids[sp]:
                C.log("WARNING: %s ids in %s are not in sorted order, which the original types files used; "
                      "training batch order will differ from the original run (rows stay aligned by id)" % (sp, f.name))
        self.types = self._write_types_files()

    # --- types files, written fresh from the ORIGINAL id order and the local PDBbind path ---
    def _pdb_index(self):
        base = self.cfg["_pdbbind_dir"] or Path(self.orig["paths"]["pdbbind_dir"])
        base = Path(base)
        if not base.exists():
            raise SystemExit("PDBbind directory not found: %s. Set PDBBIND_DIR to the folder that holds the PDBbind_2020 complexes." % base)
        idx = {}
        for b in [base] + [d for d in base.iterdir() if d.is_dir() and len(d.name) != 4]:
            for d in b.iterdir():
                if d.is_dir() and len(d.name) == 4:
                    idx[d.name.lower()] = d
        return idx

    def _write_types_files(self):
        idx = self._pdb_index()
        out = {}
        tdir = self.cfg["_out"] / "types"
        tdir.mkdir(parents=True, exist_ok=True)
        for sp in ("train", "val", "test"):
            lines = []
            for pid in self.ids[sp]:
                d = idx.get(pid)
                if d is None:
                    raise SystemExit("no PDBbind directory for %s" % pid)
                pocket = d / (pid + "_pocket.pdb")
                lig = d / (pid + "_ligand.sdf")
                if not lig.exists():
                    lig = d / (pid + "_ligand.mol2")
                if not pocket.exists() or not lig.exists():
                    raise SystemExit("missing pocket or ligand file for %s" % pid)
                lines.append("%s %s %s" % (self.split.loc[pid, self.aff], pocket, lig))
            path = tdir / (sp + ".types")
            path.write_text("\n".join(lines) + "\n")
            out[sp] = path
            C.log("types file %s: %d complexes" % (sp, len(lines)))
        return out

    # --- model ---
    def fresh_arch(self):
        result = self.setup_gnina_model(self.cnn)
        model, is_ens = result if isinstance(result, tuple) else (result, False)
        if is_ens and isinstance(model, (list, tuple)):
            model = model[0]
        return model

    def reinit_weights(self, model, seed):
        torch.manual_seed(seed)
        n = 0
        for m in model.modules():
            if hasattr(m, "reset_parameters"):
                m.reset_parameters()
                n += 1
        C.log("reinitialized %d submodules with reset_parameters() under seed %d" % (n, seed))
        return model

    def make_random_init(self, seed):
        """Exactly train_gnina: fresh architecture moved to the training device, then reinit under the seed."""
        model = self.fresh_arch().to(self.device)
        self.reinit_weights(model, seed)
        return model

    def pick_affinity(self, output):
        if torch.is_tensor(output):
            return output.squeeze(-1) if output.dim() > 1 else output
        if isinstance(output, (tuple, list)):
            cands = [o for o in output if o.dim() >= 1 and (o.dim() == 1 or o.shape[-1] == 1)]
            if len(cands) == 1:
                return cands[0].squeeze(-1) if cands[0].dim() > 1 else cands[0]
            raise RuntimeError("could not uniquely identify the affinity output among %s" % [tuple(o.shape) for o in output])
        raise RuntimeError("unexpected model output type: %s" % type(output))

    # --- data ---
    def make_provider(self, types_path, batch_size, shuffle):
        mg = self.molgrid
        provider = mg.ExampleProvider(self.receptor_typer, self.ligand_typer, default_batch_size=batch_size,
                                      shuffle=shuffle, iteration_scheme=mg.IterationScheme.LargeEpoch)
        provider.populate(str(types_path))
        return provider

    def next_grid_batch(self, provider, batch_size, random_rotation, random_translation):
        batch = provider.next_batch(batch_size)
        dims = self.gmaker.grid_dimensions(provider.num_types())
        grid = torch.zeros((batch_size,) + dims, dtype=torch.float32, device=self.device)
        self.gmaker.forward(batch, grid, random_translation=random_translation, random_rotation=random_rotation)
        labels = torch.zeros(batch_size, dtype=torch.float32, device=self.device)
        batch.extract_label(0, labels)
        return grid, labels

    @torch.no_grad()
    def evaluate(self, model, split_name, batch_size=None):
        batch_size = batch_size or self.hp["batch_size"]
        n_examples = len(self.ids[split_name])
        model.eval()
        provider = self.make_provider(self.types[split_name], batch_size, False)
        preds, trues, seen = [], [], 0
        nb = -(-n_examples // batch_size)
        for _ in range(nb):
            this_bs = min(batch_size, n_examples - seen) if seen + batch_size > n_examples else batch_size
            grid, labels = self.next_grid_batch(provider, batch_size, False, 0.0)
            out = self.pick_affinity(model(grid))
            preds.append(out[:this_bs].cpu().numpy())
            trues.append(labels[:this_bs].cpu().numpy())
            seen += this_bs
            if seen >= n_examples:
                break
        preds = np.concatenate(preds)
        trues = np.concatenate(trues)
        r = float(pearsonr(preds, trues)[0]) if len(preds) > 1 else float("nan")
        mse = float(np.mean(np.square(preds - trues)))
        return dict(val_loss=mse, pearson_r=r, rmse=float(np.sqrt(mse)), n=len(preds))

    def epoch_seed(self, seed, epoch):
        """Seed for the data stream of one epoch.
        legacy     seed plus epoch, exactly what the original training notebook did. Runs whose seeds differ by a few
                   units therefore see the same shuffles and augmentations shifted by a few epochs.
        decoupled  independent stream per (seed, epoch) pair from numpy SeedSequence, so no two runs share a stream.
        """
        if self.epoch_seeding == "legacy":
            return int(seed) + int(epoch)
        return int(np.random.SeedSequence([int(seed), int(epoch)]).generate_state(1)[0] % 2147483647)

    @torch.no_grad()
    def predict(self, model, split_name, batch_size=None):
        """Predictions in id order for one split (same loop as evaluate, returns the arrays)."""
        batch_size = batch_size or self.hp["batch_size"]
        n_examples = len(self.ids[split_name])
        model.eval()
        provider = self.make_provider(self.types[split_name], batch_size, False)
        preds, seen = [], 0
        nb = -(-n_examples // batch_size)
        for _ in range(nb):
            this_bs = min(batch_size, n_examples - seen) if seen + batch_size > n_examples else batch_size
            grid, labels = self.next_grid_batch(provider, batch_size, False, 0.0)
            out = self.pick_affinity(model(grid))
            preds.append(out[:this_bs].cpu().numpy())
            seen += this_bs
            if seen >= n_examples:
                break
        return np.concatenate(preds)

    # --- training (verbatim logic of train_gnina in notebook 2b) ---
    def train_gnina(self, seed, tag):
        hp = self.hp
        ckpt_path = C.ckpt_dir(self.cfg) / ("gnina_%s.pt" % tag)
        C.ckpt_dir(self.cfg).mkdir(parents=True, exist_ok=True)
        model = self.fresh_arch().to(self.device)
        self.reinit_weights(model, seed)
        opt = torch.optim.Adam(model.parameters(), lr=hp["lr"])
        start_epoch, best_val_loss, patience_ctr, history = 0, float("inf"), 0, []
        best_state = None
        if ckpt_path.exists():
            state = torch_load(ckpt_path, self.device)
            model.load_state_dict(state["model"])
            if state.get("finished"):
                C.log("[gnina/%s] already finished (is_best=%s); loaded, not retraining" % (tag, state.get("is_best")))
                return model, {"history": state.get("history", []), "best_val_loss": state.get("best_val_loss"),
                               "epoch": state.get("epoch")}
            if state.get("optimizer") is not None:
                opt.load_state_dict(state["optimizer"])
            start_epoch = state["epoch"] + 1
            best_val_loss = state.get("best_val_loss", float("inf"))
            patience_ctr = state.get("patience_ctr", 0)
            history = state.get("history", [])
            best_state = state.get("best_state")
            C.log("[gnina/%s] resuming from epoch %d (best val_loss=%.4f)" % (tag, start_epoch, best_val_loss))
        n_train = len(self.ids["train"])
        nb_train = max(1, n_train // hp["batch_size"])
        epoch = start_epoch - 1
        mg = self.molgrid
        for epoch in range(start_epoch, hp["max_epochs"]):
            model.train()
            es = self.epoch_seed(seed, epoch)
            mg.set_random_seed(es)
            torch.manual_seed(es)
            train_provider = self.make_provider(self.types["train"], hp["batch_size"], True)
            t0 = time.time()
            for _ in range(nb_train):
                grid, labels = self.next_grid_batch(train_provider, hp["batch_size"], True, self.aug_translate_a)
                opt.zero_grad()
                out = self.pick_affinity(model(grid))
                loss = torch.nn.functional.mse_loss(out, labels)
                loss.backward()
                opt.step()
            vm = self.evaluate(model, "val", hp["batch_size"])
            rec = dict(epoch=epoch, sec=round(time.time() - t0, 1))
            rec.update(vm)
            history.append(rec)
            improved = vm["val_loss"] < best_val_loss - 1e-6
            if improved:
                best_val_loss = vm["val_loss"]
                patience_ctr = 0
                best_state = {k: v.clone() for k, v in model.state_dict().items()}
            else:
                patience_ctr += 1
            torch.save(dict(epoch=epoch, model=model.state_dict(), optimizer=opt.state_dict(),
                            best_val_loss=best_val_loss, patience_ctr=patience_ctr, history=history,
                            seed=seed, untrained=False, best_state=best_state, finished=False), ckpt_path)
            if epoch % 2 == 0 or improved:
                C.log("[gnina/%s] epoch %d: val_loss=%.4f r=%.3f rmse=%.3f (%.0fs/epoch, patience %d/%d)"
                      % (tag, epoch, vm["val_loss"], vm["pearson_r"], vm["rmse"], time.time() - t0,
                         patience_ctr, hp["early_stopping_patience"]))
            if patience_ctr >= hp["early_stopping_patience"]:
                C.log("[gnina/%s] early stopping at epoch %d" % (tag, epoch))
                break
        if best_state is None:
            raise SystemExit("no best-validation weights recorded for gnina/%s" % tag)
        model.load_state_dict(best_state)
        torch.save(dict(epoch=epoch, model=model.state_dict(), optimizer=opt.state_dict(),
                        best_val_loss=best_val_loss, patience_ctr=patience_ctr, history=history,
                        seed=seed, untrained=False, is_best=True, finished=True), ckpt_path)
        return model, {"history": history, "best_val_loss": best_val_loss, "epoch": epoch}

    def save_untrained(self, model, seed, tag):
        path = C.ckpt_dir(self.cfg) / ("gnina_%s.pt" % tag)
        torch.save(dict(epoch=0, model=model.state_dict(), optimizer=None, seed=seed, untrained=True), path)
        return path

    # --- extraction (verbatim logic of notebook 2c) ---
    def load_extraction_model(self, tag):
        ckpt = torch_load(C.ckpt_dir(self.cfg) / ("gnina_%s.pt" % tag), "cpu")
        if not (ckpt.get("untrained") or ckpt.get("is_best")):
            raise SystemExit("gnina_%s.pt is an in-progress checkpoint, not the best-validation weights" % tag)
        model = self.fresh_arch()
        model.load_state_dict(ckpt["model"])
        return model.double().eval().to(self.extract_device)

    def _grid_double(self, provider, batch_size):
        batch = provider.next_batch(batch_size)
        dims = self.gmaker.grid_dimensions(provider.num_types())
        grid = torch.zeros((batch_size,) + dims, dtype=torch.float32)
        self.gmaker.forward(batch, grid, random_translation=0.0, random_rotation=False)
        return grid.double().to(self.extract_device)

    @torch.no_grad()
    def extract_rows(self, model, split_name, n_rows=None, out_npy=None):
        ids = self.ids[split_name]
        n = len(ids) if n_rows is None else min(n_rows, len(ids))
        provider = self.make_provider(self.types[split_name], 1, False)
        if out_npy is not None:
            arr = np.lib.format.open_memmap(out_npy, mode="w+", dtype=np.float64, shape=(n, self.expected_dim))
        else:
            arr = np.zeros((n, self.expected_dim), dtype=np.float64)
        t0 = time.time()
        for i in range(n):
            grid = self._grid_double(provider, 1)
            with self.eu.PreHeadCapture(model, self.frozen_layer) as cap:
                model(grid)
                arr[i] = cap.value.cpu().numpy()[0]
            if i == 19:
                rate = (time.time() - t0) / 20
                C.log("  first 20 complexes: %.2f s/complex on %s -> about %.0f min for %d" % (rate, self.extract_device, mul(rate, n) / 60, n))
            if out_npy is not None and i % 500 == 0:
                arr.flush()
        if out_npy is not None:
            arr.flush()
        return arr

    def extract_tag(self, tag):
        """Extract train, val, test for a saved checkpoint tag; writes the .npy and _ids.txt files."""
        model = self.load_extraction_model(tag)
        out = {}
        for sp in ("train", "val", "test"):
            npy, idsf = C.emb_paths(self.cfg, "gnina", tag, sp)
            arr = self.extract_rows(model, sp, None, npy)
            del arr
            idsf.write_text("\n".join(self.ids[sp]))
            out[sp] = npy
            C.log("gnina/%s/%s written (%s)" % (tag, sp, npy.name))
        return out

    def load_saved_untrained(self, tag="untrained"):
        """The saved untrained checkpoint loaded onto the training device (for the validation gate)."""
        ck = torch_load(C.ckpt_dir(self.cfg) / ("gnina_%s.pt" % tag), "cpu")
        model = self.fresh_arch()
        model.load_state_dict(ck["model"])
        return model.to(self.device)

    # --- self test ---
    def selftest(self, strict_init=False, n_rows=5, tol_rel=1e-6):
        seed0 = int(self.cfg["seeds"]["existing_seed_values"]["primary"])
        report = {"extract_device": str(self.extract_device), "train_device": str(self.device)}
        saved_p = C.ckpt_dir(self.cfg) / "gnina_untrained.pt"
        if saved_p.exists():
            saved = torch_load(saved_p, "cpu")["model"]
            model = self.make_random_init(seed0)
            worst = 0.0
            for k, v in model.state_dict().items():
                if k in saved:
                    worst = max(worst, float((v.detach().cpu().double() - saved[k].double()).abs().max()))
            report["init1_reproduces_saved_max_abs_diff"] = worst
            if worst > 0.0:
                msg = ("random init with seed %d on %s does NOT reproduce the saved gnina_untrained.pt (max abs diff %.3g). "
                       "Package, torch or CUDA versions differ from the original run." % (seed0, self.device, worst))
                if strict_init:
                    raise SystemExit(msg)
                C.log("WARNING: " + msg)
            else:
                C.log("selftest gnina: random init reproduces the saved untrained checkpoint exactly")
            del model
        pm = self.load_extraction_model("primary")
        E = self.extract_rows(pm, "test", n_rows)
        npy, idsf = C.emb_paths(self.cfg, "gnina", "primary", "test")
        S = np.load(npy, mmap_mode="r")
        ref = np.asarray(S[:n_rows], dtype=np.float64)
        rel = float(np.abs(E - ref).max() / max(np.abs(ref).max(), 1e-12))
        report["primary_extraction_rel_diff"] = rel
        if rel > tol_rel:
            raise SystemExit("selftest gnina: extraction of the saved primary checkpoint differs from the saved embeddings "
                             "(rel %.3g). Grid, typer or layer differs from the original run." % rel)
        C.log("selftest gnina: extraction reproduces saved primary embeddings (rel diff %.2e on %s)" % (rel, self.extract_device))
        return report
