#!/usr/bin/env python
"""r2_c8_size_balanced.py  --  CPU box. Exploratory. Alignment on size-balanced subsets of the test set.

The test complexes are cut into tertiles of ligand heavy-atom count and tertiles of affinity. Every cell of the 3 x 3 table is
subsampled (without replacement) to the size of the smallest cell, so that affinity is unrelated to ligand size in the subset.
The seed-aware analysis is run on the subset (centering, residualization and the cluster bootstrap all inside the subset). The
subsampling is repeated n_draws times with different seeds. Round 1 projections are used unchanged.

Output: results/size_balanced.json, report/size_balanced.md
"""
import argparse

import numpy as np

import common as C
import r2lib as R


def balanced_rows(size_lab, y_lab, nb, rng):
    cells = {}
    for c in range(nb):
        for d in range(nb):
            cells[(c, d)] = np.where((size_lab == c) & (y_lab == d))[0]
    m = min(len(v) for v in cells.values())
    rows = np.sort(np.concatenate([rng.choice(v, size=m, replace=False) for v in cells.values()]))
    return rows, m


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--n_draws", type=int, default=None)
    ap.add_argument("--n_boot", type=int, default=None, help="override draws per subset (smoke tests only)")
    a = ap.parse_args()
    cfg = R.load_cfg2()
    C.ensure_dirs(cfg)
    C.verify_lock(cfg)
    sb = cfg["size_balanced"]
    n_draws = int(a.n_draws if a.n_draws is not None else sb["n_draws"])
    n_boot = int(a.n_boot if a.n_boot is not None else sb["n_boot"])
    core = C.core_ids(cfg)
    cov = C.load_covariates(cfg, core)
    clusters = C.load_clusters(cfg, core)
    size = C.ligand_size(cfg, core)
    split, orig = C.split_table(cfg)
    y = split.loc[[p.lower() for p in core], orig["split"]["affinity_column"]].to_numpy(dtype=np.float64)
    nb = int(sb["n_bins"])
    size_lab = R.tertile_labels(size, nb)
    y_lab = R.tertile_labels(y, nb)
    full_corr = R.spearman(size, y)
    trained = R.round1_trained(cfg)
    design = R.make_design(cfg, trained, which=("orig",))
    Zmap = R.zmap_for(cfg, design)
    rng = np.random.default_rng([int(sb["seed"]), 5])
    draws = []
    for d in range(n_draws):
        rows, m = balanced_rows(size_lab, y_lab, nb, rng)
        corr = R.spearman(size[rows], y[rows])
        res = R.run_engine(cfg, Zmap, cov, clusters, design, sb["modes"], n_boot, rows=rows)
        rec = dict(draw=d, n_rows=int(len(rows)), cell_size=int(m), n_clusters=int(len(np.unique(clusters[rows]))),
                   spearman_size_affinity=corr, results={})
        for mode in sb["modes"]:
            rec["results"][mode] = {}
            for (A, B) in cfg["arch_pairs"]:
                e = R.pick(res, mode, R.pair_key(A, B), "orig", "seed_min")
                rec["results"][mode][R.pair_key(A, B)] = {k: e.get(k) for k in ("obs", "floor", "ceil", "nab", "ci_complex", "ci_two_level")}
        draws.append(rec)
        C.log("subset draw %d of %d: %d complexes, %d clusters, Spearman(size, affinity) %.3f" % (d + 1, n_draws, len(rows), rec["n_clusters"], corr))
    out = dict(stamp=C.stamp(), label="added_after_review_round2", exploratory=True, full_spearman_size_affinity=full_corr,
               n_boot=n_boot, draws=draws)
    C.json_dump(out, cfg["_out"] / "results" / "size_balanced.json")

    lines = ["# Size-balanced evaluation (exploratory, added after review, round 2)", "",
             "Full test set Spearman(size, affinity) = %s. Subsets: %d draws, about %d complexes each (cell size %d)." %
             (R.fnum(full_corr), n_draws, draws[0]["n_rows"], draws[0]["cell_size"]), ""]
    rows = []
    for mode in sb["modes"]:
        for (A, B) in cfg["arch_pairs"]:
            key = R.pair_key(A, B)
            obs = [q["results"][mode][key]["obs"] for q in draws]
            nab = [q["results"][mode][key]["nab"] for q in draws]
            nab_f = [v for v in nab if v is not None and np.isfinite(v)]
            rows.append([mode, key, R.fnum(float(np.median(obs))), "%s to %s" % (R.fnum(min(obs)), R.fnum(max(obs))),
                         R.fnum(float(np.median(nab_f))) if nab_f else "undefined",
                         "%d of %d defined" % (len(nab_f), len(nab))])
    lines.append(R.md_table(["mode", "pair", "median CKA", "range of CKA", "median n_AB", "n_AB defined"], rows))
    R.write_report(cfg, "size_balanced", "\n".join(lines) + "\n")


if __name__ == "__main__":
    main()
