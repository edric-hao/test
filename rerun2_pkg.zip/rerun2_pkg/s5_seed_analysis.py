#!/usr/bin/env python
"""s5_seed_analysis.py  --  CPU box. Item 2 and the CPU part of item 3: the seed-aware alignment analysis.

Runs, for raw, linearly residualized and quadratically residualized embeddings (config analysis.modes):
  - the published estimator (orig) as the PRIMARY result,
  - seed-aware estimators (seed_min, seed_geo) as SENSITIVITY analyses,
  - complex-level-free cluster bootstrap intervals (ci_complex) and two-level intervals (ci_two_level),
  - two floor sets: the original GNINA untrained references and the five regenerated ones.
Seeds that failed the validation gate are left out of the primary analysis; if there are any, the analysis is repeated with
them included and stored under with_failed.
Also reports the spread of the five GNINA untrained references and CKA between old and regenerated initializations.

Output: results/seed_analysis.json, results/seed_analysis_draws.npz
"""
import argparse

import numpy as np

import alignlib2 as al
import common as C
import engine as eg
from s4_project import load_proj, proj_path


def build_design(cfg, failed, include_failed, have_regen, only_set=None):
    trained = {}
    new_tags = [t for t in C.trained_tags(cfg) if t not in ("primary", "anchor")]
    for arch in cfg["archs"]:
        tags = ["primary", "anchor"]
        for t in new_tags:
            if not proj_path(cfg, arch, t).exists():
                continue
            if t in failed.get(arch, []) and not include_failed:
                continue
            tags.append(t)
        trained[arch] = tags
    orig = {a: list(cfg["floors"]["orig_tags"]) for a in cfg["archs"]}
    floor_sets = {"orig": orig}
    if have_regen:
        reg = dict(orig)
        reg["gnina"] = list(cfg["floors"]["regen_tags"])
        floor_sets["regen"] = reg
    if only_set is not None:
        if only_set not in floor_sets:
            raise SystemExit("floor set %s is not available (regenerated GNINA floors missing?)" % only_set)
        floor_sets = {only_set: floor_sets[only_set]}
    return eg.Design(cfg["arch_pairs"], trained, floor_sets)


def floor_report(cfg, Zmap, cov, clusters, have_regen):
    """Spread of the GNINA untrained references and the old-versus-regenerated agreement (raw mode)."""
    out = {}
    tags = list(cfg["floors"]["orig_tags"])
    regen = list(cfg["floors"]["regen_tags"]) if have_regen else []
    names = ["gnina/" + t for t in tags + regen]
    grams = {nm: al.gram_zero_diag(al.residualize(Zmap[nm], cov, "raw")) for nm in names}
    bank = al.GramBank(grams)
    pairs = []
    for i in range(len(tags)):
        for j in range(len(regen)):
            pairs.append(eg.canon("gnina/" + tags[i], "gnina/" + regen[j]))
    for i in range(len(tags)):
        for j in range(i + 1, len(tags)):
            pairs.append(eg.canon("gnina/" + tags[i], "gnina/" + tags[j]))
    pairs = list(dict.fromkeys(pairs))
    if not pairs:
        return out
    vals = bank.cka_point(pairs)
    tab = {p[0] + "|" + p[1]: float(v) for p, v in zip(pairs, vals)}
    out["raw_cka_between_gnina_untrained_inits"] = tab
    if regen:
        out["old_init_k_vs_regen_init_k"] = {
            tags[k] + "|" + regen[k]: tab[eg.canon("gnina/" + tags[k], "gnina/" + regen[k])[0] + "|" +
                                          eg.canon("gnina/" + tags[k], "gnina/" + regen[k])[1]]
            for k in range(min(len(tags), len(regen)))}
    return out


def check_seed_bookkeeping(cfg, failed, allow_missing):
    """Every added seed must either be projected and have a gate record, or the run stops."""
    man = C.read_new_seed_manifest(cfg)
    new_tags = [t for t in C.trained_tags(cfg) if t not in ("primary", "anchor")]
    problems = []
    for arch in cfg["archs"]:
        for t in new_tags:
            has = proj_path(cfg, arch, t).exists()
            rec = man.get("%s/%s" % (arch, t))
            if not has:
                problems.append("%s/%s has no projection (not trained, or s4_project.py not run)" % (arch, t))
            elif rec is None:
                problems.append("%s/%s has embeddings but no gate record in new_seed_manifest.json" % (arch, t))
    if problems:
        for p in problems:
            C.log("PROBLEM: " + p)
        if not allow_missing:
            raise SystemExit("Seed bookkeeping is incomplete (see above). Finish s1 and s2 and rerun s4, "
                             "or pass --allow_missing_seeds to analyse what exists (the output will say so).")
    return problems


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--allow_missing_seeds", action="store_true")
    ap.add_argument("--n_boot", type=int, default=None, help="override analysis.n_boot (smoke tests only)")
    a = ap.parse_args()
    cfg = C.load_cfg()
    C.ensure_dirs(cfg)
    C.verify_lock(cfg)
    an = cfg["analysis"]
    n_boot = int(a.n_boot if a.n_boot is not None else an["n_boot"])
    if a.n_boot is not None:
        C.log("WARNING: n_boot overridden to %d; do not use these numbers in the paper" % n_boot)
    core = C.core_ids(cfg)
    cov = C.load_covariates(cfg, core)
    clusters = C.load_clusters(cfg, core)
    failed = C.failed_seed_tags(cfg)
    have_regen = all(proj_path(cfg, "gnina", t).exists() for t in cfg["floors"]["regen_tags"])
    if not have_regen:
        C.log("WARNING: regenerated GNINA floors are missing; running the original floor set only")
    for arch in cfg["archs"]:
        for t in ["primary", "anchor"] + list(cfg["floors"]["orig_tags"]):
            if not proj_path(cfg, arch, t).exists():
                raise SystemExit("missing projection %s/%s; run s4_project.py" % (arch, t))
    C.log("failed seeds (excluded from the primary analysis): %s" % (failed if failed else "none"))
    seed_problems = check_seed_bookkeeping(cfg, failed, a.allow_missing_seeds)

    def run(include_failed):
        design = build_design(cfg, failed, include_failed, have_regen)
        C.log("trained networks: %s" % design.trained)
        Zmap = {nm: load_proj(cfg, nm.split("/", 1)[0], nm.split("/", 1)[1]) for nm in design.nets()}
        res = eg.run_seed_analysis(Zmap, cov, clusters, design, list(an["modes"]), n_boot, int(an["boot_seed"]),
                                   boot_kind=an["boot_kind"], chunk=int(an["chunk"]),
                                   min_den=float(an["min_denominator"]), max_undef=float(an["max_undefined_fraction"]),
                                   level=float(an["ci_level"]), keep_draws=True, log=C.log)
        return design, Zmap, res

    design, Zmap, res = run(False)
    draws = res.pop("_draws", {})
    out = dict(stamp=C.stamp(), label="added_after_review", n_boot=n_boot, boot_seed=int(an["boot_seed"]),
               failed_seeds=failed, seed_bookkeeping_problems=seed_problems, primary_estimator=an["primary_estimator"],
               trained=design.trained, floor_sets={k: v for k, v in design.floor_sets.items()},
               n_core=len(core), n_clusters=int(len(np.unique(clusters))), results=res)
    if any(failed.values()):
        d2, _, r2 = run(True)
        r2.pop("_draws", None)
        out["with_failed"] = dict(trained=d2.trained, results=r2)
    out["gnina_floor_report"] = floor_report(cfg, Zmap, cov, clusters, have_regen)
    C.json_dump(out, cfg["_out"] / "results" / "seed_analysis.json")
    C.save_npz(cfg["_out"] / "results" / "seed_analysis_draws.npz", draws)
    C.log("wrote results/seed_analysis.json")


if __name__ == "__main__":
    main()
