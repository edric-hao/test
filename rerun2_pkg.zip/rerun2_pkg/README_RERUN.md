# Reruns added after review: how to run everything on AWS

Everything here is labeled "added after review". The registered plan is in config_rerun.yaml (machine readable) and
PREREGISTRATION_RERUN.md (the same thing in words). The first command you run (s0) hashes config_rerun.yaml and writes
rerun_out/PREREG_RERUN_LOCK.json. Every later stage refuses to run if the config changed after that. Do not edit the config after s0.

No file in this package contains the asterisk character, so every command and file can be pasted through Discord.

## What gets run

| Item | Script | Box | Output |
|---|---|---|---|
| 1. five trained seeds per architecture, validation gate | s1_train_gnn_seeds.py (EGNN, Distance-GNN), s2_train_gnina_seeds.py (GNINA) | GPU | results/new_seed_manifest.json, embeddings in data/embeddings |
| 3. five GNINA untrained references, one procedure | s3_gnina_floor.py | GPU | results/gnina_floor_regen.json, embeddings |
| projections and regression gate | s4_project.py | CPU | proj/, results/regression_gate.json |
| 2. full pipeline on all seed pairs | s5_seed_analysis.py | CPU | results/seed_analysis.json |
| 4. positive control | s6_positive_control.py | CPU | results/positive_control.json |
| 5. PC removal, RSA, CCA | s7_pc_removal_rsa_cca.py | CPU | results/pc_removal.json, results/rsa_cca.json |
| 6. size-stratified CKA (optional) | s8_size_stratified.py | CPU | results/size_stratified.json |
| tables and figures | s9_report.py | CPU | report/report_rerun.md, tables, figures |

## Setup

1. Put this folder anywhere on the box and set the two variables:

   export PROJECT_ROOT=/home/ec2-user/SageMaker/pdbbind_data
   export PDBBIND_DIR=/path/to/PDBbind_2020

   PROJECT_ROOT is the project folder from the earlier runs (it holds config, data, src and logs). PDBBIND_DIR is needed on the GPU
   box only. The original config points to Google Drive paths, so PDBBIND_DIR must be set. Outputs go to PROJECT_ROOT/rerun_out.

2. CPU box: pip install -r requirements_rerun.txt. GPU box: use the same environment that produced the original embeddings
   (torch, rdkit, molgrid and gninatorch with numpy below 2).

3. Run the tests (about one minute, CPU only):

   python tests/test_alignlib2.py
   python tests/test_engine.py
   python tests/test_simlib.py
   bash tests/smoke_test_cpu.sh

   The smoke test builds a small synthetic project and runs every CPU stage on it in about a minute. Its numbers are random and
   must never be used; it only proves the code runs on your machine. The GPU stages have no synthetic test (see the notes below).

## Run

GPU box:

   bash run_all_aws.sh gpu

CPU box (first copy over data/embeddings, data/splits, data/covariates.tsv, data/clusters.tsv, config, and rerun_out/results from the GPU box, or run both on one machine):

   bash run_all_aws.sh cpu

One machine with a GPU:

   bash run_all_aws.sh all

Each stage is resumable. If it stops, run the same command again. Finished seeds, finished embeddings and finished
positive-control cells are skipped. Logs go to rerun_out/logs.

Environment variables for the CPU stages: WORKERS (positive-control processes, default 4) and THREADS (BLAS threads each, default 2).
Set WORKERS times THREADS to the number of cores. Do not set GATE_FLAG unless the regression gate fails and you know why.

To copy results back: aws s3 cp rerun_out s3://YOUR_BUCKET/rerun_out --recursive

## What each GPU stage checks before it spends hours

- s1 selftest: the fresh initialization with the original seed must equal your saved untrained checkpoint exactly, and your
  saved primary checkpoint must reproduce the first rows of your saved primary test embeddings (relative difference below 1e-6).
- s2 and s3 selftest: the saved GNINA primary checkpoint must reproduce its saved embeddings. A mismatch in random initialization
  with the saved gnina_untrained.pt is printed as a WARNING and written to results/gnina_selftest_seeds.json (s2) or inside
  results/gnina_floor_regen.json (s3). It is disclosed, not a failure.
- A seed that fails the validation gate (validation r below 0.4, or less than 0.10 above untrained) is recorded, kept out of the primary
  analysis, never retrained, and the analysis is repeated with it included (with_failed in seed_analysis.json).

## Expected time (measured on a 2-core machine for the CPU parts; GPU parts depend on your instance)

- s1: one training run per architecture and seed, the same cost as your original run. Extraction is float64 on one complex at a time.
- s2: three GNINA trainings, each as long as the original GNINA run. Extraction prints its speed after 20 complexes and an estimated total.
- s3: five initializations, extraction only (no training). Each tag needs train, validation and test embeddings.
- s4: PCA-64 for every network. GNINA train embeddings are about 1.6 GB per network in float64, so use 32 GB of RAM or more,
  or set data.pca_method to exact in config_rerun.yaml before s0 (low memory, tiny numerical differences).
- s5: about 8 seconds per 256 bootstrap draws for 50 network pairs on 2 cores; this analysis has about 125 pairs and 10000 draws,
  so roughly 40 to 90 minutes on 4 cores, longer if a seed failed (the analysis runs twice).
- s6: 320 simulation cells, about 30 seconds each on 2 cores. With 8 workers expect about 30 to 40 minutes.
- s7: PC removal about 20 minutes. RSA is the slow part (about 15 seconds per bootstrap draw, 200 draws, 2 modes: roughly 1.5 hours).
- s8: a few minutes. s9: seconds.

## Things to know before you launch

1. The GPU scripts could not be run on real data where I built them (no torch, molgrid or data there). Their logic was checked by reading
   against your original code and notebooks, and the CPU stages were run end to end on a synthetic project. The GPU selftests above
   are the safety net; if one aborts, send me the message.

2. Quadratic residualization. The published code residualized on [1, c1, c2, c1 squared, c2 squared] (no cross term). The appendix text
   describes the cross product c1 times c2 as well. The registered mode resid_poly2 reproduces the code. Either change the sentence in the
   paper to match the code, or add resid_poly2x to analysis.modes in config_rerun.yaml before running s0.

3. Bootstrap centering. The original centered the Gram matrix again inside every bootstrap draw. Here it is centered once on the full
   sample. The tested difference is about 5e-7 in CKA and 1e-4 in n_AB at n = 160. The regression gate in s4 confirms that the two-seed
   numbers still match your published values within 0.003.

4. Extraction device. The original extracted GNINA on CPU. Here extraction runs on the GPU in float64 by default (--extract_device cpu
   restores the original). The selftest compares against your saved primary embeddings, so a device effect would be caught.

5. GNINA initialization 1. If random initialization with the original seed does not reproduce your saved gnina_untrained.pt, the
   mismatch is reported in gnina_floor_regen.json (key _init1_vs_saved_untrained) and in the selftest output. This is the likely reason the earlier regeneration
   failed (reinitializing on CPU instead of the training device); here it is done on the training device.

6. New seed values (20261001, 20261002, 20261003) and the positive-control seeds are fixed in the config and therefore in the lock.

7. Positive-control conditions: no shared signal, size-independent shared signal, and size-associated shared signal in two forms
   (linear size, nonlinear size), so four conditions. Truth is analytic. Residualized estimates are compared with the planted
   protein-level alignment; raw estimates are compared with the truth that still contains size. The real-embedding spike-in has no analytic
   truth and only checks that the estimates respond monotonically.

8. The floor set used by s7 and s8 is analysis.headline_floor_set (orig). s5 reports both orig and regenerated GNINA floors.

## Mapping to the paper

- Table A1 (gate), A2 (main), A3 (every seed pair), A4 to A6 (individual floors and spread, regenerated GNINA validation) from s9.
- Positive-control table and the recovered-versus-planted figure: s9 (figures/positive_control_recovered_vs_planted.png).
- PC removal, RSA and CCA, size strata: appendix tables, each labeled added after review.
- Reading rule used everywhere: an interval that contains zero is called uninformative. Claims are scoped to calibration in a
  low-performance regime. H3b and pose recovery stay in the appendix. Say "shared objective and stopping rule", not "training held fixed".
