#!/usr/bin/env python
"""s4_project.py  --  CPU box. PCA-64 projections for every network, plus the regression gate.

For each (architecture, tag): fit PCA-64 on that network's TRAIN embeddings, project its TEST embeddings
(rows put in the sorted core order). The result is cached in rerun_out/proj/ARCH__TAG.npz.
PCA method follows config data.pca_method: sklearn (what the published pipeline ran) or exact (chunked, low memory).

Regression gate: with only the two original seeds (primary, anchor) and the original floors, the recomputed
CKA, floor, ceiling and n_AB must match the published numbers (reference/) within regression_gate.tolerance.
If they do not, nothing downstream can be trusted and the script stops (use --gate_warn_only to continue anyway).

Usage
  python s4_project.py
  python s4_project.py --force            recompute every projection
  python s4_project.py --gate_warn_only
"""
import argparse
import json

import numpy as np

import alignlib2 as al
import common as C
import engine as eg

PAIR_KEYS = {"egnn_x_gnina": ("egnn", "gnina"), "egnn_x_distance_gnn": ("egnn", "distance_gnn"),
             "gnina_x_distance_gnn": ("gnina", "distance_gnn")}


def proj_path(cfg, arch, tag):
    return cfg["_out"] / "proj" / (arch + "__" + tag + ".npz")


def wanted_tags(cfg, arch):
    tags = list(C.trained_tags(cfg)) + list(cfg["floors"]["orig_tags"])
    if arch == "gnina":
        tags += list(cfg["floors"]["regen_tags"])
    return tags


def project_one(cfg, arch, tag, core, method, k):
    npy_tr, ids_tr = C.emb_paths(cfg, arch, tag, "train")
    npy_te, ids_te = C.emb_paths(cfg, arch, tag, "test")
    ids_test = C.read_ids(ids_te)
    Ete = np.load(npy_te, mmap_mode="r")
    Ete = C.strict_subset(np.asarray(Ete, dtype=np.float64), ids_test, core, name=arch + "/" + tag)
    Etr = np.asarray(np.load(npy_tr, mmap_mode="r"), dtype=np.float64)
    if len(C.read_ids(ids_tr)) != Etr.shape[0]:
        raise SystemExit("%s/%s: train ids and rows differ" % (arch, tag))
    if not (np.isfinite(Etr).all() and np.isfinite(Ete).all()):
        raise SystemExit("%s/%s: non-finite embeddings" % (arch, tag))
    if method == "sklearn":
        Z, evr = al.pca_fit_project_sklearn(Etr, Ete, k)
    else:
        fit = al.pca_fit(Etr, k)
        Z = al.pca_project(Ete, fit)
        evr = np.asarray(fit.get("evr", np.zeros(k)))
    return np.asarray(Z, dtype=np.float64), np.asarray(evr, dtype=np.float64), Etr.shape


def source_signature(cfg, arch, tag):
    """Size and modification time of the train and test embedding files; a change invalidates the cache."""
    sig = []
    for sp in ("train", "test"):
        npy, ids = C.emb_paths(cfg, arch, tag, sp)
        for f in (npy, ids):
            st = f.stat()
            sig.append("%d:%d" % (st.st_size, st.st_mtime_ns))
    return "|".join(sig)


def load_proj(cfg, arch, tag):
    d = np.load(proj_path(cfg, arch, tag))
    return d["Z"]


def regression_gate(cfg, core, cov, tol):
    ref_raw = json.loads((C.PKG_DIR / "reference" / "h1_results_published.json").read_text())
    ref_res = json.loads((C.PKG_DIR / "reference" / "h1_size_resid_published.json").read_text())
    archs = cfg["archs"]
    trained = {a: ["primary", "anchor"] for a in archs}
    orig_floor = {a: list(cfg["floors"]["orig_tags"]) for a in archs}
    design = eg.Design(cfg["arch_pairs"], trained, {"orig": orig_floor})
    Zmap = {nm: load_proj(cfg, nm.split("/", 1)[0], nm.split("/", 1)[1]) for nm in design.nets()}
    clusters = C.load_clusters(cfg, core)
    res = eg.run_seed_analysis(Zmap, cov, clusters, design, ["raw", "resid_linear", "resid_poly2"], 0, 0,
                               min_den=float(cfg["analysis"]["min_denominator"]), log=C.log)
    rows, worst = [], 0.0
    for key in PAIR_KEYS:
        for mode, ref in (("raw", None), ("resid_linear", ref_res["linear"][key]["cluster"]),
                          ("resid_poly2", ref_res["poly2"][key]["cluster"])):
            est = res[mode][key]["orig"]["estimators"]["orig"]
            if ref is None:
                r = ref_raw[key]
                want = dict(obs=r["cka"], floor=r["floor"], ceil=r["ceiling"], nab=r["n_AB"])
            else:
                want = dict(obs=ref["obs_point"], floor=ref["floor_point"], ceil=ref["ceiling_point"],
                            nab=ref["n_ab_point"])
            for q in ("obs", "floor", "ceil", "nab"):
                got, w = est[q], want[q]
                if w is None or got is None:
                    diff = 0.0 if (w is None and got is None) else float("inf")
                else:
                    diff = abs(float(got) - float(w))
                worst = max(worst, diff)
                rows.append(dict(pair=key, mode=mode, quantity=q, recomputed=got, published=w, abs_diff=diff,
                                 ok=bool(diff <= tol)))
    return rows, worst


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--force", action="store_true")
    ap.add_argument("--gate_warn_only", action="store_true")
    ap.add_argument("--archs", nargs="+", default=None)
    a = ap.parse_args()

    cfg = C.load_cfg()
    C.ensure_dirs(cfg)
    C.verify_lock(cfg)
    core = C.core_ids(cfg)
    method = cfg["data"]["pca_method"]
    k = int(cfg["data"]["pca_dim"])
    cov = C.load_covariates(cfg, core)
    C.log("core complexes: %d, PCA method: %s, dim %d" % (len(core), method, k))

    for arch in (a.archs or cfg["archs"]):
        for tag in wanted_tags(cfg, arch):
            out = proj_path(cfg, arch, tag)
            if not C.have_embeddings(cfg, arch, tag, ("train", "test")):
                C.log("[%s/%s] embeddings not present; skipped" % (arch, tag))
                continue
            if out.exists() and not a.force:
                old = np.load(out, allow_pickle=False)
                if (str(old["method"]) == method and int(old["dim"]) == k
                        and "source_sig" in old.files and str(old["source_sig"]) == source_signature(cfg, arch, tag)):
                    C.log("[%s/%s] cached" % (arch, tag))
                    continue
            Z, evr, shp = project_one(cfg, arch, tag, core, method, k)
            np.savez(out, Z=Z, evr=evr, ids=np.array(core), method=np.array(method), dim=np.array(k),
                     train_shape=np.array(shp), source_sig=np.array(source_signature(cfg, arch, tag)))
            C.log("[%s/%s] projected %s from train %s, top-3 variance share %s"
                  % (arch, tag, Z.shape, shp, np.round(evr[:3], 3).tolist()))

    # regression gate on the two original seeds
    need = [(ar, t) for ar in cfg["archs"] for t in ["primary", "anchor"] + list(cfg["floors"]["orig_tags"])]
    if not all(proj_path(cfg, ar, t).exists() for ar, t in need):
        raise SystemExit("cannot run the regression gate: projections for the original networks are missing")
    tol = float(cfg["regression_gate"]["tolerance"])
    rows, worst = regression_gate(cfg, core, cov, tol)
    bad = [r for r in rows if not r["ok"]]
    C.json_dump(dict(stamp=C.stamp(), tolerance=tol, worst_abs_diff=worst, n_checks=len(rows),
                     n_failed=len(bad), rows=rows), cfg["_out"] / "results" / "regression_gate.json")
    C.log("regression gate: %d checks, %d outside %.4f, worst abs diff %.5f" % (len(rows), len(bad), tol, worst))
    for r in bad[:12]:
        C.log("  MISMATCH %s %s %s: recomputed %s published %s" % (r["pair"], r["mode"], r["quantity"], r["recomputed"], r["published"]))
    if bad and not a.gate_warn_only:
        raise SystemExit("Regression gate failed: the recomputation does not reproduce the published numbers. "
                         "Fix this before running any new analysis (see results/regression_gate.json).")


if __name__ == "__main__":
    main()
