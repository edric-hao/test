"""Graph models (EGNN, Distance-GNN): data, training loop and extraction.

This is the project's own code from gpu_runs/run_t3_anchors.py (graph construction, collate,
train_one, evaluate, extract), moved into functions. The model classes come from the project's
src/embed_utils.py and are NOT re-implemented. Training settings come from the project's locked
config/config.yaml. Nothing about the models or the loop changes except the seed and the tag.

Only the GPU box needs this module (it imports torch).
"""
import json
import os
import sys
import time
from pathlib import Path

import numpy as np
import torch
import torch.nn as nn
from scipy.stats import pearsonr
from torch.utils.data import DataLoader, Dataset

import common as C

N_TYPES = 16
HALOGENS = {"F", "CL", "BR", "I"}
METALS = {"ZN", "MG", "CA", "MN", "FE", "NA", "K", "CU", "NI", "CO", "CD", "HG", "MO"}


def torch_load(path, map_location="cpu"):
    try:
        return torch.load(path, map_location=map_location, weights_only=False)
    except TypeError:
        return torch.load(path, map_location=map_location)


# ----------------------------------------------------------------------------
# graph construction (identical to run_t3_anchors.py / notebook 2a)
# ----------------------------------------------------------------------------
def element_bucket(sym):
    s = sym.strip().upper()
    if s == "C":
        return 0
    if s == "N":
        return 1
    if s == "O":
        return 2
    if s == "S":
        return 3
    if s == "P":
        return 4
    if s in HALOGENS:
        return 5
    if s in METALS:
        return 6
    return 7


def node_type(sym, is_ligand):
    return element_bucket(sym) + element_bucket(sym) + (1 if is_ligand else 0)


def parse_pocket(pdb):
    out = []
    with open(pdb) as fh:
        for line in fh:
            if not line.startswith(("ATOM", "HETATM")):
                continue
            if line[17:20].strip() in ("HOH", "WAT", "H2O"):
                continue
            el = line[76:78].strip() if len(line) >= 78 else ""
            if not el:
                el = line[12:16].strip().lstrip("0123456789")[:1]
            if el.upper() in ("H", "D") or not el:
                continue
            try:
                x, y, z = float(line[30:38]), float(line[38:46]), float(line[46:54])
            except ValueError:
                continue
            out.append((el, x, y, z))
    return out


def parse_ligand(lig):
    from rdkit import Chem
    path = str(lig)
    mol = (Chem.SDMolSupplier(path, removeHs=False, sanitize=False)[0]
           if path.endswith(".sdf")
           else Chem.MolFromMol2File(path, removeHs=False, sanitize=False))
    if mol is None or mol.GetNumConformers() == 0:
        raise ValueError("unreadable ligand: %s" % lig)
    conf = mol.GetConformer()
    return [(a.GetSymbol(),) + tuple(conf.GetAtomPosition(a.GetIdx())) for a in mol.GetAtoms() if a.GetAtomicNum() > 1]


class GnnContext:
    """Everything a graph-model run needs: config, split ids, graph cache, model specs."""

    def __init__(self, cfg, device=None):
        self.cfg = cfg
        self.root = cfg["_root"]
        for p in (str(self.root), str(self.root / "src")):
            if p not in sys.path:
                sys.path.insert(0, p)
        import embed_utils as eu  # project file src/embed_utils.py
        import seeds as seedmod   # project file src/seeds.py
        self.eu, self.seedmod = eu, seedmod
        self.orig = C.load_original_cfg(cfg)
        self.device = device or torch.device("cuda" if torch.cuda.is_available() else "cpu")
        egnn_hp = self.orig["training"]["egnn"]
        dgnn_hp = self.orig["training"]["distance_gnn"]
        self.cutoff = float(dgnn_hp.get("cutoff_A", 5.0))
        n_rbf = int(dgnn_hp.get("n_rbf", 16))
        cutoff = self.cutoff
        self.specs = {
            "egnn": dict(hp=egnn_hp,
                         make=lambda: eu.EGNNAffinity(n_types=N_TYPES, hidden=egnn_hp["hidden"],
                                                      n_layers=egnn_hp["n_layers"])),
            "distance_gnn": dict(hp=dgnn_hp,
                                 make=lambda: eu.DistanceGNN(n_types=N_TYPES, hidden=dgnn_hp["hidden"],
                                                             n_layers=dgnn_hp["n_layers"], n_rbf=n_rbf,
                                                             cutoff=cutoff)),
        }
        self.split, _ = C.split_table(cfg)
        self.aff = self.orig["split"]["affinity_column"]
        self.graph_cache = self.root / "data" / "graph_cache"
        self.ids = {}
        for sp in ("train", "val", "test"):
            f = C.emb_dir(cfg) / ("egnn_primary_%s_ids.txt" % sp)
            if not f.exists():
                raise SystemExit("missing %s (the original primary embeddings define the id order)" % f)
            self.ids[sp] = C.read_ids(f)
        self._idx = None
        missing = [p for sp in self.ids for p in self.ids[sp] if not (self.graph_cache / (p + ".pt")).exists()]
        if missing:
            C.log("graph cache missing for %d complexes; will build them from PDBbind (needs PDBBIND_DIR and rdkit)" % len(missing))
            for p in missing:
                self.get_graph(p)

    def _pdb_index(self):
        if self._idx is None:
            base = self.cfg["_pdbbind_dir"] or Path(self.orig["paths"]["pdbbind_dir"])
            base = Path(base)
            if not base.exists():
                raise SystemExit("PDBbind directory not found: %s (set PDBBIND_DIR)" % base)
            idx = {}
            for b in [base] + [d for d in base.iterdir() if d.is_dir() and len(d.name) != 4]:
                for d in b.iterdir():
                    if d.is_dir() and len(d.name) == 4:
                        idx[d.name.lower()] = d
            self._idx = idx
        return self._idx

    def get_graph(self, pid):
        cache = self.graph_cache / (pid + ".pt")
        if cache.exists():
            d = torch_load(cache, "cpu")
            return d["z"], d["x"], d["y"]
        d = self._pdb_index().get(pid)
        if d is None:
            raise FileNotFoundError("no dir for " + pid)
        pocket = d / (pid + "_pocket.pdb")
        lig = d / (pid + "_ligand.sdf") if (d / (pid + "_ligand.sdf")).exists() else d / (pid + "_ligand.mol2")
        if not pocket.exists() or not lig.exists():
            raise FileNotFoundError("missing pocket/ligand for " + pid)
        prot = parse_pocket(pocket)
        lig_atoms = parse_ligand(lig)
        zs, xs = [], []
        for el, x, y, z in prot:
            zs.append(node_type(el, False))
            xs.append((x, y, z))
        for el, x, y, z in lig_atoms:
            zs.append(node_type(el, True))
            xs.append((x, y, z))
        Z = torch.tensor(zs, dtype=torch.long)
        X = torch.tensor(xs, dtype=torch.float32)
        Y = float(self.split.loc[pid, self.aff])
        self.graph_cache.mkdir(parents=True, exist_ok=True)
        torch.save({"z": Z, "x": X, "y": Y}, cache)
        return Z, X, Y

    # --- data ---
    def dataset(self, ids):
        ctx = self

        class ComplexDataset(Dataset):
            def __init__(self, ids_):
                self.ids = list(ids_)

            def __len__(self):
                return len(self.ids)

            def __getitem__(self, i):
                pid = self.ids[i]
                z, x, y = ctx.get_graph(pid)
                return pid, z, x, y
        return ComplexDataset(ids)

    def collate(self, batch):
        pids, zs, xs, ys, bs = [], [], [], [], []
        for gi, (pid, z, x, y) in enumerate(batch):
            pids.append(pid)
            zs.append(z)
            xs.append(x)
            ys.append(y)
            bs.append(torch.full((z.shape[0],), gi, dtype=torch.long))
        z = torch.cat(zs)
        x = torch.cat(xs)
        b = torch.cat(bs)
        y = torch.tensor(ys, dtype=torch.float32)
        ei = self.eu.radius_edges(x, b, cutoff=self.cutoff)
        return pids, z, x, ei, b, len(batch), y

    def loader(self, ids, batch_size, shuffle):
        return DataLoader(self.dataset(ids), batch_size=batch_size, shuffle=shuffle,
                          collate_fn=self.collate, num_workers=0)

    def new_model(self, name):
        return self.specs[name]["make"]()

    # --- evaluation ---
    @torch.no_grad()
    def evaluate(self, model, loader):
        model.eval()
        preds, trues, total, n = [], [], 0.0, 0
        for _, z, x, ei, b, ng, y in loader:
            z, x, ei, b, y = (z.to(self.device), x.to(self.device), ei.to(self.device),
                              b.to(self.device), y.to(self.device))
            out = model(z, x, ei, b, ng)
            total += nn.functional.mse_loss(out, y, reduction="sum").item()
            n += ng
            preds.append(out.cpu().numpy())
            trues.append(y.cpu().numpy())
        preds = np.concatenate(preds)
        trues = np.concatenate(trues)
        r = float(pearsonr(preds, trues)[0]) if len(preds) > 1 else float("nan")
        return dict(val_loss=total / max(n, 1), pearson_r=r,
                    rmse=float(np.sqrt(np.mean(np.square(preds - trues)))), n=n)

    @torch.no_grad()
    def predict(self, model, loader):
        """Predictions and ids in loader order."""
        model.eval()
        preds, ids = [], []
        for pids, z, x, ei, b, ng, y in loader:
            z, x, ei, b = z.to(self.device), x.to(self.device), ei.to(self.device), b.to(self.device)
            preds.append(model(z, x, ei, b, ng).cpu().numpy())
            ids += list(pids)
        return np.concatenate(preds), ids

    # --- training (verbatim logic of train_one in run_t3_anchors.py) ---
    def train_one(self, name, seed, tag):
        spec = self.specs[name]
        hp = spec["hp"]
        ck = C.ckpt_dir(self.cfg)
        ck.mkdir(parents=True, exist_ok=True)
        ckpt = ck / ("%s_%s.pt" % (name, tag))
        best_ckpt = ck / ("%s_%s_best.pt" % (name, tag))
        self.seedmod.seed_everything(seed)
        model = spec["make"]().to(self.device)
        opt = torch.optim.Adam(model.parameters(), lr=hp["lr"])
        start, best_loss, patience_ctr, history = 0, float("inf"), 0, []
        if ckpt.exists():
            state = torch_load(ckpt, self.device)
            if state.get("is_best") and state.get("patience_ctr", 0) >= hp["early_stopping_patience"]:
                model.load_state_dict(state["model"])
                C.log("[%s/%s] already finished (epoch %s, best_val_loss=%.4f); not retraining"
                      % (name, tag, state["epoch"], state["best_val_loss"]))
                return model, {"history": state.get("history", []), "best_val_loss": state["best_val_loss"],
                               "epoch": state["epoch"], "seed": state.get("seed", seed)}
            model.load_state_dict(state["model"])
            if state.get("optimizer") is not None:
                opt.load_state_dict(state["optimizer"])
            start = state["epoch"] + 1
            best_loss = state.get("best_val_loss", float("inf"))
            patience_ctr = state.get("patience_ctr", 0)
            history = state.get("history", [])
            C.log("[%s/%s] resuming from epoch %d (best val_loss=%.4f)" % (name, tag, start, best_loss))
        best_state = None
        if best_ckpt.exists():
            bs = torch_load(best_ckpt, self.device)
            best_state = bs["model"]
            best_loss = min(best_loss, bs.get("best_val_loss", best_loss))
        train_loader = self.loader(self.ids["train"], hp["batch_size"], True)
        val_loader = self.loader(self.ids["val"], hp["batch_size"], False)
        epoch = start - 1
        for epoch in range(start, hp["max_epochs"]):
            model.train()
            t0 = time.time()
            for _, z, x, ei, b, ng, y in train_loader:
                z, x, ei, b, y = (z.to(self.device), x.to(self.device), ei.to(self.device),
                                  b.to(self.device), y.to(self.device))
                opt.zero_grad()
                nn.functional.mse_loss(model(z, x, ei, b, ng), y).backward()
                opt.step()
            vm = self.evaluate(model, val_loader)
            rec = dict(epoch=epoch, sec=round(time.time() - t0, 1))
            rec.update(vm)
            history.append(rec)
            improved = vm["val_loss"] < best_loss - 1e-6
            if improved:
                best_loss = vm["val_loss"]
                patience_ctr = 0
                best_state = {k: v.clone() for k, v in model.state_dict().items()}
                torch.save(dict(epoch=epoch, model=best_state, best_val_loss=best_loss, seed=seed), best_ckpt)
            else:
                patience_ctr += 1
            torch.save(dict(epoch=epoch, model=model.state_dict(), optimizer=opt.state_dict(),
                            best_val_loss=best_loss, patience_ctr=patience_ctr,
                            history=history, seed=seed, untrained=False), ckpt)
            if epoch % 5 == 0 or improved:
                C.log("[%s/%s] epoch %d: val_loss=%.4f r=%.3f (patience %d/%d)"
                      % (name, tag, epoch, vm["val_loss"], vm["pearson_r"], patience_ctr, hp["early_stopping_patience"]))
            if patience_ctr >= hp["early_stopping_patience"]:
                C.log("[%s/%s] early stopping at epoch %d" % (name, tag, epoch))
                break
        if best_state is not None:
            model.load_state_dict(best_state)
            torch.save(dict(epoch=epoch, model=model.state_dict(), optimizer=opt.state_dict(),
                            best_val_loss=best_loss, patience_ctr=patience_ctr,
                            history=history, seed=seed, untrained=False, is_best=True), ckpt)
            if best_ckpt.exists():
                best_ckpt.unlink()
        return model, {"history": history, "best_val_loss": best_loss, "epoch": epoch, "seed": seed}

    # --- extraction (verbatim logic of extract in run_t3_anchors.py) ---
    @torch.no_grad()
    def extract_ids(self, name, model, ids):
        m64 = self.new_model(name).double()
        m64.load_state_dict({k: v.double() for k, v in model.state_dict().items()})
        m64.eval()
        loader = self.loader(ids, 1, False)
        rows, ordered = [], []
        for pids, z, x, ei, b, ng, _ in loader:
            x = x.double()
            with self.eu.PreHeadCapture(m64, "readout.0") as cap:
                m64(z, x, ei, b, ng)
                rows.append(cap.value.cpu().numpy()[0])
            ordered.append(pids[0])
        return np.stack(rows).astype(np.float64), ordered

    def load_checkpoint_model(self, name, tag):
        st = torch_load(C.ckpt_dir(self.cfg) / ("%s_%s.pt" % (name, tag)), self.device)
        m = self.new_model(name).to(self.device)
        m.load_state_dict(st["model"])
        return m, st

    # --- gate and self test ---
    def gate(self, name, val_r, untrained_val_r):
        g = self.cfg["gate"]
        ok = (val_r >= float(g["min_val_pearson"])) and ((val_r - untrained_val_r) >= float(g["min_margin_over_untrained"]))
        return bool(ok)

    def selftest(self, names, n_rows=12, tol_rel=1e-6):
        """Prove this code reproduces the original models before spending GPU hours.

        1. untrained init: seed_everything(20260919) + constructor must equal the saved untrained checkpoint exactly.
        2. extraction: the saved primary checkpoint must reproduce the first rows of the saved primary test embeddings.
        """
        seed0 = int(self.cfg["seeds"]["existing_seed_values"]["primary"])
        for name in names:
            saved = torch_load(C.ckpt_dir(self.cfg) / ("%s_untrained.pt" % name), "cpu")["model"]
            self.seedmod.seed_everything(seed0)
            fresh = self.new_model(name).state_dict()
            worst = 0.0
            for k, v in saved.items():
                if k not in fresh:
                    raise SystemExit("selftest %s: key %s not in the freshly built model (different model class?)" % (name, k))
                worst = max(worst, float((fresh[k].double() - v.double()).abs().max()))
            if worst > 0.0:
                raise SystemExit("selftest %s: fresh init with seed %d differs from the saved untrained checkpoint "
                                 "(max abs diff %.3g). Torch version or model code differs from the original run."
                                 % (name, seed0, worst))
            C.log("selftest %s: initialization reproduces the saved untrained checkpoint exactly" % name)
            model, _ = self.load_checkpoint_model(name, "primary")
            ids = self.ids["test"][:n_rows]
            E, _ = self.extract_ids(name, model.cpu(), ids)
            npy, idsf = C.emb_paths(self.cfg, name, "primary", "test")
            S = np.load(npy, mmap_mode="r")
            sid = C.read_ids(idsf)
            rows = [sid.index(p) for p in ids]
            ref = np.asarray(S[rows], dtype=np.float64)
            rel = float(np.abs(E - ref).max() / max(np.abs(ref).max(), 1e-12))
            if rel > tol_rel:
                raise SystemExit("selftest %s: extraction differs from saved primary embeddings (rel %.3g)" % (name, rel))
            C.log("selftest %s: extraction reproduces saved primary embeddings (rel diff %.2e)" % (name, rel))
