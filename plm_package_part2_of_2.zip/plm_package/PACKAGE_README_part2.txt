PLM harm-detection package - PART 2 of 2. Extract into the SAME folder as Part 1 (plm_package/); see plm_package/PACKAGE_README.txt.
Contains logs/ and the esm2_3b probe direction vectors.
