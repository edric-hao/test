# Remaining runs (SageMaker terminal, no EC2 or bucket needed)

Standardised noise draws: every experiment that uses random noise is run for seeds 0 to 3 (`DRAWS=4`). Blur is deterministic and runs once.

| Stage | What | Seeds |
|---|---|---|
| seeds_identity | main sweeps, original option order, native resolution (3 datasets) | 0 to 3 |
| probe_seeds | noise probe activations for APTOS and VQA-RAD, then nested-CV probes on CPU | 0 to 3 (seed 0 exists, skipped) |
| seeds_reverse | reversed option order, noise | 0 to 3 (seed 0 exists, skipped) |
| seeds_resolution | degradation at the 896 px model input, noise | 0 to 3 (seed 0 exists, skipped) |
| rotate | second alternative option order (abstention option moves to the middle), noise and blur | 0 to 3 |
| lang_seeds | per-example language mutation, APTOS and HAM10000 | 0 to 3 (seed 0 exists, skipped) |
| validation | readout validation rerun (fixes the accuracy print and the LLaVA-Med VQA-RAD reversed run that stopped on an error) | n/a |

## Steps

1. Upload this zip with drag and drop, then in the terminal:

        cd /home/ec2-user/SageMaker
        unzip remaining_runs.zip
        cd remaining_runs

2. Set your Hugging Face token in the terminal (type it, do not save it in a file):

        export HF_TOKEN=<your token>

3. Check everything and see the time estimate (a minute, no GPU used):

        bash bash.sh check

4. Run the whole chain in the background:

        nohup bash bash.sh > chain.log 2>&1 &
        tail -f chain.log

Close the browser freely. If the instance stops, repeat step 2 and step 4: finished outputs are skipped and sweeps resume from their checkpoints.

## Options (environment variables, put them before `bash bash.sh`)

- `DRAWS=3` fewer draws, `LITE=1` 13 of 15 severities for the reverse, resolution and rotate repeats, `PARALLEL=1` on a g5.xlarge.
- `SKIP_LANG=1`, `SKIP_VALIDATION=1` leave out the two stages that are not about noise draws.
- `KERNEL=<name>` if `jupyter kernelspec list` shows a different pytorch kernel. `VI=<path>` if `vlm_internals` is not in `/home/ec2-user/SageMaker`.
- One stage only: `bash bash.sh seeds_identity`. Analysis only on what has finished: `bash bash.sh analyze`.

Stages run in priority order, so stopping early still leaves the most important results. Estimated total is about 13 hours on a g5.2xlarge with two parallel streams (the check step prints the estimate, and it is corrected from the measured speed of the smoke test).

## What to send back

`results_to_send_back.zip` is written at the end (or by `bash bash.sh analyze`). Download it from the file browser. It contains the CSV and JSON summaries in `results_draws/` and the executed notebooks. The large sweep JSON files stay on the instance.

## Notes

- The Ovis validation notebooks install an older transformers. They run last, and the chain restores transformers afterwards. If a later MedGemma notebook fails on an import error, run `pip install -U transformers`.
- Probe activations are float32 and need about 3 GB.
- Output locations: sweeps and probes in `vlm_internals/generations/medgemma/<dataset>/review/`, language draws next to the earlier `lang_forced_v2_results.json`.
