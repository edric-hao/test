"""Convert a '# %%' percent-format script to a notebook (papermill needs .ipynb).  usage: py2ipynb.py in.py out.ipynb"""
import json, sys, re
src = open(sys.argv[1]).read().split("\n"); cells, cur, kind, tags = [], [], None, []
def flush():
    global cur, kind, tags
    if kind is None: return
    body = "\n".join(cur).strip("\n")
    if kind == "md": body = "\n".join(re.sub(r"^# ?", "", l) for l in body.split("\n"))
    c = {"cell_type": "markdown" if kind == "md" else "code", "metadata": ({"tags": tags} if tags else {}), "source": body.splitlines(True)}
    if kind == "code": c.update(execution_count=None, outputs=[])
    cells.append(c); cur = []
for line in src:
    m = re.match(r"^# %%(.*)$", line)
    if m:
        flush(); rest = m.group(1); kind = "md" if "[markdown]" in rest else "code"
        t = re.search(r'tags=\["([^"]+)"\]', rest); tags = [t.group(1)] if t else []
    else: cur.append(line)
flush()
json.dump({"cells": cells, "metadata": {"kernelspec": {"display_name": "Python 3", "language": "python", "name": "python3"}, "language_info": {"name": "python"}}, "nbformat": 4, "nbformat_minor": 5}, open(sys.argv[2], "w"), indent=1)
