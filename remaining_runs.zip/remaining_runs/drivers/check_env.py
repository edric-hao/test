import importlib, sys
pip = {"sklearn": "scikit-learn", "PIL": "pillow"}
miss = 0
for m in ("papermill", "torch", "transformers", "accelerate", "sklearn", "pandas", "PIL", "numpy"):
    try:
        importlib.import_module(m); print("  ok   ", m)
    except Exception:
        miss = 1; print("  MISSING ", m, "-> pip install", pip.get(m, m))
try:
    import torch; print("  cuda available:", torch.cuda.is_available())
except Exception:
    pass
sys.exit(miss)
