"""Print a shell prefix that runs *the kernel's* python.  SageMaker conda kernels have argv[0]=='bash'
(argv = ['bash','-c','source activate <env>; python -m ipykernel_launcher ...']), so we keep the activation part."""
import json, re, subprocess, sys
try:
    spec = json.loads(subprocess.check_output(["jupyter", "kernelspec", "list", "--json"]))["kernelspecs"][sys.argv[1]]["spec"]
    argv = spec["argv"]
    if argv[0] in ("bash", "sh") and "-c" in argv:
        cmd = argv[argv.index("-c") + 1]
        m = re.search(r"^(.*?)(\S*python\S*)\s+-m\s+ipykernel", cmd, re.S)
        print((m.group(1) + m.group(2)) if m else "python")
    else:
        print(argv[0])
except Exception:
    print("python")
