import sys, os, pandas as pd
df = pd.read_csv(sys.argv[1]); p = df["image_path"].dropna().iloc[:20]
miss = [x for x in p if not os.path.exists(x)]
print(f"        image_path: first 20 rows, {len(miss)} missing" + (f" e.g. {miss[0]}" if miss else ""))
