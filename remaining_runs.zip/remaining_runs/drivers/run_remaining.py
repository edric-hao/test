#!/usr/bin/env python3
"""Job runner for the remaining camera-ready runs (papermill only).  Called by bash.sh.

    python3 drivers/run_remaining.py --list
    python3 drivers/run_remaining.py --stage seeds_identity --dry-run
    python3 drivers/run_remaining.py --stage seeds_identity probe_seeds --parallel 2

Standardised noise draws: every experiment that uses random noise is repeated for seeds 0 .. DRAWS-1 (default DRAWS=4).
Blur has no randomness (one run).  A job is skipped when its output file is already complete, so the whole chain can be
stopped and restarted at any time, and the seed-0 files that already exist on the instance are not recomputed.
"""
import argparse, json, os, shlex, subprocess, sys, time, shutil

HERE = os.path.dirname(os.path.abspath(__file__)); ROOT = os.path.dirname(HERE)
GPU = os.path.join(ROOT, "gpu"); EXEC = os.path.join(ROOT, "executed"); LOGS = os.path.join(ROOT, "logs")
VI = os.environ.get("VI", "/home/ec2-user/SageMaker/vlm_internals")
DATA = os.environ.get("PAPER_DATA_DIR", os.path.join(ROOT, "data"))
DRAWS = int(os.environ.get("DRAWS", "4"))
OUTROOT = os.path.join(VI, "generations", "medgemma")
DS = ["aptos", "ham", "vqarad"]
CSVDIR = {"aptos": "aptos", "ham": "ham10000", "vqarad": "vqarad"}
CAPPED = {("aptos", "noise"): "aptos_degradation_results.json", ("aptos", "blur"): "aptos_blur_degradation_results.json",
          ("ham", "noise"): "ham_degradation_results.json", ("ham", "blur"): "ham_blur_degradation_results.json",
          ("vqarad", "noise"): "vqarad_degradation_64cap_results.json", ("vqarad", "blur"): "vqarad_blur_degradation_64cap_results.json"}
S_STAR = {("aptos", "noise"): 4, ("aptos", "blur"): 7, ("vqarad", "noise"): 8, ("vqarad", "blur"): 7}   # paper s* (probes)
SEEDS = list(range(DRAWS))
SEV_LITE = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 12, 14]    # LITE=1: 13 of 15 severities for the repeat draws (s* ranges 3 to 8, all kept)
LITE = os.environ.get("LITE", "0") == "1"

_n_items = {}
def n_items(ds):
    if ds not in _n_items:
        rows = json.load(open(os.path.join(DATA, CAPPED[(ds, "noise")])))
        _n_items[ds] = len({r["row_id"] for r in rows if r["severity"] == 0})
    return _n_items[ds]

def sweep_tag(mod, perm, seed, at):
    return f"{mod}_{perm}" + (f"_seed{seed}" if mod == "noise" else "") + f"_{at}"

def sweep_job(ds, mod, perm="identity", seed=0, at="native", lite=False):
    tag = sweep_tag(mod, perm, seed, at)
    sevs = SEV_LITE if (lite and LITE) else list(range(15))
    p = dict(MODALITY=mod, PERM=perm, NOISE_SEED=seed, DEGRADE_AT=at)
    if sevs != list(range(15)): p["SEVERITIES"] = sevs
    out = os.path.join(OUTROOT, CSVDIR[ds], "review", f"{ds}_{tag}.json")
    return dict(nb=f"medgemma_{ds}_review_sweep.ipynb", params=p, name=f"sweep_{ds}_{tag}", out=out, expect=n_items(ds) * len(sevs), kind="sweep")

def probe_job(ds, seed):
    ss = S_STAR[(ds, "noise")]
    out = os.path.join(OUTROOT, CSVDIR[ds], "review", "probe_acts", f"{ds}_noise_seed{seed}_native_s{ss}_meta.json")
    return dict(nb=f"medgemma_{ds}_probe_activations.ipynb", params=dict(MODALITY="noise", S_STAR=ss, NOISE_SEED=seed, DEGRADE_AT="native"),
                name=f"probeacts_{ds}_noise_seed{seed}", out=out, expect=None, kind="file")

def lang_job(ds, seed):
    d = CSVDIR[ds]
    out = os.path.join(OUTROOT, d, "lang_forced_v2_results.json" if seed == 0 else f"lang_forced_v2_seed{seed}_results.json")
    nb = f"lang/medgemma_{ds}_lang_v2.ipynb"
    expect = {"aptos": 256, "ham": 346}[ds] * 7 * 4        # items x (3+3+1 attack levels) x 4 protection configurations
    return dict(nb=nb, params={}, env=dict(LANG_SEED=str(seed)), name=f"langv2_{ds}_seed{seed}", out=out, expect=expect, kind="sweep")

def val_job(fam, ds, perm):
    out = os.path.join(VI, "generations", fam, CSVDIR[ds], "review", f"{fam}_{ds}_readout_validation_{perm}.json")
    return dict(nb=f"validation/{fam}_{ds}_readout_validation.ipynb", params=dict(PERM=perm), name=f"val_{fam}_{ds}_{perm}", out=None, expect=None, kind="always")

def stages():
    S = {}
    S["smoke"] = [dict(sweep_job(ds, "blur", "rotate"), params=dict(MODALITY="blur", PERM="rotate", MAX_ITEMS=20, SEVERITIES=[0, 5, 14],
                  OUT_DIR=os.path.join(OUTROOT, CSVDIR[ds], "review_smoke")), name=f"smoke_{ds}_rotate_blur", out=None, kind="always") for ds in DS]
    # priority order: the main experiment first, so a partial run is still useful
    S["seeds_identity"]   = [sweep_job(ds, "noise", "identity", s, "native") for s in SEEDS for ds in DS]
    S["probe_seeds"]      = [probe_job(ds, s) for s in SEEDS for ds in ("aptos", "vqarad")]
    S["seeds_reverse"]    = [sweep_job(ds, "noise", "reverse", s, "native", lite=True) for s in SEEDS for ds in DS]
    S["seeds_resolution"] = [sweep_job(ds, "noise", "identity", s, "model_input", lite=True) for s in SEEDS for ds in DS]
    S["rotate"]           = [sweep_job(ds, "blur", "rotate", 0, "native", lite=True) for ds in DS] + \
                            [sweep_job(ds, "noise", "rotate", s, "native", lite=True) for s in SEEDS for ds in DS]
    S["lang_seeds"]       = [lang_job(ds, s) for s in SEEDS for ds in ("aptos", "ham")]
    S["validation"]       = [val_job(f, ds, p) for f in ("llava", "ovis", "medgemma") for ds in DS for p in ("identity", "reverse")]
    return S

def is_done(j):
    if j["kind"] == "always" or not j.get("out"): return False
    if not os.path.exists(j["out"]): return False
    if j["kind"] == "file": return True
    try:
        n = len(json.load(open(j["out"])))
    except Exception:
        return False
    return n >= j["expect"]

def spr():
    """seconds per forward pass: measured by the smoke jobs when available, else 0.3"""
    best = []
    for ds in DS:
        f = os.path.join(OUTROOT, CSVDIR[ds], "review_smoke", f"{ds}_blur_rotate_native.json.timing.json")
        if os.path.exists(f):
            try: best.append(json.load(open(f))["sec_per_row"])
            except Exception: pass
    return (sum(best) / len(best)) if best else 0.3

def estimate(S, parallel):
    t = spr(); speed = {1: 1.0, 2: 1.6, 3: 2.0}.get(parallel, 1.6)
    print(f"seconds per forward pass: {t:.2f} ({'measured by smoke' if t != 0.3 else 'assumed'}), parallel streams: {parallel} (assumed speed-up x{speed})")
    tot = 0.0
    for k, js in S.items():
        rows = 0
        for j in js:
            if is_done(j) or j["kind"] == "always": continue
            if j["kind"] == "sweep":
                have = 0
                if os.path.exists(j["out"]):
                    try: have = len(json.load(open(j["out"])))
                    except Exception: pass
                rows += max(0, j["expect"] - have)
            elif j["nb"].endswith("probe_activations.ipynb"): rows += 2 * n_items(j["name"].split("_")[1])
        h = rows * t / speed / 3600 + (len([j for j in js if j["kind"] == "always" and not is_done(j)]) * 0.1 if k == "validation" else 0)
        tot += h if k != "smoke" else 0
        print(f"  {k:18s} {rows:7d} forward passes  ~{h:5.1f} h")
    print(f"  total (excluding smoke) ~{tot:.1f} h")

def command(j, kernel):
    params = dict(j["params"])
    if j["nb"].startswith("medgemma_"):
        ds = j["nb"].split("_")[1]
        params.setdefault("PAPER_DATA_DIR", DATA); params.setdefault("BASE", VI)
        params.setdefault("OUT_DIR", os.path.join(OUTROOT, CSVDIR[ds], "review") + ("/probe_acts" if "probe" in j["nb"] else ""))
    y = "\n".join(f"{k}: {json.dumps(v) if isinstance(v, (list, bool)) else v}" for k, v in params.items()) or "{}"
    cmd = ["papermill", os.path.join(GPU, j["nb"]), os.path.join(EXEC, j["name"] + ".ipynb"), "-k", kernel, "-y", y, "--log-output"]
    return cmd

def main():
    S = stages()
    ap = argparse.ArgumentParser()
    ap.add_argument("--stage", nargs="*", default=[]); ap.add_argument("--list", action="store_true"); ap.add_argument("--dry-run", action="store_true"); ap.add_argument("--estimate", action="store_true")
    ap.add_argument("--kernel", default=os.environ.get("KERNEL", "conda_pytorch")); ap.add_argument("--parallel", type=int, default=int(os.environ.get("PARALLEL", "2")))
    a = ap.parse_args()
    if a.estimate:
        estimate(S, a.parallel); return
    if a.list or not a.stage:
        for k, js in S.items():
            todo = sum(not is_done(j) for j in js)
            print(f"{k:18s} {len(js):3d} jobs, {todo:3d} to run")
        return
    os.makedirs(EXEC, exist_ok=True); os.makedirs(LOGS, exist_ok=True)
    if not a.dry_run and shutil.which("papermill") is None: sys.exit("papermill not found")
    for st in a.stage:
        todo = [j for j in S[st] if not is_done(j)]
        print(f"== stage {st}: {len(S[st]) - len(todo)} done, {len(todo)} to run (parallel {a.parallel})", flush=True)
        running = []                                                    # (Popen, job, t0)
        def reap(block):
            for pr in list(running):
                if pr[0].poll() is not None or (block and pr[0].wait() is not None):
                    running.remove(pr); dt = time.time() - pr[2]; ok = pr[0].returncode == 0
                    with open(os.path.join(EXEC, "timing.tsv"), "a") as f: f.write(f"{time.strftime('%F %T')}\t{st}\t{pr[1]['name']}\t{dt:.0f}s\t{'ok' if ok else 'FAILED'}\n")
                    print(f"   {'ok    ' if ok else 'FAILED'} {pr[1]['name']} ({dt/60:.1f} min)", flush=True)
                    return True
            return False
        for j in todo:
            cmd = command(j, a.kernel)
            print(("DRY  " if a.dry_run else "RUN  ") + j["name"], flush=True)
            if a.dry_run: print("     " + " ".join(shlex.quote(c) for c in cmd[:5])); continue
            while len(running) >= a.parallel:
                if not reap(False): time.sleep(5)
            env = dict(os.environ, **j.get("env", {}))
            log = open(os.path.join(LOGS, j["name"] + ".log"), "w")
            running.append((subprocess.Popen(cmd, env=env, stdout=log, stderr=subprocess.STDOUT), j, time.time()))
            time.sleep(float(os.environ.get("STAGGER", "20")))                                              # stagger model loads
        while running:
            if not reap(False): time.sleep(5)
if __name__ == "__main__":
    main()
