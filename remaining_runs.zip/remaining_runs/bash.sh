#!/usr/bin/env bash
# Chain for all remaining runs.  Standardised noise draws: seeds 0 to DRAWS-1 (default 4) for every experiment that uses noise.
#
#   export HF_TOKEN=<your token>          (type it in the terminal; it is never written to a file)
#   nohup bash bash.sh > chain.log 2>&1 &
#   tail -f chain.log
#
# Other uses:   bash bash.sh check      only run the pre-flight checks and print the time estimate
#               bash bash.sh analyze    only run the CPU analysis on whatever has finished so far
#               bash bash.sh STAGE      run one stage (seeds_identity, probe_seeds, seeds_reverse, seeds_resolution, rotate, lang_seeds, validation)
# Options (environment variables):  DRAWS=4  PARALLEL=2  LITE=1 (13 of 15 severities for the reverse/resolution/rotate repeats)
#                                   KERNEL=conda_pytorch  VI=/home/ec2-user/SageMaker/vlm_internals  SKIP_VALIDATION=1  SKIP_LANG=1
# Safe to stop (kill, close browser) and start again: finished outputs are skipped and every sweep resumes from its checkpoint.
set -uo pipefail
cd "$(dirname "$0")"
MODE="${1:-all}"
export DRAWS="${DRAWS:-4}" PARALLEL="${PARALLEL:-2}"
export VI="${VI:-/home/ec2-user/SageMaker/vlm_internals}"
export PAPER_DATA_DIR="${PAPER_DATA_DIR:-$PWD/data}"
KERNEL="${KERNEL:-conda_pytorch}"
ts() { date '+%F %T'; }
say() { echo "[$(ts)] $@"; }

# ---------------------------------------------------------------- environment
if ! jupyter kernelspec list 2>/dev/null | grep -qw "$KERNEL"; then
  alt=$(jupyter kernelspec list 2>/dev/null | grep -i pytorch | head -1 | awk '{print $1}')
  [ -n "$alt" ] && { say "kernel $KERNEL not found, using $alt"; KERNEL="$alt"; } || { echo "no pytorch kernel found: run 'jupyter kernelspec list' and rerun with KERNEL=<name>"; exit 1; }
fi
export KERNEL
KPY=$(python3 drivers/kernel_python.py "$KERNEL")          # python that the kernel runs (SageMaker conda kernels)
say "kernel $KERNEL ; python prefix: $KPY"
bash -c "$KPY -m pip install -q papermill scikit-learn pandas matplotlib nltk" 2>&1 | tail -2
pip install -q papermill 2>&1 | tail -1

pre() {
  local bad=0
  [ -n "${HF_TOKEN:-}" ] || { echo "  MISSING  HF_TOKEN (run: export HF_TOKEN=<your token>)"; bad=1; }
  nvidia-smi --query-gpu=name,memory.total --format=csv,noheader 2>/dev/null || { echo "  MISSING  GPU"; bad=1; }
  for d in aptos ham10000 vqarad; do [ -f "$VI/datasets/formatted/$d/main.csv" ] || { echo "  MISSING  $VI/datasets/formatted/$d/main.csv (if your vlm_internals is elsewhere: VI=/path bash bash.sh)"; bad=1; }; done
  [ -f "$PAPER_DATA_DIR/aptos_degradation_results.json" ] || { echo "  MISSING  capped JSONs in $PAPER_DATA_DIR"; bad=1; }
  [ -f "$VI/generations/medgemma/aptos/prefilter_results.json" ] || echo "  note: $VI/generations/medgemma/aptos/prefilter_results.json not found (needed by the language stage)"
  df -h "$VI" | tail -1
  echo "  disk needed: about 3 GB (probe activations are float32)"
  return $bad
}
say "pre-flight"; pre || { echo "PREFLIGHT FAILED"; exit 1; }
mkdir -p executed logs results_draws
python3 drivers/py2ipynb.py cpu/R5_draws_and_orders.py cpu/R5_draws_and_orders.ipynb

analyze() {
  say "CPU analysis R5 (draws, orders, resolution, language, probes)"
  papermill cpu/R5_draws_and_orders.ipynb executed/R5.ipynb -k "$KERNEL" \
    -p DATA_DIR "$PAPER_DATA_DIR" -p REVIEW_BASE "$VI/generations/medgemma" -p OUT_DIR results_draws -p EXPECTED_DRAWS "$DRAWS" 2>&1 | tail -3
  ls results_draws
}

probes_cpu() {      # nested-CV probes for the new noise seeds, CPU only; output goes to results_draws so older results are not overwritten
  for d in aptos vqarad; do
    ACT="$VI/generations/medgemma/$d/review/probe_acts"
    TAGS=""
    for f in $(ls "$ACT" 2>/dev/null | grep -E "^${d}_noise_seed[0-9]+_native_s[0-9]+_meta[.]json$" | sort); do
      t=$(basename "$f" _meta.json); sd=$(echo "$t" | sed -E 's/^.+_seed([0-9]+)_.+$/\1/')
      [ "$sd" = "0" ] && continue                                  # seed 0 was analysed before
      [ -f "results_draws/.r2_done_$t" ] && continue
      TAGS="$TAGS \"$t\","
    done
    [ -z "$TAGS" ] && continue
    say "R2 nested-CV probes ($d)"
    papermill cpu/R2_probe_nested_cv.ipynb "executed/R2_draws_$d.ipynb" -k "$KERNEL" -p ACT_DIR "$ACT" -p OUT_DIR results_draws -p N_SHUFFLE 1 -y "TAGS: [${TAGS%,}]" > "logs/R2_draws_$d.log" 2>&1 \
      && for t in $(echo "$TAGS" | tr -d '",'); do touch "results_draws/.r2_done_$t"; done
  done
}

stage() { say "stage $1"; python3 drivers/run_remaining.py --stage "$1" --parallel "$PARALLEL"; }

pack() {
  rm -f results_to_send_back.zip
  zip -qr results_to_send_back.zip results_draws executed/timing.tsv executed chain.log 2>/dev/null
  say "results_to_send_back.zip written ($(du -h results_to_send_back.zip | cut -f1)); download it from the file browser"
}

case "$MODE" in
  check)   python3 drivers/run_remaining.py --list; python3 drivers/run_remaining.py --estimate --parallel "$PARALLEL"; exit 0 ;;
  analyze) probes_cpu; analyze; pack; exit 0 ;;
  all) ;;
  *)       stage "$MODE"; probes_cpu; analyze; exit 0 ;;
esac

python3 drivers/run_remaining.py --list
python3 drivers/run_remaining.py --estimate --parallel "$PARALLEL"

say "1/8 smoke test (rotated option order, 20 items, 3 severities)"
python3 drivers/run_remaining.py --stage smoke --parallel 1
if grep -q FAILED executed/timing.tsv 2>/dev/null; then echo "SMOKE FAILED: see the logs folder and the notebooks in the executed folder (red cell). Fix, then rerun. Set FORCE=1 to continue anyway."; [ "${FORCE:-0}" = "1" ] || exit 1; fi
python3 drivers/run_remaining.py --estimate --parallel "$PARALLEL"

say "2/8 main experiment: noise draws, original option order"; stage seeds_identity
say "3/8 probes: noise draws";                                  stage probe_seeds; ( probes_cpu ) &
say "4/8 reversed option order: noise draws";                   stage seeds_reverse
say "5/8 model-input resolution: noise draws";                  stage seeds_resolution
say "6/8 rotated option order (second alternative order)";      stage rotate
if [ "${SKIP_LANG:-0}" != "1" ]; then say "7/8 language mutation draws"; stage lang_seeds; else say "7/8 language draws skipped"; fi
wait; probes_cpu; analyze
if [ "${SKIP_VALIDATION:-0}" != "1" ]; then
  say "8/8 readout validation, rerun (LAST: the Ovis notebooks pip-install transformers==4.51.3 into this environment)"
  stage validation
  say "restoring transformers"; bash -c "$KPY -m pip install -q -U transformers" 2>&1 | tail -1
else say "8/8 validation skipped"; fi
analyze; pack
say "all done"; cat executed/timing.tsv
