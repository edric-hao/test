# %% [markdown]
# # R5: noise-draw repeats, option orders, resolution, language draws, probe draws (CPU only)
#
# Collects every sweep written by the remaining-runs chain and reports, for each experiment, the spread **across noise draws**
# (seeds 0 to DRAWS-1; blur is deterministic and appears once). It answers the reviewer requests for an error margin on the noise results (fY3U, H84i)
# and extends the option-order analysis (cX8q #3) from one alternative order to two (reversed and rotated).
#
# s* uses the paper's rule: first severity where the share of confident-correct items (answered, H < tau, correct) is at or below p_max of the evaluated sample.
# The reference sample, p_max and tau are those of the submitted paper; nothing here changes them.

# %% tags=["parameters"]
DATA_DIR = "/home/ec2-user/SageMaker/data"
REVIEW_BASE = "/home/ec2-user/SageMaker/vlm_internals/generations/medgemma"     # <dir>/review/<ds>_<tag>.json
R2_DIRS = ["results", "results_draws"]                                         # folders holding R2_probe_nested_cv_*.csv
OUT_DIR = "results_draws"
TAU = 0.30
EXPECTED_DRAWS = 4

# %%
import os, re, json, glob, csv, collections
import numpy as np
os.makedirs(OUT_DIR, exist_ok=True)
PAPER = {("APTOS", "noise"): "aptos_degradation_results.json", ("APTOS", "blur"): "aptos_blur_degradation_results.json",
         ("HAM", "noise"): "ham_degradation_results.json", ("HAM", "blur"): "ham_blur_degradation_results.json",
         ("VQA", "noise"): "vqarad_degradation_64cap_results.json", ("VQA", "blur"): "vqarad_blur_degradation_64cap_results.json"}
PREFIX = {"aptos": "APTOS", "ham": "HAM", "vqarad": "VQA"}
IDK = {"APTOS": "F", "HAM": "H", "VQA": "C"}
PAIRS = list(PAPER)

def group(rows, ds):
    g = collections.defaultdict(dict)
    for r in rows:
        r = dict(r); r["abstained"] = bool(r.get("abstained")) or r["pred_letter"] == IDK[ds]       # canonical-letter abstention (HAM override fix)
        g[r["row_id"]][r["severity"]] = r
    return g

def nat_correct(r): return (not r["abstained"]) and r["pred_letter"] == r["answer"]
def bc_state(r):    return (not r["abstained"]) and r["entropy"] < TAU and r["pred_letter"] == r["answer"]
def curve(g, fn):
    sevs = sorted({s for v in g.values() for s in v})
    return {s: float(np.mean([fn(v[s]) for v in g.values() if s in v])) for s in sevs}
def sstar(cur, ref):
    for s in sorted(cur):
        if cur[s] <= ref + 1e-12: return s
    return None
def pmax_of(g):
    c = collections.Counter(v[0]["answer"] for v in g.values() if 0 in v); return max(c.values()) / sum(c.values())
def rows_at(g, s): return [v[s] for v in g.values() if s in v]
def frac(g, s, fn):
    r = rows_at(g, s); return float(np.mean([fn(x) for x in r])) if r else float("nan")
def write_csv(name, rows):
    if not rows: print("   (no rows for", name, ")"); return
    keys = []
    for r in rows:
        for k in r:
            if k not in keys: keys.append(k)
    with open(os.path.join(OUT_DIR, name), "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=keys); w.writeheader(); w.writerows(rows)
    print("wrote", name, len(rows), "rows")
def ms(x):
    x = [v for v in x if v is not None and not (isinstance(v, float) and np.isnan(v))]
    if not x: return dict(mean=None, sd=None, min=None, max=None)
    return dict(mean=round(float(np.mean(x)), 2), sd=round(float(np.std(x, ddof=1)), 2) if len(x) > 1 else 0.0, min=round(float(np.min(x)), 2), max=round(float(np.max(x)), 2))

paper = {k: group(json.load(open(os.path.join(DATA_DIR, f))), k[0]) for k, f in PAPER.items()}
PM = {k: pmax_of(g) for k, g in paper.items()}
S_PAPER = {k: sstar(curve(g, bc_state), PM[k]) for k, g in paper.items()}
print("paper s*:", S_PAPER)

# %% [markdown]
# ## 1. Discover the sweeps

# %%
PAT = re.compile(r"^(aptos|ham|vqarad)_(noise|blur)_(identity|reverse|rotate|idk_first)(?:_seed(\d+))?_(native|model_input)\.json$")
RUNS = {}        # (pair, perm, at, seed) -> grouped rows
for p in sorted(glob.glob(os.path.join(REVIEW_BASE, "*", "review", "*.json"))):
    m = PAT.match(os.path.basename(p))
    if not m: continue
    ds, mod, perm, seed, at = m.groups(); pair = (PREFIX[ds], mod)
    g = group(json.load(open(p)), PREFIX[ds])
    sevs = {s for v in g.values() for s in v}
    n_expected = len(paper[pair])
    if len(g) < 0.98 * n_expected or len(sevs) < 10:
        print("   skipping incomplete", os.path.basename(p), len(g), "items", len(sevs), "severities"); continue
    RUNS[(pair, perm, at, int(seed) if seed is not None else 0)] = g
cfgs = sorted({(k[1], k[2]) for k in RUNS}, key=str)
print("configurations found:", cfgs)
for c in cfgs:
    print('  ', c, {f'{k[0][0]}-{k[0][1]}': sorted(x[3] for x in RUNS if x[0] == k[0] and x[1:3] == c) for k in RUNS if k[1:3] == c and k[3] == 0})

# %% [markdown]
# ## 2. Per-draw metrics and the spread across draws

# %%
def metrics(pair, g):
    common = set(g) & set(paper[pair]); g = {i: g[i] for i in common}; gp = {i: paper[pair][i] for i in common}
    cur = curve(g, bc_state); sp = S_PAPER[pair]; so = sstar(cur, PM[pair])
    out = dict(n_items=len(common), p_max=round(PM[pair], 3), bc_share_s0=round(cur.get(0, float("nan")), 3), s_star_own=so, s_star_paper=sp)
    out["mirage_at_own_s*_%"] = round(100 * frac(g, so, lambda r: not r["abstained"]), 1) if so is not None else None
    if sp is not None:
        out["mirage_at_paper_s*_%"] = round(100 * frac(g, sp, lambda r: not r["abstained"]), 1)
        out["wrong_commit_at_paper_s*_%"] = round(100 * frac(g, sp, lambda r: (not r["abstained"]) and r["pred_letter"] != r["answer"]), 1)
        out["confident_wrong_at_paper_s*_%"] = round(100 * frac(g, sp, lambda r: (not r["abstained"]) and r["entropy"] < TAU and r["pred_letter"] != r["answer"]), 1)
    out["blackout_abstain_%"] = round(100 * frac(g, 14, lambda r: r["abstained"]), 1)
    return out, cur

per_draw, curves = [], {}
for (pair, perm, at, seed), g in sorted(RUNS.items(), key=str):
    m, cur = metrics(pair, g)
    per_draw.append({"pair": f"{pair[0]}-{pair[1]}", "order": perm, "degrade_at": at, "seed": seed if pair[1] == "noise" else "-", **m})
    curves[(pair, perm, at, seed)] = cur
for pair in PAIRS:                                       # the submitted run, for reference
    m, cur = metrics(pair, paper[pair])
    per_draw.append({"pair": f"{pair[0]}-{pair[1]}", "order": "identity (submitted run)", "degrade_at": "native", "seed": "submitted", **m})
write_csv("R5_per_draw_metrics.csv", per_draw)

agg = []
by = collections.defaultdict(list)
for r in per_draw:
    if r["seed"] == "submitted": continue
    by[(r["pair"], r["order"], r["degrade_at"])].append(r)
for (pair, perm, at), rs in sorted(by.items()):
    sv = [r["s_star_own"] for r in rs if r["s_star_own"] is not None]
    mode = collections.Counter(sv).most_common(1)[0] if sv else (None, 0)
    row = {"pair": pair, "order": perm, "degrade_at": at, "n_draws": len(rs), "draws_expected": EXPECTED_DRAWS if pair.endswith("noise") else 1,
           "s_star_values": sorted(sv), "s_star_modal": mode[0], "share_draws_at_modal_s*_%": round(100 * mode[1] / max(1, len(sv)), 0),
           "s_star_min": min(sv) if sv else None, "s_star_max": max(sv) if sv else None}
    for key in ("bc_share_s0", "mirage_at_own_s*_%", "mirage_at_paper_s*_%", "wrong_commit_at_paper_s*_%", "confident_wrong_at_paper_s*_%", "blackout_abstain_%"):
        for stat, v in ms([r.get(key) for r in rs]).items(): row[f"{key}_{stat}"] = v
    agg.append(row)
write_csv("R5_draw_aggregate.csv", agg)
for r in agg:
    print(f"{r['pair']:12s} {r['order']:9s} {r['degrade_at']:12s} draws={r['n_draws']} s*={r['s_star_values']} mirage@own {r['mirage_at_own_s*_%_mean']}±{r['mirage_at_own_s*_%_sd']} (min {r['mirage_at_own_s*_%_min']}, max {r['mirage_at_own_s*_%_max']})")

# %% [markdown]
# ## 3. Does the answer change between noise draws?  Row-level agreement across draws (severities at and beyond the paper's s*)

# %%
agree = []
for pair in PAIRS:
    if pair[1] != "noise": continue
    for perm in sorted({k[1] for k in RUNS}):
        for at in sorted({k[2] for k in RUNS}):
            gs = [RUNS[k] for k in sorted(RUNS, key=str) if k[0] == pair and k[1] == perm and k[2] == at]
            if len(gs) < 2: continue
            sp = S_PAPER[pair]; sevs = [s for s in range(15) if sp is not None and s >= sp and s < 14]
            cls, abst = [], []
            for rid in set.intersection(*[set(g) for g in gs]):
                for s in sevs:
                    if all(s in g[rid] for g in gs):
                        cls.append(len({g[rid][s]["pred_letter"] for g in gs}) == 1); abst.append(len({g[rid][s]["abstained"] for g in gs}) == 1)
            agree.append({"pair": f"{pair[0]}-{pair[1]}", "order": perm, "degrade_at": at, "n_draws": len(gs), "cells": len(cls),
                          "same_answer_in_all_draws_%": round(100 * np.mean(cls), 1), "same_abstain_flag_in_all_draws_%": round(100 * np.mean(abst), 1)})
write_csv("R5_row_agreement_across_draws.csv", agree)
for r in agree: print(r)

# %% [markdown]
# ## 4. Option order: does the post-boundary answer follow the class or the displayed letter? (reversed and rotated, noise-seed-matched to the identity order)

# %%
def disp(r): return r.get("pred_letter_displayed", r["pred_letter"])
def lvc(ref, tgt, sevs):
    rr = [v[s] for v in ref.values() for s in sevs if s in v]; rt = [v[s] for v in tgt.values() for s in sevs if s in v]
    if not rr or not rt: return None
    top_cls, n = collections.Counter(r["pred_letter"] for r in rr).most_common(1)[0]
    top_let = collections.Counter(disp(r) for r in rr).most_common(1)[0][0]
    return dict(top_class_ref=top_cls, top_letter_ref=top_let, ref_share=round(100 * n / len(rr), 1),
                same_class_in_target=round(100 * np.mean([r["pred_letter"] == top_cls for r in rt]), 1),
                same_displayed_letter_in_target=round(100 * np.mean([disp(r) == top_let for r in rt]), 1), rows_ref=len(rr), rows_tgt=len(rt))
lv = []
for pair in PAIRS:
    sp = S_PAPER[pair]
    if sp is None: continue
    for perm in ("reverse", "rotate"):
        for window, sevs in (("severity >= paper s*", [s for s in range(15) if s >= sp]), ("blackout (s=14)", [14])):
            res = []
            seeds = sorted({k[3] for k in RUNS if k[0] == pair and k[1] == perm and k[2] == "native"}) if pair[1] == "noise" else [0]
            for sd in seeds:
                tgt = RUNS.get((pair, perm, "native", sd))
                ref = RUNS.get((pair, "identity", "native", sd)) or paper[pair]
                if tgt is None: continue
                common = set(ref) & set(tgt); r = lvc({i: ref[i] for i in common}, {i: tgt[i] for i in common}, sevs)
                if r: res.append(r)
            if not res: continue
            def agg_(k): return ms([x[k] for x in res])
            lv.append({"pair": f"{pair[0]}-{pair[1]}", "order": perm, "window": window, "n_draws": len(res), "reference": "identity, same noise seed" if (pair, "identity", "native", 0) in RUNS else "submitted identity run",
                       "top_class_ref": res[0]["top_class_ref"], "top_letter_ref": res[0]["top_letter_ref"],
                       "ref_share_%_mean": agg_("ref_share")["mean"],
                       "same_class_%_mean": agg_("same_class_in_target")["mean"], "same_class_%_sd": agg_("same_class_in_target")["sd"],
                       "same_letter_%_mean": agg_("same_displayed_letter_in_target")["mean"], "same_letter_%_sd": agg_("same_displayed_letter_in_target")["sd"]})
write_csv("R5_letter_vs_class_by_order.csv", lv)
for r in lv: print(r)

# %% [markdown]
# ## 5. Curves (mean over draws, band = min to max)

# %%
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
STY = {("identity", "native"): ("k", "identity, native"), ("reverse", "native"): ("r", "reversed"), ("rotate", "native"): ("g", "rotated"), ("identity", "model_input"): ("b", "model-input resolution")}
fig, axes = plt.subplots(2, 3, figsize=(13, 6.5), sharey=True)
for i, mod in enumerate(("noise", "blur")):
    for j, ds in enumerate(("APTOS", "HAM", "VQA")):
        ax = axes[i][j]; pair = (ds, mod); ax.set_title(f"{ds} - {mod}")
        cp = curve(paper[pair], bc_state); ax.plot(list(cp), list(cp.values()), "-o", color="gray", ms=2, label="submitted run")
        for (perm, at), (col, lab) in STY.items():
            cs = [curves[k] for k in curves if k[0] == pair and k[1] == perm and k[2] == at]
            if not cs: continue
            sv = sorted(set.intersection(*[set(c) for c in cs])); M = np.array([[c[s] for s in sv] for c in cs])
            ax.plot(sv, M.mean(0), "-", color=col, lw=1.2, label=f"{lab} (n={len(cs)})")
            if len(cs) > 1: ax.fill_between(sv, M.min(0), M.max(0), color=col, alpha=0.2)
        ax.axhline(PM[pair], color="lightgray", lw=0.8); ax.set_xlabel("severity")
axes[0][0].set_ylabel("confident-correct share"); axes[1][0].set_ylabel("confident-correct share"); axes[0][0].legend(fontsize=6)
fig.tight_layout(); fig.savefig(os.path.join(OUT_DIR, "R5_curves_draws.png"), dpi=170)

# %% [markdown]
# ## 6. Language mutation draws (seed 0 = the v2 run, seeds 1 to 3 = new draws)

# %%
LANG = {"APTOS": "aptos", "HAM": "ham10000"}; lang_rows = []
for ds, d in LANG.items():
    files = sorted(glob.glob(os.path.join(REVIEW_BASE, d, "lang_forced_v2*_results.json")))
    per_seed = {}
    for p in files:
        m = re.search(r"_seed(\d+)_results", os.path.basename(p)); sd = int(m.group(1)) if m else 0
        rows = json.load(open(p))
        if len(rows) < 0.98 * (256 if ds == "APTOS" else 346) * 28: print("   skipping incomplete", os.path.basename(p), len(rows)); continue
        acc = collections.defaultdict(list)
        for r in rows: acc[(r["attack_type"], r["config"], r["severity"])].append(bool(r["correct"]))
        per_seed[sd] = {k: 100 * np.mean(v) for k, v in acc.items()}
    for k in sorted({k for v in per_seed.values() for k in v}):
        vals = [per_seed[s][k] for s in sorted(per_seed) if k in per_seed[s]]
        lang_rows.append({"dataset": ds, "attack": k[0], "config": k[1], "severity": k[2], "n_draws": len(vals), **{f"acc_{a}": b for a, b in ms(vals).items()}, "range": round(max(vals) - min(vals), 1)})
write_csv("R5_language_draws.csv", lang_rows)
if lang_rows:
    print("largest between-draw range per dataset:", {ds: max(r["range"] for r in lang_rows if r["dataset"] == ds) for ds in LANG if any(r["dataset"] == ds for r in lang_rows)})

# %% [markdown]
# ## 7. Probe draws (nested-CV AUROC, noise seeds)

# %%
probe_rows, seen = [], set()
for d in R2_DIRS:
    for p in sorted(glob.glob(os.path.join(d, "R2_probe_nested_cv_*.csv"))):
        for r in csv.DictReader(open(p)):
            probe_rows.append(r)
uniq = {}
for r in probe_rows: uniq[(r["tag"], r["activations_from"], r["position"])] = r
grp = collections.defaultdict(list)
for (tag, cond, pos), r in uniq.items():
    m = re.match(r"^(aptos|vqarad)_(noise|blur)_seed(\d+)_", tag)
    if m: grp[(m.group(1), m.group(2), cond, pos)].append((int(m.group(3)), float(r["nested_auroc"]), float(r["class_only_baseline"]), int(r["n_commit"]), int(r["n_abstain"])))
pr = []
for (ds, mod, cond, pos), v in sorted(grp.items()):
    a = ms([x[1] for x in v]); b = ms([x[2] for x in v])
    pr.append({"dataset": ds, "modality": mod, "activations_from": cond, "position": pos, "n_draws": len(v), "seeds": sorted(x[0] for x in v),
               **{f"nested_auroc_{k}": x for k, x in a.items()}, "class_only_mean": b["mean"], "n_commit_range": f"{min(x[3] for x in v)}-{max(x[3] for x in v)}", "n_abstain_range": f"{min(x[4] for x in v)}-{max(x[4] for x in v)}"})
write_csv("R5_probe_draws.csv", pr)

# %%
json.dump({"paper_s_star": {f"{k[0]}-{k[1]}": v for k, v in S_PAPER.items()}, "aggregate": agg, "agreement": agree, "letter_vs_class": lv}, open(os.path.join(OUT_DIR, "R5_numbers.json"), "w"), indent=1, default=str)
print("Done. Outputs in", os.path.abspath(OUT_DIR))
