# %% [markdown]
# # R2 — Probe re-analysis with nested CV, several token positions, and clean-input prediction (CPU only)
#
# Consumes the files written by `gpu/medgemma_{aptos,vqarad}_probe_activations.ipynb`:
# `{tag}_acts_clean.npy`, `{tag}_acts_sstar.npy` (float16, shape [N, layers, positions, d]) and `{tag}_meta.json`.
#
# What this answers (reviewer cX8q #4, fY3U):
# * the layer is chosen **inside** the training folds (nested CV) instead of on the reported AUROC;
# * the probe is fit at several positions (last image token / last question token / last prompt token / **readout** token);
#   the readout position is the by-construction upper bound, earlier positions are the informative ones;
# * "eventual" is tested directly: do **clean-input (s=0)** activations predict commit-vs-abstain at s*?
# * class-only baseline and a label-shuffle sanity check are reported next to every number.

# %% tags=["parameters"]
ACT_DIR = "../results/probe_acts"   # folder written by the GPU notebooks
OUT_DIR = "../results"
TAGS = []                           # [] = auto-discover every *_meta.json in ACT_DIR
N_OUTER = 5
N_INNER = 3
N_REPEATS = 1                       # repeats of the outer CV (raise for tighter intervals; cost scales linearly)
N_SHUFFLE = 3                       # label-shuffle sanity runs per (condition, position)
C_REG = 1.0
SEED = 0

# %%
import os, json, glob, collections, csv, warnings
import numpy as np
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import StratifiedKFold, cross_val_score
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import Pipeline
from sklearn.metrics import roc_auc_score
warnings.filterwarnings("ignore")
os.makedirs(OUT_DIR, exist_ok=True)

def make_pipe():
    return Pipeline([("sc", StandardScaler()), ("lr", LogisticRegression(C=C_REG, class_weight="balanced", max_iter=500))])

def nested_auc(X, y, seed):
    """X: [N, L, d].  Layer is chosen by inner CV on the outer-training fold only."""
    N, L, _ = X.shape
    outer = StratifiedKFold(N_OUTER, shuffle=True, random_state=seed)
    aucs, chosen = [], []
    for tr, te in outer.split(np.zeros(N), y):
        inner = StratifiedKFold(N_INNER, shuffle=True, random_state=seed + 1)
        scores = [cross_val_score(make_pipe(), X[tr][:, l], y[tr], cv=inner, scoring="roc_auc").mean() for l in range(L)]
        l_star = int(np.argmax(scores)); chosen.append(l_star)
        pipe = make_pipe().fit(X[tr][:, l_star], y[tr])
        aucs.append(roc_auc_score(y[te], pipe.predict_proba(X[te][:, l_star])[:, 1]))
    return float(np.mean(aucs)), float(np.std(aucs)), chosen

def best_layer_unnested(X, y, seed):
    N, L, _ = X.shape
    cv = StratifiedKFold(N_OUTER, shuffle=True, random_state=seed)
    s = [cross_val_score(make_pipe(), X[:, l], y, cv=cv, scoring="roc_auc").mean() for l in range(L)]
    return int(np.argmax(s)), float(np.max(s)), [float(v) for v in s]

def class_only_auc(answers, y, seed):
    cls = sorted(set(answers)); X = np.array([[a == c for c in cls] for a in answers], dtype=float)
    cv = StratifiedKFold(N_OUTER, shuffle=True, random_state=seed)
    return float(cross_val_score(LogisticRegression(class_weight="balanced", max_iter=500), X, y, cv=cv, scoring="roc_auc").mean())

tags = TAGS or sorted(os.path.basename(p)[:-10] for p in glob.glob(os.path.join(ACT_DIR, "*_meta.json")))
print("tags:", tags)
rows, curves = [], {}
for tag in tags:
    meta = json.load(open(os.path.join(ACT_DIR, f"{tag}_meta.json")))
    acts = {c: np.load(os.path.join(ACT_DIR, f"{tag}_acts_{c}.npy"), mmap_mode="r") for c in ("clean", "sstar")}
    pos_names = meta["pos_names"]
    committed = np.array([0 if a else 1 for a in meta["sstar"]["abstained"]])
    answers = meta["answers"]
    print(f"\n== {tag}: N={len(committed)} commit={committed.sum()} abstain={(1-committed).sum()}  s*={meta['s_star']}")
    if min(committed.sum(), (1 - committed).sum()) < 10:
        print("   too few items in one class — skipped"); continue
    base = class_only_auc(answers, committed, SEED)
    for cond in ("sstar", "clean"):
        for pi, pn in enumerate(pos_names):
            X = np.asarray(acts[cond][:, :, pi, :], dtype=np.float32)
            finite = np.isfinite(X).all(axis=(0, 1))          # float16 overflow (older runs) or NaN: drop those hidden dimensions
            if not finite.all():
                print(f"   NOTE {cond}/{pn}: dropping {int((~finite).sum())} of {X.shape[2]} non-finite hidden dims")
                X = X[:, :, finite]
            res = [nested_auc(X, committed, SEED + r) for r in range(N_REPEATS)]
            nested = float(np.mean([r_[0] for r_ in res])); sd = float(np.mean([r_[1] for r_ in res]))
            chosen = collections.Counter(l for r_ in res for l in r_[2])
            bl, bl_auc, layer_curve = best_layer_unnested(X, committed, SEED)
            rng = np.random.default_rng(SEED)
            shuf = [nested_auc(X, rng.permutation(committed), SEED)[0] for _ in range(N_SHUFFLE)]
            rows.append({"tag": tag, "activations_from": cond, "position": pn, "n": len(committed), "n_commit": int(committed.sum()), "n_abstain": int((1 - committed).sum()),
                         "nested_auroc": round(nested, 3), "outer_fold_sd": round(sd, 3), "unnested_best_layer": bl, "unnested_best_auroc": round(bl_auc, 3),
                         "optimism_gap": round(bl_auc - nested, 3), "class_only_baseline": round(base, 3), "label_shuffle_mean": round(float(np.mean(shuf)), 3),
                         "layers_chosen": dict(chosen)})
            curves[f"{tag}|{cond}|{pn}"] = layer_curve
            print(f"   {cond:5s} {pn:20s} nested={nested:.3f}±{sd:.3f}  unnested-best(L{bl})={bl_auc:.3f}  class-only={base:.3f}  shuffle={np.mean(shuf):.3f}")

if rows:
    with open(os.path.join(OUT_DIR, "R2_probe_nested_cv_" + "_".join(sorted({t.split("_")[0] for t in tags})) + ".csv"), "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0].keys())); w.writeheader()
        for r in rows: w.writerow({k: (json.dumps(v) if isinstance(v, dict) else v) for k, v in r.items()})
    json.dump(curves, open(os.path.join(OUT_DIR, "R2_probe_layer_curves_" + "_".join(sorted({t.split("_")[0] for t in tags})) + ".json"), "w"))
print("\nDone.")

# %% [markdown]
# ### How to read the table
# * `activations_from = sstar, position = readout_token` — decodes the model's own decision from the state that produces it (expected to be ~1.0; this is the "by construction" ceiling).
# * `activations_from = sstar, position = last_prompt_token / last_question_token / last_image_token` — the paper's probe position and two earlier ones.
# * `activations_from = clean` — activations from the **undegraded** input predicting what the model does at s*: the test that supports (or not) the word "eventual".
# * Compare each `nested_auroc` with `class_only_baseline` and `label_shuffle_mean`; `optimism_gap` is how much the paper-style best-layer-on-the-reported-CV number overstated it.
